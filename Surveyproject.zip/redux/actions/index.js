export {
  resultGetData,
  deleteResult,
  postResultData,
  updateResultData,
  resultEditGetData,
  resultSetData,
  resultEditSetData,
} from "./ResultCreators";
