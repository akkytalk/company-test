"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
/* harmony import */ var _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Data/Data.json */ "./components/Data/Data.json");
/* harmony import */ var _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Data/options.json */ "./components/Data/options.json");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _redux_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../redux/actions */ "./redux/actions/index.js");
/* harmony import */ var react_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-router */ "./node_modules/react-router/esm/react-router.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "E:\\git vinraj\\company-test\\pages\\index.js",
    _s = $RefreshSig$();












var result = new Array();
var MainResult = new Array();

function Home(props) {
  _s();

  var _this = this;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      value = _useState[0],
      setValue = _useState[1];

  var history = (0,react_router__WEBPACK_IMPORTED_MODULE_9__.useHistory)();

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      company = _useState2[0],
      setCompany = _useState2[1];

  console.log("props.result", props.result);
  console.log("value", value);

  var handleSubmit = function handleSubmit(values, setSubmitting) {
    if (props.result) {
      var _props$result;

      (_props$result = props.result) === null || _props$result === void 0 ? void 0 : _props$result.map(function (r) {
        data === null || data === void 0 ? void 0 : data.map(function (d) {
          if (r.question_id == d.question_id) {
            if (d.CDU / CSU == r.answer) {
              console.log("aakash");
            }
          }
        });
      });
    }

    var data = {
      result: result
    };
    console.log(data);
    axios__WEBPACK_IMPORTED_MODULE_0___default().post("/test", data).then(function (res) {
      console.log(res);
      console.log("intial value is submited to results");
      result = [];
      history.push("/thankyou");
    })["catch"](function (err) {
      console.log(err.response.data); // history.push("/exam-appeared");
      // result = [];
    });
  };

  console.log("array", result);
  var dataLength = _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.length;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
    className: "",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("title", {
        children: "Create Next App"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 73,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 72,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Card, {
      className: "p-5 border-2 shadow-md rounded-md",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardBody, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
          initialValues: {
            result: [],
            answer: ""
          },
          onSubmit: function onSubmit(values, setSubmitting) {
            var _props$result2;

            if (((_props$result2 = props.result) === null || _props$result2 === void 0 ? void 0 : _props$result2.length) > 0) {
              var _props$result3, _props$result4, _props$result5;

              console.log("result length", (_props$result3 = props.result) === null || _props$result3 === void 0 ? void 0 : _props$result3.length);
              var resultLength = (_props$result4 = props.result) === null || _props$result4 === void 0 ? void 0 : _props$result4.length;

              for (var i = 0; i < resultLength; i++) {
                console("result map");
              }

              (_props$result5 = props.result) === null || _props$result5 === void 0 ? void 0 : _props$result5.map(function (r) {
                console("result map");
                return data === null || data === void 0 ? void 0 : data.map(function (d) {
                  if (r.question_id == d.id) {
                    console.log("r.question_id", r.question_id, "d.id", d.id);

                    if (d.SPD == r.answer) {
                      console.log("aakash");
                    }
                  }
                });
              });
            }

            var data = {
              result: props.result
            };
            console.log("submit click"); // axios
            //   .post("https://uditsolutions.in/yarn/public/api/scores", data)
            //   .then((res) => {
            //     console.log(res);
            //     console.log("intial value is submited to results");
            //     result = [];
            //     history.push("/thankyou");
            //   })
            //   .catch((err) => {
            //     console.log(err.response.data);
            //     // history.push("/exam-appeared");
            //   });
          },
          children: function children(_ref) {
            var handleSubmit = _ref.handleSubmit;
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Form, {
              onSubmit: handleSubmit,
              children: [_components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === null || _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === void 0 ? void 0 : _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.map(function (d, id) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                  className: "mt-3",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardTitle, {
                    children: [" ", d.id, "/", dataLength]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 127,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardSubtitle, {
                    children: d.Schlagwort
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 131,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardText, {
                    children: d.question_text
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 132,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.FieldArray, {
                    name: "result",
                    render: function render(arrayHelpers) {
                      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Row, {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Col, {
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.FormGroup, {
                              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.InputGroup, {
                                className: "flex flex-col mt-2",
                                children: _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === null || _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === void 0 ? void 0 : _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__.map(function (opt) {
                                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("label", {
                                    className: "p-2 bg-gray-600 text-white rounded-md text-center hover:bg-yellow-300 hover:text-black mb-1",
                                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                                      type: "radio" // name="answer"
                                      ,
                                      value: opt.option_Value,
                                      className: "hidden",
                                      onChange: function onChange() {
                                        setValue({
                                          question_id: d.id,
                                          answer: opt.option_Value
                                        });

                                        if (result.length > 0) {
                                          for (var i = 0; i < result.length; i++) {
                                            var _result$i;

                                            if (((_result$i = result[i]) === null || _result$i === void 0 ? void 0 : _result$i.question_id) == d.id) {
                                              console.log("splice");
                                              result.splice(i, 1, {
                                                question_id: d.id,
                                                answer: opt.option_Value
                                              });
                                              return;
                                            } else if (result[i].question_id !== d.id) {
                                              console.log("else_if question of data", d.id, "result q-id", result[i].question_id);
                                              result.push({
                                                question_id: d.id,
                                                answer: opt.option_Value // value,

                                              });
                                              return;
                                            }
                                          }

                                          props.resultSetData(result);
                                        } else {
                                          console.log("else");
                                          result.push({
                                            question_id: d.id,
                                            answer: opt.option_Value
                                          });
                                          props.resultSetData(result);
                                        }
                                      }
                                    }, void 0, false, {
                                      fileName: _jsxFileName,
                                      lineNumber: 148,
                                      columnNumber: 47
                                    }, _this), opt.option_text]
                                  }, opt.id, true, {
                                    fileName: _jsxFileName,
                                    lineNumber: 144,
                                    columnNumber: 45
                                  }, _this);
                                })
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 141,
                                columnNumber: 39
                              }, _this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 140,
                              columnNumber: 37
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 139,
                            columnNumber: 35
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 138,
                          columnNumber: 33
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 137,
                        columnNumber: 31
                      }, _this);
                    }
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 133,
                    columnNumber: 25
                  }, _this)]
                }, d.id, true, {
                  fileName: _jsxFileName,
                  lineNumber: 126,
                  columnNumber: 23
                }, _this);
              }), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Button, {
                  block: true,
                  className: "border-2 p-2 border-black mt-7",
                  type: "submit" // onClick={handleSubmit}
                  // disabled={formProps.isSubmitting}
                  ,
                  children: "Eegebnis zeigen"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 232,
                  columnNumber: 21
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 231,
                columnNumber: 19
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 123,
              columnNumber: 17
            }, _this);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 78,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 76,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 71,
    columnNumber: 5
  }, this);
}

_s(Home, "+Ok9uqErGU59sIRoYnjvw5OYqYQ=", false, function () {
  return [react_router__WEBPACK_IMPORTED_MODULE_9__.useHistory];
});

_c = Home;

var mapStateToProps = function mapStateToProps(state) {
  return {
    result: state.result.result
  };
};

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    resultSetData: function resultSetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultSetData(data));
    },
    onDeleteResult: function onDeleteResult(data, id) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.deleteResult(data, id));
    },
    onPostResultData: function onPostResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.postResultData(data, user, toggle));
    },
    onUpdateResultData: function onUpdateResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.updateResultData(data, user, toggle));
    },
    resultEditGetData: function resultEditGetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultEditGetData(data));
    }
  };
};

/* harmony default export */ __webpack_exports__["default"] = ((0,react_redux__WEBPACK_IMPORTED_MODULE_6__.connect)(mapStateToProps, mapDispatchToProps)(Home));

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguYTNkMzBlYTI2OWZmY2M4NGEzNjkuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFjQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLElBQUl3QixNQUFNLEdBQUcsSUFBSUMsS0FBSixFQUFiO0FBQ0EsSUFBSUMsVUFBVSxHQUFHLElBQUlELEtBQUosRUFBakI7O0FBQ0EsU0FBU0UsSUFBVCxDQUFjQyxLQUFkLEVBQXFCO0FBQUE7O0FBQUE7O0FBQ25CLGtCQUEwQnRCLCtDQUFRLENBQUMsRUFBRCxDQUFsQztBQUFBLE1BQU91QixLQUFQO0FBQUEsTUFBY0MsUUFBZDs7QUFDQSxNQUFNQyxPQUFPLEdBQUdSLHdEQUFVLEVBQTFCOztBQUVBLG1CQUE4QmpCLCtDQUFRLENBQUMsRUFBRCxDQUF0QztBQUFBLE1BQU8wQixPQUFQO0FBQUEsTUFBZ0JDLFVBQWhCOztBQUVBQyxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBQTRCUCxLQUFLLENBQUNKLE1BQWxDO0FBRUFVLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVosRUFBcUJOLEtBQXJCOztBQUNBLE1BQU1PLFlBQVksR0FBRyxTQUFmQSxZQUFlLENBQUNDLE1BQUQsRUFBU0MsYUFBVCxFQUEyQjtBQUM5QyxRQUFJVixLQUFLLENBQUNKLE1BQVYsRUFBa0I7QUFBQTs7QUFDaEIsdUJBQUFJLEtBQUssQ0FBQ0osTUFBTixnRUFBY2UsR0FBZCxDQUFrQixVQUFDQyxDQUFELEVBQU87QUFDdkJyQixRQUFBQSxJQUFJLFNBQUosSUFBQUEsSUFBSSxXQUFKLFlBQUFBLElBQUksQ0FBRW9CLEdBQU4sQ0FBVSxVQUFDRSxDQUFELEVBQU87QUFDZixjQUFJRCxDQUFDLENBQUNFLFdBQUYsSUFBaUJELENBQUMsQ0FBQ0MsV0FBdkIsRUFBb0M7QUFDbEMsZ0JBQUlELENBQUMsQ0FBQ0UsR0FBRixHQUFRQyxHQUFSLElBQWVKLENBQUMsQ0FBQ0ssTUFBckIsRUFBNkI7QUFDM0JYLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVo7QUFDRDtBQUNGO0FBQ0YsU0FORDtBQU9ELE9BUkQ7QUFTRDs7QUFDRCxRQUFJaEIsSUFBSSxHQUFHO0FBQ1RLLE1BQUFBLE1BQU0sRUFBRUE7QUFEQyxLQUFYO0FBR0FVLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZaEIsSUFBWjtBQUVBbkIsSUFBQUEsaURBQUEsQ0FDUSxPQURSLEVBQ2lCbUIsSUFEakIsRUFFRzRCLElBRkgsQ0FFUSxVQUFDQyxHQUFELEVBQVM7QUFDYmQsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlhLEdBQVo7QUFDQWQsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVkscUNBQVo7QUFDQVgsTUFBQUEsTUFBTSxHQUFHLEVBQVQ7QUFDQU8sTUFBQUEsT0FBTyxDQUFDa0IsSUFBUixDQUFhLFdBQWI7QUFDRCxLQVBILFdBUVMsVUFBQ0MsR0FBRCxFQUFTO0FBQ2RoQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWWUsR0FBRyxDQUFDQyxRQUFKLENBQWFoQyxJQUF6QixFQURjLENBRWQ7QUFDQTtBQUNELEtBWkg7QUFhRCxHQTlCRDs7QUErQkFlLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVosRUFBcUJYLE1BQXJCO0FBQ0EsTUFBTTRCLFVBQVUsR0FBR2pDLDhEQUFuQjtBQUVBLHNCQUNFO0FBQUssYUFBUyxFQUFDLEVBQWY7QUFBQSw0QkFDRSw4REFBQyxrREFBRDtBQUFBLDhCQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFRTtBQUFNLFdBQUcsRUFBQyxNQUFWO0FBQWlCLFlBQUksRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFLRSw4REFBQyw2Q0FBRDtBQUFNLGVBQVMsRUFBQyxtQ0FBaEI7QUFBQSw2QkFDRSw4REFBQyxpREFBRDtBQUFBLCtCQUNFLDhEQUFDLDBDQUFEO0FBQ0UsdUJBQWEsRUFBRTtBQUNiSyxZQUFBQSxNQUFNLEVBQUUsRUFESztBQUVicUIsWUFBQUEsTUFBTSxFQUFFO0FBRkssV0FEakI7QUFLRSxrQkFBUSxFQUFFLGtCQUFDUixNQUFELEVBQVNDLGFBQVQsRUFBMkI7QUFBQTs7QUFDbkMsZ0JBQUksbUJBQUFWLEtBQUssQ0FBQ0osTUFBTixrRUFBYzZCLE1BQWQsSUFBdUIsQ0FBM0IsRUFBOEI7QUFBQTs7QUFDNUJuQixjQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxlQUFaLG9CQUE2QlAsS0FBSyxDQUFDSixNQUFuQyxtREFBNkIsZUFBYzZCLE1BQTNDO0FBQ0Esa0JBQU1DLFlBQVkscUJBQUcxQixLQUFLLENBQUNKLE1BQVQsbURBQUcsZUFBYzZCLE1BQW5DOztBQUNBLG1CQUFLLElBQUlFLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdELFlBQXBCLEVBQWtDQyxDQUFDLEVBQW5DLEVBQXVDO0FBQ3JDckIsZ0JBQUFBLE9BQU8sQ0FBQyxZQUFELENBQVA7QUFDRDs7QUFDRCxnQ0FBQU4sS0FBSyxDQUFDSixNQUFOLGtFQUFjZSxHQUFkLENBQWtCLFVBQUNDLENBQUQsRUFBTztBQUN2Qk4sZ0JBQUFBLE9BQU8sQ0FBQyxZQUFELENBQVA7QUFDQSx1QkFBT2YsSUFBUCxhQUFPQSxJQUFQLHVCQUFPQSxJQUFJLENBQUVvQixHQUFOLENBQVUsVUFBQ0UsQ0FBRCxFQUFPO0FBQ3RCLHNCQUFJRCxDQUFDLENBQUNFLFdBQUYsSUFBaUJELENBQUMsQ0FBQ2UsRUFBdkIsRUFBMkI7QUFDekJ0QixvQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksZUFBWixFQUE2QkssQ0FBQyxDQUFDRSxXQUEvQixFQUE0QyxNQUE1QyxFQUFvREQsQ0FBQyxDQUFDZSxFQUF0RDs7QUFDQSx3QkFBSWYsQ0FBQyxDQUFDZ0IsR0FBRixJQUFTakIsQ0FBQyxDQUFDSyxNQUFmLEVBQXVCO0FBQ3JCWCxzQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWjtBQUNEO0FBQ0Y7QUFDRixpQkFQTSxDQUFQO0FBUUQsZUFWRDtBQVdEOztBQUNELGdCQUFJaEIsSUFBSSxHQUFHO0FBQ1RLLGNBQUFBLE1BQU0sRUFBRUksS0FBSyxDQUFDSjtBQURMLGFBQVg7QUFHQVUsWUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQXRCbUMsQ0F1Qm5DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNELFdBekNIO0FBQUEsb0JBMkNHLHdCQUFzQjtBQUFBLGdCQUFuQkMsWUFBbUIsUUFBbkJBLFlBQW1CO0FBQ3JCLGdDQUNFLDhEQUFDLDZDQUFEO0FBQU0sc0JBQVEsRUFBRUEsWUFBaEI7QUFBQSx5QkFDR2pCLHVEQURILGFBQ0dBLHVEQURILHVCQUNHQSwyREFBQSxDQUFVLFVBQUNzQixDQUFELEVBQUllLEVBQUosRUFBVztBQUNwQixvQ0FDRTtBQUFnQiwyQkFBUyxFQUFDLE1BQTFCO0FBQUEsMENBQ0UsOERBQUMsa0RBQUQ7QUFBQSwrQkFDRyxHQURILEVBRUdmLENBQUMsQ0FBQ2UsRUFGTCxPQUVVSixVQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFERixlQUtFLDhEQUFDLHFEQUFEO0FBQUEsOEJBQWVYLENBQUMsQ0FBQ2lCO0FBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTEYsZUFNRSw4REFBQyxpREFBRDtBQUFBLDhCQUFXakIsQ0FBQyxDQUFDa0I7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU5GLGVBT0UsOERBQUMsOENBQUQ7QUFDRSx3QkFBSSxFQUFDLFFBRFA7QUFFRSwwQkFBTSxFQUFFLGdCQUFDQyxZQUFELEVBQWtCO0FBQ3hCLDBDQUNFO0FBQUEsK0NBQ0UsOERBQUMsNENBQUQ7QUFBQSxpREFDRSw4REFBQyw0Q0FBRDtBQUFBLG1EQUNFLDhEQUFDLGtEQUFEO0FBQUEscURBQ0UsOERBQUMsbURBQUQ7QUFBWSx5Q0FBUyxFQUFDLG9CQUF0QjtBQUFBLDBDQUNHeEMsMERBREgsYUFDR0EsMERBREgsdUJBQ0dBLDhEQUFBLENBQWEsVUFBQ3lDLEdBQUQsRUFBUztBQUNyQixzREFDRTtBQUVFLDZDQUFTLEVBQUMsNkZBRlo7QUFBQSw0REFJRSw4REFBQyx5Q0FBRDtBQUNFLDBDQUFJLEVBQUMsT0FEUCxDQUVFO0FBRkY7QUFHRSwyQ0FBSyxFQUFFQSxHQUFHLENBQUNDLFlBSGI7QUFJRSwrQ0FBUyxFQUFDLFFBSlo7QUFLRSw4Q0FBUSxFQUFFLG9CQUFNO0FBQ2RoQyx3Q0FBQUEsUUFBUSxDQUFDO0FBQ1BZLDBDQUFBQSxXQUFXLEVBQUVELENBQUMsQ0FBQ2UsRUFEUjtBQUVQWCwwQ0FBQUEsTUFBTSxFQUFFZ0IsR0FBRyxDQUFDQztBQUZMLHlDQUFELENBQVI7O0FBS0EsNENBQUl0QyxNQUFNLENBQUM2QixNQUFQLEdBQWdCLENBQXBCLEVBQXVCO0FBQ3JCLCtDQUNFLElBQUlFLENBQUMsR0FBRyxDQURWLEVBRUVBLENBQUMsR0FBRy9CLE1BQU0sQ0FBQzZCLE1BRmIsRUFHRUUsQ0FBQyxFQUhILEVBSUU7QUFBQTs7QUFDQSxnREFDRSxjQUFBL0IsTUFBTSxDQUFDK0IsQ0FBRCxDQUFOLHdEQUNJYixXQURKLEtBQ21CRCxDQUFDLENBQUNlLEVBRnZCLEVBR0U7QUFDQXRCLDhDQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0FBQ0FYLDhDQUFBQSxNQUFNLENBQUN1QyxNQUFQLENBQWNSLENBQWQsRUFBaUIsQ0FBakIsRUFBb0I7QUFDbEJiLGdEQUFBQSxXQUFXLEVBQUVELENBQUMsQ0FBQ2UsRUFERztBQUVsQlgsZ0RBQUFBLE1BQU0sRUFDSmdCLEdBQUcsQ0FBQ0M7QUFIWSwrQ0FBcEI7QUFLQTtBQUNELDZDQVhELE1BV08sSUFDTHRDLE1BQU0sQ0FBQytCLENBQUQsQ0FBTixDQUNHYixXQURILEtBQ21CRCxDQUFDLENBQUNlLEVBRmhCLEVBR0w7QUFDQXRCLDhDQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FDRSwwQkFERixFQUVFTSxDQUFDLENBQUNlLEVBRkosRUFHRSxhQUhGLEVBSUVoQyxNQUFNLENBQUMrQixDQUFELENBQU4sQ0FBVWIsV0FKWjtBQU9BbEIsOENBQUFBLE1BQU0sQ0FBQ3lCLElBQVAsQ0FBWTtBQUNWUCxnREFBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNlLEVBREw7QUFFVlgsZ0RBQUFBLE1BQU0sRUFDSmdCLEdBQUcsQ0FBQ0MsWUFISSxDQUlWOztBQUpVLCtDQUFaO0FBTUE7QUFDRDtBQUNGOztBQUNEbEMsMENBQUFBLEtBQUssQ0FBQ29DLGFBQU4sQ0FBb0J4QyxNQUFwQjtBQUNELHlDQXRDRCxNQXNDTztBQUNMVSwwQ0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWjtBQUNBWCwwQ0FBQUEsTUFBTSxDQUFDeUIsSUFBUCxDQUFZO0FBQ1ZQLDRDQUFBQSxXQUFXLEVBQUVELENBQUMsQ0FBQ2UsRUFETDtBQUVWWCw0Q0FBQUEsTUFBTSxFQUFFZ0IsR0FBRyxDQUFDQztBQUZGLDJDQUFaO0FBSUFsQywwQ0FBQUEsS0FBSyxDQUFDb0MsYUFBTixDQUFvQnhDLE1BQXBCO0FBQ0Q7QUFDRjtBQXpESDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZDQUpGLEVBK0RHcUMsR0FBRyxDQUFDSSxXQS9EUDtBQUFBLHFDQUNPSixHQUFHLENBQUNMLEVBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQ0FERjtBQW1FRCxpQ0FwRUE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFERjtBQTBGRDtBQTdGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVBGO0FBQUEsbUJBQVVmLENBQUMsQ0FBQ2UsRUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGO0FBeUdELGVBMUdBLENBREgsZUE0R0U7QUFBSyx5QkFBUyxFQUFDLHFCQUFmO0FBQUEsdUNBQ0UsOERBQUMsK0NBQUQ7QUFDRSx1QkFBSyxNQURQO0FBRUUsMkJBQVMsRUFBQyxnQ0FGWjtBQUdFLHNCQUFJLEVBQUMsUUFIUCxDQUlFO0FBQ0E7QUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBNUdGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERjtBQTBIRDtBQXRLSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQW9MRDs7R0EvTlE3QjtVQUVTSjs7O0tBRlRJOztBQWlPVCxJQUFNdUMsZUFBZSxHQUFHLFNBQWxCQSxlQUFrQixDQUFDQyxLQUFELEVBQVc7QUFDakMsU0FBTztBQUNMM0MsSUFBQUEsTUFBTSxFQUFFMkMsS0FBSyxDQUFDM0MsTUFBTixDQUFhQTtBQURoQixHQUFQO0FBR0QsQ0FKRDs7QUFNQSxJQUFNNEMsa0JBQWtCLEdBQUcsU0FBckJBLGtCQUFxQixDQUFDQyxRQUFELEVBQWM7QUFDdkMsU0FBTztBQUNMTCxJQUFBQSxhQUFhLEVBQUUsdUJBQUM3QyxJQUFEO0FBQUEsYUFBVWtELFFBQVEsQ0FBQy9DLHlEQUFBLENBQXNCSCxJQUF0QixDQUFELENBQWxCO0FBQUEsS0FEVjtBQUVMbUQsSUFBQUEsY0FBYyxFQUFFLHdCQUFDbkQsSUFBRCxFQUFPcUMsRUFBUDtBQUFBLGFBQWNhLFFBQVEsQ0FBQy9DLHdEQUFBLENBQXFCSCxJQUFyQixFQUEyQnFDLEVBQTNCLENBQUQsQ0FBdEI7QUFBQSxLQUZYO0FBR0xnQixJQUFBQSxnQkFBZ0IsRUFBRSwwQkFBQ3JELElBQUQsRUFBT3NELElBQVAsRUFBYUMsTUFBYjtBQUFBLGFBQ2hCTCxRQUFRLENBQUMvQywwREFBQSxDQUF1QkgsSUFBdkIsRUFBNkJzRCxJQUE3QixFQUFtQ0MsTUFBbkMsQ0FBRCxDQURRO0FBQUEsS0FIYjtBQUtMRSxJQUFBQSxrQkFBa0IsRUFBRSw0QkFBQ3pELElBQUQsRUFBT3NELElBQVAsRUFBYUMsTUFBYjtBQUFBLGFBQ2xCTCxRQUFRLENBQUMvQyw0REFBQSxDQUF5QkgsSUFBekIsRUFBK0JzRCxJQUEvQixFQUFxQ0MsTUFBckMsQ0FBRCxDQURVO0FBQUEsS0FMZjtBQU9MSSxJQUFBQSxpQkFBaUIsRUFBRSwyQkFBQzNELElBQUQ7QUFBQSxhQUFVa0QsUUFBUSxDQUFDL0MsNkRBQUEsQ0FBMEJILElBQTFCLENBQUQsQ0FBbEI7QUFBQTtBQVBkLEdBQVA7QUFTRCxDQVZEOztBQVdBLCtEQUFlRSxvREFBTyxDQUFDNkMsZUFBRCxFQUFrQkUsa0JBQWxCLENBQVAsQ0FBNkN6QyxJQUE3QyxDQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3BhZ2VzL2luZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcbmltcG9ydCB7IEZpZWxkLCBGaWVsZEFycmF5LCBGb3JtaWsgfSBmcm9tIFwiZm9ybWlrXCI7XG5pbXBvcnQgSGVhZCBmcm9tIFwibmV4dC9oZWFkXCI7XG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQge1xuICBCdXR0b24sXG4gIENhcmQsXG4gIENhcmRCb2R5LFxuICBDYXJkSGVhZGVyLFxuICBDYXJkU3VidGl0bGUsXG4gIENhcmRUZXh0LFxuICBDYXJkVGl0bGUsXG4gIENvbCxcbiAgRm9ybSxcbiAgRm9ybUdyb3VwLFxuICBJbnB1dEdyb3VwLFxuICBSb3csXG59IGZyb20gXCJyZWFjdHN0cmFwXCI7XG5pbXBvcnQgZGF0YSBmcm9tIFwiLi4vY29tcG9uZW50cy9EYXRhL0RhdGEuanNvblwiO1xuaW1wb3J0IG9wdGlvbnMgZnJvbSBcIi4uL2NvbXBvbmVudHMvRGF0YS9vcHRpb25zLmpzb25cIjtcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcbmltcG9ydCAqIGFzIGFjdGlvbnMgZnJvbSBcIi4uL3JlZHV4L2FjdGlvbnNcIjtcbmltcG9ydCB7IHVzZUhpc3RvcnkgfSBmcm9tIFwicmVhY3Qtcm91dGVyXCI7XG5cbnZhciByZXN1bHQgPSBuZXcgQXJyYXkoKTtcbnZhciBNYWluUmVzdWx0ID0gbmV3IEFycmF5KCk7XG5mdW5jdGlvbiBIb21lKHByb3BzKSB7XG4gIGNvbnN0IFt2YWx1ZSwgc2V0VmFsdWVdID0gdXNlU3RhdGUoe30pO1xuICBjb25zdCBoaXN0b3J5ID0gdXNlSGlzdG9yeSgpO1xuXG4gIGNvbnN0IFtjb21wYW55LCBzZXRDb21wYW55XSA9IHVzZVN0YXRlKHt9KTtcblxuICBjb25zb2xlLmxvZyhcInByb3BzLnJlc3VsdFwiLCBwcm9wcy5yZXN1bHQpO1xuXG4gIGNvbnNvbGUubG9nKFwidmFsdWVcIiwgdmFsdWUpO1xuICBjb25zdCBoYW5kbGVTdWJtaXQgPSAodmFsdWVzLCBzZXRTdWJtaXR0aW5nKSA9PiB7XG4gICAgaWYgKHByb3BzLnJlc3VsdCkge1xuICAgICAgcHJvcHMucmVzdWx0Py5tYXAoKHIpID0+IHtcbiAgICAgICAgZGF0YT8ubWFwKChkKSA9PiB7XG4gICAgICAgICAgaWYgKHIucXVlc3Rpb25faWQgPT0gZC5xdWVzdGlvbl9pZCkge1xuICAgICAgICAgICAgaWYgKGQuQ0RVIC8gQ1NVID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWFrYXNoXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgbGV0IGRhdGEgPSB7XG4gICAgICByZXN1bHQ6IHJlc3VsdCxcbiAgICB9O1xuICAgIGNvbnNvbGUubG9nKGRhdGEpO1xuXG4gICAgYXhpb3NcbiAgICAgIC5wb3N0KFwiL3Rlc3RcIiwgZGF0YSlcbiAgICAgIC50aGVuKChyZXMpID0+IHtcbiAgICAgICAgY29uc29sZS5sb2cocmVzKTtcbiAgICAgICAgY29uc29sZS5sb2coXCJpbnRpYWwgdmFsdWUgaXMgc3VibWl0ZWQgdG8gcmVzdWx0c1wiKTtcbiAgICAgICAgcmVzdWx0ID0gW107XG4gICAgICAgIGhpc3RvcnkucHVzaChcIi90aGFua3lvdVwiKTtcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyhlcnIucmVzcG9uc2UuZGF0YSk7XG4gICAgICAgIC8vIGhpc3RvcnkucHVzaChcIi9leGFtLWFwcGVhcmVkXCIpO1xuICAgICAgICAvLyByZXN1bHQgPSBbXTtcbiAgICAgIH0pO1xuICB9O1xuICBjb25zb2xlLmxvZyhcImFycmF5XCIsIHJlc3VsdCk7XG4gIGNvbnN0IGRhdGFMZW5ndGggPSBkYXRhLmxlbmd0aDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiXCI+XG4gICAgICA8SGVhZD5cbiAgICAgICAgPHRpdGxlPkNyZWF0ZSBOZXh0IEFwcDwvdGl0bGU+XG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cbiAgICAgIDwvSGVhZD5cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNSBib3JkZXItMiBzaGFkb3ctbWQgcm91bmRlZC1tZFwiPlxuICAgICAgICA8Q2FyZEJvZHk+XG4gICAgICAgICAgPEZvcm1pa1xuICAgICAgICAgICAgaW5pdGlhbFZhbHVlcz17e1xuICAgICAgICAgICAgICByZXN1bHQ6IFtdLFxuICAgICAgICAgICAgICBhbnN3ZXI6IFwiXCIsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgb25TdWJtaXQ9eyh2YWx1ZXMsIHNldFN1Ym1pdHRpbmcpID0+IHtcbiAgICAgICAgICAgICAgaWYgKHByb3BzLnJlc3VsdD8ubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwicmVzdWx0IGxlbmd0aFwiLCBwcm9wcy5yZXN1bHQ/Lmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0TGVuZ3RoID0gcHJvcHMucmVzdWx0Py5sZW5ndGg7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByZXN1bHRMZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgY29uc29sZShcInJlc3VsdCBtYXBcIik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHByb3BzLnJlc3VsdD8ubWFwKChyKSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zb2xlKFwicmVzdWx0IG1hcFwiKTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBkYXRhPy5tYXAoKGQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHIucXVlc3Rpb25faWQgPT0gZC5pZCkge1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwici5xdWVzdGlvbl9pZFwiLCByLnF1ZXN0aW9uX2lkLCBcImQuaWRcIiwgZC5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGQuU1BEID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImFha2FzaFwiKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGxldCBkYXRhID0ge1xuICAgICAgICAgICAgICAgIHJlc3VsdDogcHJvcHMucmVzdWx0LFxuICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInN1Ym1pdCBjbGlja1wiKTtcbiAgICAgICAgICAgICAgLy8gYXhpb3NcbiAgICAgICAgICAgICAgLy8gICAucG9zdChcImh0dHBzOi8vdWRpdHNvbHV0aW9ucy5pbi95YXJuL3B1YmxpYy9hcGkvc2NvcmVzXCIsIGRhdGEpXG4gICAgICAgICAgICAgIC8vICAgLnRoZW4oKHJlcykgPT4ge1xuICAgICAgICAgICAgICAvLyAgICAgY29uc29sZS5sb2cocmVzKTtcbiAgICAgICAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKFwiaW50aWFsIHZhbHVlIGlzIHN1Ym1pdGVkIHRvIHJlc3VsdHNcIik7XG4gICAgICAgICAgICAgIC8vICAgICByZXN1bHQgPSBbXTtcbiAgICAgICAgICAgICAgLy8gICAgIGhpc3RvcnkucHVzaChcIi90aGFua3lvdVwiKTtcbiAgICAgICAgICAgICAgLy8gICB9KVxuICAgICAgICAgICAgICAvLyAgIC5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhlcnIucmVzcG9uc2UuZGF0YSk7XG4gICAgICAgICAgICAgIC8vICAgICAvLyBoaXN0b3J5LnB1c2goXCIvZXhhbS1hcHBlYXJlZFwiKTtcblxuICAgICAgICAgICAgICAvLyAgIH0pO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7KHsgaGFuZGxlU3VibWl0IH0pID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8Rm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cbiAgICAgICAgICAgICAgICAgIHtkYXRhPy5tYXAoKGQsIGlkKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2QuaWR9IGNsYXNzTmFtZT1cIm10LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkVGl0bGU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtcIiBcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2QuaWR9L3tkYXRhTGVuZ3RofVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9DYXJkVGl0bGU+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2FyZFN1YnRpdGxlPntkLlNjaGxhZ3dvcnR9PC9DYXJkU3VidGl0bGU+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2FyZFRleHQ+e2QucXVlc3Rpb25fdGV4dH08L0NhcmRUZXh0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZpZWxkQXJyYXlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInJlc3VsdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlbmRlcj17KGFycmF5SGVscGVycykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Um93PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDb2w+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRHcm91cCBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG10LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3B0aW9ucz8ubWFwKChvcHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17b3B0LmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiBiZy1ncmF5LTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbWQgdGV4dC1jZW50ZXIgaG92ZXI6YmcteWVsbG93LTMwMCBob3Zlcjp0ZXh0LWJsYWNrIG1iLTFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicmFkaW9cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbmFtZT1cImFuc3dlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17b3B0Lm9wdGlvbl9WYWx1ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRWYWx1ZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25faWQ6IGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOiBvcHQub3B0aW9uX1ZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGkgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaSA8IHJlc3VsdC5sZW5ndGg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpKytcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0W2ldXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPy5xdWVzdGlvbl9pZCA9PSBkLmlkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJzcGxpY2VcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC5zcGxpY2UoaSwgMSwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uX2lkOiBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdC5vcHRpb25fVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucXVlc3Rpb25faWQgIT09IGQuaWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVsc2VfaWYgcXVlc3Rpb24gb2YgZGF0YVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJyZXN1bHQgcS1pZFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdFtpXS5xdWVzdGlvbl9pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHQub3B0aW9uX1ZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wcy5yZXN1bHRTZXREYXRhKHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJlbHNlXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uX2lkOiBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOiBvcHQub3B0aW9uX1ZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3BzLnJlc3VsdFNldERhdGEocmVzdWx0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcHQub3B0aW9uX3RleHR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6e1wiIFwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Jlc3VsdD8ubWFwKChyKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyLnF1ZXN0aW9uX2lkID09IGQuaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gci5hbnN3ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PiAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9JbnB1dEdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvUm93PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgYmxvY2tcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItMiBwLTIgYm9yZGVyLWJsYWNrIG10LTdcIlxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICAgIC8vIG9uQ2xpY2s9e2hhbmRsZVN1Ym1pdH1cbiAgICAgICAgICAgICAgICAgICAgICAvLyBkaXNhYmxlZD17Zm9ybVByb3BzLmlzU3VibWl0dGluZ31cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIEVlZ2VibmlzIHplaWdlblxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvRm9ybT5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPC9Gb3JtaWs+XG4gICAgICAgIDwvQ2FyZEJvZHk+XG4gICAgICA8L0NhcmQ+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IChzdGF0ZSkgPT4ge1xuICByZXR1cm4ge1xuICAgIHJlc3VsdDogc3RhdGUucmVzdWx0LnJlc3VsdCxcbiAgfTtcbn07XG5cbmNvbnN0IG1hcERpc3BhdGNoVG9Qcm9wcyA9IChkaXNwYXRjaCkgPT4ge1xuICByZXR1cm4ge1xuICAgIHJlc3VsdFNldERhdGE6IChkYXRhKSA9PiBkaXNwYXRjaChhY3Rpb25zLnJlc3VsdFNldERhdGEoZGF0YSkpLFxuICAgIG9uRGVsZXRlUmVzdWx0OiAoZGF0YSwgaWQpID0+IGRpc3BhdGNoKGFjdGlvbnMuZGVsZXRlUmVzdWx0KGRhdGEsIGlkKSksXG4gICAgb25Qb3N0UmVzdWx0RGF0YTogKGRhdGEsIHVzZXIsIHRvZ2dsZSkgPT5cbiAgICAgIGRpc3BhdGNoKGFjdGlvbnMucG9zdFJlc3VsdERhdGEoZGF0YSwgdXNlciwgdG9nZ2xlKSksXG4gICAgb25VcGRhdGVSZXN1bHREYXRhOiAoZGF0YSwgdXNlciwgdG9nZ2xlKSA9PlxuICAgICAgZGlzcGF0Y2goYWN0aW9ucy51cGRhdGVSZXN1bHREYXRhKGRhdGEsIHVzZXIsIHRvZ2dsZSkpLFxuICAgIHJlc3VsdEVkaXRHZXREYXRhOiAoZGF0YSkgPT4gZGlzcGF0Y2goYWN0aW9ucy5yZXN1bHRFZGl0R2V0RGF0YShkYXRhKSksXG4gIH07XG59O1xuZXhwb3J0IGRlZmF1bHQgY29ubmVjdChtYXBTdGF0ZVRvUHJvcHMsIG1hcERpc3BhdGNoVG9Qcm9wcykoSG9tZSk7XG4iXSwibmFtZXMiOlsiYXhpb3MiLCJGaWVsZCIsIkZpZWxkQXJyYXkiLCJGb3JtaWsiLCJIZWFkIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJCdXR0b24iLCJDYXJkIiwiQ2FyZEJvZHkiLCJDYXJkSGVhZGVyIiwiQ2FyZFN1YnRpdGxlIiwiQ2FyZFRleHQiLCJDYXJkVGl0bGUiLCJDb2wiLCJGb3JtIiwiRm9ybUdyb3VwIiwiSW5wdXRHcm91cCIsIlJvdyIsImRhdGEiLCJvcHRpb25zIiwiY29ubmVjdCIsImFjdGlvbnMiLCJ1c2VIaXN0b3J5IiwicmVzdWx0IiwiQXJyYXkiLCJNYWluUmVzdWx0IiwiSG9tZSIsInByb3BzIiwidmFsdWUiLCJzZXRWYWx1ZSIsImhpc3RvcnkiLCJjb21wYW55Iiwic2V0Q29tcGFueSIsImNvbnNvbGUiLCJsb2ciLCJoYW5kbGVTdWJtaXQiLCJ2YWx1ZXMiLCJzZXRTdWJtaXR0aW5nIiwibWFwIiwiciIsImQiLCJxdWVzdGlvbl9pZCIsIkNEVSIsIkNTVSIsImFuc3dlciIsInBvc3QiLCJ0aGVuIiwicmVzIiwicHVzaCIsImVyciIsInJlc3BvbnNlIiwiZGF0YUxlbmd0aCIsImxlbmd0aCIsInJlc3VsdExlbmd0aCIsImkiLCJpZCIsIlNQRCIsIlNjaGxhZ3dvcnQiLCJxdWVzdGlvbl90ZXh0IiwiYXJyYXlIZWxwZXJzIiwib3B0Iiwib3B0aW9uX1ZhbHVlIiwic3BsaWNlIiwicmVzdWx0U2V0RGF0YSIsIm9wdGlvbl90ZXh0IiwibWFwU3RhdGVUb1Byb3BzIiwic3RhdGUiLCJtYXBEaXNwYXRjaFRvUHJvcHMiLCJkaXNwYXRjaCIsIm9uRGVsZXRlUmVzdWx0IiwiZGVsZXRlUmVzdWx0Iiwib25Qb3N0UmVzdWx0RGF0YSIsInVzZXIiLCJ0b2dnbGUiLCJwb3N0UmVzdWx0RGF0YSIsIm9uVXBkYXRlUmVzdWx0RGF0YSIsInVwZGF0ZVJlc3VsdERhdGEiLCJyZXN1bHRFZGl0R2V0RGF0YSJdLCJzb3VyY2VSb290IjoiIn0=