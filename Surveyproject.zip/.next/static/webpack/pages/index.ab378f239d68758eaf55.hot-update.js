"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
/* harmony import */ var _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Data/Data.json */ "./components/Data/Data.json");
/* harmony import */ var _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Data/options.json */ "./components/Data/options.json");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _redux_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../redux/actions */ "./redux/actions/index.js");
/* harmony import */ var react_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-router */ "./node_modules/react-router/esm/react-router.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "E:\\git vinraj\\company-test\\pages\\index.js",
    _s = $RefreshSig$();












var result = new Array();
var MainResult = new Array();

function Home(props) {
  _s();

  var _this = this;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      value = _useState[0],
      setValue = _useState[1];

  var history = (0,react_router__WEBPACK_IMPORTED_MODULE_9__.useHistory)();

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
    CDU: 0,
    SPD: 0,
    AfD: 0,
    FDP: 0,
    Grüne: 0,
    Linke: 0
  }),
      company = _useState2[0],
      setCompany = _useState2[1];

  console.log("props.result", props.result);
  console.log("value", value);

  var handleSubmit = function handleSubmit(values, setSubmitting) {
    if (props.result) {
      var _props$result;

      (_props$result = props.result) === null || _props$result === void 0 ? void 0 : _props$result.map(function (r) {
        data === null || data === void 0 ? void 0 : data.map(function (d) {
          if (r.question_id == d.question_id) {
            if (d.CDU / CSU == r.answer) {
              console.log("aakash");
            }
          }
        });
      });
    }

    var data = {
      result: result
    };
    console.log(data);
    axios__WEBPACK_IMPORTED_MODULE_0___default().post("/test", data).then(function (res) {
      console.log(res);
      console.log("intial value is submited to results");
      result = [];
      history.push("/thankyou");
    })["catch"](function (err) {
      console.log(err.response.data); // history.push("/exam-appeared");
      // result = [];
    });
  };

  console.log("array", result);
  console.log("company", company);
  var dataLength = _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.length;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
    className: "",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("title", {
        children: "Create Next App"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 82,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 83,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 81,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Card, {
      className: "p-5 border-2 shadow-md rounded-md",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardBody, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
          initialValues: {
            result: [],
            answer: ""
          },
          onSubmit: function onSubmit(values, setSubmitting) {
            var _props$result2;

            if (((_props$result2 = props.result) === null || _props$result2 === void 0 ? void 0 : _props$result2.length) > 0 && _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__) {
              var _props$result3, _props$result4, _props$result5;

              console.log("result length", (_props$result3 = props.result) === null || _props$result3 === void 0 ? void 0 : _props$result3.length);
              var resultLength = (_props$result4 = props.result) === null || _props$result4 === void 0 ? void 0 : _props$result4.length; // for (let i = 0; i < resultLength; i++) {
              //   console.log("result map");
              // }

              (_props$result5 = props.result) === null || _props$result5 === void 0 ? void 0 : _props$result5.map(function (r) {
                console.log("result map");
                _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === null || _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === void 0 ? void 0 : _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.map(function (d) {
                  console.log("data map");

                  if (r.question_id == d.id) {
                    console.log("r.question_id", r.question_id, "d.id", d.id);

                    if (d.SPD == r.answer) {
                      // setCompany(...company, company.SPD + 1);
                      console.log("SPD");
                    }

                    if (d.CDU == r.answer) {
                      // setCompany(...company, company.CDU + 1);
                      console.log("CDU");
                    }

                    if (d.AfD == r.answer) {
                      // setCompany(...company, company.AfD + 1);
                      console.log("AfD");
                    }

                    if (d.FDP == r.answer) {
                      // setCompany(...company, company.FDP + 1);
                      console.log("FDP");
                    }

                    if (d.Grüne == r.answer) {
                      // setCompany(...company, company.Grüne + 1);
                      console.log("Grüne");
                    }

                    if (d.Linke == r.answer) {
                      // setCompany(...company, company.Linke + 1);
                      console.log("Linke");
                    } else {
                      console.log("else from last if");
                    }
                  }
                });
              });
            }

            console.log("submit click"); // axios
            //   .post("https://uditsolutions.in/yarn/public/api/scores", data)
            //   .then((res) => {
            //     console.log(res);
            //     console.log("intial value is submited to results");
            //     result = [];
            //     history.push("/thankyou");
            //   })
            //   .catch((err) => {
            //     console.log(err.response.data);
            //     // history.push("/exam-appeared");
            //   });
          },
          children: function children(_ref) {
            var handleSubmit = _ref.handleSubmit;
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Form, {
              onSubmit: handleSubmit,
              children: [_components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === null || _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === void 0 ? void 0 : _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.map(function (d, id) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                  className: "mt-3",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardTitle, {
                    children: [" ", d.id, "/", dataLength]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 159,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardSubtitle, {
                    children: d.Schlagwort
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 163,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardText, {
                    children: d.question_text
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 164,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.FieldArray, {
                    name: "result",
                    render: function render(arrayHelpers) {
                      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Row, {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Col, {
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.FormGroup, {
                              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.InputGroup, {
                                className: "flex flex-col mt-2",
                                children: _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === null || _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === void 0 ? void 0 : _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__.map(function (opt) {
                                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("label", {
                                    className: "p-2 bg-gray-600 text-white rounded-md text-center hover:bg-yellow-300 hover:text-black mb-1",
                                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                                      type: "radio" // name="answer"
                                      ,
                                      value: opt.option_Value,
                                      className: "hidden",
                                      onChange: function onChange() {
                                        setValue({
                                          question_id: d.id,
                                          answer: opt.option_Value
                                        });

                                        if (result.length > 0) {
                                          for (var i = 0; i < result.length; i++) {
                                            var _result$i;

                                            if (((_result$i = result[i]) === null || _result$i === void 0 ? void 0 : _result$i.question_id) == d.id) {
                                              console.log("splice");
                                              result.splice(i, 1, {
                                                question_id: d.id,
                                                answer: opt.option_Value
                                              });
                                              return;
                                            } else if (result[i].question_id !== d.id) {
                                              console.log("else_if question of data", d.id, "result q-id", result[i].question_id);
                                              result.push({
                                                question_id: d.id,
                                                answer: opt.option_Value // value,

                                              });
                                              return;
                                            }
                                          }

                                          props.resultSetData(result);
                                        } else {
                                          console.log("else");
                                          result.push({
                                            question_id: d.id,
                                            answer: opt.option_Value
                                          });
                                          props.resultSetData(result);
                                        }
                                      }
                                    }, void 0, false, {
                                      fileName: _jsxFileName,
                                      lineNumber: 180,
                                      columnNumber: 47
                                    }, _this), opt.option_text]
                                  }, opt.id, true, {
                                    fileName: _jsxFileName,
                                    lineNumber: 176,
                                    columnNumber: 45
                                  }, _this);
                                })
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 173,
                                columnNumber: 39
                              }, _this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 172,
                              columnNumber: 37
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 171,
                            columnNumber: 35
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 170,
                          columnNumber: 33
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 169,
                        columnNumber: 31
                      }, _this);
                    }
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 165,
                    columnNumber: 25
                  }, _this)]
                }, d.id, true, {
                  fileName: _jsxFileName,
                  lineNumber: 158,
                  columnNumber: 23
                }, _this);
              }), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Button, {
                  block: true,
                  className: "border-2 p-2 border-black mt-7",
                  type: "submit" // onClick={handleSubmit}
                  // disabled={formProps.isSubmitting}
                  ,
                  children: "Eegebnis zeigen"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 264,
                  columnNumber: 21
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 263,
                columnNumber: 19
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 155,
              columnNumber: 17
            }, _this);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 87,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 86,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 85,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 80,
    columnNumber: 5
  }, this);
}

_s(Home, "syk22Nggr5mAGvDPPQuoSiuoVjA=", false, function () {
  return [react_router__WEBPACK_IMPORTED_MODULE_9__.useHistory];
});

_c = Home;

var mapStateToProps = function mapStateToProps(state) {
  return {
    result: state.result.result
  };
};

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    resultSetData: function resultSetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultSetData(data));
    },
    onDeleteResult: function onDeleteResult(data, id) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.deleteResult(data, id));
    },
    onPostResultData: function onPostResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.postResultData(data, user, toggle));
    },
    onUpdateResultData: function onUpdateResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.updateResultData(data, user, toggle));
    },
    resultEditGetData: function resultEditGetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultEditGetData(data));
    }
  };
};

/* harmony default export */ __webpack_exports__["default"] = ((0,react_redux__WEBPACK_IMPORTED_MODULE_6__.connect)(mapStateToProps, mapDispatchToProps)(Home));

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguYWIzNzhmMjM5ZDY4NzU4ZWFmNTUuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFjQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLElBQUl3QixNQUFNLEdBQUcsSUFBSUMsS0FBSixFQUFiO0FBQ0EsSUFBSUMsVUFBVSxHQUFHLElBQUlELEtBQUosRUFBakI7O0FBQ0EsU0FBU0UsSUFBVCxDQUFjQyxLQUFkLEVBQXFCO0FBQUE7O0FBQUE7O0FBQ25CLGtCQUEwQnRCLCtDQUFRLENBQUMsRUFBRCxDQUFsQztBQUFBLE1BQU91QixLQUFQO0FBQUEsTUFBY0MsUUFBZDs7QUFDQSxNQUFNQyxPQUFPLEdBQUdSLHdEQUFVLEVBQTFCOztBQUVBLG1CQUE4QmpCLCtDQUFRLENBQUM7QUFDckMwQixJQUFBQSxHQUFHLEVBQUUsQ0FEZ0M7QUFFckNDLElBQUFBLEdBQUcsRUFBRSxDQUZnQztBQUdyQ0MsSUFBQUEsR0FBRyxFQUFFLENBSGdDO0FBSXJDQyxJQUFBQSxHQUFHLEVBQUUsQ0FKZ0M7QUFLckNDLElBQUFBLEtBQUssRUFBRSxDQUw4QjtBQU1yQ0MsSUFBQUEsS0FBSyxFQUFFO0FBTjhCLEdBQUQsQ0FBdEM7QUFBQSxNQUFPQyxPQUFQO0FBQUEsTUFBZ0JDLFVBQWhCOztBQVNBQyxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBQTRCYixLQUFLLENBQUNKLE1BQWxDO0FBRUFnQixFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQXFCWixLQUFyQjs7QUFDQSxNQUFNYSxZQUFZLEdBQUcsU0FBZkEsWUFBZSxDQUFDQyxNQUFELEVBQVNDLGFBQVQsRUFBMkI7QUFDOUMsUUFBSWhCLEtBQUssQ0FBQ0osTUFBVixFQUFrQjtBQUFBOztBQUNoQix1QkFBQUksS0FBSyxDQUFDSixNQUFOLGdFQUFjcUIsR0FBZCxDQUFrQixVQUFDQyxDQUFELEVBQU87QUFDdkIzQixRQUFBQSxJQUFJLFNBQUosSUFBQUEsSUFBSSxXQUFKLFlBQUFBLElBQUksQ0FBRTBCLEdBQU4sQ0FBVSxVQUFDRSxDQUFELEVBQU87QUFDZixjQUFJRCxDQUFDLENBQUNFLFdBQUYsSUFBaUJELENBQUMsQ0FBQ0MsV0FBdkIsRUFBb0M7QUFDbEMsZ0JBQUlELENBQUMsQ0FBQ2YsR0FBRixHQUFRaUIsR0FBUixJQUFlSCxDQUFDLENBQUNJLE1BQXJCLEVBQTZCO0FBQzNCVixjQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0FBQ0Q7QUFDRjtBQUNGLFNBTkQ7QUFPRCxPQVJEO0FBU0Q7O0FBQ0QsUUFBSXRCLElBQUksR0FBRztBQUNUSyxNQUFBQSxNQUFNLEVBQUVBO0FBREMsS0FBWDtBQUdBZ0IsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVl0QixJQUFaO0FBRUFuQixJQUFBQSxpREFBQSxDQUNRLE9BRFIsRUFDaUJtQixJQURqQixFQUVHaUMsSUFGSCxDQUVRLFVBQUNDLEdBQUQsRUFBUztBQUNiYixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWVksR0FBWjtBQUNBYixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxxQ0FBWjtBQUNBakIsTUFBQUEsTUFBTSxHQUFHLEVBQVQ7QUFDQU8sTUFBQUEsT0FBTyxDQUFDdUIsSUFBUixDQUFhLFdBQWI7QUFDRCxLQVBILFdBUVMsVUFBQ0MsR0FBRCxFQUFTO0FBQ2RmLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZYyxHQUFHLENBQUNDLFFBQUosQ0FBYXJDLElBQXpCLEVBRGMsQ0FFZDtBQUNBO0FBQ0QsS0FaSDtBQWFELEdBOUJEOztBQWdDQXFCLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVosRUFBcUJqQixNQUFyQjtBQUNBZ0IsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWixFQUF1QkgsT0FBdkI7QUFDQSxNQUFNbUIsVUFBVSxHQUFHdEMsOERBQW5CO0FBRUEsc0JBQ0U7QUFBSyxhQUFTLEVBQUMsRUFBZjtBQUFBLDRCQUNFLDhEQUFDLGtEQUFEO0FBQUEsOEJBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUVFO0FBQU0sV0FBRyxFQUFDLE1BQVY7QUFBaUIsWUFBSSxFQUFDO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQUtFLDhEQUFDLDZDQUFEO0FBQU0sZUFBUyxFQUFDLG1DQUFoQjtBQUFBLDZCQUNFLDhEQUFDLGlEQUFEO0FBQUEsK0JBQ0UsOERBQUMsMENBQUQ7QUFDRSx1QkFBYSxFQUFFO0FBQ2JLLFlBQUFBLE1BQU0sRUFBRSxFQURLO0FBRWIwQixZQUFBQSxNQUFNLEVBQUU7QUFGSyxXQURqQjtBQUtFLGtCQUFRLEVBQUUsa0JBQUNQLE1BQUQsRUFBU0MsYUFBVCxFQUEyQjtBQUFBOztBQUNuQyxnQkFBSSxtQkFBQWhCLEtBQUssQ0FBQ0osTUFBTixrRUFBY2tDLE1BQWQsSUFBdUIsQ0FBdkIsSUFBNEJ2Qyx1REFBaEMsRUFBc0M7QUFBQTs7QUFDcENxQixjQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxlQUFaLG9CQUE2QmIsS0FBSyxDQUFDSixNQUFuQyxtREFBNkIsZUFBY2tDLE1BQTNDO0FBQ0Esa0JBQU1DLFlBQVkscUJBQUcvQixLQUFLLENBQUNKLE1BQVQsbURBQUcsZUFBY2tDLE1BQW5DLENBRm9DLENBR3BDO0FBQ0E7QUFDQTs7QUFFQSxnQ0FBQTlCLEtBQUssQ0FBQ0osTUFBTixrRUFBY3FCLEdBQWQsQ0FBa0IsVUFBQ0MsQ0FBRCxFQUFPO0FBQ3ZCTixnQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksWUFBWjtBQUNBdEIsZ0JBQUFBLHVEQUFJLFNBQUosSUFBQUEsdURBQUksV0FBSixZQUFBQSwyREFBQSxDQUFVLFVBQUM0QixDQUFELEVBQU87QUFDZlAsa0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVo7O0FBQ0Esc0JBQUlLLENBQUMsQ0FBQ0UsV0FBRixJQUFpQkQsQ0FBQyxDQUFDYSxFQUF2QixFQUEyQjtBQUN6QnBCLG9CQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxlQUFaLEVBQTZCSyxDQUFDLENBQUNFLFdBQS9CLEVBQTRDLE1BQTVDLEVBQW9ERCxDQUFDLENBQUNhLEVBQXREOztBQUNBLHdCQUFJYixDQUFDLENBQUNkLEdBQUYsSUFBU2EsQ0FBQyxDQUFDSSxNQUFmLEVBQXVCO0FBQ3JCO0FBQ0FWLHNCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaO0FBQ0Q7O0FBQ0Qsd0JBQUlNLENBQUMsQ0FBQ2YsR0FBRixJQUFTYyxDQUFDLENBQUNJLE1BQWYsRUFBdUI7QUFDckI7QUFDQVYsc0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVo7QUFDRDs7QUFDRCx3QkFBSU0sQ0FBQyxDQUFDYixHQUFGLElBQVNZLENBQUMsQ0FBQ0ksTUFBZixFQUF1QjtBQUNyQjtBQUNBVixzQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksS0FBWjtBQUNEOztBQUNELHdCQUFJTSxDQUFDLENBQUNaLEdBQUYsSUFBU1csQ0FBQyxDQUFDSSxNQUFmLEVBQXVCO0FBQ3JCO0FBQ0FWLHNCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaO0FBQ0Q7O0FBQ0Qsd0JBQUlNLENBQUMsQ0FBQ1gsS0FBRixJQUFXVSxDQUFDLENBQUNJLE1BQWpCLEVBQXlCO0FBQ3ZCO0FBQ0FWLHNCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0Q7O0FBQ0Qsd0JBQUlNLENBQUMsQ0FBQ1YsS0FBRixJQUFXUyxDQUFDLENBQUNJLE1BQWpCLEVBQXlCO0FBQ3ZCO0FBQ0FWLHNCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0QscUJBSEQsTUFHTztBQUNMRCxzQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksbUJBQVo7QUFDRDtBQUNGO0FBQ0YsaUJBL0JEO0FBZ0NELGVBbENEO0FBbUNEOztBQUVERCxZQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBN0NtQyxDQThDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0QsV0FoRUg7QUFBQSxvQkFrRUcsd0JBQXNCO0FBQUEsZ0JBQW5CQyxZQUFtQixRQUFuQkEsWUFBbUI7QUFDckIsZ0NBQ0UsOERBQUMsNkNBQUQ7QUFBTSxzQkFBUSxFQUFFQSxZQUFoQjtBQUFBLHlCQUNHdkIsdURBREgsYUFDR0EsdURBREgsdUJBQ0dBLDJEQUFBLENBQVUsVUFBQzRCLENBQUQsRUFBSWEsRUFBSixFQUFXO0FBQ3BCLG9DQUNFO0FBQWdCLDJCQUFTLEVBQUMsTUFBMUI7QUFBQSwwQ0FDRSw4REFBQyxrREFBRDtBQUFBLCtCQUNHLEdBREgsRUFFR2IsQ0FBQyxDQUFDYSxFQUZMLE9BRVVILFVBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURGLGVBS0UsOERBQUMscURBQUQ7QUFBQSw4QkFBZVYsQ0FBQyxDQUFDYztBQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUxGLGVBTUUsOERBQUMsaURBQUQ7QUFBQSw4QkFBV2QsQ0FBQyxDQUFDZTtBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTkYsZUFPRSw4REFBQyw4Q0FBRDtBQUNFLHdCQUFJLEVBQUMsUUFEUDtBQUVFLDBCQUFNLEVBQUUsZ0JBQUNDLFlBQUQsRUFBa0I7QUFDeEIsMENBQ0U7QUFBQSwrQ0FDRSw4REFBQyw0Q0FBRDtBQUFBLGlEQUNFLDhEQUFDLDRDQUFEO0FBQUEsbURBQ0UsOERBQUMsa0RBQUQ7QUFBQSxxREFDRSw4REFBQyxtREFBRDtBQUFZLHlDQUFTLEVBQUMsb0JBQXRCO0FBQUEsMENBQ0czQywwREFESCxhQUNHQSwwREFESCx1QkFDR0EsOERBQUEsQ0FBYSxVQUFDNEMsR0FBRCxFQUFTO0FBQ3JCLHNEQUNFO0FBRUUsNkNBQVMsRUFBQyw2RkFGWjtBQUFBLDREQUlFLDhEQUFDLHlDQUFEO0FBQ0UsMENBQUksRUFBQyxPQURQLENBRUU7QUFGRjtBQUdFLDJDQUFLLEVBQUVBLEdBQUcsQ0FBQ0MsWUFIYjtBQUlFLCtDQUFTLEVBQUMsUUFKWjtBQUtFLDhDQUFRLEVBQUUsb0JBQU07QUFDZG5DLHdDQUFBQSxRQUFRLENBQUM7QUFDUGtCLDBDQUFBQSxXQUFXLEVBQUVELENBQUMsQ0FBQ2EsRUFEUjtBQUVQViwwQ0FBQUEsTUFBTSxFQUFFYyxHQUFHLENBQUNDO0FBRkwseUNBQUQsQ0FBUjs7QUFLQSw0Q0FBSXpDLE1BQU0sQ0FBQ2tDLE1BQVAsR0FBZ0IsQ0FBcEIsRUFBdUI7QUFDckIsK0NBQ0UsSUFBSVEsQ0FBQyxHQUFHLENBRFYsRUFFRUEsQ0FBQyxHQUFHMUMsTUFBTSxDQUFDa0MsTUFGYixFQUdFUSxDQUFDLEVBSEgsRUFJRTtBQUFBOztBQUNBLGdEQUNFLGNBQUExQyxNQUFNLENBQUMwQyxDQUFELENBQU4sd0RBQ0lsQixXQURKLEtBQ21CRCxDQUFDLENBQUNhLEVBRnZCLEVBR0U7QUFDQXBCLDhDQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0FBQ0FqQiw4Q0FBQUEsTUFBTSxDQUFDMkMsTUFBUCxDQUFjRCxDQUFkLEVBQWlCLENBQWpCLEVBQW9CO0FBQ2xCbEIsZ0RBQUFBLFdBQVcsRUFBRUQsQ0FBQyxDQUFDYSxFQURHO0FBRWxCVixnREFBQUEsTUFBTSxFQUNKYyxHQUFHLENBQUNDO0FBSFksK0NBQXBCO0FBS0E7QUFDRCw2Q0FYRCxNQVdPLElBQ0x6QyxNQUFNLENBQUMwQyxDQUFELENBQU4sQ0FDR2xCLFdBREgsS0FDbUJELENBQUMsQ0FBQ2EsRUFGaEIsRUFHTDtBQUNBcEIsOENBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUNFLDBCQURGLEVBRUVNLENBQUMsQ0FBQ2EsRUFGSixFQUdFLGFBSEYsRUFJRXBDLE1BQU0sQ0FBQzBDLENBQUQsQ0FBTixDQUFVbEIsV0FKWjtBQU9BeEIsOENBQUFBLE1BQU0sQ0FBQzhCLElBQVAsQ0FBWTtBQUNWTixnREFBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNhLEVBREw7QUFFVlYsZ0RBQUFBLE1BQU0sRUFDSmMsR0FBRyxDQUFDQyxZQUhJLENBSVY7O0FBSlUsK0NBQVo7QUFNQTtBQUNEO0FBQ0Y7O0FBQ0RyQywwQ0FBQUEsS0FBSyxDQUFDd0MsYUFBTixDQUFvQjVDLE1BQXBCO0FBQ0QseUNBdENELE1Bc0NPO0FBQ0xnQiwwQ0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWjtBQUNBakIsMENBQUFBLE1BQU0sQ0FBQzhCLElBQVAsQ0FBWTtBQUNWTiw0Q0FBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNhLEVBREw7QUFFVlYsNENBQUFBLE1BQU0sRUFBRWMsR0FBRyxDQUFDQztBQUZGLDJDQUFaO0FBSUFyQywwQ0FBQUEsS0FBSyxDQUFDd0MsYUFBTixDQUFvQjVDLE1BQXBCO0FBQ0Q7QUFDRjtBQXpESDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZDQUpGLEVBK0RHd0MsR0FBRyxDQUFDSyxXQS9EUDtBQUFBLHFDQUNPTCxHQUFHLENBQUNKLEVBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQ0FERjtBQW1FRCxpQ0FwRUE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFERjtBQTBGRDtBQTdGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVBGO0FBQUEsbUJBQVViLENBQUMsQ0FBQ2EsRUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGO0FBeUdELGVBMUdBLENBREgsZUE0R0U7QUFBSyx5QkFBUyxFQUFDLHFCQUFmO0FBQUEsdUNBQ0UsOERBQUMsK0NBQUQ7QUFDRSx1QkFBSyxNQURQO0FBRUUsMkJBQVMsRUFBQyxnQ0FGWjtBQUdFLHNCQUFJLEVBQUMsUUFIUCxDQUlFO0FBQ0E7QUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBNUdGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERjtBQTBIRDtBQTdMSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQTJNRDs7R0EvUFFqQztVQUVTSjs7O0tBRlRJOztBQWlRVCxJQUFNMkMsZUFBZSxHQUFHLFNBQWxCQSxlQUFrQixDQUFDQyxLQUFELEVBQVc7QUFDakMsU0FBTztBQUNML0MsSUFBQUEsTUFBTSxFQUFFK0MsS0FBSyxDQUFDL0MsTUFBTixDQUFhQTtBQURoQixHQUFQO0FBR0QsQ0FKRDs7QUFNQSxJQUFNZ0Qsa0JBQWtCLEdBQUcsU0FBckJBLGtCQUFxQixDQUFDQyxRQUFELEVBQWM7QUFDdkMsU0FBTztBQUNMTCxJQUFBQSxhQUFhLEVBQUUsdUJBQUNqRCxJQUFEO0FBQUEsYUFBVXNELFFBQVEsQ0FBQ25ELHlEQUFBLENBQXNCSCxJQUF0QixDQUFELENBQWxCO0FBQUEsS0FEVjtBQUVMdUQsSUFBQUEsY0FBYyxFQUFFLHdCQUFDdkQsSUFBRCxFQUFPeUMsRUFBUDtBQUFBLGFBQWNhLFFBQVEsQ0FBQ25ELHdEQUFBLENBQXFCSCxJQUFyQixFQUEyQnlDLEVBQTNCLENBQUQsQ0FBdEI7QUFBQSxLQUZYO0FBR0xnQixJQUFBQSxnQkFBZ0IsRUFBRSwwQkFBQ3pELElBQUQsRUFBTzBELElBQVAsRUFBYUMsTUFBYjtBQUFBLGFBQ2hCTCxRQUFRLENBQUNuRCwwREFBQSxDQUF1QkgsSUFBdkIsRUFBNkIwRCxJQUE3QixFQUFtQ0MsTUFBbkMsQ0FBRCxDQURRO0FBQUEsS0FIYjtBQUtMRSxJQUFBQSxrQkFBa0IsRUFBRSw0QkFBQzdELElBQUQsRUFBTzBELElBQVAsRUFBYUMsTUFBYjtBQUFBLGFBQ2xCTCxRQUFRLENBQUNuRCw0REFBQSxDQUF5QkgsSUFBekIsRUFBK0IwRCxJQUEvQixFQUFxQ0MsTUFBckMsQ0FBRCxDQURVO0FBQUEsS0FMZjtBQU9MSSxJQUFBQSxpQkFBaUIsRUFBRSwyQkFBQy9ELElBQUQ7QUFBQSxhQUFVc0QsUUFBUSxDQUFDbkQsNkRBQUEsQ0FBMEJILElBQTFCLENBQUQsQ0FBbEI7QUFBQTtBQVBkLEdBQVA7QUFTRCxDQVZEOztBQVdBLCtEQUFlRSxvREFBTyxDQUFDaUQsZUFBRCxFQUFrQkUsa0JBQWxCLENBQVAsQ0FBNkM3QyxJQUE3QyxDQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3BhZ2VzL2luZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcbmltcG9ydCB7IEZpZWxkLCBGaWVsZEFycmF5LCBGb3JtaWsgfSBmcm9tIFwiZm9ybWlrXCI7XG5pbXBvcnQgSGVhZCBmcm9tIFwibmV4dC9oZWFkXCI7XG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQge1xuICBCdXR0b24sXG4gIENhcmQsXG4gIENhcmRCb2R5LFxuICBDYXJkSGVhZGVyLFxuICBDYXJkU3VidGl0bGUsXG4gIENhcmRUZXh0LFxuICBDYXJkVGl0bGUsXG4gIENvbCxcbiAgRm9ybSxcbiAgRm9ybUdyb3VwLFxuICBJbnB1dEdyb3VwLFxuICBSb3csXG59IGZyb20gXCJyZWFjdHN0cmFwXCI7XG5pbXBvcnQgZGF0YSBmcm9tIFwiLi4vY29tcG9uZW50cy9EYXRhL0RhdGEuanNvblwiO1xuaW1wb3J0IG9wdGlvbnMgZnJvbSBcIi4uL2NvbXBvbmVudHMvRGF0YS9vcHRpb25zLmpzb25cIjtcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcbmltcG9ydCAqIGFzIGFjdGlvbnMgZnJvbSBcIi4uL3JlZHV4L2FjdGlvbnNcIjtcbmltcG9ydCB7IHVzZUhpc3RvcnkgfSBmcm9tIFwicmVhY3Qtcm91dGVyXCI7XG5cbnZhciByZXN1bHQgPSBuZXcgQXJyYXkoKTtcbnZhciBNYWluUmVzdWx0ID0gbmV3IEFycmF5KCk7XG5mdW5jdGlvbiBIb21lKHByb3BzKSB7XG4gIGNvbnN0IFt2YWx1ZSwgc2V0VmFsdWVdID0gdXNlU3RhdGUoe30pO1xuICBjb25zdCBoaXN0b3J5ID0gdXNlSGlzdG9yeSgpO1xuXG4gIGNvbnN0IFtjb21wYW55LCBzZXRDb21wYW55XSA9IHVzZVN0YXRlKHtcbiAgICBDRFU6IDAsXG4gICAgU1BEOiAwLFxuICAgIEFmRDogMCxcbiAgICBGRFA6IDAsXG4gICAgR3LDvG5lOiAwLFxuICAgIExpbmtlOiAwLFxuICB9KTtcblxuICBjb25zb2xlLmxvZyhcInByb3BzLnJlc3VsdFwiLCBwcm9wcy5yZXN1bHQpO1xuXG4gIGNvbnNvbGUubG9nKFwidmFsdWVcIiwgdmFsdWUpO1xuICBjb25zdCBoYW5kbGVTdWJtaXQgPSAodmFsdWVzLCBzZXRTdWJtaXR0aW5nKSA9PiB7XG4gICAgaWYgKHByb3BzLnJlc3VsdCkge1xuICAgICAgcHJvcHMucmVzdWx0Py5tYXAoKHIpID0+IHtcbiAgICAgICAgZGF0YT8ubWFwKChkKSA9PiB7XG4gICAgICAgICAgaWYgKHIucXVlc3Rpb25faWQgPT0gZC5xdWVzdGlvbl9pZCkge1xuICAgICAgICAgICAgaWYgKGQuQ0RVIC8gQ1NVID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWFrYXNoXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgbGV0IGRhdGEgPSB7XG4gICAgICByZXN1bHQ6IHJlc3VsdCxcbiAgICB9O1xuICAgIGNvbnNvbGUubG9nKGRhdGEpO1xuXG4gICAgYXhpb3NcbiAgICAgIC5wb3N0KFwiL3Rlc3RcIiwgZGF0YSlcbiAgICAgIC50aGVuKChyZXMpID0+IHtcbiAgICAgICAgY29uc29sZS5sb2cocmVzKTtcbiAgICAgICAgY29uc29sZS5sb2coXCJpbnRpYWwgdmFsdWUgaXMgc3VibWl0ZWQgdG8gcmVzdWx0c1wiKTtcbiAgICAgICAgcmVzdWx0ID0gW107XG4gICAgICAgIGhpc3RvcnkucHVzaChcIi90aGFua3lvdVwiKTtcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyhlcnIucmVzcG9uc2UuZGF0YSk7XG4gICAgICAgIC8vIGhpc3RvcnkucHVzaChcIi9leGFtLWFwcGVhcmVkXCIpO1xuICAgICAgICAvLyByZXN1bHQgPSBbXTtcbiAgICAgIH0pO1xuICB9O1xuXG4gIGNvbnNvbGUubG9nKFwiYXJyYXlcIiwgcmVzdWx0KTtcbiAgY29uc29sZS5sb2coXCJjb21wYW55XCIsIGNvbXBhbnkpO1xuICBjb25zdCBkYXRhTGVuZ3RoID0gZGF0YS5sZW5ndGg7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiPlxuICAgICAgPEhlYWQ+XG4gICAgICAgIDx0aXRsZT5DcmVhdGUgTmV4dCBBcHA8L3RpdGxlPlxuICAgICAgICA8bGluayByZWw9XCJpY29uXCIgaHJlZj1cIi9mYXZpY29uLmljb1wiIC8+XG4gICAgICA8L0hlYWQ+XG4gICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTUgYm9yZGVyLTIgc2hhZG93LW1kIHJvdW5kZWQtbWRcIj5cbiAgICAgICAgPENhcmRCb2R5PlxuICAgICAgICAgIDxGb3JtaWtcbiAgICAgICAgICAgIGluaXRpYWxWYWx1ZXM9e3tcbiAgICAgICAgICAgICAgcmVzdWx0OiBbXSxcbiAgICAgICAgICAgICAgYW5zd2VyOiBcIlwiLFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIG9uU3VibWl0PXsodmFsdWVzLCBzZXRTdWJtaXR0aW5nKSA9PiB7XG4gICAgICAgICAgICAgIGlmIChwcm9wcy5yZXN1bHQ/Lmxlbmd0aCA+IDAgJiYgZGF0YSkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwicmVzdWx0IGxlbmd0aFwiLCBwcm9wcy5yZXN1bHQ/Lmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0TGVuZ3RoID0gcHJvcHMucmVzdWx0Py5sZW5ndGg7XG4gICAgICAgICAgICAgICAgLy8gZm9yIChsZXQgaSA9IDA7IGkgPCByZXN1bHRMZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIC8vICAgY29uc29sZS5sb2coXCJyZXN1bHQgbWFwXCIpO1xuICAgICAgICAgICAgICAgIC8vIH1cblxuICAgICAgICAgICAgICAgIHByb3BzLnJlc3VsdD8ubWFwKChyKSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInJlc3VsdCBtYXBcIik7XG4gICAgICAgICAgICAgICAgICBkYXRhPy5tYXAoKGQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJkYXRhIG1hcFwiKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHIucXVlc3Rpb25faWQgPT0gZC5pZCkge1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwici5xdWVzdGlvbl9pZFwiLCByLnF1ZXN0aW9uX2lkLCBcImQuaWRcIiwgZC5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGQuU1BEID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzZXRDb21wYW55KC4uLmNvbXBhbnksIGNvbXBhbnkuU1BEICsgMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlNQRFwiKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGQuQ0RVID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzZXRDb21wYW55KC4uLmNvbXBhbnksIGNvbXBhbnkuQ0RVICsgMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNEVVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGQuQWZEID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzZXRDb21wYW55KC4uLmNvbXBhbnksIGNvbXBhbnkuQWZEICsgMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkFmRFwiKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGQuRkRQID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzZXRDb21wYW55KC4uLmNvbXBhbnksIGNvbXBhbnkuRkRQICsgMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkZEUFwiKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGQuR3LDvG5lID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzZXRDb21wYW55KC4uLmNvbXBhbnksIGNvbXBhbnkuR3LDvG5lICsgMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkdyw7xuZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGQuTGlua2UgPT0gci5hbnN3ZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHNldENvbXBhbnkoLi4uY29tcGFueSwgY29tcGFueS5MaW5rZSArIDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJMaW5rZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJlbHNlIGZyb20gbGFzdCBpZlwiKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJzdWJtaXQgY2xpY2tcIik7XG4gICAgICAgICAgICAgIC8vIGF4aW9zXG4gICAgICAgICAgICAgIC8vICAgLnBvc3QoXCJodHRwczovL3VkaXRzb2x1dGlvbnMuaW4veWFybi9wdWJsaWMvYXBpL3Njb3Jlc1wiLCBkYXRhKVxuICAgICAgICAgICAgICAvLyAgIC50aGVuKChyZXMpID0+IHtcbiAgICAgICAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKHJlcyk7XG4gICAgICAgICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhcImludGlhbCB2YWx1ZSBpcyBzdWJtaXRlZCB0byByZXN1bHRzXCIpO1xuICAgICAgICAgICAgICAvLyAgICAgcmVzdWx0ID0gW107XG4gICAgICAgICAgICAgIC8vICAgICBoaXN0b3J5LnB1c2goXCIvdGhhbmt5b3VcIik7XG4gICAgICAgICAgICAgIC8vICAgfSlcbiAgICAgICAgICAgICAgLy8gICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICAgICAgICAvLyAgICAgY29uc29sZS5sb2coZXJyLnJlc3BvbnNlLmRhdGEpO1xuICAgICAgICAgICAgICAvLyAgICAgLy8gaGlzdG9yeS5wdXNoKFwiL2V4YW0tYXBwZWFyZWRcIik7XG5cbiAgICAgICAgICAgICAgLy8gICB9KTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgeyh7IGhhbmRsZVN1Ym1pdCB9KSA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPEZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XG4gICAgICAgICAgICAgICAgICB7ZGF0YT8ubWFwKChkLCBpZCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtkLmlkfSBjbGFzc05hbWU9XCJtdC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2FyZFRpdGxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7XCIgXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtkLmlkfS97ZGF0YUxlbmd0aH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQ2FyZFRpdGxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcmRTdWJ0aXRsZT57ZC5TY2hsYWd3b3J0fTwvQ2FyZFN1YnRpdGxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcmRUZXh0PntkLnF1ZXN0aW9uX3RleHR9PC9DYXJkVGV4dD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGaWVsZEFycmF5XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZXN1bHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICByZW5kZXI9eyhhcnJheUhlbHBlcnMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJvdz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q29sPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0R3JvdXAgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29wdGlvbnM/Lm1hcCgob3B0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e29wdC5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgYmctZ3JheS02MDAgdGV4dC13aGl0ZSByb3VuZGVkLW1kIHRleHQtY2VudGVyIGhvdmVyOmJnLXllbGxvdy0zMDAgaG92ZXI6dGV4dC1ibGFjayBtYi0xXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhZGlvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIG5hbWU9XCJhbnN3ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e29wdC5vcHRpb25fVmFsdWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VmFsdWUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uX2lkOiBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjogb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBpID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGkgPCByZXN1bHQubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaSsrXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdFtpXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8ucXVlc3Rpb25faWQgPT0gZC5pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic3BsaWNlXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQuc3BsaWNlKGksIDEsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHQub3B0aW9uX1ZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0W2ldXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnF1ZXN0aW9uX2lkICE9PSBkLmlkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbHNlX2lmIHF1ZXN0aW9uIG9mIGRhdGFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwicmVzdWx0IHEtaWRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV0ucXVlc3Rpb25faWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25faWQ6IGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcHMucmVzdWx0U2V0RGF0YShyZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZWxzZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjogb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wcy5yZXN1bHRTZXREYXRhKHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3B0Lm9wdGlvbl90ZXh0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOntcIiBcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZXN1bHQ/Lm1hcCgocikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoci5xdWVzdGlvbl9pZCA9PSBkLmlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHIuYW5zd2VyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvSW5wdXRHcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIGJsb2NrXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLTIgcC0yIGJvcmRlci1ibGFjayBtdC03XCJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAvLyBvbkNsaWNrPXtoYW5kbGVTdWJtaXR9XG4gICAgICAgICAgICAgICAgICAgICAgLy8gZGlzYWJsZWQ9e2Zvcm1Qcm9wcy5pc1N1Ym1pdHRpbmd9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICBFZWdlYm5pcyB6ZWlnZW5cbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L0Zvcm0+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgIDwvRm9ybWlrPlxuICAgICAgICA8L0NhcmRCb2R5PlxuICAgICAgPC9DYXJkPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5jb25zdCBtYXBTdGF0ZVRvUHJvcHMgPSAoc3RhdGUpID0+IHtcbiAgcmV0dXJuIHtcbiAgICByZXN1bHQ6IHN0YXRlLnJlc3VsdC5yZXN1bHQsXG4gIH07XG59O1xuXG5jb25zdCBtYXBEaXNwYXRjaFRvUHJvcHMgPSAoZGlzcGF0Y2gpID0+IHtcbiAgcmV0dXJuIHtcbiAgICByZXN1bHRTZXREYXRhOiAoZGF0YSkgPT4gZGlzcGF0Y2goYWN0aW9ucy5yZXN1bHRTZXREYXRhKGRhdGEpKSxcbiAgICBvbkRlbGV0ZVJlc3VsdDogKGRhdGEsIGlkKSA9PiBkaXNwYXRjaChhY3Rpb25zLmRlbGV0ZVJlc3VsdChkYXRhLCBpZCkpLFxuICAgIG9uUG9zdFJlc3VsdERhdGE6IChkYXRhLCB1c2VyLCB0b2dnbGUpID0+XG4gICAgICBkaXNwYXRjaChhY3Rpb25zLnBvc3RSZXN1bHREYXRhKGRhdGEsIHVzZXIsIHRvZ2dsZSkpLFxuICAgIG9uVXBkYXRlUmVzdWx0RGF0YTogKGRhdGEsIHVzZXIsIHRvZ2dsZSkgPT5cbiAgICAgIGRpc3BhdGNoKGFjdGlvbnMudXBkYXRlUmVzdWx0RGF0YShkYXRhLCB1c2VyLCB0b2dnbGUpKSxcbiAgICByZXN1bHRFZGl0R2V0RGF0YTogKGRhdGEpID0+IGRpc3BhdGNoKGFjdGlvbnMucmVzdWx0RWRpdEdldERhdGEoZGF0YSkpLFxuICB9O1xufTtcbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QobWFwU3RhdGVUb1Byb3BzLCBtYXBEaXNwYXRjaFRvUHJvcHMpKEhvbWUpO1xuIl0sIm5hbWVzIjpbImF4aW9zIiwiRmllbGQiLCJGaWVsZEFycmF5IiwiRm9ybWlrIiwiSGVhZCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiQnV0dG9uIiwiQ2FyZCIsIkNhcmRCb2R5IiwiQ2FyZEhlYWRlciIsIkNhcmRTdWJ0aXRsZSIsIkNhcmRUZXh0IiwiQ2FyZFRpdGxlIiwiQ29sIiwiRm9ybSIsIkZvcm1Hcm91cCIsIklucHV0R3JvdXAiLCJSb3ciLCJkYXRhIiwib3B0aW9ucyIsImNvbm5lY3QiLCJhY3Rpb25zIiwidXNlSGlzdG9yeSIsInJlc3VsdCIsIkFycmF5IiwiTWFpblJlc3VsdCIsIkhvbWUiLCJwcm9wcyIsInZhbHVlIiwic2V0VmFsdWUiLCJoaXN0b3J5IiwiQ0RVIiwiU1BEIiwiQWZEIiwiRkRQIiwiR3LDvG5lIiwiTGlua2UiLCJjb21wYW55Iiwic2V0Q29tcGFueSIsImNvbnNvbGUiLCJsb2ciLCJoYW5kbGVTdWJtaXQiLCJ2YWx1ZXMiLCJzZXRTdWJtaXR0aW5nIiwibWFwIiwiciIsImQiLCJxdWVzdGlvbl9pZCIsIkNTVSIsImFuc3dlciIsInBvc3QiLCJ0aGVuIiwicmVzIiwicHVzaCIsImVyciIsInJlc3BvbnNlIiwiZGF0YUxlbmd0aCIsImxlbmd0aCIsInJlc3VsdExlbmd0aCIsImlkIiwiU2NobGFnd29ydCIsInF1ZXN0aW9uX3RleHQiLCJhcnJheUhlbHBlcnMiLCJvcHQiLCJvcHRpb25fVmFsdWUiLCJpIiwic3BsaWNlIiwicmVzdWx0U2V0RGF0YSIsIm9wdGlvbl90ZXh0IiwibWFwU3RhdGVUb1Byb3BzIiwic3RhdGUiLCJtYXBEaXNwYXRjaFRvUHJvcHMiLCJkaXNwYXRjaCIsIm9uRGVsZXRlUmVzdWx0IiwiZGVsZXRlUmVzdWx0Iiwib25Qb3N0UmVzdWx0RGF0YSIsInVzZXIiLCJ0b2dnbGUiLCJwb3N0UmVzdWx0RGF0YSIsIm9uVXBkYXRlUmVzdWx0RGF0YSIsInVwZGF0ZVJlc3VsdERhdGEiLCJyZXN1bHRFZGl0R2V0RGF0YSJdLCJzb3VyY2VSb290IjoiIn0=