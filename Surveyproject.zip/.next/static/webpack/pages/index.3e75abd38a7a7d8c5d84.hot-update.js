"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
/* harmony import */ var _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Data/Data.json */ "./components/Data/Data.json");
/* harmony import */ var _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Data/options.json */ "./components/Data/options.json");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _redux_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../redux/actions */ "./redux/actions/index.js");
/* harmony import */ var react_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-router */ "./node_modules/react-router/esm/react-router.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "E:\\git vinraj\\company-test\\pages\\index.js",
    _s = $RefreshSig$();

function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }












var result = new Array();
var MainResult = new Array();

function Home(props) {
  _s();

  var _this = this;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      value = _useState[0],
      setValue = _useState[1];

  var history = (0,react_router__WEBPACK_IMPORTED_MODULE_9__.useHistory)();

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
    CDU: 0,
    SPD: 0,
    AfD: 0,
    FDP: 0,
    Grüne: 0,
    Linke: 0
  }),
      company = _useState2[0],
      setCompany = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0),
      CDU = _useState3[0],
      setCDU = _useState3[1];

  var _useState4 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0),
      SPD = _useState4[0],
      setSPD = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0),
      AfD = _useState5[0],
      setAfD = _useState5[1];

  var _useState6 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0),
      FDP = _useState6[0],
      setFDP = _useState6[1];

  var _useState7 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0),
      Grüne = _useState7[0],
      setGrüne = _useState7[1];

  var _useState8 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0),
      Linke = _useState8[0],
      setLinke = _useState8[1];

  console.log("props.result", props.result);
  console.log("value", value);
  console.log("array", result);
  console.log("CDU", CDU);
  console.log("SPD", SPD);
  console.log("AfD", AfD);
  console.log("FDP", FDP);
  console.log("Grüne", Grüne);
  console.log("Linke", Linke);
  var dataLength = _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === null || _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === void 0 ? void 0 : _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.length;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
    className: "",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("title", {
        children: "Create Next App"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 62,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Card, {
      className: "p-5 border-2 shadow-md rounded-md",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardBody, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
          initialValues: {
            result: [],
            answer: ""
          },
          onSubmit: function onSubmit(values, setSubmitting) {
            var _props$result;

            // setSPD(SPD + 1);
            if (((_props$result = props.result) === null || _props$result === void 0 ? void 0 : _props$result.length) > 0) {
              var _props$result2, _props$result3;

              console.log("result length", (_props$result2 = props.result) === null || _props$result2 === void 0 ? void 0 : _props$result2.length);
              var resultLength = (_props$result3 = props.result) === null || _props$result3 === void 0 ? void 0 : _props$result3.length;

              var _iterator = _createForOfIteratorHelper(props.result),
                  _step;

              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  var r = _step.value;
                  console.log("result map");

                  var _iterator2 = _createForOfIteratorHelper(_components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__),
                      _step2;

                  try {
                    for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                      var d = _step2.value;
                      console.log("data map");

                      if (r.question_id == d.id) {
                        console.log("r.question_id", r.question_id, "d.id", d.id);

                        if (d.SPD == r.answer) {
                          console.log("SPD", SPD);
                          setSPD(SPD + 1);
                          console.log("SPD", SPD);
                        }

                        if (d.CDU == r.answer) {
                          console.log("CDU", CDU);
                          setCDU(CDU + 1);
                        }

                        if (d.AfD == r.answer) {
                          console.log("AfD");
                          setAfD(AfD + 1);
                        }

                        if (d.FDP == r.answer) {
                          console.log("FDP");
                          setFDP(FDP + 1);
                        }

                        if (d.Grüne == r.answer) {
                          console.log("Grüne");
                          setGrüne(Grüne + 1);
                        }

                        if (d.Linke == r.answer) {
                          console.log("Linke");
                          setLinke(Linke + 1);
                        } else {
                          console.log("else from last if");
                        }
                      }
                    }
                  } catch (err) {
                    _iterator2.e(err);
                  } finally {
                    _iterator2.f();
                  }
                } // props.result?.map((r) => {
                //   console.log("result map");
                //   data?.map((d) => {
                //     console.log("data map");
                //     if (r.question_id == d.id) {
                //       console.log("r.question_id", r.question_id, "d.id", d.id);
                //       if (d.SPD == r.answer) {
                //         console.log("SPD");
                //         setSPD(...SPD, SPD + 1);
                //       }
                //       if (d.CDU == r.answer) {
                //         console.log("CDU");
                //         setCDU(...CDU, CDU + 1);
                //       }
                //       if (d.AfD == r.answer) {
                //         console.log("AfD");
                //         setAfD(...AfD, AfD + 1);
                //       }
                //       if (d.FDP == r.answer) {
                //         console.log("FDP");
                //         setFDP(...FDP, FDP + 1);
                //       }
                //       if (d.Grüne == r.answer) {
                //         console.log("Grüne");
                //         setGrüne(...Grüne, Grüne + 1);
                //       }
                //       if (d.Linke == r.answer) {
                //         console.log("Linke");
                //         setLinke(...Linke, Linke + 1);
                //       } else {
                //         console.log("else from last if");
                //       }
                //     }
                //   });
                // });

              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }
            } // let graphData = {
            //   CDU: CDU,
            //   SPD: SPD,
            //   AfD: AfD,
            //   FDP: FDP,
            //   Grüne: Grüne,
            //   Linke: Linke,
            // };


            var graphData = [CDU, SPD, AfD, FDP, Grüne, Linke];
            props.resultEditSetData(graphData);
            console.log("submit click"); // axios
            //   .post("https://uditsolutions.in/yarn/public/api/scores", data)
            //   .then((res) => {
            //     console.log(res);
            //     console.log("intial value is submited to results");
            //     result = [];
            //     history.push("/thankyou");
            //   })
            //   .catch((err) => {
            //     console.log(err.response.data);
            //     // history.push("/exam-appeared");
            //   });
          },
          children: function children(_ref) {
            var handleSubmit = _ref.handleSubmit;
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Form, {
              onSubmit: handleSubmit,
              children: [_components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === null || _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === void 0 ? void 0 : _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.map(function (d, id) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                  className: "mt-3",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardTitle, {
                    children: [" ", d.id, "/", dataLength]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 188,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardSubtitle, {
                    children: d.Schlagwort
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 192,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardText, {
                    children: d.question_text
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 193,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.FieldArray, {
                    name: "result",
                    render: function render(arrayHelpers) {
                      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Row, {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Col, {
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.FormGroup, {
                              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.InputGroup, {
                                className: "flex flex-col mt-2",
                                children: _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === null || _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === void 0 ? void 0 : _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__.map(function (opt) {
                                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("label", {
                                    className: "p-2 bg-gray-600 text-white rounded-md text-center hover:bg-yellow-300 hover:text-black mb-1",
                                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                                      type: "radio" // name="answer"
                                      ,
                                      value: opt.option_Value,
                                      className: "hidden",
                                      onChange: function onChange() {
                                        setValue({
                                          question_id: d.id,
                                          answer: opt.option_Value
                                        });

                                        if (result.length > 0) {
                                          for (var i = 0; i < result.length; i++) {
                                            var _result$i;

                                            if (((_result$i = result[i]) === null || _result$i === void 0 ? void 0 : _result$i.question_id) == d.id) {
                                              console.log("splice");
                                              result.splice(i, 1, {
                                                question_id: d.id,
                                                answer: opt.option_Value
                                              });
                                              props.resultSetData(result);
                                              return;
                                            } else if (result[i].question_id !== d.id) {
                                              console.log("else_if question of data", d.id, "result q-id", result[i].question_id);
                                              result.push({
                                                question_id: d.id,
                                                answer: opt.option_Value
                                              });
                                              props.resultSetData(result);
                                              return;
                                            }
                                          }

                                          props.resultSetData(result);
                                        } else {
                                          console.log("else");
                                          result.push({
                                            question_id: d.id,
                                            answer: opt.option_Value
                                          });
                                          props.resultSetData(result);
                                        }
                                      }
                                    }, void 0, false, {
                                      fileName: _jsxFileName,
                                      lineNumber: 209,
                                      columnNumber: 47
                                    }, _this), opt.option_text]
                                  }, opt.id, true, {
                                    fileName: _jsxFileName,
                                    lineNumber: 205,
                                    columnNumber: 45
                                  }, _this);
                                })
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 202,
                                columnNumber: 39
                              }, _this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 201,
                              columnNumber: 37
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 200,
                            columnNumber: 35
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 199,
                          columnNumber: 33
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 198,
                        columnNumber: 31
                      }, _this);
                    }
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 194,
                    columnNumber: 25
                  }, _this)]
                }, d.id, true, {
                  fileName: _jsxFileName,
                  lineNumber: 187,
                  columnNumber: 23
                }, _this);
              }), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Button, {
                  block: true,
                  className: "border-2 p-2 border-black mt-7",
                  type: "submit" // onClick={handleSubmit}
                  // disabled={formProps.isSubmitting}
                  ,
                  children: "Eegebnis zeigen"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 299,
                  columnNumber: 21
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 298,
                columnNumber: 19
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 184,
              columnNumber: 17
            }, _this);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 68,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 67,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 66,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 61,
    columnNumber: 5
  }, this);
}

_s(Home, "ea2M+Wy0wZipXmzz6sFKfCdQsqY=", false, function () {
  return [react_router__WEBPACK_IMPORTED_MODULE_9__.useHistory];
});

_c = Home;

var mapStateToProps = function mapStateToProps(state) {
  return {
    result: state.result.result
  };
};

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    resultSetData: function resultSetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultSetData(data));
    },
    onDeleteResult: function onDeleteResult(data, id) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.deleteResult(data, id));
    },
    onPostResultData: function onPostResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.postResultData(data, user, toggle));
    },
    onUpdateResultData: function onUpdateResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.updateResultData(data, user, toggle));
    },
    resultEditGetData: function resultEditGetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultEditGetData(data));
    }
  };
};

/* harmony default export */ __webpack_exports__["default"] = ((0,react_redux__WEBPACK_IMPORTED_MODULE_6__.connect)(mapStateToProps, mapDispatchToProps)(Home));

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguM2U3NWFiZDM4YTdhN2Q4YzVkODQuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFjQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLElBQUl3QixNQUFNLEdBQUcsSUFBSUMsS0FBSixFQUFiO0FBQ0EsSUFBSUMsVUFBVSxHQUFHLElBQUlELEtBQUosRUFBakI7O0FBQ0EsU0FBU0UsSUFBVCxDQUFjQyxLQUFkLEVBQXFCO0FBQUE7O0FBQUE7O0FBQ25CLGtCQUEwQnRCLCtDQUFRLENBQUMsRUFBRCxDQUFsQztBQUFBLE1BQU91QixLQUFQO0FBQUEsTUFBY0MsUUFBZDs7QUFDQSxNQUFNQyxPQUFPLEdBQUdSLHdEQUFVLEVBQTFCOztBQUVBLG1CQUE4QmpCLCtDQUFRLENBQUM7QUFDckMwQixJQUFBQSxHQUFHLEVBQUUsQ0FEZ0M7QUFFckNDLElBQUFBLEdBQUcsRUFBRSxDQUZnQztBQUdyQ0MsSUFBQUEsR0FBRyxFQUFFLENBSGdDO0FBSXJDQyxJQUFBQSxHQUFHLEVBQUUsQ0FKZ0M7QUFLckNDLElBQUFBLEtBQUssRUFBRSxDQUw4QjtBQU1yQ0MsSUFBQUEsS0FBSyxFQUFFO0FBTjhCLEdBQUQsQ0FBdEM7QUFBQSxNQUFPQyxPQUFQO0FBQUEsTUFBZ0JDLFVBQWhCOztBQVNBLG1CQUFzQmpDLCtDQUFRLENBQUMsQ0FBRCxDQUE5QjtBQUFBLE1BQU8wQixHQUFQO0FBQUEsTUFBWVEsTUFBWjs7QUFDQSxtQkFBc0JsQywrQ0FBUSxDQUFDLENBQUQsQ0FBOUI7QUFBQSxNQUFPMkIsR0FBUDtBQUFBLE1BQVlRLE1BQVo7O0FBQ0EsbUJBQXNCbkMsK0NBQVEsQ0FBQyxDQUFELENBQTlCO0FBQUEsTUFBTzRCLEdBQVA7QUFBQSxNQUFZUSxNQUFaOztBQUNBLG1CQUFzQnBDLCtDQUFRLENBQUMsQ0FBRCxDQUE5QjtBQUFBLE1BQU82QixHQUFQO0FBQUEsTUFBWVEsTUFBWjs7QUFDQSxtQkFBMEJyQywrQ0FBUSxDQUFDLENBQUQsQ0FBbEM7QUFBQSxNQUFPOEIsS0FBUDtBQUFBLE1BQWNRLFFBQWQ7O0FBQ0EsbUJBQTBCdEMsK0NBQVEsQ0FBQyxDQUFELENBQWxDO0FBQUEsTUFBTytCLEtBQVA7QUFBQSxNQUFjUSxRQUFkOztBQUVBQyxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBQTRCbkIsS0FBSyxDQUFDSixNQUFsQztBQUVBc0IsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFxQmxCLEtBQXJCO0FBRUFpQixFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQXFCdkIsTUFBckI7QUFDQXNCLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVosRUFBbUJmLEdBQW5CO0FBQ0FjLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVosRUFBbUJkLEdBQW5CO0FBQ0FhLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVosRUFBbUJiLEdBQW5CO0FBQ0FZLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVosRUFBbUJaLEdBQW5CO0FBQ0FXLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVosRUFBcUJYLEtBQXJCO0FBQ0FVLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVosRUFBcUJWLEtBQXJCO0FBRUEsTUFBTVcsVUFBVSxHQUFHN0IsdURBQUgsYUFBR0EsdURBQUgsdUJBQUdBLDhEQUFuQjtBQUNBLHNCQUNFO0FBQUssYUFBUyxFQUFDLEVBQWY7QUFBQSw0QkFDRSw4REFBQyxrREFBRDtBQUFBLDhCQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFRTtBQUFNLFdBQUcsRUFBQyxNQUFWO0FBQWlCLFlBQUksRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFLRSw4REFBQyw2Q0FBRDtBQUFNLGVBQVMsRUFBQyxtQ0FBaEI7QUFBQSw2QkFDRSw4REFBQyxpREFBRDtBQUFBLCtCQUNFLDhEQUFDLDBDQUFEO0FBQ0UsdUJBQWEsRUFBRTtBQUNiSyxZQUFBQSxNQUFNLEVBQUUsRUFESztBQUViMEIsWUFBQUEsTUFBTSxFQUFFO0FBRkssV0FEakI7QUFLRSxrQkFBUSxFQUFFLGtCQUFDQyxNQUFELEVBQVNDLGFBQVQsRUFBMkI7QUFBQTs7QUFDbkM7QUFDQSxnQkFBSSxrQkFBQXhCLEtBQUssQ0FBQ0osTUFBTixnRUFBY3lCLE1BQWQsSUFBdUIsQ0FBM0IsRUFBOEI7QUFBQTs7QUFDNUJILGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGVBQVosb0JBQTZCbkIsS0FBSyxDQUFDSixNQUFuQyxtREFBNkIsZUFBY3lCLE1BQTNDO0FBQ0Esa0JBQU1JLFlBQVkscUJBQUd6QixLQUFLLENBQUNKLE1BQVQsbURBQUcsZUFBY3lCLE1BQW5DOztBQUY0Qix5REFJWnJCLEtBQUssQ0FBQ0osTUFKTTtBQUFBOztBQUFBO0FBSTVCLG9FQUE4QjtBQUFBLHNCQUFuQjhCLENBQW1CO0FBQzVCUixrQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksWUFBWjs7QUFENEIsOERBRVo1Qix1REFGWTtBQUFBOztBQUFBO0FBRTVCLDJFQUFzQjtBQUFBLDBCQUFYb0MsQ0FBVztBQUNwQlQsc0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVo7O0FBQ0EsMEJBQUlPLENBQUMsQ0FBQ0UsV0FBRixJQUFpQkQsQ0FBQyxDQUFDRSxFQUF2QixFQUEyQjtBQUN6Qlgsd0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGVBQVosRUFBNkJPLENBQUMsQ0FBQ0UsV0FBL0IsRUFBNEMsTUFBNUMsRUFBb0RELENBQUMsQ0FBQ0UsRUFBdEQ7O0FBQ0EsNEJBQUlGLENBQUMsQ0FBQ3RCLEdBQUYsSUFBU3FCLENBQUMsQ0FBQ0osTUFBZixFQUF1QjtBQUNyQkosMEJBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVosRUFBbUJkLEdBQW5CO0FBQ0FRLDBCQUFBQSxNQUFNLENBQUNSLEdBQUcsR0FBRyxDQUFQLENBQU47QUFDQWEsMEJBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVosRUFBbUJkLEdBQW5CO0FBQ0Q7O0FBQ0QsNEJBQUlzQixDQUFDLENBQUN2QixHQUFGLElBQVNzQixDQUFDLENBQUNKLE1BQWYsRUFBdUI7QUFDckJKLDBCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaLEVBQW1CZixHQUFuQjtBQUNBUSwwQkFBQUEsTUFBTSxDQUFDUixHQUFHLEdBQUcsQ0FBUCxDQUFOO0FBQ0Q7O0FBQ0QsNEJBQUl1QixDQUFDLENBQUNyQixHQUFGLElBQVNvQixDQUFDLENBQUNKLE1BQWYsRUFBdUI7QUFDckJKLDBCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaO0FBQ0FMLDBCQUFBQSxNQUFNLENBQUNSLEdBQUcsR0FBRyxDQUFQLENBQU47QUFDRDs7QUFDRCw0QkFBSXFCLENBQUMsQ0FBQ3BCLEdBQUYsSUFBU21CLENBQUMsQ0FBQ0osTUFBZixFQUF1QjtBQUNyQkosMEJBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVo7QUFDQUosMEJBQUFBLE1BQU0sQ0FBQ1IsR0FBRyxHQUFHLENBQVAsQ0FBTjtBQUNEOztBQUNELDRCQUFJb0IsQ0FBQyxDQUFDbkIsS0FBRixJQUFXa0IsQ0FBQyxDQUFDSixNQUFqQixFQUF5QjtBQUN2QkosMEJBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7QUFDQUgsMEJBQUFBLFFBQVEsQ0FBQ1IsS0FBSyxHQUFHLENBQVQsQ0FBUjtBQUNEOztBQUNELDRCQUFJbUIsQ0FBQyxDQUFDbEIsS0FBRixJQUFXaUIsQ0FBQyxDQUFDSixNQUFqQixFQUF5QjtBQUN2QkosMEJBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7QUFDQUYsMEJBQUFBLFFBQVEsQ0FBQ1IsS0FBSyxHQUFHLENBQVQsQ0FBUjtBQUNELHlCQUhELE1BR087QUFDTFMsMEJBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLG1CQUFaO0FBQ0Q7QUFDRjtBQUNGO0FBbEMyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBbUM3QixpQkF2QzJCLENBeUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQTNFNEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQTRFN0IsYUE5RWtDLENBZ0ZuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFFQSxnQkFBSVcsU0FBUyxHQUFHLENBQUMxQixHQUFELEVBQU1DLEdBQU4sRUFBV0MsR0FBWCxFQUFnQkMsR0FBaEIsRUFBcUJDLEtBQXJCLEVBQTRCQyxLQUE1QixDQUFoQjtBQUVBVCxZQUFBQSxLQUFLLENBQUMrQixpQkFBTixDQUF3QkQsU0FBeEI7QUFFQVosWUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQTdGbUMsQ0E4Rm5DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNELFdBaEhIO0FBQUEsb0JBa0hHLHdCQUFzQjtBQUFBLGdCQUFuQmEsWUFBbUIsUUFBbkJBLFlBQW1CO0FBQ3JCLGdDQUNFLDhEQUFDLDZDQUFEO0FBQU0sc0JBQVEsRUFBRUEsWUFBaEI7QUFBQSx5QkFDR3pDLHVEQURILGFBQ0dBLHVEQURILHVCQUNHQSwyREFBQSxDQUFVLFVBQUNvQyxDQUFELEVBQUlFLEVBQUosRUFBVztBQUNwQixvQ0FDRTtBQUFnQiwyQkFBUyxFQUFDLE1BQTFCO0FBQUEsMENBQ0UsOERBQUMsa0RBQUQ7QUFBQSwrQkFDRyxHQURILEVBRUdGLENBQUMsQ0FBQ0UsRUFGTCxPQUVVVCxVQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFERixlQUtFLDhEQUFDLHFEQUFEO0FBQUEsOEJBQWVPLENBQUMsQ0FBQ087QUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFMRixlQU1FLDhEQUFDLGlEQUFEO0FBQUEsOEJBQVdQLENBQUMsQ0FBQ1E7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU5GLGVBT0UsOERBQUMsOENBQUQ7QUFDRSx3QkFBSSxFQUFDLFFBRFA7QUFFRSwwQkFBTSxFQUFFLGdCQUFDQyxZQUFELEVBQWtCO0FBQ3hCLDBDQUNFO0FBQUEsK0NBQ0UsOERBQUMsNENBQUQ7QUFBQSxpREFDRSw4REFBQyw0Q0FBRDtBQUFBLG1EQUNFLDhEQUFDLGtEQUFEO0FBQUEscURBQ0UsOERBQUMsbURBQUQ7QUFBWSx5Q0FBUyxFQUFDLG9CQUF0QjtBQUFBLDBDQUNHNUMsMERBREgsYUFDR0EsMERBREgsdUJBQ0dBLDhEQUFBLENBQWEsVUFBQzZDLEdBQUQsRUFBUztBQUNyQixzREFDRTtBQUVFLDZDQUFTLEVBQUMsNkZBRlo7QUFBQSw0REFJRSw4REFBQyx5Q0FBRDtBQUNFLDBDQUFJLEVBQUMsT0FEUCxDQUVFO0FBRkY7QUFHRSwyQ0FBSyxFQUFFQSxHQUFHLENBQUNDLFlBSGI7QUFJRSwrQ0FBUyxFQUFDLFFBSlo7QUFLRSw4Q0FBUSxFQUFFLG9CQUFNO0FBQ2RwQyx3Q0FBQUEsUUFBUSxDQUFDO0FBQ1AwQiwwQ0FBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNFLEVBRFI7QUFFUFAsMENBQUFBLE1BQU0sRUFBRWUsR0FBRyxDQUFDQztBQUZMLHlDQUFELENBQVI7O0FBS0EsNENBQUkxQyxNQUFNLENBQUN5QixNQUFQLEdBQWdCLENBQXBCLEVBQXVCO0FBQ3JCLCtDQUNFLElBQUlrQixDQUFDLEdBQUcsQ0FEVixFQUVFQSxDQUFDLEdBQUczQyxNQUFNLENBQUN5QixNQUZiLEVBR0VrQixDQUFDLEVBSEgsRUFJRTtBQUFBOztBQUNBLGdEQUNFLGNBQUEzQyxNQUFNLENBQUMyQyxDQUFELENBQU4sd0RBQ0lYLFdBREosS0FDbUJELENBQUMsQ0FBQ0UsRUFGdkIsRUFHRTtBQUNBWCw4Q0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWjtBQUNBdkIsOENBQUFBLE1BQU0sQ0FBQzRDLE1BQVAsQ0FBY0QsQ0FBZCxFQUFpQixDQUFqQixFQUFvQjtBQUNsQlgsZ0RBQUFBLFdBQVcsRUFBRUQsQ0FBQyxDQUFDRSxFQURHO0FBRWxCUCxnREFBQUEsTUFBTSxFQUNKZSxHQUFHLENBQUNDO0FBSFksK0NBQXBCO0FBTUF0Qyw4Q0FBQUEsS0FBSyxDQUFDeUMsYUFBTixDQUNFN0MsTUFERjtBQUdBO0FBQ0QsNkNBZkQsTUFlTyxJQUNMQSxNQUFNLENBQUMyQyxDQUFELENBQU4sQ0FDR1gsV0FESCxLQUNtQkQsQ0FBQyxDQUFDRSxFQUZoQixFQUdMO0FBQ0FYLDhDQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FDRSwwQkFERixFQUVFUSxDQUFDLENBQUNFLEVBRkosRUFHRSxhQUhGLEVBSUVqQyxNQUFNLENBQUMyQyxDQUFELENBQU4sQ0FBVVgsV0FKWjtBQU9BaEMsOENBQUFBLE1BQU0sQ0FBQzhDLElBQVAsQ0FBWTtBQUNWZCxnREFBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNFLEVBREw7QUFFVlAsZ0RBQUFBLE1BQU0sRUFDSmUsR0FBRyxDQUFDQztBQUhJLCtDQUFaO0FBS0F0Qyw4Q0FBQUEsS0FBSyxDQUFDeUMsYUFBTixDQUNFN0MsTUFERjtBQUdBO0FBQ0Q7QUFDRjs7QUFDREksMENBQUFBLEtBQUssQ0FBQ3lDLGFBQU4sQ0FBb0I3QyxNQUFwQjtBQUNELHlDQTVDRCxNQTRDTztBQUNMc0IsMENBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVo7QUFDQXZCLDBDQUFBQSxNQUFNLENBQUM4QyxJQUFQLENBQVk7QUFDVmQsNENBQUFBLFdBQVcsRUFBRUQsQ0FBQyxDQUFDRSxFQURMO0FBRVZQLDRDQUFBQSxNQUFNLEVBQUVlLEdBQUcsQ0FBQ0M7QUFGRiwyQ0FBWjtBQUlBdEMsMENBQUFBLEtBQUssQ0FBQ3lDLGFBQU4sQ0FBb0I3QyxNQUFwQjtBQUNEO0FBQ0Y7QUEvREg7QUFBQTtBQUFBO0FBQUE7QUFBQSw2Q0FKRixFQXFFR3lDLEdBQUcsQ0FBQ00sV0FyRVA7QUFBQSxxQ0FDT04sR0FBRyxDQUFDUixFQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkNBREY7QUF5RUQsaUNBMUVBO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBREY7QUFnR0Q7QUFuR0g7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFQRjtBQUFBLG1CQUFVRixDQUFDLENBQUNFLEVBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERjtBQStHRCxlQWhIQSxDQURILGVBa0hFO0FBQUsseUJBQVMsRUFBQyxxQkFBZjtBQUFBLHVDQUNFLDhEQUFDLCtDQUFEO0FBQ0UsdUJBQUssTUFEUDtBQUVFLDJCQUFTLEVBQUMsZ0NBRlo7QUFHRSxzQkFBSSxFQUFDLFFBSFAsQ0FJRTtBQUNBO0FBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWxIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREY7QUFnSUQ7QUFuUEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFpUUQ7O0dBbFNROUI7VUFFU0o7OztLQUZUSTs7QUFvU1QsSUFBTTZDLGVBQWUsR0FBRyxTQUFsQkEsZUFBa0IsQ0FBQ0MsS0FBRCxFQUFXO0FBQ2pDLFNBQU87QUFDTGpELElBQUFBLE1BQU0sRUFBRWlELEtBQUssQ0FBQ2pELE1BQU4sQ0FBYUE7QUFEaEIsR0FBUDtBQUdELENBSkQ7O0FBTUEsSUFBTWtELGtCQUFrQixHQUFHLFNBQXJCQSxrQkFBcUIsQ0FBQ0MsUUFBRCxFQUFjO0FBQ3ZDLFNBQU87QUFDTE4sSUFBQUEsYUFBYSxFQUFFLHVCQUFDbEQsSUFBRDtBQUFBLGFBQVV3RCxRQUFRLENBQUNyRCx5REFBQSxDQUFzQkgsSUFBdEIsQ0FBRCxDQUFsQjtBQUFBLEtBRFY7QUFFTHlELElBQUFBLGNBQWMsRUFBRSx3QkFBQ3pELElBQUQsRUFBT3NDLEVBQVA7QUFBQSxhQUFja0IsUUFBUSxDQUFDckQsd0RBQUEsQ0FBcUJILElBQXJCLEVBQTJCc0MsRUFBM0IsQ0FBRCxDQUF0QjtBQUFBLEtBRlg7QUFHTHFCLElBQUFBLGdCQUFnQixFQUFFLDBCQUFDM0QsSUFBRCxFQUFPNEQsSUFBUCxFQUFhQyxNQUFiO0FBQUEsYUFDaEJMLFFBQVEsQ0FBQ3JELDBEQUFBLENBQXVCSCxJQUF2QixFQUE2QjRELElBQTdCLEVBQW1DQyxNQUFuQyxDQUFELENBRFE7QUFBQSxLQUhiO0FBS0xFLElBQUFBLGtCQUFrQixFQUFFLDRCQUFDL0QsSUFBRCxFQUFPNEQsSUFBUCxFQUFhQyxNQUFiO0FBQUEsYUFDbEJMLFFBQVEsQ0FBQ3JELDREQUFBLENBQXlCSCxJQUF6QixFQUErQjRELElBQS9CLEVBQXFDQyxNQUFyQyxDQUFELENBRFU7QUFBQSxLQUxmO0FBT0xJLElBQUFBLGlCQUFpQixFQUFFLDJCQUFDakUsSUFBRDtBQUFBLGFBQVV3RCxRQUFRLENBQUNyRCw2REFBQSxDQUEwQkgsSUFBMUIsQ0FBRCxDQUFsQjtBQUFBO0FBUGQsR0FBUDtBQVNELENBVkQ7O0FBV0EsK0RBQWVFLG9EQUFPLENBQUNtRCxlQUFELEVBQWtCRSxrQkFBbEIsQ0FBUCxDQUE2Qy9DLElBQTdDLENBQWYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xuaW1wb3J0IHsgRmllbGQsIEZpZWxkQXJyYXksIEZvcm1payB9IGZyb20gXCJmb3JtaWtcIjtcbmltcG9ydCBIZWFkIGZyb20gXCJuZXh0L2hlYWRcIjtcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7XG4gIEJ1dHRvbixcbiAgQ2FyZCxcbiAgQ2FyZEJvZHksXG4gIENhcmRIZWFkZXIsXG4gIENhcmRTdWJ0aXRsZSxcbiAgQ2FyZFRleHQsXG4gIENhcmRUaXRsZSxcbiAgQ29sLFxuICBGb3JtLFxuICBGb3JtR3JvdXAsXG4gIElucHV0R3JvdXAsXG4gIFJvdyxcbn0gZnJvbSBcInJlYWN0c3RyYXBcIjtcbmltcG9ydCBkYXRhIGZyb20gXCIuLi9jb21wb25lbnRzL0RhdGEvRGF0YS5qc29uXCI7XG5pbXBvcnQgb3B0aW9ucyBmcm9tIFwiLi4vY29tcG9uZW50cy9EYXRhL29wdGlvbnMuanNvblwiO1xuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xuaW1wb3J0ICogYXMgYWN0aW9ucyBmcm9tIFwiLi4vcmVkdXgvYWN0aW9uc1wiO1xuaW1wb3J0IHsgdXNlSGlzdG9yeSB9IGZyb20gXCJyZWFjdC1yb3V0ZXJcIjtcblxudmFyIHJlc3VsdCA9IG5ldyBBcnJheSgpO1xudmFyIE1haW5SZXN1bHQgPSBuZXcgQXJyYXkoKTtcbmZ1bmN0aW9uIEhvbWUocHJvcHMpIHtcbiAgY29uc3QgW3ZhbHVlLCBzZXRWYWx1ZV0gPSB1c2VTdGF0ZSh7fSk7XG4gIGNvbnN0IGhpc3RvcnkgPSB1c2VIaXN0b3J5KCk7XG5cbiAgY29uc3QgW2NvbXBhbnksIHNldENvbXBhbnldID0gdXNlU3RhdGUoe1xuICAgIENEVTogMCxcbiAgICBTUEQ6IDAsXG4gICAgQWZEOiAwLFxuICAgIEZEUDogMCxcbiAgICBHcsO8bmU6IDAsXG4gICAgTGlua2U6IDAsXG4gIH0pO1xuXG4gIGNvbnN0IFtDRFUsIHNldENEVV0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW1NQRCwgc2V0U1BEXSA9IHVzZVN0YXRlKDApO1xuICBjb25zdCBbQWZELCBzZXRBZkRdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtGRFAsIHNldEZEUF0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW0dyw7xuZSwgc2V0R3LDvG5lXSA9IHVzZVN0YXRlKDApO1xuICBjb25zdCBbTGlua2UsIHNldExpbmtlXSA9IHVzZVN0YXRlKDApO1xuXG4gIGNvbnNvbGUubG9nKFwicHJvcHMucmVzdWx0XCIsIHByb3BzLnJlc3VsdCk7XG5cbiAgY29uc29sZS5sb2coXCJ2YWx1ZVwiLCB2YWx1ZSk7XG5cbiAgY29uc29sZS5sb2coXCJhcnJheVwiLCByZXN1bHQpO1xuICBjb25zb2xlLmxvZyhcIkNEVVwiLCBDRFUpO1xuICBjb25zb2xlLmxvZyhcIlNQRFwiLCBTUEQpO1xuICBjb25zb2xlLmxvZyhcIkFmRFwiLCBBZkQpO1xuICBjb25zb2xlLmxvZyhcIkZEUFwiLCBGRFApO1xuICBjb25zb2xlLmxvZyhcIkdyw7xuZVwiLCBHcsO8bmUpO1xuICBjb25zb2xlLmxvZyhcIkxpbmtlXCIsIExpbmtlKTtcblxuICBjb25zdCBkYXRhTGVuZ3RoID0gZGF0YT8ubGVuZ3RoO1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiXCI+XG4gICAgICA8SGVhZD5cbiAgICAgICAgPHRpdGxlPkNyZWF0ZSBOZXh0IEFwcDwvdGl0bGU+XG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cbiAgICAgIDwvSGVhZD5cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNSBib3JkZXItMiBzaGFkb3ctbWQgcm91bmRlZC1tZFwiPlxuICAgICAgICA8Q2FyZEJvZHk+XG4gICAgICAgICAgPEZvcm1pa1xuICAgICAgICAgICAgaW5pdGlhbFZhbHVlcz17e1xuICAgICAgICAgICAgICByZXN1bHQ6IFtdLFxuICAgICAgICAgICAgICBhbnN3ZXI6IFwiXCIsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgb25TdWJtaXQ9eyh2YWx1ZXMsIHNldFN1Ym1pdHRpbmcpID0+IHtcbiAgICAgICAgICAgICAgLy8gc2V0U1BEKFNQRCArIDEpO1xuICAgICAgICAgICAgICBpZiAocHJvcHMucmVzdWx0Py5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJyZXN1bHQgbGVuZ3RoXCIsIHByb3BzLnJlc3VsdD8ubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICBjb25zdCByZXN1bHRMZW5ndGggPSBwcm9wcy5yZXN1bHQ/Lmxlbmd0aDtcblxuICAgICAgICAgICAgICAgIGZvciAoY29uc3QgciBvZiBwcm9wcy5yZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwicmVzdWx0IG1hcFwiKTtcbiAgICAgICAgICAgICAgICAgIGZvciAoY29uc3QgZCBvZiBkYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZGF0YSBtYXBcIik7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyLnF1ZXN0aW9uX2lkID09IGQuaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInIucXVlc3Rpb25faWRcIiwgci5xdWVzdGlvbl9pZCwgXCJkLmlkXCIsIGQuaWQpO1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChkLlNQRCA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJTUERcIiwgU1BEKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNQRChTUEQgKyAxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiU1BEXCIsIFNQRCk7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIGlmIChkLkNEVSA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDRFVcIiwgQ0RVKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldENEVShDRFUgKyAxKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGQuQWZEID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkFmRFwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEFmRChBZkQgKyAxKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGQuRkRQID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkZEUFwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEZEUChGRFAgKyAxKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGQuR3LDvG5lID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkdyw7xuZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEdyw7xuZShHcsO8bmUgKyAxKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGQuTGlua2UgPT0gci5hbnN3ZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiTGlua2VcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRMaW5rZShMaW5rZSArIDEpO1xuICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImVsc2UgZnJvbSBsYXN0IGlmXCIpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIHByb3BzLnJlc3VsdD8ubWFwKChyKSA9PiB7XG4gICAgICAgICAgICAgICAgLy8gICBjb25zb2xlLmxvZyhcInJlc3VsdCBtYXBcIik7XG4gICAgICAgICAgICAgICAgLy8gICBkYXRhPy5tYXAoKGQpID0+IHtcbiAgICAgICAgICAgICAgICAvLyAgICAgY29uc29sZS5sb2coXCJkYXRhIG1hcFwiKTtcbiAgICAgICAgICAgICAgICAvLyAgICAgaWYgKHIucXVlc3Rpb25faWQgPT0gZC5pZCkge1xuICAgICAgICAgICAgICAgIC8vICAgICAgIGNvbnNvbGUubG9nKFwici5xdWVzdGlvbl9pZFwiLCByLnF1ZXN0aW9uX2lkLCBcImQuaWRcIiwgZC5pZCk7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgaWYgKGQuU1BEID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgICBjb25zb2xlLmxvZyhcIlNQRFwiKTtcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIHNldFNQRCguLi5TUEQsIFNQRCArIDEpO1xuICAgICAgICAgICAgICAgIC8vICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyAgICAgICBpZiAoZC5DRFUgPT0gci5hbnN3ZXIpIHtcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIGNvbnNvbGUubG9nKFwiQ0RVXCIpO1xuICAgICAgICAgICAgICAgIC8vICAgICAgICAgc2V0Q0RVKC4uLkNEVSwgQ0RVICsgMSk7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgfVxuICAgICAgICAgICAgICAgIC8vICAgICAgIGlmIChkLkFmRCA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICAgIC8vICAgICAgICAgY29uc29sZS5sb2coXCJBZkRcIik7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgICBzZXRBZkQoLi4uQWZELCBBZkQgKyAxKTtcbiAgICAgICAgICAgICAgICAvLyAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gICAgICAgaWYgKGQuRkRQID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgICBjb25zb2xlLmxvZyhcIkZEUFwiKTtcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIHNldEZEUCguLi5GRFAsIEZEUCArIDEpO1xuICAgICAgICAgICAgICAgIC8vICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyAgICAgICBpZiAoZC5HcsO8bmUgPT0gci5hbnN3ZXIpIHtcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIGNvbnNvbGUubG9nKFwiR3LDvG5lXCIpO1xuICAgICAgICAgICAgICAgIC8vICAgICAgICAgc2V0R3LDvG5lKC4uLkdyw7xuZSwgR3LDvG5lICsgMSk7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgfVxuICAgICAgICAgICAgICAgIC8vICAgICAgIGlmIChkLkxpbmtlID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgICBjb25zb2xlLmxvZyhcIkxpbmtlXCIpO1xuICAgICAgICAgICAgICAgIC8vICAgICAgICAgc2V0TGlua2UoLi4uTGlua2UsIExpbmtlICsgMSk7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIGNvbnNvbGUubG9nKFwiZWxzZSBmcm9tIGxhc3QgaWZcIik7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgfVxuICAgICAgICAgICAgICAgIC8vICAgICB9XG4gICAgICAgICAgICAgICAgLy8gICB9KTtcbiAgICAgICAgICAgICAgICAvLyB9KTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIC8vIGxldCBncmFwaERhdGEgPSB7XG4gICAgICAgICAgICAgIC8vICAgQ0RVOiBDRFUsXG4gICAgICAgICAgICAgIC8vICAgU1BEOiBTUEQsXG4gICAgICAgICAgICAgIC8vICAgQWZEOiBBZkQsXG4gICAgICAgICAgICAgIC8vICAgRkRQOiBGRFAsXG4gICAgICAgICAgICAgIC8vICAgR3LDvG5lOiBHcsO8bmUsXG4gICAgICAgICAgICAgIC8vICAgTGlua2U6IExpbmtlLFxuICAgICAgICAgICAgICAvLyB9O1xuXG4gICAgICAgICAgICAgIGxldCBncmFwaERhdGEgPSBbQ0RVLCBTUEQsIEFmRCwgRkRQLCBHcsO8bmUsIExpbmtlXTtcblxuICAgICAgICAgICAgICBwcm9wcy5yZXN1bHRFZGl0U2V0RGF0YShncmFwaERhdGEpO1xuXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic3VibWl0IGNsaWNrXCIpO1xuICAgICAgICAgICAgICAvLyBheGlvc1xuICAgICAgICAgICAgICAvLyAgIC5wb3N0KFwiaHR0cHM6Ly91ZGl0c29sdXRpb25zLmluL3lhcm4vcHVibGljL2FwaS9zY29yZXNcIiwgZGF0YSlcbiAgICAgICAgICAgICAgLy8gICAudGhlbigocmVzKSA9PiB7XG4gICAgICAgICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhyZXMpO1xuICAgICAgICAgICAgICAvLyAgICAgY29uc29sZS5sb2coXCJpbnRpYWwgdmFsdWUgaXMgc3VibWl0ZWQgdG8gcmVzdWx0c1wiKTtcbiAgICAgICAgICAgICAgLy8gICAgIHJlc3VsdCA9IFtdO1xuICAgICAgICAgICAgICAvLyAgICAgaGlzdG9yeS5wdXNoKFwiL3RoYW5reW91XCIpO1xuICAgICAgICAgICAgICAvLyAgIH0pXG4gICAgICAgICAgICAgIC8vICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKGVyci5yZXNwb25zZS5kYXRhKTtcbiAgICAgICAgICAgICAgLy8gICAgIC8vIGhpc3RvcnkucHVzaChcIi9leGFtLWFwcGVhcmVkXCIpO1xuXG4gICAgICAgICAgICAgIC8vICAgfSk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHsoeyBoYW5kbGVTdWJtaXQgfSkgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxGb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxuICAgICAgICAgICAgICAgICAge2RhdGE/Lm1hcCgoZCwgaWQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17ZC5pZH0gY2xhc3NOYW1lPVwibXQtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcmRUaXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge1wiIFwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZC5pZH0ve2RhdGFMZW5ndGh9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NhcmRUaXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkU3VidGl0bGU+e2QuU2NobGFnd29ydH08L0NhcmRTdWJ0aXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkVGV4dD57ZC5xdWVzdGlvbl90ZXh0fTwvQ2FyZFRleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRBcnJheVxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVzdWx0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVuZGVyPXsoYXJyYXlIZWxwZXJzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSb3c+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dEdyb3VwIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcHRpb25zPy5tYXAoKG9wdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtvcHQuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGJnLWdyYXktNjAwIHRleHQtd2hpdGUgcm91bmRlZC1tZCB0ZXh0LWNlbnRlciBob3ZlcjpiZy15ZWxsb3ctMzAwIGhvdmVyOnRleHQtYmxhY2sgbWItMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBuYW1lPVwiYW5zd2VyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtvcHQub3B0aW9uX1ZhbHVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFZhbHVlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6IG9wdC5vcHRpb25fVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgaSA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpIDwgcmVzdWx0Lmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGkrK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/LnF1ZXN0aW9uX2lkID09IGQuaWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInNwbGljZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnNwbGljZShpLCAxLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25faWQ6IGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcHMucmVzdWx0U2V0RGF0YShcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0W2ldXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnF1ZXN0aW9uX2lkICE9PSBkLmlkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbHNlX2lmIHF1ZXN0aW9uIG9mIGRhdGFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwicmVzdWx0IHEtaWRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV0ucXVlc3Rpb25faWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25faWQ6IGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3BzLnJlc3VsdFNldERhdGEoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcHMucmVzdWx0U2V0RGF0YShyZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZWxzZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjogb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wcy5yZXN1bHRTZXREYXRhKHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3B0Lm9wdGlvbl90ZXh0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOntcIiBcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZXN1bHQ/Lm1hcCgocikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoci5xdWVzdGlvbl9pZCA9PSBkLmlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHIuYW5zd2VyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvSW5wdXRHcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIGJsb2NrXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLTIgcC0yIGJvcmRlci1ibGFjayBtdC03XCJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAvLyBvbkNsaWNrPXtoYW5kbGVTdWJtaXR9XG4gICAgICAgICAgICAgICAgICAgICAgLy8gZGlzYWJsZWQ9e2Zvcm1Qcm9wcy5pc1N1Ym1pdHRpbmd9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICBFZWdlYm5pcyB6ZWlnZW5cbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L0Zvcm0+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgIDwvRm9ybWlrPlxuICAgICAgICA8L0NhcmRCb2R5PlxuICAgICAgPC9DYXJkPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5jb25zdCBtYXBTdGF0ZVRvUHJvcHMgPSAoc3RhdGUpID0+IHtcbiAgcmV0dXJuIHtcbiAgICByZXN1bHQ6IHN0YXRlLnJlc3VsdC5yZXN1bHQsXG4gIH07XG59O1xuXG5jb25zdCBtYXBEaXNwYXRjaFRvUHJvcHMgPSAoZGlzcGF0Y2gpID0+IHtcbiAgcmV0dXJuIHtcbiAgICByZXN1bHRTZXREYXRhOiAoZGF0YSkgPT4gZGlzcGF0Y2goYWN0aW9ucy5yZXN1bHRTZXREYXRhKGRhdGEpKSxcbiAgICBvbkRlbGV0ZVJlc3VsdDogKGRhdGEsIGlkKSA9PiBkaXNwYXRjaChhY3Rpb25zLmRlbGV0ZVJlc3VsdChkYXRhLCBpZCkpLFxuICAgIG9uUG9zdFJlc3VsdERhdGE6IChkYXRhLCB1c2VyLCB0b2dnbGUpID0+XG4gICAgICBkaXNwYXRjaChhY3Rpb25zLnBvc3RSZXN1bHREYXRhKGRhdGEsIHVzZXIsIHRvZ2dsZSkpLFxuICAgIG9uVXBkYXRlUmVzdWx0RGF0YTogKGRhdGEsIHVzZXIsIHRvZ2dsZSkgPT5cbiAgICAgIGRpc3BhdGNoKGFjdGlvbnMudXBkYXRlUmVzdWx0RGF0YShkYXRhLCB1c2VyLCB0b2dnbGUpKSxcbiAgICByZXN1bHRFZGl0R2V0RGF0YTogKGRhdGEpID0+IGRpc3BhdGNoKGFjdGlvbnMucmVzdWx0RWRpdEdldERhdGEoZGF0YSkpLFxuICB9O1xufTtcbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QobWFwU3RhdGVUb1Byb3BzLCBtYXBEaXNwYXRjaFRvUHJvcHMpKEhvbWUpO1xuIl0sIm5hbWVzIjpbImF4aW9zIiwiRmllbGQiLCJGaWVsZEFycmF5IiwiRm9ybWlrIiwiSGVhZCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiQnV0dG9uIiwiQ2FyZCIsIkNhcmRCb2R5IiwiQ2FyZEhlYWRlciIsIkNhcmRTdWJ0aXRsZSIsIkNhcmRUZXh0IiwiQ2FyZFRpdGxlIiwiQ29sIiwiRm9ybSIsIkZvcm1Hcm91cCIsIklucHV0R3JvdXAiLCJSb3ciLCJkYXRhIiwib3B0aW9ucyIsImNvbm5lY3QiLCJhY3Rpb25zIiwidXNlSGlzdG9yeSIsInJlc3VsdCIsIkFycmF5IiwiTWFpblJlc3VsdCIsIkhvbWUiLCJwcm9wcyIsInZhbHVlIiwic2V0VmFsdWUiLCJoaXN0b3J5IiwiQ0RVIiwiU1BEIiwiQWZEIiwiRkRQIiwiR3LDvG5lIiwiTGlua2UiLCJjb21wYW55Iiwic2V0Q29tcGFueSIsInNldENEVSIsInNldFNQRCIsInNldEFmRCIsInNldEZEUCIsInNldEdyw7xuZSIsInNldExpbmtlIiwiY29uc29sZSIsImxvZyIsImRhdGFMZW5ndGgiLCJsZW5ndGgiLCJhbnN3ZXIiLCJ2YWx1ZXMiLCJzZXRTdWJtaXR0aW5nIiwicmVzdWx0TGVuZ3RoIiwiciIsImQiLCJxdWVzdGlvbl9pZCIsImlkIiwiZ3JhcGhEYXRhIiwicmVzdWx0RWRpdFNldERhdGEiLCJoYW5kbGVTdWJtaXQiLCJtYXAiLCJTY2hsYWd3b3J0IiwicXVlc3Rpb25fdGV4dCIsImFycmF5SGVscGVycyIsIm9wdCIsIm9wdGlvbl9WYWx1ZSIsImkiLCJzcGxpY2UiLCJyZXN1bHRTZXREYXRhIiwicHVzaCIsIm9wdGlvbl90ZXh0IiwibWFwU3RhdGVUb1Byb3BzIiwic3RhdGUiLCJtYXBEaXNwYXRjaFRvUHJvcHMiLCJkaXNwYXRjaCIsIm9uRGVsZXRlUmVzdWx0IiwiZGVsZXRlUmVzdWx0Iiwib25Qb3N0UmVzdWx0RGF0YSIsInVzZXIiLCJ0b2dnbGUiLCJwb3N0UmVzdWx0RGF0YSIsIm9uVXBkYXRlUmVzdWx0RGF0YSIsInVwZGF0ZVJlc3VsdERhdGEiLCJyZXN1bHRFZGl0R2V0RGF0YSJdLCJzb3VyY2VSb290IjoiIn0=