"use strict";
self["webpackHotUpdate_N_E"]("pages/graph",{

/***/ "./pages/graph.js":
/*!************************!*\
  !*** ./pages/graph.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-chartjs-2 */ "./node_modules/react-chartjs-2/dist/index.modern.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "E:\\git vinraj\\company-test\\pages\\graph.js",
    _this = undefined,
    _s = $RefreshSig$();







var BarGraph = function BarGraph(props) {
  _s();

  var _props$login, _props$login$login, _props$result, _props$result2;

  var accessToken = "".concat((_props$login = props.login) === null || _props$login === void 0 ? void 0 : (_props$login$login = _props$login.login) === null || _props$login$login === void 0 ? void 0 : _props$login$login.token);
  var data = {
    token: accessToken,
    id: 1
  };

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false),
      showGraph = _useState[0],
      setShowGraph = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({}),
      chartData = _useState2[0],
      setChartData = _useState2[1];

  var graph = [];
  var graphdata = [];
  graph = props.result;
  graphdata = (_props$result = props.result) === null || _props$result === void 0 ? void 0 : _props$result.map(function (gd) {
    return {
      label: "",
      data: gd,
      backgroundColor: ["rgba(255, 99, 132, 0.2)", "rgba(54, 162, 235, 0.2)", "rgba(255, 206, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(255, 159, 64, 0.2)", "rgba(255, 99, 132, 0.2)", "rgba(54, 162, 235, 0.2)", "rgba(255, 206, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(255, 159, 64, 0.2)", "rgba(255, 99, 132, 0.2)", "rgba(54, 162, 235, 0.2)", "rgba(255, 206, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(255, 159, 64, 0.2)", "rgba(255, 99, 132, 0.2)", "rgba(54, 162, 235, 0.2)", "rgba(255, 206, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(255, 159, 64, 0.2)"],
      borderColor: ["rgba(255, 99, 132, 1)", "rgba(54, 162, 235, 1)", "rgba(255, 206, 86, 1)", "rgba(75, 192, 192, 1)", "rgba(153, 102, 255, 1)", "rgba(255, 159, 64, 1)", "rgba(255, 99, 132, 1)", "rgba(54, 162, 235, 1)", "rgba(255, 206, 86, 1)", "rgba(75, 192, 192, 1)", "rgba(153, 102, 255, 1)", "rgba(255, 159, 64, 1)", "rgba(255, 99, 132, 1)", "rgba(54, 162, 235, 1)", "rgba(255, 206, 86, 1)", "rgba(75, 192, 192, 1)", "rgba(153, 102, 255, 1)", "rgba(255, 159, 64, 1)", "rgba(255, 99, 132, 1)", "rgba(54, 162, 235, 1)", "rgba(255, 206, 86, 1)", "rgba(75, 192, 192, 1)", "rgba(153, 102, 255, 1)", "rgba(255, 159, 64, 1)"],
      borderWidth: 1
    };
  });

  var Chart = function Chart() {
    var time = [];
    var temp = [];
    var sensors = [];
    console.log("Chart Function"); // for (const dataObj of graph) {
    //   dataObj?.data.map((t) => {
    //     time.push(t.time);
    //   });
    //   sensors.push(dataObj?.sensor);
    // }

    setChartData({
      labels: ["CDU/MDU", "SPD", "AfD", "FDP", "Grüne", "Linke"],
      datasets: [{
        label: "data",
        data: [10, 20, 40, 50, 90, 10],
        fill: true,
        backgroundColor: "yellow",
        borderColor: "yellow"
      }]
    });
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
    Chart();
  }, [graphdata && ((_props$result2 = props.result) === null || _props$result2 === void 0 ? void 0 : _props$result2.length) > 0]);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_4__.Card, {
    className: "h-100 p-3",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_4__.CardBody, {
      className: "p-0",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h3", {
        className: "text-center pt-4 pr-4 pl-4 pb-1 ",
        children: "Ihr Ergebnis"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 114,
        columnNumber: 9
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(react_chartjs_2__WEBPACK_IMPORTED_MODULE_2__.Bar, {
        data: chartData,
        options: {
          responsive: true,
          title: {
            text: "THICCNESS SCALE",
            display: true
          },
          scales: {
            yAxes: {
              ticks: {
                beginAtZero: true
              }
            }
          }
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 116,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 113,
      columnNumber: 7
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 112,
    columnNumber: 5
  }, _this);
};

_s(BarGraph, "w0JUL31rlpdgEJ0KU+CzX4MjnvY=");

_c = BarGraph;

var mapStateToProps = function mapStateToProps(state) {
  return {
    result: state.result.mainResult
  };
};

/* harmony default export */ __webpack_exports__["default"] = ((0,react_redux__WEBPACK_IMPORTED_MODULE_1__.connect)(mapStateToProps)(BarGraph));

var _c;

$RefreshReg$(_c, "BarGraph");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvZ3JhcGguODA3MTA1OTJlZGE1YTE0ZGFlMTAuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUVBO0FBRUE7OztBQUVBLElBQU1RLFFBQVEsR0FBRyxTQUFYQSxRQUFXLENBQUNDLEtBQUQsRUFBVztBQUFBOztBQUFBOztBQUMxQixNQUFNQyxXQUFXLDZCQUFNRCxLQUFLLENBQUNFLEtBQVosdUVBQU0sYUFBYUEsS0FBbkIsdURBQU0sbUJBQW9CQyxLQUExQixDQUFqQjtBQUVBLE1BQUlDLElBQUksR0FBRztBQUNURCxJQUFBQSxLQUFLLEVBQUVGLFdBREU7QUFFVEksSUFBQUEsRUFBRSxFQUFFO0FBRkssR0FBWDs7QUFLQSxrQkFBa0NaLCtDQUFRLENBQUMsS0FBRCxDQUExQztBQUFBLE1BQU9hLFNBQVA7QUFBQSxNQUFrQkMsWUFBbEI7O0FBQ0EsbUJBQWtDZCwrQ0FBUSxDQUFDLEVBQUQsQ0FBMUM7QUFBQSxNQUFPZSxTQUFQO0FBQUEsTUFBa0JDLFlBQWxCOztBQUNBLE1BQUlDLEtBQUssR0FBRyxFQUFaO0FBQ0EsTUFBSUMsU0FBUyxHQUFHLEVBQWhCO0FBQ0FELEVBQUFBLEtBQUssR0FBR1YsS0FBSyxDQUFDWSxNQUFkO0FBQ0FELEVBQUFBLFNBQVMsb0JBQUdYLEtBQUssQ0FBQ1ksTUFBVCxrREFBRyxjQUFjQyxHQUFkLENBQWtCLFVBQUNDLEVBQUQsRUFBUTtBQUNwQyxXQUFPO0FBQ0xDLE1BQUFBLEtBQUssRUFBRSxFQURGO0FBRUxYLE1BQUFBLElBQUksRUFBRVUsRUFGRDtBQUdMRSxNQUFBQSxlQUFlLEVBQUUsQ0FDZix5QkFEZSxFQUVmLHlCQUZlLEVBR2YseUJBSGUsRUFJZix5QkFKZSxFQUtmLDBCQUxlLEVBTWYseUJBTmUsRUFPZix5QkFQZSxFQVFmLHlCQVJlLEVBU2YseUJBVGUsRUFVZix5QkFWZSxFQVdmLDBCQVhlLEVBWWYseUJBWmUsRUFhZix5QkFiZSxFQWNmLHlCQWRlLEVBZWYseUJBZmUsRUFnQmYseUJBaEJlLEVBaUJmLDBCQWpCZSxFQWtCZix5QkFsQmUsRUFtQmYseUJBbkJlLEVBb0JmLHlCQXBCZSxFQXFCZix5QkFyQmUsRUFzQmYseUJBdEJlLEVBdUJmLDBCQXZCZSxFQXdCZix5QkF4QmUsQ0FIWjtBQTZCTEMsTUFBQUEsV0FBVyxFQUFFLENBQ1gsdUJBRFcsRUFFWCx1QkFGVyxFQUdYLHVCQUhXLEVBSVgsdUJBSlcsRUFLWCx3QkFMVyxFQU1YLHVCQU5XLEVBT1gsdUJBUFcsRUFRWCx1QkFSVyxFQVNYLHVCQVRXLEVBVVgsdUJBVlcsRUFXWCx3QkFYVyxFQVlYLHVCQVpXLEVBYVgsdUJBYlcsRUFjWCx1QkFkVyxFQWVYLHVCQWZXLEVBZ0JYLHVCQWhCVyxFQWlCWCx3QkFqQlcsRUFrQlgsdUJBbEJXLEVBbUJYLHVCQW5CVyxFQW9CWCx1QkFwQlcsRUFxQlgsdUJBckJXLEVBc0JYLHVCQXRCVyxFQXVCWCx3QkF2QlcsRUF3QlgsdUJBeEJXLENBN0JSO0FBd0RMQyxNQUFBQSxXQUFXLEVBQUU7QUF4RFIsS0FBUDtBQTBERCxHQTNEVyxDQUFaOztBQTZEQSxNQUFNQyxLQUFLLEdBQUcsU0FBUkEsS0FBUSxHQUFNO0FBQ2xCLFFBQUlDLElBQUksR0FBRyxFQUFYO0FBQ0EsUUFBSUMsSUFBSSxHQUFHLEVBQVg7QUFDQSxRQUFJQyxPQUFPLEdBQUcsRUFBZDtBQUNBQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxnQkFBWixFQUprQixDQUtsQjtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUFmLElBQUFBLFlBQVksQ0FBQztBQUNYZ0IsTUFBQUEsTUFBTSxFQUFFLENBQUMsU0FBRCxFQUFZLEtBQVosRUFBbUIsS0FBbkIsRUFBMEIsS0FBMUIsRUFBaUMsT0FBakMsRUFBMEMsT0FBMUMsQ0FERztBQUVYQyxNQUFBQSxRQUFRLEVBQUUsQ0FDUjtBQUNFWCxRQUFBQSxLQUFLLEVBQUUsTUFEVDtBQUVFWCxRQUFBQSxJQUFJLEVBQUUsQ0FBQyxFQUFELEVBQUssRUFBTCxFQUFTLEVBQVQsRUFBYSxFQUFiLEVBQWlCLEVBQWpCLEVBQXFCLEVBQXJCLENBRlI7QUFHRXVCLFFBQUFBLElBQUksRUFBRSxJQUhSO0FBSUVYLFFBQUFBLGVBQWUsRUFBRSxRQUpuQjtBQUtFQyxRQUFBQSxXQUFXLEVBQUU7QUFMZixPQURRO0FBRkMsS0FBRCxDQUFaO0FBWUQsR0F6QkQ7O0FBMEJBekIsRUFBQUEsZ0RBQVMsQ0FBQyxZQUFNO0FBQ2QyQixJQUFBQSxLQUFLO0FBQ04sR0FGUSxFQUVOLENBQUNSLFNBQVMsSUFBSSxtQkFBQVgsS0FBSyxDQUFDWSxNQUFOLGtFQUFjZ0IsTUFBZCxJQUF1QixDQUFyQyxDQUZNLENBQVQ7QUFHQSxzQkFDRSw4REFBQyw0Q0FBRDtBQUFNLGFBQVMsRUFBQyxXQUFoQjtBQUFBLDJCQUNFLDhEQUFDLGdEQUFEO0FBQVUsZUFBUyxFQUFDLEtBQXBCO0FBQUEsOEJBQ0U7QUFBSSxpQkFBUyxFQUFDLGtDQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREYsZUFHRSw4REFBQyxnREFBRDtBQUNFLFlBQUksRUFBRXBCLFNBRFI7QUFFRSxlQUFPLEVBQUU7QUFDUHFCLFVBQUFBLFVBQVUsRUFBRSxJQURMO0FBRVBDLFVBQUFBLEtBQUssRUFBRTtBQUFFQyxZQUFBQSxJQUFJLEVBQUUsaUJBQVI7QUFBMkJDLFlBQUFBLE9BQU8sRUFBRTtBQUFwQyxXQUZBO0FBR1BDLFVBQUFBLE1BQU0sRUFBRTtBQUNOQyxZQUFBQSxLQUFLLEVBQUU7QUFDTEMsY0FBQUEsS0FBSyxFQUFFO0FBQ0xDLGdCQUFBQSxXQUFXLEVBQUU7QUFEUjtBQURGO0FBREQ7QUFIRDtBQUZYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUFzQkQsQ0E3SEQ7O0dBQU1yQzs7S0FBQUE7O0FBK0hOLElBQU1zQyxlQUFlLEdBQUcsU0FBbEJBLGVBQWtCLENBQUNDLEtBQUQsRUFBVztBQUNqQyxTQUFPO0FBQ0wxQixJQUFBQSxNQUFNLEVBQUUwQixLQUFLLENBQUMxQixNQUFOLENBQWEyQjtBQURoQixHQUFQO0FBR0QsQ0FKRDs7QUFNQSwrREFBZTFDLG9EQUFPLENBQUN3QyxlQUFELENBQVAsQ0FBeUJ0QyxRQUF6QixDQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3BhZ2VzL2dyYXBoLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IEJ1dHRvbiwgQ2FyZCwgQ2FyZEJvZHkgfSBmcm9tIFwicmVhY3RzdHJhcFwiO1xyXG5cclxuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xyXG5cclxuaW1wb3J0IHsgQmFyIH0gZnJvbSBcInJlYWN0LWNoYXJ0anMtMlwiO1xyXG5cclxuY29uc3QgQmFyR3JhcGggPSAocHJvcHMpID0+IHtcclxuICBjb25zdCBhY2Nlc3NUb2tlbiA9IGAke3Byb3BzLmxvZ2luPy5sb2dpbj8udG9rZW59YDtcclxuXHJcbiAgbGV0IGRhdGEgPSB7XHJcbiAgICB0b2tlbjogYWNjZXNzVG9rZW4sXHJcbiAgICBpZDogMSxcclxuICB9O1xyXG5cclxuICBjb25zdCBbc2hvd0dyYXBoLCBzZXRTaG93R3JhcGhdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjaGFydERhdGEsIHNldENoYXJ0RGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgbGV0IGdyYXBoID0gW107XHJcbiAgbGV0IGdyYXBoZGF0YSA9IFtdO1xyXG4gIGdyYXBoID0gcHJvcHMucmVzdWx0O1xyXG4gIGdyYXBoZGF0YSA9IHByb3BzLnJlc3VsdD8ubWFwKChnZCkgPT4ge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgbGFiZWw6IFwiXCIsXHJcbiAgICAgIGRhdGE6IGdkLFxyXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6IFtcclxuICAgICAgICBcInJnYmEoMjU1LCA5OSwgMTMyLCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDU0LCAxNjIsIDIzNSwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDIwNiwgODYsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoNzUsIDE5MiwgMTkyLCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDE1MywgMTAyLCAyNTUsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoMjU1LCAxNTksIDY0LCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgOTksIDEzMiwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSg1NCwgMTYyLCAyMzUsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoMjU1LCAyMDYsIDg2LCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDc1LCAxOTIsIDE5MiwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSgxNTMsIDEwMiwgMjU1LCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgMTU5LCA2NCwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDk5LCAxMzIsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoNTQsIDE2MiwgMjM1LCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgMjA2LCA4NiwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSg3NSwgMTkyLCAxOTIsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoMTUzLCAxMDIsIDI1NSwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDE1OSwgNjQsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoMjU1LCA5OSwgMTMyLCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDU0LCAxNjIsIDIzNSwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDIwNiwgODYsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoNzUsIDE5MiwgMTkyLCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDE1MywgMTAyLCAyNTUsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoMjU1LCAxNTksIDY0LCAwLjIpXCIsXHJcbiAgICAgIF0sXHJcbiAgICAgIGJvcmRlckNvbG9yOiBbXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgOTksIDEzMiwgMSlcIixcclxuICAgICAgICBcInJnYmEoNTQsIDE2MiwgMjM1LCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDIwNiwgODYsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDc1LCAxOTIsIDE5MiwgMSlcIixcclxuICAgICAgICBcInJnYmEoMTUzLCAxMDIsIDI1NSwgMSlcIixcclxuICAgICAgICBcInJnYmEoMjU1LCAxNTksIDY0LCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDk5LCAxMzIsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDU0LCAxNjIsIDIzNSwgMSlcIixcclxuICAgICAgICBcInJnYmEoMjU1LCAyMDYsIDg2LCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSg3NSwgMTkyLCAxOTIsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDE1MywgMTAyLCAyNTUsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgMTU5LCA2NCwgMSlcIixcclxuICAgICAgICBcInJnYmEoMjU1LCA5OSwgMTMyLCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSg1NCwgMTYyLCAyMzUsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgMjA2LCA4NiwgMSlcIixcclxuICAgICAgICBcInJnYmEoNzUsIDE5MiwgMTkyLCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSgxNTMsIDEwMiwgMjU1LCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDE1OSwgNjQsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgOTksIDEzMiwgMSlcIixcclxuICAgICAgICBcInJnYmEoNTQsIDE2MiwgMjM1LCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDIwNiwgODYsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDc1LCAxOTIsIDE5MiwgMSlcIixcclxuICAgICAgICBcInJnYmEoMTUzLCAxMDIsIDI1NSwgMSlcIixcclxuICAgICAgICBcInJnYmEoMjU1LCAxNTksIDY0LCAxKVwiLFxyXG4gICAgICBdLFxyXG5cclxuICAgICAgYm9yZGVyV2lkdGg6IDEsXHJcbiAgICB9O1xyXG4gIH0pO1xyXG5cclxuICBjb25zdCBDaGFydCA9ICgpID0+IHtcclxuICAgIGxldCB0aW1lID0gW107XHJcbiAgICBsZXQgdGVtcCA9IFtdO1xyXG4gICAgbGV0IHNlbnNvcnMgPSBbXTtcclxuICAgIGNvbnNvbGUubG9nKFwiQ2hhcnQgRnVuY3Rpb25cIik7XHJcbiAgICAvLyBmb3IgKGNvbnN0IGRhdGFPYmogb2YgZ3JhcGgpIHtcclxuICAgIC8vICAgZGF0YU9iaj8uZGF0YS5tYXAoKHQpID0+IHtcclxuICAgIC8vICAgICB0aW1lLnB1c2godC50aW1lKTtcclxuICAgIC8vICAgfSk7XHJcblxyXG4gICAgLy8gICBzZW5zb3JzLnB1c2goZGF0YU9iaj8uc2Vuc29yKTtcclxuICAgIC8vIH1cclxuXHJcbiAgICBzZXRDaGFydERhdGEoe1xyXG4gICAgICBsYWJlbHM6IFtcIkNEVS9NRFVcIiwgXCJTUERcIiwgXCJBZkRcIiwgXCJGRFBcIiwgXCJHcsO8bmVcIiwgXCJMaW5rZVwiXSxcclxuICAgICAgZGF0YXNldHM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBsYWJlbDogXCJkYXRhXCIsXHJcbiAgICAgICAgICBkYXRhOiBbMTAsIDIwLCA0MCwgNTAsIDkwLCAxMF0sXHJcbiAgICAgICAgICBmaWxsOiB0cnVlLFxyXG4gICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBcInllbGxvd1wiLFxyXG4gICAgICAgICAgYm9yZGVyQ29sb3I6IFwieWVsbG93XCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgIH0pO1xyXG4gIH07XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIENoYXJ0KCk7XHJcbiAgfSwgW2dyYXBoZGF0YSAmJiBwcm9wcy5yZXN1bHQ/Lmxlbmd0aCA+IDBdKTtcclxuICByZXR1cm4gKFxyXG4gICAgPENhcmQgY2xhc3NOYW1lPVwiaC0xMDAgcC0zXCI+XHJcbiAgICAgIDxDYXJkQm9keSBjbGFzc05hbWU9XCJwLTBcIj5cclxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHQtNCBwci00IHBsLTQgcGItMSBcIj5JaHIgRXJnZWJuaXM8L2gzPlxyXG5cclxuICAgICAgICA8QmFyXHJcbiAgICAgICAgICBkYXRhPXtjaGFydERhdGF9XHJcbiAgICAgICAgICBvcHRpb25zPXt7XHJcbiAgICAgICAgICAgIHJlc3BvbnNpdmU6IHRydWUsXHJcbiAgICAgICAgICAgIHRpdGxlOiB7IHRleHQ6IFwiVEhJQ0NORVNTIFNDQUxFXCIsIGRpc3BsYXk6IHRydWUgfSxcclxuICAgICAgICAgICAgc2NhbGVzOiB7XHJcbiAgICAgICAgICAgICAgeUF4ZXM6IHtcclxuICAgICAgICAgICAgICAgIHRpY2tzOiB7XHJcbiAgICAgICAgICAgICAgICAgIGJlZ2luQXRaZXJvOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICAvPlxyXG4gICAgICA8L0NhcmRCb2R5PlxyXG4gICAgPC9DYXJkPlxyXG4gICk7XHJcbn07XHJcblxyXG5jb25zdCBtYXBTdGF0ZVRvUHJvcHMgPSAoc3RhdGUpID0+IHtcclxuICByZXR1cm4ge1xyXG4gICAgcmVzdWx0OiBzdGF0ZS5yZXN1bHQubWFpblJlc3VsdCxcclxuICB9O1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY29ubmVjdChtYXBTdGF0ZVRvUHJvcHMpKEJhckdyYXBoKTtcclxuIl0sIm5hbWVzIjpbIlJlYWN0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJCdXR0b24iLCJDYXJkIiwiQ2FyZEJvZHkiLCJjb25uZWN0IiwiQmFyIiwiQmFyR3JhcGgiLCJwcm9wcyIsImFjY2Vzc1Rva2VuIiwibG9naW4iLCJ0b2tlbiIsImRhdGEiLCJpZCIsInNob3dHcmFwaCIsInNldFNob3dHcmFwaCIsImNoYXJ0RGF0YSIsInNldENoYXJ0RGF0YSIsImdyYXBoIiwiZ3JhcGhkYXRhIiwicmVzdWx0IiwibWFwIiwiZ2QiLCJsYWJlbCIsImJhY2tncm91bmRDb2xvciIsImJvcmRlckNvbG9yIiwiYm9yZGVyV2lkdGgiLCJDaGFydCIsInRpbWUiLCJ0ZW1wIiwic2Vuc29ycyIsImNvbnNvbGUiLCJsb2ciLCJsYWJlbHMiLCJkYXRhc2V0cyIsImZpbGwiLCJsZW5ndGgiLCJyZXNwb25zaXZlIiwidGl0bGUiLCJ0ZXh0IiwiZGlzcGxheSIsInNjYWxlcyIsInlBeGVzIiwidGlja3MiLCJiZWdpbkF0WmVybyIsIm1hcFN0YXRlVG9Qcm9wcyIsInN0YXRlIiwibWFpblJlc3VsdCJdLCJzb3VyY2VSb290IjoiIn0=