"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var E_git_vinraj_company_test_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
/* harmony import */ var _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Data/Data.json */ "./components/Data/Data.json");
/* harmony import */ var _components_Data_options_json__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../components/Data/options.json */ "./components/Data/options.json");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _redux_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../redux/actions */ "./redux/actions/index.js");
/* harmony import */ var react_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-router */ "./node_modules/react-router/esm/react-router.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__);
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "E:\\git vinraj\\company-test\\pages\\index.js",
    _s = $RefreshSig$();












var result = new Array();
var MainResult = new Array();

function Home(props) {
  _s();

  var _this = this;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)({}),
      value = _useState[0],
      setValue = _useState[1];

  var history = (0,react_router__WEBPACK_IMPORTED_MODULE_10__.useHistory)();

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)({
    CDU: 0,
    SPD: 0,
    AfD: 0,
    FDP: 0,
    Grüne: 0,
    Linke: 0
  }),
      company = _useState2[0],
      setCompany = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(0),
      CDU = _useState3[0],
      setCDU = _useState3[1];

  var _useState4 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(0),
      SPD = _useState4[0],
      setSPD = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(0),
      AfD = _useState5[0],
      setAfD = _useState5[1];

  var _useState6 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(0),
      FDP = _useState6[0],
      setFDP = _useState6[1];

  var _useState7 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(0),
      Grüne = _useState7[0],
      setGrüne = _useState7[1];

  var _useState8 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(0),
      Linke = _useState8[0],
      setLinke = _useState8[1];

  console.log("props.result", props.result);
  console.log("value", value);

  var handleSubmit = function handleSubmit(values, setSubmitting) {
    if (props.result) {
      var _props$result;

      (_props$result = props.result) === null || _props$result === void 0 ? void 0 : _props$result.map(function (r) {
        data === null || data === void 0 ? void 0 : data.map(function (d) {
          if (r.question_id == d.question_id) {
            if (d.CDU / CSU == r.answer) {
              console.log("aakash");
            }
          }
        });
      });
    }

    var data = {
      result: result
    };
    console.log(data);
    axios__WEBPACK_IMPORTED_MODULE_1___default().post("/test", data).then(function (res) {
      console.log(res);
      console.log("intial value is submited to results");
      result = [];
      history.push("/thankyou");
    })["catch"](function (err) {
      console.log(err.response.data); // history.push("/exam-appeared");
      // result = [];
    });
  };

  console.log("array", result);
  console.log("company", company);
  var dataLength = _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_5__.length;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)("div", {
    className: "",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)("title", {
        children: "Create Next App"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 89,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 90,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 88,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_11__.Card, {
      className: "p-5 border-2 shadow-md rounded-md",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_11__.CardBody, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_2__.Formik, {
          initialValues: {
            result: [],
            answer: ""
          },
          onSubmit: function onSubmit(values, setSubmitting) {
            var _props$result2;

            if (((_props$result2 = props.result) === null || _props$result2 === void 0 ? void 0 : _props$result2.length) > 0 && _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_5__) {
              var _props$result3, _props$result4, _props$result5;

              console.log("result length", (_props$result3 = props.result) === null || _props$result3 === void 0 ? void 0 : _props$result3.length);
              var resultLength = (_props$result4 = props.result) === null || _props$result4 === void 0 ? void 0 : _props$result4.length; // for (let i = 0; i < resultLength; i++) {
              //   console.log("result map");
              // }

              (_props$result5 = props.result) === null || _props$result5 === void 0 ? void 0 : _props$result5.map(function (r) {
                console.log("result map");
                _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_5__ === null || _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_5__ === void 0 ? void 0 : _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_5__.map(function (d) {
                  console.log("data map");

                  if (r.question_id == d.id) {
                    console.log("r.question_id", r.question_id, "d.id", d.id);

                    if (d.SPD == r.answer) {
                      console.log("SPD");
                    }

                    if (d.CDU == r.answer) {
                      console.log("CDU");
                      setCDU.apply(void 0, (0,E_git_vinraj_company_test_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__.default)(CDU).concat([CDU + 1]));
                    }

                    if (d.AfD == r.answer) {
                      console.log("AfD");
                      setAfD.apply(void 0, (0,E_git_vinraj_company_test_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__.default)(AfD).concat([AfD + 1]));
                    }

                    if (d.FDP == r.answer) {
                      console.log("FDP");
                      setFDP.apply(void 0, (0,E_git_vinraj_company_test_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__.default)(FDP).concat([FDP + 1]));
                    }

                    if (d.Grüne == r.answer) {
                      console.log("Grüne");
                      setGrüne.apply(void 0, (0,E_git_vinraj_company_test_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__.default)(Grüne).concat([Grüne + 1]));
                    }

                    if (d.Linke == r.answer) {
                      console.log("Linke");
                      setLinke.apply(void 0, (0,E_git_vinraj_company_test_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__.default)(Linke).concat([Linke + 1]));
                    } else {
                      console.log("else from last if");
                    }
                  }
                });
              });
            }

            console.log("submit click"); // axios
            //   .post("https://uditsolutions.in/yarn/public/api/scores", data)
            //   .then((res) => {
            //     console.log(res);
            //     console.log("intial value is submited to results");
            //     result = [];
            //     history.push("/thankyou");
            //   })
            //   .catch((err) => {
            //     console.log(err.response.data);
            //     // history.push("/exam-appeared");
            //   });
          },
          children: function children(_ref) {
            var handleSubmit = _ref.handleSubmit;
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_11__.Form, {
              onSubmit: handleSubmit,
              children: [_components_Data_Data_json__WEBPACK_IMPORTED_MODULE_5__ === null || _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_5__ === void 0 ? void 0 : _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_5__.map(function (d, id) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)("div", {
                  className: "mt-3",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_11__.CardTitle, {
                    children: [" ", d.id, "/", dataLength]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 165,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_11__.CardSubtitle, {
                    children: d.Schlagwort
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 169,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_11__.CardText, {
                    children: d.question_text
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 170,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_2__.FieldArray, {
                    name: "result",
                    render: function render(arrayHelpers) {
                      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)("div", {
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_11__.Row, {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_11__.Col, {
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_11__.FormGroup, {
                              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_11__.InputGroup, {
                                className: "flex flex-col mt-2",
                                children: _components_Data_options_json__WEBPACK_IMPORTED_MODULE_6__ === null || _components_Data_options_json__WEBPACK_IMPORTED_MODULE_6__ === void 0 ? void 0 : _components_Data_options_json__WEBPACK_IMPORTED_MODULE_6__.map(function (opt) {
                                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)("label", {
                                    className: "p-2 bg-gray-600 text-white rounded-md text-center hover:bg-yellow-300 hover:text-black mb-1",
                                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_2__.Field, {
                                      type: "radio" // name="answer"
                                      ,
                                      value: opt.option_Value,
                                      className: "hidden",
                                      onChange: function onChange() {
                                        setValue({
                                          question_id: d.id,
                                          answer: opt.option_Value
                                        });

                                        if (result.length > 0) {
                                          for (var i = 0; i < result.length; i++) {
                                            var _result$i;

                                            if (((_result$i = result[i]) === null || _result$i === void 0 ? void 0 : _result$i.question_id) == d.id) {
                                              console.log("splice");
                                              result.splice(i, 1, {
                                                question_id: d.id,
                                                answer: opt.option_Value
                                              });
                                              return;
                                            } else if (result[i].question_id !== d.id) {
                                              console.log("else_if question of data", d.id, "result q-id", result[i].question_id);
                                              result.push({
                                                question_id: d.id,
                                                answer: opt.option_Value // value,

                                              });
                                              return;
                                            }
                                          }

                                          props.resultSetData(result);
                                        } else {
                                          console.log("else");
                                          result.push({
                                            question_id: d.id,
                                            answer: opt.option_Value
                                          });
                                          props.resultSetData(result);
                                        }
                                      }
                                    }, void 0, false, {
                                      fileName: _jsxFileName,
                                      lineNumber: 186,
                                      columnNumber: 47
                                    }, _this), opt.option_text]
                                  }, opt.id, true, {
                                    fileName: _jsxFileName,
                                    lineNumber: 182,
                                    columnNumber: 45
                                  }, _this);
                                })
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 179,
                                columnNumber: 39
                              }, _this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 178,
                              columnNumber: 37
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 177,
                            columnNumber: 35
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 176,
                          columnNumber: 33
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 175,
                        columnNumber: 31
                      }, _this);
                    }
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 171,
                    columnNumber: 25
                  }, _this)]
                }, d.id, true, {
                  fileName: _jsxFileName,
                  lineNumber: 164,
                  columnNumber: 23
                }, _this);
              }), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_11__.Button, {
                  block: true,
                  className: "border-2 p-2 border-black mt-7",
                  type: "submit" // onClick={handleSubmit}
                  // disabled={formProps.isSubmitting}
                  ,
                  children: "Eegebnis zeigen"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 270,
                  columnNumber: 21
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 269,
                columnNumber: 19
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 161,
              columnNumber: 17
            }, _this);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 94,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 93,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 92,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 87,
    columnNumber: 5
  }, this);
}

_s(Home, "ea2M+Wy0wZipXmzz6sFKfCdQsqY=", false, function () {
  return [react_router__WEBPACK_IMPORTED_MODULE_10__.useHistory];
});

_c = Home;

var mapStateToProps = function mapStateToProps(state) {
  return {
    result: state.result.result
  };
};

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    resultSetData: function resultSetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_8__.resultSetData(data));
    },
    onDeleteResult: function onDeleteResult(data, id) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_8__.deleteResult(data, id));
    },
    onPostResultData: function onPostResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_8__.postResultData(data, user, toggle));
    },
    onUpdateResultData: function onUpdateResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_8__.updateResultData(data, user, toggle));
    },
    resultEditGetData: function resultEditGetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_8__.resultEditGetData(data));
    }
  };
};

/* harmony default export */ __webpack_exports__["default"] = ((0,react_redux__WEBPACK_IMPORTED_MODULE_7__.connect)(mapStateToProps, mapDispatchToProps)(Home));

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js":
/*!*********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _arrayLikeToArray; }
/* harmony export */ });
function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/arrayWithoutHoles.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/arrayWithoutHoles.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _arrayWithoutHoles; }
/* harmony export */ });
/* harmony import */ var _arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./arrayLikeToArray.js */ "./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js");

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return (0,_arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__.default)(arr);
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/iterableToArray.js":
/*!********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/iterableToArray.js ***!
  \********************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _iterableToArray; }
/* harmony export */ });
function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/nonIterableSpread.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/nonIterableSpread.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _nonIterableSpread; }
/* harmony export */ });
function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _toConsumableArray; }
/* harmony export */ });
/* harmony import */ var _arrayWithoutHoles_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./arrayWithoutHoles.js */ "./node_modules/@babel/runtime/helpers/esm/arrayWithoutHoles.js");
/* harmony import */ var _iterableToArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./iterableToArray.js */ "./node_modules/@babel/runtime/helpers/esm/iterableToArray.js");
/* harmony import */ var _unsupportedIterableToArray_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./unsupportedIterableToArray.js */ "./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js");
/* harmony import */ var _nonIterableSpread_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./nonIterableSpread.js */ "./node_modules/@babel/runtime/helpers/esm/nonIterableSpread.js");




function _toConsumableArray(arr) {
  return (0,_arrayWithoutHoles_js__WEBPACK_IMPORTED_MODULE_0__.default)(arr) || (0,_iterableToArray_js__WEBPACK_IMPORTED_MODULE_1__.default)(arr) || (0,_unsupportedIterableToArray_js__WEBPACK_IMPORTED_MODULE_2__.default)(arr) || (0,_nonIterableSpread_js__WEBPACK_IMPORTED_MODULE_3__.default)();
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _unsupportedIterableToArray; }
/* harmony export */ });
/* harmony import */ var _arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./arrayLikeToArray.js */ "./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js");

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return (0,_arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__.default)(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return (0,_arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__.default)(o, minLen);
}

/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguZjBjYmYzNjZiNmMzOTgxOTdhZWYuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFjQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLElBQUl3QixNQUFNLEdBQUcsSUFBSUMsS0FBSixFQUFiO0FBQ0EsSUFBSUMsVUFBVSxHQUFHLElBQUlELEtBQUosRUFBakI7O0FBQ0EsU0FBU0UsSUFBVCxDQUFjQyxLQUFkLEVBQXFCO0FBQUE7O0FBQUE7O0FBQ25CLGtCQUEwQnRCLCtDQUFRLENBQUMsRUFBRCxDQUFsQztBQUFBLE1BQU91QixLQUFQO0FBQUEsTUFBY0MsUUFBZDs7QUFDQSxNQUFNQyxPQUFPLEdBQUdSLHlEQUFVLEVBQTFCOztBQUVBLG1CQUE4QmpCLCtDQUFRLENBQUM7QUFDckMwQixJQUFBQSxHQUFHLEVBQUUsQ0FEZ0M7QUFFckNDLElBQUFBLEdBQUcsRUFBRSxDQUZnQztBQUdyQ0MsSUFBQUEsR0FBRyxFQUFFLENBSGdDO0FBSXJDQyxJQUFBQSxHQUFHLEVBQUUsQ0FKZ0M7QUFLckNDLElBQUFBLEtBQUssRUFBRSxDQUw4QjtBQU1yQ0MsSUFBQUEsS0FBSyxFQUFFO0FBTjhCLEdBQUQsQ0FBdEM7QUFBQSxNQUFPQyxPQUFQO0FBQUEsTUFBZ0JDLFVBQWhCOztBQVNBLG1CQUFzQmpDLCtDQUFRLENBQUMsQ0FBRCxDQUE5QjtBQUFBLE1BQU8wQixHQUFQO0FBQUEsTUFBWVEsTUFBWjs7QUFDQSxtQkFBc0JsQywrQ0FBUSxDQUFDLENBQUQsQ0FBOUI7QUFBQSxNQUFPMkIsR0FBUDtBQUFBLE1BQVlRLE1BQVo7O0FBQ0EsbUJBQXNCbkMsK0NBQVEsQ0FBQyxDQUFELENBQTlCO0FBQUEsTUFBTzRCLEdBQVA7QUFBQSxNQUFZUSxNQUFaOztBQUNBLG1CQUFzQnBDLCtDQUFRLENBQUMsQ0FBRCxDQUE5QjtBQUFBLE1BQU82QixHQUFQO0FBQUEsTUFBWVEsTUFBWjs7QUFDQSxtQkFBMEJyQywrQ0FBUSxDQUFDLENBQUQsQ0FBbEM7QUFBQSxNQUFPOEIsS0FBUDtBQUFBLE1BQWNRLFFBQWQ7O0FBQ0EsbUJBQTBCdEMsK0NBQVEsQ0FBQyxDQUFELENBQWxDO0FBQUEsTUFBTytCLEtBQVA7QUFBQSxNQUFjUSxRQUFkOztBQUVBQyxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBQTRCbkIsS0FBSyxDQUFDSixNQUFsQztBQUVBc0IsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFxQmxCLEtBQXJCOztBQUNBLE1BQU1tQixZQUFZLEdBQUcsU0FBZkEsWUFBZSxDQUFDQyxNQUFELEVBQVNDLGFBQVQsRUFBMkI7QUFDOUMsUUFBSXRCLEtBQUssQ0FBQ0osTUFBVixFQUFrQjtBQUFBOztBQUNoQix1QkFBQUksS0FBSyxDQUFDSixNQUFOLGdFQUFjMkIsR0FBZCxDQUFrQixVQUFDQyxDQUFELEVBQU87QUFDdkJqQyxRQUFBQSxJQUFJLFNBQUosSUFBQUEsSUFBSSxXQUFKLFlBQUFBLElBQUksQ0FBRWdDLEdBQU4sQ0FBVSxVQUFDRSxDQUFELEVBQU87QUFDZixjQUFJRCxDQUFDLENBQUNFLFdBQUYsSUFBaUJELENBQUMsQ0FBQ0MsV0FBdkIsRUFBb0M7QUFDbEMsZ0JBQUlELENBQUMsQ0FBQ3JCLEdBQUYsR0FBUXVCLEdBQVIsSUFBZUgsQ0FBQyxDQUFDSSxNQUFyQixFQUE2QjtBQUMzQlYsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWjtBQUNEO0FBQ0Y7QUFDRixTQU5EO0FBT0QsT0FSRDtBQVNEOztBQUNELFFBQUk1QixJQUFJLEdBQUc7QUFDVEssTUFBQUEsTUFBTSxFQUFFQTtBQURDLEtBQVg7QUFHQXNCLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZNUIsSUFBWjtBQUVBbkIsSUFBQUEsaURBQUEsQ0FDUSxPQURSLEVBQ2lCbUIsSUFEakIsRUFFR3VDLElBRkgsQ0FFUSxVQUFDQyxHQUFELEVBQVM7QUFDYmIsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlZLEdBQVo7QUFDQWIsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVkscUNBQVo7QUFDQXZCLE1BQUFBLE1BQU0sR0FBRyxFQUFUO0FBQ0FPLE1BQUFBLE9BQU8sQ0FBQzZCLElBQVIsQ0FBYSxXQUFiO0FBQ0QsS0FQSCxXQVFTLFVBQUNDLEdBQUQsRUFBUztBQUNkZixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWWMsR0FBRyxDQUFDQyxRQUFKLENBQWEzQyxJQUF6QixFQURjLENBRWQ7QUFDQTtBQUNELEtBWkg7QUFhRCxHQTlCRDs7QUFnQ0EyQixFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQXFCdkIsTUFBckI7QUFDQXNCLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVosRUFBdUJULE9BQXZCO0FBQ0EsTUFBTXlCLFVBQVUsR0FBRzVDLDhEQUFuQjtBQUVBLHNCQUNFO0FBQUssYUFBUyxFQUFDLEVBQWY7QUFBQSw0QkFDRSw4REFBQyxrREFBRDtBQUFBLDhCQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFRTtBQUFNLFdBQUcsRUFBQyxNQUFWO0FBQWlCLFlBQUksRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFLRSw4REFBQyw2Q0FBRDtBQUFNLGVBQVMsRUFBQyxtQ0FBaEI7QUFBQSw2QkFDRSw4REFBQyxpREFBRDtBQUFBLCtCQUNFLDhEQUFDLDBDQUFEO0FBQ0UsdUJBQWEsRUFBRTtBQUNiSyxZQUFBQSxNQUFNLEVBQUUsRUFESztBQUViZ0MsWUFBQUEsTUFBTSxFQUFFO0FBRkssV0FEakI7QUFLRSxrQkFBUSxFQUFFLGtCQUFDUCxNQUFELEVBQVNDLGFBQVQsRUFBMkI7QUFBQTs7QUFDbkMsZ0JBQUksbUJBQUF0QixLQUFLLENBQUNKLE1BQU4sa0VBQWN3QyxNQUFkLElBQXVCLENBQXZCLElBQTRCN0MsdURBQWhDLEVBQXNDO0FBQUE7O0FBQ3BDMkIsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksZUFBWixvQkFBNkJuQixLQUFLLENBQUNKLE1BQW5DLG1EQUE2QixlQUFjd0MsTUFBM0M7QUFDQSxrQkFBTUMsWUFBWSxxQkFBR3JDLEtBQUssQ0FBQ0osTUFBVCxtREFBRyxlQUFjd0MsTUFBbkMsQ0FGb0MsQ0FHcEM7QUFDQTtBQUNBOztBQUVBLGdDQUFBcEMsS0FBSyxDQUFDSixNQUFOLGtFQUFjMkIsR0FBZCxDQUFrQixVQUFDQyxDQUFELEVBQU87QUFDdkJOLGdCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxZQUFaO0FBQ0E1QixnQkFBQUEsdURBQUksU0FBSixJQUFBQSx1REFBSSxXQUFKLFlBQUFBLDJEQUFBLENBQVUsVUFBQ2tDLENBQUQsRUFBTztBQUNmUCxrQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWjs7QUFDQSxzQkFBSUssQ0FBQyxDQUFDRSxXQUFGLElBQWlCRCxDQUFDLENBQUNhLEVBQXZCLEVBQTJCO0FBQ3pCcEIsb0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGVBQVosRUFBNkJLLENBQUMsQ0FBQ0UsV0FBL0IsRUFBNEMsTUFBNUMsRUFBb0RELENBQUMsQ0FBQ2EsRUFBdEQ7O0FBQ0Esd0JBQUliLENBQUMsQ0FBQ3BCLEdBQUYsSUFBU21CLENBQUMsQ0FBQ0ksTUFBZixFQUF1QjtBQUNyQlYsc0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVo7QUFDRDs7QUFDRCx3QkFBSU0sQ0FBQyxDQUFDckIsR0FBRixJQUFTb0IsQ0FBQyxDQUFDSSxNQUFmLEVBQXVCO0FBQ3JCVixzQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksS0FBWjtBQUNBUCxzQkFBQUEsTUFBTSxNQUFOLHFJQUFVUixHQUFWLFVBQWVBLEdBQUcsR0FBRyxDQUFyQjtBQUNEOztBQUNELHdCQUFJcUIsQ0FBQyxDQUFDbkIsR0FBRixJQUFTa0IsQ0FBQyxDQUFDSSxNQUFmLEVBQXVCO0FBQ3JCVixzQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksS0FBWjtBQUNBTCxzQkFBQUEsTUFBTSxNQUFOLHFJQUFVUixHQUFWLFVBQWVBLEdBQUcsR0FBRyxDQUFyQjtBQUNEOztBQUNELHdCQUFJbUIsQ0FBQyxDQUFDbEIsR0FBRixJQUFTaUIsQ0FBQyxDQUFDSSxNQUFmLEVBQXVCO0FBQ3JCVixzQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksS0FBWjtBQUNBSixzQkFBQUEsTUFBTSxNQUFOLHFJQUFVUixHQUFWLFVBQWVBLEdBQUcsR0FBRyxDQUFyQjtBQUNEOztBQUNELHdCQUFJa0IsQ0FBQyxDQUFDakIsS0FBRixJQUFXZ0IsQ0FBQyxDQUFDSSxNQUFqQixFQUF5QjtBQUN2QlYsc0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7QUFDQUgsc0JBQUFBLFFBQVEsTUFBUixxSUFBWVIsS0FBWixVQUFtQkEsS0FBSyxHQUFHLENBQTNCO0FBQ0Q7O0FBQ0Qsd0JBQUlpQixDQUFDLENBQUNoQixLQUFGLElBQVdlLENBQUMsQ0FBQ0ksTUFBakIsRUFBeUI7QUFDdkJWLHNCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0FGLHNCQUFBQSxRQUFRLE1BQVIscUlBQVlSLEtBQVosVUFBbUJBLEtBQUssR0FBRyxDQUEzQjtBQUNELHFCQUhELE1BR087QUFDTFMsc0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLG1CQUFaO0FBQ0Q7QUFDRjtBQUNGLGlCQTlCRDtBQStCRCxlQWpDRDtBQWtDRDs7QUFFREQsWUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQTVDbUMsQ0E2Q25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNELFdBL0RIO0FBQUEsb0JBaUVHLHdCQUFzQjtBQUFBLGdCQUFuQkMsWUFBbUIsUUFBbkJBLFlBQW1CO0FBQ3JCLGdDQUNFLDhEQUFDLDZDQUFEO0FBQU0sc0JBQVEsRUFBRUEsWUFBaEI7QUFBQSx5QkFDRzdCLHVEQURILGFBQ0dBLHVEQURILHVCQUNHQSwyREFBQSxDQUFVLFVBQUNrQyxDQUFELEVBQUlhLEVBQUosRUFBVztBQUNwQixvQ0FDRTtBQUFnQiwyQkFBUyxFQUFDLE1BQTFCO0FBQUEsMENBQ0UsOERBQUMsa0RBQUQ7QUFBQSwrQkFDRyxHQURILEVBRUdiLENBQUMsQ0FBQ2EsRUFGTCxPQUVVSCxVQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFERixlQUtFLDhEQUFDLHFEQUFEO0FBQUEsOEJBQWVWLENBQUMsQ0FBQ2M7QUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFMRixlQU1FLDhEQUFDLGlEQUFEO0FBQUEsOEJBQVdkLENBQUMsQ0FBQ2U7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU5GLGVBT0UsOERBQUMsOENBQUQ7QUFDRSx3QkFBSSxFQUFDLFFBRFA7QUFFRSwwQkFBTSxFQUFFLGdCQUFDQyxZQUFELEVBQWtCO0FBQ3hCLDBDQUNFO0FBQUEsK0NBQ0UsOERBQUMsNENBQUQ7QUFBQSxpREFDRSw4REFBQyw0Q0FBRDtBQUFBLG1EQUNFLDhEQUFDLGtEQUFEO0FBQUEscURBQ0UsOERBQUMsbURBQUQ7QUFBWSx5Q0FBUyxFQUFDLG9CQUF0QjtBQUFBLDBDQUNHakQsMERBREgsYUFDR0EsMERBREgsdUJBQ0dBLDhEQUFBLENBQWEsVUFBQ2tELEdBQUQsRUFBUztBQUNyQixzREFDRTtBQUVFLDZDQUFTLEVBQUMsNkZBRlo7QUFBQSw0REFJRSw4REFBQyx5Q0FBRDtBQUNFLDBDQUFJLEVBQUMsT0FEUCxDQUVFO0FBRkY7QUFHRSwyQ0FBSyxFQUFFQSxHQUFHLENBQUNDLFlBSGI7QUFJRSwrQ0FBUyxFQUFDLFFBSlo7QUFLRSw4Q0FBUSxFQUFFLG9CQUFNO0FBQ2R6Qyx3Q0FBQUEsUUFBUSxDQUFDO0FBQ1B3QiwwQ0FBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNhLEVBRFI7QUFFUFYsMENBQUFBLE1BQU0sRUFBRWMsR0FBRyxDQUFDQztBQUZMLHlDQUFELENBQVI7O0FBS0EsNENBQUkvQyxNQUFNLENBQUN3QyxNQUFQLEdBQWdCLENBQXBCLEVBQXVCO0FBQ3JCLCtDQUNFLElBQUlRLENBQUMsR0FBRyxDQURWLEVBRUVBLENBQUMsR0FBR2hELE1BQU0sQ0FBQ3dDLE1BRmIsRUFHRVEsQ0FBQyxFQUhILEVBSUU7QUFBQTs7QUFDQSxnREFDRSxjQUFBaEQsTUFBTSxDQUFDZ0QsQ0FBRCxDQUFOLHdEQUNJbEIsV0FESixLQUNtQkQsQ0FBQyxDQUFDYSxFQUZ2QixFQUdFO0FBQ0FwQiw4Q0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWjtBQUNBdkIsOENBQUFBLE1BQU0sQ0FBQ2lELE1BQVAsQ0FBY0QsQ0FBZCxFQUFpQixDQUFqQixFQUFvQjtBQUNsQmxCLGdEQUFBQSxXQUFXLEVBQUVELENBQUMsQ0FBQ2EsRUFERztBQUVsQlYsZ0RBQUFBLE1BQU0sRUFDSmMsR0FBRyxDQUFDQztBQUhZLCtDQUFwQjtBQUtBO0FBQ0QsNkNBWEQsTUFXTyxJQUNML0MsTUFBTSxDQUFDZ0QsQ0FBRCxDQUFOLENBQ0dsQixXQURILEtBQ21CRCxDQUFDLENBQUNhLEVBRmhCLEVBR0w7QUFDQXBCLDhDQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FDRSwwQkFERixFQUVFTSxDQUFDLENBQUNhLEVBRkosRUFHRSxhQUhGLEVBSUUxQyxNQUFNLENBQUNnRCxDQUFELENBQU4sQ0FBVWxCLFdBSlo7QUFPQTlCLDhDQUFBQSxNQUFNLENBQUNvQyxJQUFQLENBQVk7QUFDVk4sZ0RBQUFBLFdBQVcsRUFBRUQsQ0FBQyxDQUFDYSxFQURMO0FBRVZWLGdEQUFBQSxNQUFNLEVBQ0pjLEdBQUcsQ0FBQ0MsWUFISSxDQUlWOztBQUpVLCtDQUFaO0FBTUE7QUFDRDtBQUNGOztBQUNEM0MsMENBQUFBLEtBQUssQ0FBQzhDLGFBQU4sQ0FBb0JsRCxNQUFwQjtBQUNELHlDQXRDRCxNQXNDTztBQUNMc0IsMENBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVo7QUFDQXZCLDBDQUFBQSxNQUFNLENBQUNvQyxJQUFQLENBQVk7QUFDVk4sNENBQUFBLFdBQVcsRUFBRUQsQ0FBQyxDQUFDYSxFQURMO0FBRVZWLDRDQUFBQSxNQUFNLEVBQUVjLEdBQUcsQ0FBQ0M7QUFGRiwyQ0FBWjtBQUlBM0MsMENBQUFBLEtBQUssQ0FBQzhDLGFBQU4sQ0FBb0JsRCxNQUFwQjtBQUNEO0FBQ0Y7QUF6REg7QUFBQTtBQUFBO0FBQUE7QUFBQSw2Q0FKRixFQStERzhDLEdBQUcsQ0FBQ0ssV0EvRFA7QUFBQSxxQ0FDT0wsR0FBRyxDQUFDSixFQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkNBREY7QUFtRUQsaUNBcEVBO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBREY7QUEwRkQ7QUE3Rkg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFQRjtBQUFBLG1CQUFVYixDQUFDLENBQUNhLEVBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERjtBQXlHRCxlQTFHQSxDQURILGVBNEdFO0FBQUsseUJBQVMsRUFBQyxxQkFBZjtBQUFBLHVDQUNFLDhEQUFDLCtDQUFEO0FBQ0UsdUJBQUssTUFEUDtBQUVFLDJCQUFTLEVBQUMsZ0NBRlo7QUFHRSxzQkFBSSxFQUFDLFFBSFAsQ0FJRTtBQUNBO0FBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTVHRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREY7QUEwSEQ7QUE1TEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUEwTUQ7O0dBclFRdkM7VUFFU0o7OztLQUZUSTs7QUF1UVQsSUFBTWlELGVBQWUsR0FBRyxTQUFsQkEsZUFBa0IsQ0FBQ0MsS0FBRCxFQUFXO0FBQ2pDLFNBQU87QUFDTHJELElBQUFBLE1BQU0sRUFBRXFELEtBQUssQ0FBQ3JELE1BQU4sQ0FBYUE7QUFEaEIsR0FBUDtBQUdELENBSkQ7O0FBTUEsSUFBTXNELGtCQUFrQixHQUFHLFNBQXJCQSxrQkFBcUIsQ0FBQ0MsUUFBRCxFQUFjO0FBQ3ZDLFNBQU87QUFDTEwsSUFBQUEsYUFBYSxFQUFFLHVCQUFDdkQsSUFBRDtBQUFBLGFBQVU0RCxRQUFRLENBQUN6RCx5REFBQSxDQUFzQkgsSUFBdEIsQ0FBRCxDQUFsQjtBQUFBLEtBRFY7QUFFTDZELElBQUFBLGNBQWMsRUFBRSx3QkFBQzdELElBQUQsRUFBTytDLEVBQVA7QUFBQSxhQUFjYSxRQUFRLENBQUN6RCx3REFBQSxDQUFxQkgsSUFBckIsRUFBMkIrQyxFQUEzQixDQUFELENBQXRCO0FBQUEsS0FGWDtBQUdMZ0IsSUFBQUEsZ0JBQWdCLEVBQUUsMEJBQUMvRCxJQUFELEVBQU9nRSxJQUFQLEVBQWFDLE1BQWI7QUFBQSxhQUNoQkwsUUFBUSxDQUFDekQsMERBQUEsQ0FBdUJILElBQXZCLEVBQTZCZ0UsSUFBN0IsRUFBbUNDLE1BQW5DLENBQUQsQ0FEUTtBQUFBLEtBSGI7QUFLTEUsSUFBQUEsa0JBQWtCLEVBQUUsNEJBQUNuRSxJQUFELEVBQU9nRSxJQUFQLEVBQWFDLE1BQWI7QUFBQSxhQUNsQkwsUUFBUSxDQUFDekQsNERBQUEsQ0FBeUJILElBQXpCLEVBQStCZ0UsSUFBL0IsRUFBcUNDLE1BQXJDLENBQUQsQ0FEVTtBQUFBLEtBTGY7QUFPTEksSUFBQUEsaUJBQWlCLEVBQUUsMkJBQUNyRSxJQUFEO0FBQUEsYUFBVTRELFFBQVEsQ0FBQ3pELDZEQUFBLENBQTBCSCxJQUExQixDQUFELENBQWxCO0FBQUE7QUFQZCxHQUFQO0FBU0QsQ0FWRDs7QUFXQSwrREFBZUUsb0RBQU8sQ0FBQ3VELGVBQUQsRUFBa0JFLGtCQUFsQixDQUFQLENBQTZDbkQsSUFBN0MsQ0FBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsVGU7QUFDZjs7QUFFQSx5Q0FBeUMsU0FBUztBQUNsRDtBQUNBOztBQUVBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7OztBQ1JxRDtBQUN0QztBQUNmLGlDQUFpQyw2REFBZ0I7QUFDakQ7Ozs7Ozs7Ozs7Ozs7O0FDSGU7QUFDZjtBQUNBOzs7Ozs7Ozs7Ozs7OztBQ0ZlO0FBQ2Y7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRnVEO0FBQ0o7QUFDc0I7QUFDbEI7QUFDeEM7QUFDZixTQUFTLDhEQUFpQixTQUFTLDREQUFlLFNBQVMsdUVBQTBCLFNBQVMsOERBQWlCO0FBQy9HOzs7Ozs7Ozs7Ozs7Ozs7QUNOcUQ7QUFDdEM7QUFDZjtBQUNBLG9DQUFvQyw2REFBZ0I7QUFDcEQ7QUFDQTtBQUNBO0FBQ0Esc0ZBQXNGLDZEQUFnQjtBQUN0RyIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9wYWdlcy9pbmRleC5qcyIsIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvZXNtL2FycmF5TGlrZVRvQXJyYXkuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL2VzbS9hcnJheVdpdGhvdXRIb2xlcy5qcyIsIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvZXNtL2l0ZXJhYmxlVG9BcnJheS5qcyIsIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvZXNtL25vbkl0ZXJhYmxlU3ByZWFkLmpzIiwid2VicGFjazovL19OX0UvLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9lc20vdG9Db25zdW1hYmxlQXJyYXkuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL2VzbS91bnN1cHBvcnRlZEl0ZXJhYmxlVG9BcnJheS5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XG5pbXBvcnQgeyBGaWVsZCwgRmllbGRBcnJheSwgRm9ybWlrIH0gZnJvbSBcImZvcm1pa1wiO1xuaW1wb3J0IEhlYWQgZnJvbSBcIm5leHQvaGVhZFwiO1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHtcbiAgQnV0dG9uLFxuICBDYXJkLFxuICBDYXJkQm9keSxcbiAgQ2FyZEhlYWRlcixcbiAgQ2FyZFN1YnRpdGxlLFxuICBDYXJkVGV4dCxcbiAgQ2FyZFRpdGxlLFxuICBDb2wsXG4gIEZvcm0sXG4gIEZvcm1Hcm91cCxcbiAgSW5wdXRHcm91cCxcbiAgUm93LFxufSBmcm9tIFwicmVhY3RzdHJhcFwiO1xuaW1wb3J0IGRhdGEgZnJvbSBcIi4uL2NvbXBvbmVudHMvRGF0YS9EYXRhLmpzb25cIjtcbmltcG9ydCBvcHRpb25zIGZyb20gXCIuLi9jb21wb25lbnRzL0RhdGEvb3B0aW9ucy5qc29uXCI7XG5pbXBvcnQgeyBjb25uZWN0IH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XG5pbXBvcnQgKiBhcyBhY3Rpb25zIGZyb20gXCIuLi9yZWR1eC9hY3Rpb25zXCI7XG5pbXBvcnQgeyB1c2VIaXN0b3J5IH0gZnJvbSBcInJlYWN0LXJvdXRlclwiO1xuXG52YXIgcmVzdWx0ID0gbmV3IEFycmF5KCk7XG52YXIgTWFpblJlc3VsdCA9IG5ldyBBcnJheSgpO1xuZnVuY3Rpb24gSG9tZShwcm9wcykge1xuICBjb25zdCBbdmFsdWUsIHNldFZhbHVlXSA9IHVzZVN0YXRlKHt9KTtcbiAgY29uc3QgaGlzdG9yeSA9IHVzZUhpc3RvcnkoKTtcblxuICBjb25zdCBbY29tcGFueSwgc2V0Q29tcGFueV0gPSB1c2VTdGF0ZSh7XG4gICAgQ0RVOiAwLFxuICAgIFNQRDogMCxcbiAgICBBZkQ6IDAsXG4gICAgRkRQOiAwLFxuICAgIEdyw7xuZTogMCxcbiAgICBMaW5rZTogMCxcbiAgfSk7XG5cbiAgY29uc3QgW0NEVSwgc2V0Q0RVXSA9IHVzZVN0YXRlKDApO1xuICBjb25zdCBbU1BELCBzZXRTUERdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtBZkQsIHNldEFmRF0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW0ZEUCwgc2V0RkRQXSA9IHVzZVN0YXRlKDApO1xuICBjb25zdCBbR3LDvG5lLCBzZXRHcsO8bmVdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtMaW5rZSwgc2V0TGlua2VdID0gdXNlU3RhdGUoMCk7XG5cbiAgY29uc29sZS5sb2coXCJwcm9wcy5yZXN1bHRcIiwgcHJvcHMucmVzdWx0KTtcblxuICBjb25zb2xlLmxvZyhcInZhbHVlXCIsIHZhbHVlKTtcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gKHZhbHVlcywgc2V0U3VibWl0dGluZykgPT4ge1xuICAgIGlmIChwcm9wcy5yZXN1bHQpIHtcbiAgICAgIHByb3BzLnJlc3VsdD8ubWFwKChyKSA9PiB7XG4gICAgICAgIGRhdGE/Lm1hcCgoZCkgPT4ge1xuICAgICAgICAgIGlmIChyLnF1ZXN0aW9uX2lkID09IGQucXVlc3Rpb25faWQpIHtcbiAgICAgICAgICAgIGlmIChkLkNEVSAvIENTVSA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImFha2FzaFwiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGxldCBkYXRhID0ge1xuICAgICAgcmVzdWx0OiByZXN1bHQsXG4gICAgfTtcbiAgICBjb25zb2xlLmxvZyhkYXRhKTtcblxuICAgIGF4aW9zXG4gICAgICAucG9zdChcIi90ZXN0XCIsIGRhdGEpXG4gICAgICAudGhlbigocmVzKSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKHJlcyk7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiaW50aWFsIHZhbHVlIGlzIHN1Ym1pdGVkIHRvIHJlc3VsdHNcIik7XG4gICAgICAgIHJlc3VsdCA9IFtdO1xuICAgICAgICBoaXN0b3J5LnB1c2goXCIvdGhhbmt5b3VcIik7XG4gICAgICB9KVxuICAgICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgY29uc29sZS5sb2coZXJyLnJlc3BvbnNlLmRhdGEpO1xuICAgICAgICAvLyBoaXN0b3J5LnB1c2goXCIvZXhhbS1hcHBlYXJlZFwiKTtcbiAgICAgICAgLy8gcmVzdWx0ID0gW107XG4gICAgICB9KTtcbiAgfTtcblxuICBjb25zb2xlLmxvZyhcImFycmF5XCIsIHJlc3VsdCk7XG4gIGNvbnNvbGUubG9nKFwiY29tcGFueVwiLCBjb21wYW55KTtcbiAgY29uc3QgZGF0YUxlbmd0aCA9IGRhdGEubGVuZ3RoO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJcIj5cbiAgICAgIDxIZWFkPlxuICAgICAgICA8dGl0bGU+Q3JlYXRlIE5leHQgQXBwPC90aXRsZT5cbiAgICAgICAgPGxpbmsgcmVsPVwiaWNvblwiIGhyZWY9XCIvZmF2aWNvbi5pY29cIiAvPlxuICAgICAgPC9IZWFkPlxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC01IGJvcmRlci0yIHNoYWRvdy1tZCByb3VuZGVkLW1kXCI+XG4gICAgICAgIDxDYXJkQm9keT5cbiAgICAgICAgICA8Rm9ybWlrXG4gICAgICAgICAgICBpbml0aWFsVmFsdWVzPXt7XG4gICAgICAgICAgICAgIHJlc3VsdDogW10sXG4gICAgICAgICAgICAgIGFuc3dlcjogXCJcIixcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBvblN1Ym1pdD17KHZhbHVlcywgc2V0U3VibWl0dGluZykgPT4ge1xuICAgICAgICAgICAgICBpZiAocHJvcHMucmVzdWx0Py5sZW5ndGggPiAwICYmIGRhdGEpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInJlc3VsdCBsZW5ndGhcIiwgcHJvcHMucmVzdWx0Py5sZW5ndGgpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3VsdExlbmd0aCA9IHByb3BzLnJlc3VsdD8ubGVuZ3RoO1xuICAgICAgICAgICAgICAgIC8vIGZvciAobGV0IGkgPSAwOyBpIDwgcmVzdWx0TGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAvLyAgIGNvbnNvbGUubG9nKFwicmVzdWx0IG1hcFwiKTtcbiAgICAgICAgICAgICAgICAvLyB9XG5cbiAgICAgICAgICAgICAgICBwcm9wcy5yZXN1bHQ/Lm1hcCgocikgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJyZXN1bHQgbWFwXCIpO1xuICAgICAgICAgICAgICAgICAgZGF0YT8ubWFwKChkKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZGF0YSBtYXBcIik7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyLnF1ZXN0aW9uX2lkID09IGQuaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInIucXVlc3Rpb25faWRcIiwgci5xdWVzdGlvbl9pZCwgXCJkLmlkXCIsIGQuaWQpO1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChkLlNQRCA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJTUERcIik7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIGlmIChkLkNEVSA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDRFVcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRDRFUoLi4uQ0RVLCBDRFUgKyAxKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGQuQWZEID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkFmRFwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEFmRCguLi5BZkQsIEFmRCArIDEpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICBpZiAoZC5GRFAgPT0gci5hbnN3ZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiRkRQXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0RkRQKC4uLkZEUCwgRkRQICsgMSk7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIGlmIChkLkdyw7xuZSA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJHcsO8bmVcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRHcsO8bmUoLi4uR3LDvG5lLCBHcsO8bmUgKyAxKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGQuTGlua2UgPT0gci5hbnN3ZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiTGlua2VcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRMaW5rZSguLi5MaW5rZSwgTGlua2UgKyAxKTtcbiAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJlbHNlIGZyb20gbGFzdCBpZlwiKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJzdWJtaXQgY2xpY2tcIik7XG4gICAgICAgICAgICAgIC8vIGF4aW9zXG4gICAgICAgICAgICAgIC8vICAgLnBvc3QoXCJodHRwczovL3VkaXRzb2x1dGlvbnMuaW4veWFybi9wdWJsaWMvYXBpL3Njb3Jlc1wiLCBkYXRhKVxuICAgICAgICAgICAgICAvLyAgIC50aGVuKChyZXMpID0+IHtcbiAgICAgICAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKHJlcyk7XG4gICAgICAgICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhcImludGlhbCB2YWx1ZSBpcyBzdWJtaXRlZCB0byByZXN1bHRzXCIpO1xuICAgICAgICAgICAgICAvLyAgICAgcmVzdWx0ID0gW107XG4gICAgICAgICAgICAgIC8vICAgICBoaXN0b3J5LnB1c2goXCIvdGhhbmt5b3VcIik7XG4gICAgICAgICAgICAgIC8vICAgfSlcbiAgICAgICAgICAgICAgLy8gICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICAgICAgICAvLyAgICAgY29uc29sZS5sb2coZXJyLnJlc3BvbnNlLmRhdGEpO1xuICAgICAgICAgICAgICAvLyAgICAgLy8gaGlzdG9yeS5wdXNoKFwiL2V4YW0tYXBwZWFyZWRcIik7XG5cbiAgICAgICAgICAgICAgLy8gICB9KTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgeyh7IGhhbmRsZVN1Ym1pdCB9KSA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPEZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XG4gICAgICAgICAgICAgICAgICB7ZGF0YT8ubWFwKChkLCBpZCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtkLmlkfSBjbGFzc05hbWU9XCJtdC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2FyZFRpdGxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7XCIgXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtkLmlkfS97ZGF0YUxlbmd0aH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQ2FyZFRpdGxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcmRTdWJ0aXRsZT57ZC5TY2hsYWd3b3J0fTwvQ2FyZFN1YnRpdGxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcmRUZXh0PntkLnF1ZXN0aW9uX3RleHR9PC9DYXJkVGV4dD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGaWVsZEFycmF5XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZXN1bHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICByZW5kZXI9eyhhcnJheUhlbHBlcnMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJvdz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q29sPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0R3JvdXAgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29wdGlvbnM/Lm1hcCgob3B0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e29wdC5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgYmctZ3JheS02MDAgdGV4dC13aGl0ZSByb3VuZGVkLW1kIHRleHQtY2VudGVyIGhvdmVyOmJnLXllbGxvdy0zMDAgaG92ZXI6dGV4dC1ibGFjayBtYi0xXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhZGlvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIG5hbWU9XCJhbnN3ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e29wdC5vcHRpb25fVmFsdWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VmFsdWUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uX2lkOiBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjogb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBpID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGkgPCByZXN1bHQubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaSsrXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdFtpXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8ucXVlc3Rpb25faWQgPT0gZC5pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic3BsaWNlXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQuc3BsaWNlKGksIDEsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHQub3B0aW9uX1ZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0W2ldXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnF1ZXN0aW9uX2lkICE9PSBkLmlkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbHNlX2lmIHF1ZXN0aW9uIG9mIGRhdGFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwicmVzdWx0IHEtaWRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV0ucXVlc3Rpb25faWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25faWQ6IGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcHMucmVzdWx0U2V0RGF0YShyZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZWxzZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjogb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wcy5yZXN1bHRTZXREYXRhKHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3B0Lm9wdGlvbl90ZXh0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOntcIiBcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZXN1bHQ/Lm1hcCgocikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoci5xdWVzdGlvbl9pZCA9PSBkLmlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHIuYW5zd2VyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvSW5wdXRHcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIGJsb2NrXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLTIgcC0yIGJvcmRlci1ibGFjayBtdC03XCJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAvLyBvbkNsaWNrPXtoYW5kbGVTdWJtaXR9XG4gICAgICAgICAgICAgICAgICAgICAgLy8gZGlzYWJsZWQ9e2Zvcm1Qcm9wcy5pc1N1Ym1pdHRpbmd9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICBFZWdlYm5pcyB6ZWlnZW5cbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L0Zvcm0+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgIDwvRm9ybWlrPlxuICAgICAgICA8L0NhcmRCb2R5PlxuICAgICAgPC9DYXJkPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5jb25zdCBtYXBTdGF0ZVRvUHJvcHMgPSAoc3RhdGUpID0+IHtcbiAgcmV0dXJuIHtcbiAgICByZXN1bHQ6IHN0YXRlLnJlc3VsdC5yZXN1bHQsXG4gIH07XG59O1xuXG5jb25zdCBtYXBEaXNwYXRjaFRvUHJvcHMgPSAoZGlzcGF0Y2gpID0+IHtcbiAgcmV0dXJuIHtcbiAgICByZXN1bHRTZXREYXRhOiAoZGF0YSkgPT4gZGlzcGF0Y2goYWN0aW9ucy5yZXN1bHRTZXREYXRhKGRhdGEpKSxcbiAgICBvbkRlbGV0ZVJlc3VsdDogKGRhdGEsIGlkKSA9PiBkaXNwYXRjaChhY3Rpb25zLmRlbGV0ZVJlc3VsdChkYXRhLCBpZCkpLFxuICAgIG9uUG9zdFJlc3VsdERhdGE6IChkYXRhLCB1c2VyLCB0b2dnbGUpID0+XG4gICAgICBkaXNwYXRjaChhY3Rpb25zLnBvc3RSZXN1bHREYXRhKGRhdGEsIHVzZXIsIHRvZ2dsZSkpLFxuICAgIG9uVXBkYXRlUmVzdWx0RGF0YTogKGRhdGEsIHVzZXIsIHRvZ2dsZSkgPT5cbiAgICAgIGRpc3BhdGNoKGFjdGlvbnMudXBkYXRlUmVzdWx0RGF0YShkYXRhLCB1c2VyLCB0b2dnbGUpKSxcbiAgICByZXN1bHRFZGl0R2V0RGF0YTogKGRhdGEpID0+IGRpc3BhdGNoKGFjdGlvbnMucmVzdWx0RWRpdEdldERhdGEoZGF0YSkpLFxuICB9O1xufTtcbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QobWFwU3RhdGVUb1Byb3BzLCBtYXBEaXNwYXRjaFRvUHJvcHMpKEhvbWUpO1xuIiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gX2FycmF5TGlrZVRvQXJyYXkoYXJyLCBsZW4pIHtcbiAgaWYgKGxlbiA9PSBudWxsIHx8IGxlbiA+IGFyci5sZW5ndGgpIGxlbiA9IGFyci5sZW5ndGg7XG5cbiAgZm9yICh2YXIgaSA9IDAsIGFycjIgPSBuZXcgQXJyYXkobGVuKTsgaSA8IGxlbjsgaSsrKSB7XG4gICAgYXJyMltpXSA9IGFycltpXTtcbiAgfVxuXG4gIHJldHVybiBhcnIyO1xufSIsImltcG9ydCBhcnJheUxpa2VUb0FycmF5IGZyb20gXCIuL2FycmF5TGlrZVRvQXJyYXkuanNcIjtcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIF9hcnJheVdpdGhvdXRIb2xlcyhhcnIpIHtcbiAgaWYgKEFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIGFycmF5TGlrZVRvQXJyYXkoYXJyKTtcbn0iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBfaXRlcmFibGVUb0FycmF5KGl0ZXIpIHtcbiAgaWYgKHR5cGVvZiBTeW1ib2wgIT09IFwidW5kZWZpbmVkXCIgJiYgaXRlcltTeW1ib2wuaXRlcmF0b3JdICE9IG51bGwgfHwgaXRlcltcIkBAaXRlcmF0b3JcIl0gIT0gbnVsbCkgcmV0dXJuIEFycmF5LmZyb20oaXRlcik7XG59IiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gX25vbkl0ZXJhYmxlU3ByZWFkKCkge1xuICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiSW52YWxpZCBhdHRlbXB0IHRvIHNwcmVhZCBub24taXRlcmFibGUgaW5zdGFuY2UuXFxuSW4gb3JkZXIgdG8gYmUgaXRlcmFibGUsIG5vbi1hcnJheSBvYmplY3RzIG11c3QgaGF2ZSBhIFtTeW1ib2wuaXRlcmF0b3JdKCkgbWV0aG9kLlwiKTtcbn0iLCJpbXBvcnQgYXJyYXlXaXRob3V0SG9sZXMgZnJvbSBcIi4vYXJyYXlXaXRob3V0SG9sZXMuanNcIjtcbmltcG9ydCBpdGVyYWJsZVRvQXJyYXkgZnJvbSBcIi4vaXRlcmFibGVUb0FycmF5LmpzXCI7XG5pbXBvcnQgdW5zdXBwb3J0ZWRJdGVyYWJsZVRvQXJyYXkgZnJvbSBcIi4vdW5zdXBwb3J0ZWRJdGVyYWJsZVRvQXJyYXkuanNcIjtcbmltcG9ydCBub25JdGVyYWJsZVNwcmVhZCBmcm9tIFwiLi9ub25JdGVyYWJsZVNwcmVhZC5qc1wiO1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gX3RvQ29uc3VtYWJsZUFycmF5KGFycikge1xuICByZXR1cm4gYXJyYXlXaXRob3V0SG9sZXMoYXJyKSB8fCBpdGVyYWJsZVRvQXJyYXkoYXJyKSB8fCB1bnN1cHBvcnRlZEl0ZXJhYmxlVG9BcnJheShhcnIpIHx8IG5vbkl0ZXJhYmxlU3ByZWFkKCk7XG59IiwiaW1wb3J0IGFycmF5TGlrZVRvQXJyYXkgZnJvbSBcIi4vYXJyYXlMaWtlVG9BcnJheS5qc1wiO1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gX3Vuc3VwcG9ydGVkSXRlcmFibGVUb0FycmF5KG8sIG1pbkxlbikge1xuICBpZiAoIW8pIHJldHVybjtcbiAgaWYgKHR5cGVvZiBvID09PSBcInN0cmluZ1wiKSByZXR1cm4gYXJyYXlMaWtlVG9BcnJheShvLCBtaW5MZW4pO1xuICB2YXIgbiA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvKS5zbGljZSg4LCAtMSk7XG4gIGlmIChuID09PSBcIk9iamVjdFwiICYmIG8uY29uc3RydWN0b3IpIG4gPSBvLmNvbnN0cnVjdG9yLm5hbWU7XG4gIGlmIChuID09PSBcIk1hcFwiIHx8IG4gPT09IFwiU2V0XCIpIHJldHVybiBBcnJheS5mcm9tKG8pO1xuICBpZiAobiA9PT0gXCJBcmd1bWVudHNcIiB8fCAvXig/OlVpfEkpbnQoPzo4fDE2fDMyKSg/OkNsYW1wZWQpP0FycmF5JC8udGVzdChuKSkgcmV0dXJuIGFycmF5TGlrZVRvQXJyYXkobywgbWluTGVuKTtcbn0iXSwibmFtZXMiOlsiYXhpb3MiLCJGaWVsZCIsIkZpZWxkQXJyYXkiLCJGb3JtaWsiLCJIZWFkIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJCdXR0b24iLCJDYXJkIiwiQ2FyZEJvZHkiLCJDYXJkSGVhZGVyIiwiQ2FyZFN1YnRpdGxlIiwiQ2FyZFRleHQiLCJDYXJkVGl0bGUiLCJDb2wiLCJGb3JtIiwiRm9ybUdyb3VwIiwiSW5wdXRHcm91cCIsIlJvdyIsImRhdGEiLCJvcHRpb25zIiwiY29ubmVjdCIsImFjdGlvbnMiLCJ1c2VIaXN0b3J5IiwicmVzdWx0IiwiQXJyYXkiLCJNYWluUmVzdWx0IiwiSG9tZSIsInByb3BzIiwidmFsdWUiLCJzZXRWYWx1ZSIsImhpc3RvcnkiLCJDRFUiLCJTUEQiLCJBZkQiLCJGRFAiLCJHcsO8bmUiLCJMaW5rZSIsImNvbXBhbnkiLCJzZXRDb21wYW55Iiwic2V0Q0RVIiwic2V0U1BEIiwic2V0QWZEIiwic2V0RkRQIiwic2V0R3LDvG5lIiwic2V0TGlua2UiLCJjb25zb2xlIiwibG9nIiwiaGFuZGxlU3VibWl0IiwidmFsdWVzIiwic2V0U3VibWl0dGluZyIsIm1hcCIsInIiLCJkIiwicXVlc3Rpb25faWQiLCJDU1UiLCJhbnN3ZXIiLCJwb3N0IiwidGhlbiIsInJlcyIsInB1c2giLCJlcnIiLCJyZXNwb25zZSIsImRhdGFMZW5ndGgiLCJsZW5ndGgiLCJyZXN1bHRMZW5ndGgiLCJpZCIsIlNjaGxhZ3dvcnQiLCJxdWVzdGlvbl90ZXh0IiwiYXJyYXlIZWxwZXJzIiwib3B0Iiwib3B0aW9uX1ZhbHVlIiwiaSIsInNwbGljZSIsInJlc3VsdFNldERhdGEiLCJvcHRpb25fdGV4dCIsIm1hcFN0YXRlVG9Qcm9wcyIsInN0YXRlIiwibWFwRGlzcGF0Y2hUb1Byb3BzIiwiZGlzcGF0Y2giLCJvbkRlbGV0ZVJlc3VsdCIsImRlbGV0ZVJlc3VsdCIsIm9uUG9zdFJlc3VsdERhdGEiLCJ1c2VyIiwidG9nZ2xlIiwicG9zdFJlc3VsdERhdGEiLCJvblVwZGF0ZVJlc3VsdERhdGEiLCJ1cGRhdGVSZXN1bHREYXRhIiwicmVzdWx0RWRpdEdldERhdGEiXSwic291cmNlUm9vdCI6IiJ9