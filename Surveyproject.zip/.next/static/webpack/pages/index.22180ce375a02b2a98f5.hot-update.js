"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
/* harmony import */ var _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Data/Data.json */ "./components/Data/Data.json");
/* harmony import */ var _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Data/options.json */ "./components/Data/options.json");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _redux_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../redux/actions */ "./redux/actions/index.js");
/* harmony import */ var react_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-router */ "./node_modules/react-router/esm/react-router.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "E:\\git vinraj\\company-test\\pages\\index.js",
    _s = $RefreshSig$();












var result = new Array();

function Home(props) {
  _s();

  var _this = this;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      value = _useState[0],
      setValue = _useState[1];

  var history = (0,react_router__WEBPACK_IMPORTED_MODULE_9__.useHistory)();

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      company = _useState2[0],
      setCompany = _useState2[1];

  console.log("props.result", props.result);
  console.log("value", value);

  var handleSubmit = function handleSubmit(values, setSubmitting) {
    if (props.result) {
      var _props$result;

      (_props$result = props.result) === null || _props$result === void 0 ? void 0 : _props$result.map(function (r) {
        data === null || data === void 0 ? void 0 : data.map(function (d) {
          if (r.question_id == d.question_id) {
            if (d.CDU / CSU == r.answer) {
              console.log("aakash");
            }
          }
        });
      });
    }

    var data = {
      result: result
    };
    console.log(data);
    axios__WEBPACK_IMPORTED_MODULE_0___default().post("/test", data).then(function (res) {
      console.log(res);
      console.log("intial value is submited to results");
      result = [];
      history.push("/thankyou");
    })["catch"](function (err) {
      console.log(err.response.data); // history.push("/exam-appeared");
      // result = [];
    });
  };

  console.log("array", result);
  var dataLength = _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.length;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
    className: "",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("title", {
        children: "Create Next App"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 72,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 73,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 71,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Card, {
      className: "p-5 border-2 shadow-md rounded-md",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardBody, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
          initialValues: {
            result: [],
            answer: ""
          },
          onSubmit: function onSubmit(values, setSubmitting) {
            if (props.result) {
              var _props$result2;

              (_props$result2 = props.result) === null || _props$result2 === void 0 ? void 0 : _props$result2.map(function (r) {
                data === null || data === void 0 ? void 0 : data.map(function (d) {
                  if (r.question_id == d.question_id) {
                    if (d.CDU / CSU == r.answer) {
                      console.log("aakash");
                    }
                  }
                });
              });
            }

            var data = {
              result: result
            };
            console.log("aakash");
            axios__WEBPACK_IMPORTED_MODULE_0___default().post("https://uditsolutions.in/yarn/public/api/scores", data).then(function (res) {
              console.log(res);
              console.log("intial value is submited to results");
              result = [];
              history.push("/thankyou");
            })["catch"](function (err) {
              console.log(err.response.data); // history.push("/exam-appeared");
              // result = [];
            });
          },
          children: function children(_ref) {
            var handleSubmit = _ref.handleSubmit;
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Form, {
              onSubmit: handleSubmit,
              children: [_components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === null || _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === void 0 ? void 0 : _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.map(function (d, id) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                  className: "mt-3",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardTitle, {
                    children: [" ", d.id, "/", dataLength]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 120,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardSubtitle, {
                    children: d.Schlagwort
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 124,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardText, {
                    children: d.question_text
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 125,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.FieldArray, {
                    name: "result",
                    render: function render(arrayHelpers) {
                      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Row, {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Col, {
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.FormGroup, {
                              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.InputGroup, {
                                className: "flex flex-col mt-2",
                                children: _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === null || _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === void 0 ? void 0 : _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__.map(function (opt) {
                                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("label", {
                                    className: "p-2 bg-gray-600 text-white rounded-md text-center hover:bg-yellow-300 hover:text-black mb-1",
                                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                                      type: "radio" // name="answer"
                                      ,
                                      value: opt.option_Value,
                                      className: "hidden",
                                      onChange: function onChange() {
                                        setValue({
                                          question_id: d.id,
                                          answer: opt.option_Value
                                        });

                                        if (result.length > 0) {
                                          for (var i = 0; i < result.length; i++) {
                                            var _result$i;

                                            if (((_result$i = result[i]) === null || _result$i === void 0 ? void 0 : _result$i.question_id) == d.id) {
                                              console.log("splice");
                                              result.splice(i, 1, {
                                                question_id: d.id,
                                                answer: opt.option_Value
                                              });
                                              return;
                                            } else if (result[i].question_id !== d.id) {
                                              console.log("else_if question of data", d.id, "result q-id", result[i].question_id);
                                              result.push({
                                                question_id: d.id,
                                                answer: opt.option_Value // value,

                                              });
                                              return;
                                            }
                                          }
                                        } else {
                                          console.log("else");
                                          result.push({
                                            question_id: d.id,
                                            answer: opt.option_Value
                                          });
                                        }
                                      }
                                    }, void 0, false, {
                                      fileName: _jsxFileName,
                                      lineNumber: 141,
                                      columnNumber: 47
                                    }, _this), opt.option_text]
                                  }, opt.id, true, {
                                    fileName: _jsxFileName,
                                    lineNumber: 137,
                                    columnNumber: 45
                                  }, _this);
                                })
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 134,
                                columnNumber: 39
                              }, _this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 133,
                              columnNumber: 37
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 132,
                            columnNumber: 35
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 131,
                          columnNumber: 33
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 130,
                        columnNumber: 31
                      }, _this);
                    }
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 126,
                    columnNumber: 25
                  }, _this)]
                }, d.id, true, {
                  fileName: _jsxFileName,
                  lineNumber: 119,
                  columnNumber: 23
                }, _this);
              }), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Button, {
                  block: true,
                  className: "border-2 p-2 border-black mt-7",
                  type: "submit" // onClick={handleSubmit}
                  // disabled={formProps.isSubmitting}
                  ,
                  children: "Eegebnis zeigen"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 223,
                  columnNumber: 21
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 222,
                columnNumber: 19
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 116,
              columnNumber: 17
            }, _this);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 77,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 76,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 75,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 70,
    columnNumber: 5
  }, this);
}

_s(Home, "+Ok9uqErGU59sIRoYnjvw5OYqYQ=", false, function () {
  return [react_router__WEBPACK_IMPORTED_MODULE_9__.useHistory];
});

_c = Home;

var mapStateToProps = function mapStateToProps(state) {
  return {
    result: state.result.result
  };
};

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    resultSetData: function resultSetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultSetData(data));
    },
    onDeleteResult: function onDeleteResult(data, id) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.deleteResult(data, id));
    },
    onPostResultData: function onPostResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.postResultData(data, user, toggle));
    },
    onUpdateResultData: function onUpdateResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.updateResultData(data, user, toggle));
    },
    resultEditGetData: function resultEditGetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultEditGetData(data));
    }
  };
};

/* harmony default export */ __webpack_exports__["default"] = ((0,react_redux__WEBPACK_IMPORTED_MODULE_6__.connect)(mapStateToProps, mapDispatchToProps)(Home));

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguMjIxODBjZTM3NWEwMmIyYTk4ZjUuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFjQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLElBQUl3QixNQUFNLEdBQUcsSUFBSUMsS0FBSixFQUFiOztBQUNBLFNBQVNDLElBQVQsQ0FBY0MsS0FBZCxFQUFxQjtBQUFBOztBQUFBOztBQUNuQixrQkFBMEJyQiwrQ0FBUSxDQUFDLEVBQUQsQ0FBbEM7QUFBQSxNQUFPc0IsS0FBUDtBQUFBLE1BQWNDLFFBQWQ7O0FBQ0EsTUFBTUMsT0FBTyxHQUFHUCx3REFBVSxFQUExQjs7QUFFQSxtQkFBOEJqQiwrQ0FBUSxDQUFDLEVBQUQsQ0FBdEM7QUFBQSxNQUFPeUIsT0FBUDtBQUFBLE1BQWdCQyxVQUFoQjs7QUFFQUMsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUE0QlAsS0FBSyxDQUFDSCxNQUFsQztBQUVBUyxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQXFCTixLQUFyQjs7QUFDQSxNQUFNTyxZQUFZLEdBQUcsU0FBZkEsWUFBZSxDQUFDQyxNQUFELEVBQVNDLGFBQVQsRUFBMkI7QUFDOUMsUUFBSVYsS0FBSyxDQUFDSCxNQUFWLEVBQWtCO0FBQUE7O0FBQ2hCLHVCQUFBRyxLQUFLLENBQUNILE1BQU4sZ0VBQWNjLEdBQWQsQ0FBa0IsVUFBQ0MsQ0FBRCxFQUFPO0FBQ3ZCcEIsUUFBQUEsSUFBSSxTQUFKLElBQUFBLElBQUksV0FBSixZQUFBQSxJQUFJLENBQUVtQixHQUFOLENBQVUsVUFBQ0UsQ0FBRCxFQUFPO0FBQ2YsY0FBSUQsQ0FBQyxDQUFDRSxXQUFGLElBQWlCRCxDQUFDLENBQUNDLFdBQXZCLEVBQW9DO0FBQ2xDLGdCQUFJRCxDQUFDLENBQUNFLEdBQUYsR0FBUUMsR0FBUixJQUFlSixDQUFDLENBQUNLLE1BQXJCLEVBQTZCO0FBQzNCWCxjQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0FBQ0Q7QUFDRjtBQUNGLFNBTkQ7QUFPRCxPQVJEO0FBU0Q7O0FBQ0QsUUFBSWYsSUFBSSxHQUFHO0FBQ1RLLE1BQUFBLE1BQU0sRUFBRUE7QUFEQyxLQUFYO0FBR0FTLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZZixJQUFaO0FBRUFuQixJQUFBQSxpREFBQSxDQUNRLE9BRFIsRUFDaUJtQixJQURqQixFQUVHMkIsSUFGSCxDQUVRLFVBQUNDLEdBQUQsRUFBUztBQUNiZCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWWEsR0FBWjtBQUNBZCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxxQ0FBWjtBQUNBVixNQUFBQSxNQUFNLEdBQUcsRUFBVDtBQUNBTSxNQUFBQSxPQUFPLENBQUNrQixJQUFSLENBQWEsV0FBYjtBQUNELEtBUEgsV0FRUyxVQUFDQyxHQUFELEVBQVM7QUFDZGhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZZSxHQUFHLENBQUNDLFFBQUosQ0FBYS9CLElBQXpCLEVBRGMsQ0FFZDtBQUNBO0FBQ0QsS0FaSDtBQWFELEdBOUJEOztBQStCQWMsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFxQlYsTUFBckI7QUFDQSxNQUFNMkIsVUFBVSxHQUFHaEMsOERBQW5CO0FBRUEsc0JBQ0U7QUFBSyxhQUFTLEVBQUMsRUFBZjtBQUFBLDRCQUNFLDhEQUFDLGtEQUFEO0FBQUEsOEJBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUVFO0FBQU0sV0FBRyxFQUFDLE1BQVY7QUFBaUIsWUFBSSxFQUFDO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQUtFLDhEQUFDLDZDQUFEO0FBQU0sZUFBUyxFQUFDLG1DQUFoQjtBQUFBLDZCQUNFLDhEQUFDLGlEQUFEO0FBQUEsK0JBQ0UsOERBQUMsMENBQUQ7QUFDRSx1QkFBYSxFQUFFO0FBQ2JLLFlBQUFBLE1BQU0sRUFBRSxFQURLO0FBRWJvQixZQUFBQSxNQUFNLEVBQUU7QUFGSyxXQURqQjtBQUtFLGtCQUFRLEVBQUUsa0JBQUNSLE1BQUQsRUFBU0MsYUFBVCxFQUEyQjtBQUNuQyxnQkFBSVYsS0FBSyxDQUFDSCxNQUFWLEVBQWtCO0FBQUE7O0FBQ2hCLGdDQUFBRyxLQUFLLENBQUNILE1BQU4sa0VBQWNjLEdBQWQsQ0FBa0IsVUFBQ0MsQ0FBRCxFQUFPO0FBQ3ZCcEIsZ0JBQUFBLElBQUksU0FBSixJQUFBQSxJQUFJLFdBQUosWUFBQUEsSUFBSSxDQUFFbUIsR0FBTixDQUFVLFVBQUNFLENBQUQsRUFBTztBQUNmLHNCQUFJRCxDQUFDLENBQUNFLFdBQUYsSUFBaUJELENBQUMsQ0FBQ0MsV0FBdkIsRUFBb0M7QUFDbEMsd0JBQUlELENBQUMsQ0FBQ0UsR0FBRixHQUFRQyxHQUFSLElBQWVKLENBQUMsQ0FBQ0ssTUFBckIsRUFBNkI7QUFDM0JYLHNCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0FBQ0Q7QUFDRjtBQUNGLGlCQU5EO0FBT0QsZUFSRDtBQVNEOztBQUNELGdCQUFJZixJQUFJLEdBQUc7QUFDVEssY0FBQUEsTUFBTSxFQUFFQTtBQURDLGFBQVg7QUFHQVMsWUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWjtBQUVBbEMsWUFBQUEsaURBQUEsQ0FDUSxpREFEUixFQUMyRG1CLElBRDNELEVBRUcyQixJQUZILENBRVEsVUFBQ0MsR0FBRCxFQUFTO0FBQ2JkLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZYSxHQUFaO0FBQ0FkLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLHFDQUFaO0FBQ0FWLGNBQUFBLE1BQU0sR0FBRyxFQUFUO0FBQ0FNLGNBQUFBLE9BQU8sQ0FBQ2tCLElBQVIsQ0FBYSxXQUFiO0FBQ0QsYUFQSCxXQVFTLFVBQUNDLEdBQUQsRUFBUztBQUNkaEIsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVllLEdBQUcsQ0FBQ0MsUUFBSixDQUFhL0IsSUFBekIsRUFEYyxDQUVkO0FBQ0E7QUFDRCxhQVpIO0FBYUQsV0FuQ0g7QUFBQSxvQkFxQ0csd0JBQXNCO0FBQUEsZ0JBQW5CZ0IsWUFBbUIsUUFBbkJBLFlBQW1CO0FBQ3JCLGdDQUNFLDhEQUFDLDZDQUFEO0FBQU0sc0JBQVEsRUFBRUEsWUFBaEI7QUFBQSx5QkFDR2hCLHVEQURILGFBQ0dBLHVEQURILHVCQUNHQSwyREFBQSxDQUFVLFVBQUNxQixDQUFELEVBQUlhLEVBQUosRUFBVztBQUNwQixvQ0FDRTtBQUFnQiwyQkFBUyxFQUFDLE1BQTFCO0FBQUEsMENBQ0UsOERBQUMsa0RBQUQ7QUFBQSwrQkFDRyxHQURILEVBRUdiLENBQUMsQ0FBQ2EsRUFGTCxPQUVVRixVQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFERixlQUtFLDhEQUFDLHFEQUFEO0FBQUEsOEJBQWVYLENBQUMsQ0FBQ2M7QUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFMRixlQU1FLDhEQUFDLGlEQUFEO0FBQUEsOEJBQVdkLENBQUMsQ0FBQ2U7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU5GLGVBT0UsOERBQUMsOENBQUQ7QUFDRSx3QkFBSSxFQUFDLFFBRFA7QUFFRSwwQkFBTSxFQUFFLGdCQUFDQyxZQUFELEVBQWtCO0FBQ3hCLDBDQUNFO0FBQUEsK0NBQ0UsOERBQUMsNENBQUQ7QUFBQSxpREFDRSw4REFBQyw0Q0FBRDtBQUFBLG1EQUNFLDhEQUFDLGtEQUFEO0FBQUEscURBQ0UsOERBQUMsbURBQUQ7QUFBWSx5Q0FBUyxFQUFDLG9CQUF0QjtBQUFBLDBDQUNHcEMsMERBREgsYUFDR0EsMERBREgsdUJBQ0dBLDhEQUFBLENBQWEsVUFBQ3FDLEdBQUQsRUFBUztBQUNyQixzREFDRTtBQUVFLDZDQUFTLEVBQUMsNkZBRlo7QUFBQSw0REFJRSw4REFBQyx5Q0FBRDtBQUNFLDBDQUFJLEVBQUMsT0FEUCxDQUVFO0FBRkY7QUFHRSwyQ0FBSyxFQUFFQSxHQUFHLENBQUNDLFlBSGI7QUFJRSwrQ0FBUyxFQUFDLFFBSlo7QUFLRSw4Q0FBUSxFQUFFLG9CQUFNO0FBQ2Q3Qix3Q0FBQUEsUUFBUSxDQUFDO0FBQ1BZLDBDQUFBQSxXQUFXLEVBQUVELENBQUMsQ0FBQ2EsRUFEUjtBQUVQVCwwQ0FBQUEsTUFBTSxFQUFFYSxHQUFHLENBQUNDO0FBRkwseUNBQUQsQ0FBUjs7QUFLQSw0Q0FBSWxDLE1BQU0sQ0FBQzRCLE1BQVAsR0FBZ0IsQ0FBcEIsRUFBdUI7QUFDckIsK0NBQ0UsSUFBSU8sQ0FBQyxHQUFHLENBRFYsRUFFRUEsQ0FBQyxHQUFHbkMsTUFBTSxDQUFDNEIsTUFGYixFQUdFTyxDQUFDLEVBSEgsRUFJRTtBQUFBOztBQUNBLGdEQUNFLGNBQUFuQyxNQUFNLENBQUNtQyxDQUFELENBQU4sd0RBQ0lsQixXQURKLEtBQ21CRCxDQUFDLENBQUNhLEVBRnZCLEVBR0U7QUFDQXBCLDhDQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0FBQ0FWLDhDQUFBQSxNQUFNLENBQUNvQyxNQUFQLENBQWNELENBQWQsRUFBaUIsQ0FBakIsRUFBb0I7QUFDbEJsQixnREFBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNhLEVBREc7QUFFbEJULGdEQUFBQSxNQUFNLEVBQ0phLEdBQUcsQ0FBQ0M7QUFIWSwrQ0FBcEI7QUFLQTtBQUNELDZDQVhELE1BV08sSUFDTGxDLE1BQU0sQ0FBQ21DLENBQUQsQ0FBTixDQUNHbEIsV0FESCxLQUNtQkQsQ0FBQyxDQUFDYSxFQUZoQixFQUdMO0FBQ0FwQiw4Q0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQ0UsMEJBREYsRUFFRU0sQ0FBQyxDQUFDYSxFQUZKLEVBR0UsYUFIRixFQUlFN0IsTUFBTSxDQUFDbUMsQ0FBRCxDQUFOLENBQVVsQixXQUpaO0FBT0FqQiw4Q0FBQUEsTUFBTSxDQUFDd0IsSUFBUCxDQUFZO0FBQ1ZQLGdEQUFBQSxXQUFXLEVBQUVELENBQUMsQ0FBQ2EsRUFETDtBQUVWVCxnREFBQUEsTUFBTSxFQUNKYSxHQUFHLENBQUNDLFlBSEksQ0FJVjs7QUFKVSwrQ0FBWjtBQU1BO0FBQ0Q7QUFDRjtBQUNGLHlDQXJDRCxNQXFDTztBQUNMekIsMENBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVo7QUFDQVYsMENBQUFBLE1BQU0sQ0FBQ3dCLElBQVAsQ0FBWTtBQUNWUCw0Q0FBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNhLEVBREw7QUFFVlQsNENBQUFBLE1BQU0sRUFBRWEsR0FBRyxDQUFDQztBQUZGLDJDQUFaO0FBSUQ7QUFDRjtBQXZESDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZDQUpGLEVBNkRHRCxHQUFHLENBQUNJLFdBN0RQO0FBQUEscUNBQ09KLEdBQUcsQ0FBQ0osRUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJDQURGO0FBaUVELGlDQWxFQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURGO0FBd0ZEO0FBM0ZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBUEY7QUFBQSxtQkFBVWIsQ0FBQyxDQUFDYSxFQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREY7QUF1R0QsZUF4R0EsQ0FESCxlQTBHRTtBQUFLLHlCQUFTLEVBQUMscUJBQWY7QUFBQSx1Q0FDRSw4REFBQywrQ0FBRDtBQUNFLHVCQUFLLE1BRFA7QUFFRSwyQkFBUyxFQUFDLGdDQUZaO0FBR0Usc0JBQUksRUFBQyxRQUhQLENBSUU7QUFDQTtBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkExR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGO0FBd0hEO0FBOUpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBNEtEOztHQXZOUTNCO1VBRVNIOzs7S0FGVEc7O0FBeU5ULElBQU1vQyxlQUFlLEdBQUcsU0FBbEJBLGVBQWtCLENBQUNDLEtBQUQsRUFBVztBQUNqQyxTQUFPO0FBQ0x2QyxJQUFBQSxNQUFNLEVBQUV1QyxLQUFLLENBQUN2QyxNQUFOLENBQWFBO0FBRGhCLEdBQVA7QUFHRCxDQUpEOztBQU1BLElBQU13QyxrQkFBa0IsR0FBRyxTQUFyQkEsa0JBQXFCLENBQUNDLFFBQUQsRUFBYztBQUN2QyxTQUFPO0FBQ0xDLElBQUFBLGFBQWEsRUFBRSx1QkFBQy9DLElBQUQ7QUFBQSxhQUFVOEMsUUFBUSxDQUFDM0MseURBQUEsQ0FBc0JILElBQXRCLENBQUQsQ0FBbEI7QUFBQSxLQURWO0FBRUxnRCxJQUFBQSxjQUFjLEVBQUUsd0JBQUNoRCxJQUFELEVBQU9rQyxFQUFQO0FBQUEsYUFBY1ksUUFBUSxDQUFDM0Msd0RBQUEsQ0FBcUJILElBQXJCLEVBQTJCa0MsRUFBM0IsQ0FBRCxDQUF0QjtBQUFBLEtBRlg7QUFHTGdCLElBQUFBLGdCQUFnQixFQUFFLDBCQUFDbEQsSUFBRCxFQUFPbUQsSUFBUCxFQUFhQyxNQUFiO0FBQUEsYUFDaEJOLFFBQVEsQ0FBQzNDLDBEQUFBLENBQXVCSCxJQUF2QixFQUE2Qm1ELElBQTdCLEVBQW1DQyxNQUFuQyxDQUFELENBRFE7QUFBQSxLQUhiO0FBS0xFLElBQUFBLGtCQUFrQixFQUFFLDRCQUFDdEQsSUFBRCxFQUFPbUQsSUFBUCxFQUFhQyxNQUFiO0FBQUEsYUFDbEJOLFFBQVEsQ0FBQzNDLDREQUFBLENBQXlCSCxJQUF6QixFQUErQm1ELElBQS9CLEVBQXFDQyxNQUFyQyxDQUFELENBRFU7QUFBQSxLQUxmO0FBT0xJLElBQUFBLGlCQUFpQixFQUFFLDJCQUFDeEQsSUFBRDtBQUFBLGFBQVU4QyxRQUFRLENBQUMzQyw2REFBQSxDQUEwQkgsSUFBMUIsQ0FBRCxDQUFsQjtBQUFBO0FBUGQsR0FBUDtBQVNELENBVkQ7O0FBV0EsK0RBQWVFLG9EQUFPLENBQUN5QyxlQUFELEVBQWtCRSxrQkFBbEIsQ0FBUCxDQUE2Q3RDLElBQTdDLENBQWYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xuaW1wb3J0IHsgRmllbGQsIEZpZWxkQXJyYXksIEZvcm1payB9IGZyb20gXCJmb3JtaWtcIjtcbmltcG9ydCBIZWFkIGZyb20gXCJuZXh0L2hlYWRcIjtcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7XG4gIEJ1dHRvbixcbiAgQ2FyZCxcbiAgQ2FyZEJvZHksXG4gIENhcmRIZWFkZXIsXG4gIENhcmRTdWJ0aXRsZSxcbiAgQ2FyZFRleHQsXG4gIENhcmRUaXRsZSxcbiAgQ29sLFxuICBGb3JtLFxuICBGb3JtR3JvdXAsXG4gIElucHV0R3JvdXAsXG4gIFJvdyxcbn0gZnJvbSBcInJlYWN0c3RyYXBcIjtcbmltcG9ydCBkYXRhIGZyb20gXCIuLi9jb21wb25lbnRzL0RhdGEvRGF0YS5qc29uXCI7XG5pbXBvcnQgb3B0aW9ucyBmcm9tIFwiLi4vY29tcG9uZW50cy9EYXRhL29wdGlvbnMuanNvblwiO1xuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xuaW1wb3J0ICogYXMgYWN0aW9ucyBmcm9tIFwiLi4vcmVkdXgvYWN0aW9uc1wiO1xuaW1wb3J0IHsgdXNlSGlzdG9yeSB9IGZyb20gXCJyZWFjdC1yb3V0ZXJcIjtcblxudmFyIHJlc3VsdCA9IG5ldyBBcnJheSgpO1xuZnVuY3Rpb24gSG9tZShwcm9wcykge1xuICBjb25zdCBbdmFsdWUsIHNldFZhbHVlXSA9IHVzZVN0YXRlKHt9KTtcbiAgY29uc3QgaGlzdG9yeSA9IHVzZUhpc3RvcnkoKTtcblxuICBjb25zdCBbY29tcGFueSwgc2V0Q29tcGFueV0gPSB1c2VTdGF0ZSh7fSk7XG5cbiAgY29uc29sZS5sb2coXCJwcm9wcy5yZXN1bHRcIiwgcHJvcHMucmVzdWx0KTtcblxuICBjb25zb2xlLmxvZyhcInZhbHVlXCIsIHZhbHVlKTtcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gKHZhbHVlcywgc2V0U3VibWl0dGluZykgPT4ge1xuICAgIGlmIChwcm9wcy5yZXN1bHQpIHtcbiAgICAgIHByb3BzLnJlc3VsdD8ubWFwKChyKSA9PiB7XG4gICAgICAgIGRhdGE/Lm1hcCgoZCkgPT4ge1xuICAgICAgICAgIGlmIChyLnF1ZXN0aW9uX2lkID09IGQucXVlc3Rpb25faWQpIHtcbiAgICAgICAgICAgIGlmIChkLkNEVSAvIENTVSA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImFha2FzaFwiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGxldCBkYXRhID0ge1xuICAgICAgcmVzdWx0OiByZXN1bHQsXG4gICAgfTtcbiAgICBjb25zb2xlLmxvZyhkYXRhKTtcblxuICAgIGF4aW9zXG4gICAgICAucG9zdChcIi90ZXN0XCIsIGRhdGEpXG4gICAgICAudGhlbigocmVzKSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKHJlcyk7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiaW50aWFsIHZhbHVlIGlzIHN1Ym1pdGVkIHRvIHJlc3VsdHNcIik7XG4gICAgICAgIHJlc3VsdCA9IFtdO1xuICAgICAgICBoaXN0b3J5LnB1c2goXCIvdGhhbmt5b3VcIik7XG4gICAgICB9KVxuICAgICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgY29uc29sZS5sb2coZXJyLnJlc3BvbnNlLmRhdGEpO1xuICAgICAgICAvLyBoaXN0b3J5LnB1c2goXCIvZXhhbS1hcHBlYXJlZFwiKTtcbiAgICAgICAgLy8gcmVzdWx0ID0gW107XG4gICAgICB9KTtcbiAgfTtcbiAgY29uc29sZS5sb2coXCJhcnJheVwiLCByZXN1bHQpO1xuICBjb25zdCBkYXRhTGVuZ3RoID0gZGF0YS5sZW5ndGg7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiPlxuICAgICAgPEhlYWQ+XG4gICAgICAgIDx0aXRsZT5DcmVhdGUgTmV4dCBBcHA8L3RpdGxlPlxuICAgICAgICA8bGluayByZWw9XCJpY29uXCIgaHJlZj1cIi9mYXZpY29uLmljb1wiIC8+XG4gICAgICA8L0hlYWQ+XG4gICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTUgYm9yZGVyLTIgc2hhZG93LW1kIHJvdW5kZWQtbWRcIj5cbiAgICAgICAgPENhcmRCb2R5PlxuICAgICAgICAgIDxGb3JtaWtcbiAgICAgICAgICAgIGluaXRpYWxWYWx1ZXM9e3tcbiAgICAgICAgICAgICAgcmVzdWx0OiBbXSxcbiAgICAgICAgICAgICAgYW5zd2VyOiBcIlwiLFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIG9uU3VibWl0PXsodmFsdWVzLCBzZXRTdWJtaXR0aW5nKSA9PiB7XG4gICAgICAgICAgICAgIGlmIChwcm9wcy5yZXN1bHQpIHtcbiAgICAgICAgICAgICAgICBwcm9wcy5yZXN1bHQ/Lm1hcCgocikgPT4ge1xuICAgICAgICAgICAgICAgICAgZGF0YT8ubWFwKChkKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyLnF1ZXN0aW9uX2lkID09IGQucXVlc3Rpb25faWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoZC5DRFUgLyBDU1UgPT0gci5hbnN3ZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWFrYXNoXCIpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgbGV0IGRhdGEgPSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0OiByZXN1bHQsXG4gICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWFrYXNoXCIpO1xuXG4gICAgICAgICAgICAgIGF4aW9zXG4gICAgICAgICAgICAgICAgLnBvc3QoXCJodHRwczovL3VkaXRzb2x1dGlvbnMuaW4veWFybi9wdWJsaWMvYXBpL3Njb3Jlc1wiLCBkYXRhKVxuICAgICAgICAgICAgICAgIC50aGVuKChyZXMpID0+IHtcbiAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlcyk7XG4gICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImludGlhbCB2YWx1ZSBpcyBzdWJtaXRlZCB0byByZXN1bHRzXCIpO1xuICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gW107XG4gICAgICAgICAgICAgICAgICBoaXN0b3J5LnB1c2goXCIvdGhhbmt5b3VcIik7XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyLnJlc3BvbnNlLmRhdGEpO1xuICAgICAgICAgICAgICAgICAgLy8gaGlzdG9yeS5wdXNoKFwiL2V4YW0tYXBwZWFyZWRcIik7XG4gICAgICAgICAgICAgICAgICAvLyByZXN1bHQgPSBbXTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgeyh7IGhhbmRsZVN1Ym1pdCB9KSA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPEZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XG4gICAgICAgICAgICAgICAgICB7ZGF0YT8ubWFwKChkLCBpZCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtkLmlkfSBjbGFzc05hbWU9XCJtdC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2FyZFRpdGxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7XCIgXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtkLmlkfS97ZGF0YUxlbmd0aH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQ2FyZFRpdGxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcmRTdWJ0aXRsZT57ZC5TY2hsYWd3b3J0fTwvQ2FyZFN1YnRpdGxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcmRUZXh0PntkLnF1ZXN0aW9uX3RleHR9PC9DYXJkVGV4dD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGaWVsZEFycmF5XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZXN1bHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICByZW5kZXI9eyhhcnJheUhlbHBlcnMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJvdz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q29sPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0R3JvdXAgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29wdGlvbnM/Lm1hcCgob3B0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e29wdC5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgYmctZ3JheS02MDAgdGV4dC13aGl0ZSByb3VuZGVkLW1kIHRleHQtY2VudGVyIGhvdmVyOmJnLXllbGxvdy0zMDAgaG92ZXI6dGV4dC1ibGFjayBtYi0xXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhZGlvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIG5hbWU9XCJhbnN3ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e29wdC5vcHRpb25fVmFsdWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VmFsdWUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uX2lkOiBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjogb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBpID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGkgPCByZXN1bHQubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaSsrXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdFtpXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8ucXVlc3Rpb25faWQgPT0gZC5pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic3BsaWNlXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQuc3BsaWNlKGksIDEsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHQub3B0aW9uX1ZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0W2ldXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnF1ZXN0aW9uX2lkICE9PSBkLmlkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbHNlX2lmIHF1ZXN0aW9uIG9mIGRhdGFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwicmVzdWx0IHEtaWRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV0ucXVlc3Rpb25faWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25faWQ6IGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJlbHNlXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uX2lkOiBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOiBvcHQub3B0aW9uX1ZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29wdC5vcHRpb25fdGV4dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjp7XCIgXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVzdWx0Py5tYXAoKHIpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHIucXVlc3Rpb25faWQgPT0gZC5pZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByLmFuc3dlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+ICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0lucHV0R3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBibG9ja1xuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlci0yIHAtMiBib3JkZXItYmxhY2sgbXQtN1wiXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgICAgLy8gb25DbGljaz17aGFuZGxlU3VibWl0fVxuICAgICAgICAgICAgICAgICAgICAgIC8vIGRpc2FibGVkPXtmb3JtUHJvcHMuaXNTdWJtaXR0aW5nfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgRWVnZWJuaXMgemVpZ2VuXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9Gb3JtPlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICA8L0Zvcm1paz5cbiAgICAgICAgPC9DYXJkQm9keT5cbiAgICAgIDwvQ2FyZD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuY29uc3QgbWFwU3RhdGVUb1Byb3BzID0gKHN0YXRlKSA9PiB7XG4gIHJldHVybiB7XG4gICAgcmVzdWx0OiBzdGF0ZS5yZXN1bHQucmVzdWx0LFxuICB9O1xufTtcblxuY29uc3QgbWFwRGlzcGF0Y2hUb1Byb3BzID0gKGRpc3BhdGNoKSA9PiB7XG4gIHJldHVybiB7XG4gICAgcmVzdWx0U2V0RGF0YTogKGRhdGEpID0+IGRpc3BhdGNoKGFjdGlvbnMucmVzdWx0U2V0RGF0YShkYXRhKSksXG4gICAgb25EZWxldGVSZXN1bHQ6IChkYXRhLCBpZCkgPT4gZGlzcGF0Y2goYWN0aW9ucy5kZWxldGVSZXN1bHQoZGF0YSwgaWQpKSxcbiAgICBvblBvc3RSZXN1bHREYXRhOiAoZGF0YSwgdXNlciwgdG9nZ2xlKSA9PlxuICAgICAgZGlzcGF0Y2goYWN0aW9ucy5wb3N0UmVzdWx0RGF0YShkYXRhLCB1c2VyLCB0b2dnbGUpKSxcbiAgICBvblVwZGF0ZVJlc3VsdERhdGE6IChkYXRhLCB1c2VyLCB0b2dnbGUpID0+XG4gICAgICBkaXNwYXRjaChhY3Rpb25zLnVwZGF0ZVJlc3VsdERhdGEoZGF0YSwgdXNlciwgdG9nZ2xlKSksXG4gICAgcmVzdWx0RWRpdEdldERhdGE6IChkYXRhKSA9PiBkaXNwYXRjaChhY3Rpb25zLnJlc3VsdEVkaXRHZXREYXRhKGRhdGEpKSxcbiAgfTtcbn07XG5leHBvcnQgZGVmYXVsdCBjb25uZWN0KG1hcFN0YXRlVG9Qcm9wcywgbWFwRGlzcGF0Y2hUb1Byb3BzKShIb21lKTtcbiJdLCJuYW1lcyI6WyJheGlvcyIsIkZpZWxkIiwiRmllbGRBcnJheSIsIkZvcm1payIsIkhlYWQiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkJ1dHRvbiIsIkNhcmQiLCJDYXJkQm9keSIsIkNhcmRIZWFkZXIiLCJDYXJkU3VidGl0bGUiLCJDYXJkVGV4dCIsIkNhcmRUaXRsZSIsIkNvbCIsIkZvcm0iLCJGb3JtR3JvdXAiLCJJbnB1dEdyb3VwIiwiUm93IiwiZGF0YSIsIm9wdGlvbnMiLCJjb25uZWN0IiwiYWN0aW9ucyIsInVzZUhpc3RvcnkiLCJyZXN1bHQiLCJBcnJheSIsIkhvbWUiLCJwcm9wcyIsInZhbHVlIiwic2V0VmFsdWUiLCJoaXN0b3J5IiwiY29tcGFueSIsInNldENvbXBhbnkiLCJjb25zb2xlIiwibG9nIiwiaGFuZGxlU3VibWl0IiwidmFsdWVzIiwic2V0U3VibWl0dGluZyIsIm1hcCIsInIiLCJkIiwicXVlc3Rpb25faWQiLCJDRFUiLCJDU1UiLCJhbnN3ZXIiLCJwb3N0IiwidGhlbiIsInJlcyIsInB1c2giLCJlcnIiLCJyZXNwb25zZSIsImRhdGFMZW5ndGgiLCJsZW5ndGgiLCJpZCIsIlNjaGxhZ3dvcnQiLCJxdWVzdGlvbl90ZXh0IiwiYXJyYXlIZWxwZXJzIiwib3B0Iiwib3B0aW9uX1ZhbHVlIiwiaSIsInNwbGljZSIsIm9wdGlvbl90ZXh0IiwibWFwU3RhdGVUb1Byb3BzIiwic3RhdGUiLCJtYXBEaXNwYXRjaFRvUHJvcHMiLCJkaXNwYXRjaCIsInJlc3VsdFNldERhdGEiLCJvbkRlbGV0ZVJlc3VsdCIsImRlbGV0ZVJlc3VsdCIsIm9uUG9zdFJlc3VsdERhdGEiLCJ1c2VyIiwidG9nZ2xlIiwicG9zdFJlc3VsdERhdGEiLCJvblVwZGF0ZVJlc3VsdERhdGEiLCJ1cGRhdGVSZXN1bHREYXRhIiwicmVzdWx0RWRpdEdldERhdGEiXSwic291cmNlUm9vdCI6IiJ9