"use strict";
self["webpackHotUpdate_N_E"]("pages/graph",{

/***/ "./pages/graph.js":
/*!************************!*\
  !*** ./pages/graph.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-chartjs-2 */ "./node_modules/react-chartjs-2/dist/index.modern.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "E:\\git vinraj\\company-test\\pages\\graph.js",
    _this = undefined,
    _s = $RefreshSig$();







var BarGraph = function BarGraph(props) {
  _s();

  var _props$login, _props$login$login, _props$result, _props$result2;

  var accessToken = "".concat((_props$login = props.login) === null || _props$login === void 0 ? void 0 : (_props$login$login = _props$login.login) === null || _props$login$login === void 0 ? void 0 : _props$login$login.token);
  var data = {
    token: accessToken,
    id: 1
  };

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false),
      showGraph = _useState[0],
      setShowGraph = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({}),
      chartData = _useState2[0],
      setChartData = _useState2[1];

  var graph = [];
  var graphdata = [];
  graph = props.result;
  graphdata = (_props$result = props.result) === null || _props$result === void 0 ? void 0 : _props$result.map(function (gd) {
    return {
      label: "",
      data: gd,
      backgroundColor: ["rgba(255, 99, 132, 0.2)", "rgba(54, 162, 235, 0.2)", "rgba(255, 206, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(255, 159, 64, 0.2)", "rgba(255, 99, 132, 0.2)", "rgba(54, 162, 235, 0.2)", "rgba(255, 206, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(255, 159, 64, 0.2)", "rgba(255, 99, 132, 0.2)", "rgba(54, 162, 235, 0.2)", "rgba(255, 206, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(255, 159, 64, 0.2)", "rgba(255, 99, 132, 0.2)", "rgba(54, 162, 235, 0.2)", "rgba(255, 206, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(255, 159, 64, 0.2)"],
      borderColor: ["rgba(255, 99, 132, 1)", "rgba(54, 162, 235, 1)", "rgba(255, 206, 86, 1)", "rgba(75, 192, 192, 1)", "rgba(153, 102, 255, 1)", "rgba(255, 159, 64, 1)", "rgba(255, 99, 132, 1)", "rgba(54, 162, 235, 1)", "rgba(255, 206, 86, 1)", "rgba(75, 192, 192, 1)", "rgba(153, 102, 255, 1)", "rgba(255, 159, 64, 1)", "rgba(255, 99, 132, 1)", "rgba(54, 162, 235, 1)", "rgba(255, 206, 86, 1)", "rgba(75, 192, 192, 1)", "rgba(153, 102, 255, 1)", "rgba(255, 159, 64, 1)", "rgba(255, 99, 132, 1)", "rgba(54, 162, 235, 1)", "rgba(255, 206, 86, 1)", "rgba(75, 192, 192, 1)", "rgba(153, 102, 255, 1)", "rgba(255, 159, 64, 1)"],
      borderWidth: 1
    };
  });

  var Chart = function Chart() {
    var time = [];
    var temp = [];
    var sensors = [];
    console.log("Chart Function"); // for (const dataObj of graph) {
    //   dataObj?.data.map((t) => {
    //     time.push(t.time);
    //   });
    //   sensors.push(dataObj?.sensor);
    // }

    setChartData({
      labels: ["CDU/MDU", "SPD", "AfD", "FDP", "Grüne", "Linke"],
      datasets: [{
        label: "First dataset",
        data: props.result,
        fill: true,
        backgroundColor: "rgba(75,192,192,0.2)",
        borderColor: "rgba(75,192,192,1)"
      }]
    });
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
    Chart();
  }, [graphdata && ((_props$result2 = props.result) === null || _props$result2 === void 0 ? void 0 : _props$result2.length) > 0]);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_4__.Card, {
    className: "h-100 p-3",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_4__.Button, {
      className: "btn-success",
      onClick: function onClick() {
        Chart();
        setShowGraph(true);
      },
      children: "Load Graph"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 113,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_4__.CardBody, {
      className: "p-0",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h3", {
        className: "text-center pt-4 pr-4 pl-4 pb-1 ",
        children: "Result of Company Data"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 123,
        columnNumber: 9
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(react_chartjs_2__WEBPACK_IMPORTED_MODULE_2__.Bar, {
        data: chartData,
        options: {
          responsive: true,
          title: {
            text: "THICCNESS SCALE",
            display: true
          },
          scales: {
            yAxes: {
              ticks: {
                beginAtZero: true
              }
            }
          }
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 127,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 122,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 112,
    columnNumber: 5
  }, _this);
};

_s(BarGraph, "w0JUL31rlpdgEJ0KU+CzX4MjnvY=");

_c = BarGraph;

var mapStateToProps = function mapStateToProps(state) {
  return {
    result: state.result.mainResult
  };
};

/* harmony default export */ __webpack_exports__["default"] = ((0,react_redux__WEBPACK_IMPORTED_MODULE_1__.connect)(mapStateToProps)(BarGraph));

var _c;

$RefreshReg$(_c, "BarGraph");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvZ3JhcGguODU3MmRjZjAxNjY2ZDIxOWMyYmMuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUVBO0FBRUE7OztBQUVBLElBQU1RLFFBQVEsR0FBRyxTQUFYQSxRQUFXLENBQUNDLEtBQUQsRUFBVztBQUFBOztBQUFBOztBQUMxQixNQUFNQyxXQUFXLDZCQUFNRCxLQUFLLENBQUNFLEtBQVosdUVBQU0sYUFBYUEsS0FBbkIsdURBQU0sbUJBQW9CQyxLQUExQixDQUFqQjtBQUVBLE1BQUlDLElBQUksR0FBRztBQUNURCxJQUFBQSxLQUFLLEVBQUVGLFdBREU7QUFFVEksSUFBQUEsRUFBRSxFQUFFO0FBRkssR0FBWDs7QUFLQSxrQkFBa0NaLCtDQUFRLENBQUMsS0FBRCxDQUExQztBQUFBLE1BQU9hLFNBQVA7QUFBQSxNQUFrQkMsWUFBbEI7O0FBQ0EsbUJBQWtDZCwrQ0FBUSxDQUFDLEVBQUQsQ0FBMUM7QUFBQSxNQUFPZSxTQUFQO0FBQUEsTUFBa0JDLFlBQWxCOztBQUNBLE1BQUlDLEtBQUssR0FBRyxFQUFaO0FBQ0EsTUFBSUMsU0FBUyxHQUFHLEVBQWhCO0FBQ0FELEVBQUFBLEtBQUssR0FBR1YsS0FBSyxDQUFDWSxNQUFkO0FBQ0FELEVBQUFBLFNBQVMsb0JBQUdYLEtBQUssQ0FBQ1ksTUFBVCxrREFBRyxjQUFjQyxHQUFkLENBQWtCLFVBQUNDLEVBQUQsRUFBUTtBQUNwQyxXQUFPO0FBQ0xDLE1BQUFBLEtBQUssRUFBRSxFQURGO0FBRUxYLE1BQUFBLElBQUksRUFBRVUsRUFGRDtBQUdMRSxNQUFBQSxlQUFlLEVBQUUsQ0FDZix5QkFEZSxFQUVmLHlCQUZlLEVBR2YseUJBSGUsRUFJZix5QkFKZSxFQUtmLDBCQUxlLEVBTWYseUJBTmUsRUFPZix5QkFQZSxFQVFmLHlCQVJlLEVBU2YseUJBVGUsRUFVZix5QkFWZSxFQVdmLDBCQVhlLEVBWWYseUJBWmUsRUFhZix5QkFiZSxFQWNmLHlCQWRlLEVBZWYseUJBZmUsRUFnQmYseUJBaEJlLEVBaUJmLDBCQWpCZSxFQWtCZix5QkFsQmUsRUFtQmYseUJBbkJlLEVBb0JmLHlCQXBCZSxFQXFCZix5QkFyQmUsRUFzQmYseUJBdEJlLEVBdUJmLDBCQXZCZSxFQXdCZix5QkF4QmUsQ0FIWjtBQTZCTEMsTUFBQUEsV0FBVyxFQUFFLENBQ1gsdUJBRFcsRUFFWCx1QkFGVyxFQUdYLHVCQUhXLEVBSVgsdUJBSlcsRUFLWCx3QkFMVyxFQU1YLHVCQU5XLEVBT1gsdUJBUFcsRUFRWCx1QkFSVyxFQVNYLHVCQVRXLEVBVVgsdUJBVlcsRUFXWCx3QkFYVyxFQVlYLHVCQVpXLEVBYVgsdUJBYlcsRUFjWCx1QkFkVyxFQWVYLHVCQWZXLEVBZ0JYLHVCQWhCVyxFQWlCWCx3QkFqQlcsRUFrQlgsdUJBbEJXLEVBbUJYLHVCQW5CVyxFQW9CWCx1QkFwQlcsRUFxQlgsdUJBckJXLEVBc0JYLHVCQXRCVyxFQXVCWCx3QkF2QlcsRUF3QlgsdUJBeEJXLENBN0JSO0FBd0RMQyxNQUFBQSxXQUFXLEVBQUU7QUF4RFIsS0FBUDtBQTBERCxHQTNEVyxDQUFaOztBQTZEQSxNQUFNQyxLQUFLLEdBQUcsU0FBUkEsS0FBUSxHQUFNO0FBQ2xCLFFBQUlDLElBQUksR0FBRyxFQUFYO0FBQ0EsUUFBSUMsSUFBSSxHQUFHLEVBQVg7QUFDQSxRQUFJQyxPQUFPLEdBQUcsRUFBZDtBQUNBQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxnQkFBWixFQUprQixDQUtsQjtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUFmLElBQUFBLFlBQVksQ0FBQztBQUNYZ0IsTUFBQUEsTUFBTSxFQUFFLENBQUMsU0FBRCxFQUFZLEtBQVosRUFBbUIsS0FBbkIsRUFBMEIsS0FBMUIsRUFBaUMsT0FBakMsRUFBMEMsT0FBMUMsQ0FERztBQUVYQyxNQUFBQSxRQUFRLEVBQUUsQ0FDUjtBQUNFWCxRQUFBQSxLQUFLLEVBQUUsZUFEVDtBQUVFWCxRQUFBQSxJQUFJLEVBQUVKLEtBQUssQ0FBQ1ksTUFGZDtBQUdFZSxRQUFBQSxJQUFJLEVBQUUsSUFIUjtBQUlFWCxRQUFBQSxlQUFlLEVBQUUsc0JBSm5CO0FBS0VDLFFBQUFBLFdBQVcsRUFBRTtBQUxmLE9BRFE7QUFGQyxLQUFELENBQVo7QUFZRCxHQXpCRDs7QUEwQkF6QixFQUFBQSxnREFBUyxDQUFDLFlBQU07QUFDZDJCLElBQUFBLEtBQUs7QUFDTixHQUZRLEVBRU4sQ0FBQ1IsU0FBUyxJQUFJLG1CQUFBWCxLQUFLLENBQUNZLE1BQU4sa0VBQWNnQixNQUFkLElBQXVCLENBQXJDLENBRk0sQ0FBVDtBQUdBLHNCQUNFLDhEQUFDLDRDQUFEO0FBQU0sYUFBUyxFQUFDLFdBQWhCO0FBQUEsNEJBQ0UsOERBQUMsOENBQUQ7QUFDRSxlQUFTLEVBQUMsYUFEWjtBQUVFLGFBQU8sRUFBRSxtQkFBTTtBQUNiVCxRQUFBQSxLQUFLO0FBQ0xaLFFBQUFBLFlBQVksQ0FBQyxJQUFELENBQVo7QUFDRCxPQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREYsZUFVRSw4REFBQyxnREFBRDtBQUFVLGVBQVMsRUFBQyxLQUFwQjtBQUFBLDhCQUNFO0FBQUksaUJBQVMsRUFBQyxrQ0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGLGVBS0UsOERBQUMsZ0RBQUQ7QUFDRSxZQUFJLEVBQUVDLFNBRFI7QUFFRSxlQUFPLEVBQUU7QUFDUHFCLFVBQUFBLFVBQVUsRUFBRSxJQURMO0FBRVBDLFVBQUFBLEtBQUssRUFBRTtBQUFFQyxZQUFBQSxJQUFJLEVBQUUsaUJBQVI7QUFBMkJDLFlBQUFBLE9BQU8sRUFBRTtBQUFwQyxXQUZBO0FBR1BDLFVBQUFBLE1BQU0sRUFBRTtBQUNOQyxZQUFBQSxLQUFLLEVBQUU7QUFDTEMsY0FBQUEsS0FBSyxFQUFFO0FBQ0xDLGdCQUFBQSxXQUFXLEVBQUU7QUFEUjtBQURGO0FBREQ7QUFIRDtBQUZYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FERjtBQWlDRCxDQXhJRDs7R0FBTXJDOztLQUFBQTs7QUEwSU4sSUFBTXNDLGVBQWUsR0FBRyxTQUFsQkEsZUFBa0IsQ0FBQ0MsS0FBRCxFQUFXO0FBQ2pDLFNBQU87QUFDTDFCLElBQUFBLE1BQU0sRUFBRTBCLEtBQUssQ0FBQzFCLE1BQU4sQ0FBYTJCO0FBRGhCLEdBQVA7QUFHRCxDQUpEOztBQU1BLCtEQUFlMUMsb0RBQU8sQ0FBQ3dDLGVBQUQsQ0FBUCxDQUF5QnRDLFFBQXpCLENBQWYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvZ3JhcGguanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgQnV0dG9uLCBDYXJkLCBDYXJkQm9keSB9IGZyb20gXCJyZWFjdHN0cmFwXCI7XHJcblxyXG5pbXBvcnQgeyBjb25uZWN0IH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XHJcblxyXG5pbXBvcnQgeyBCYXIgfSBmcm9tIFwicmVhY3QtY2hhcnRqcy0yXCI7XHJcblxyXG5jb25zdCBCYXJHcmFwaCA9IChwcm9wcykgPT4ge1xyXG4gIGNvbnN0IGFjY2Vzc1Rva2VuID0gYCR7cHJvcHMubG9naW4/LmxvZ2luPy50b2tlbn1gO1xyXG5cclxuICBsZXQgZGF0YSA9IHtcclxuICAgIHRva2VuOiBhY2Nlc3NUb2tlbixcclxuICAgIGlkOiAxLFxyXG4gIH07XHJcblxyXG4gIGNvbnN0IFtzaG93R3JhcGgsIHNldFNob3dHcmFwaF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2NoYXJ0RGF0YSwgc2V0Q2hhcnREYXRhXSA9IHVzZVN0YXRlKHt9KTtcclxuICBsZXQgZ3JhcGggPSBbXTtcclxuICBsZXQgZ3JhcGhkYXRhID0gW107XHJcbiAgZ3JhcGggPSBwcm9wcy5yZXN1bHQ7XHJcbiAgZ3JhcGhkYXRhID0gcHJvcHMucmVzdWx0Py5tYXAoKGdkKSA9PiB7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBsYWJlbDogXCJcIixcclxuICAgICAgZGF0YTogZ2QsXHJcbiAgICAgIGJhY2tncm91bmRDb2xvcjogW1xyXG4gICAgICAgIFwicmdiYSgyNTUsIDk5LCAxMzIsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoNTQsIDE2MiwgMjM1LCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgMjA2LCA4NiwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSg3NSwgMTkyLCAxOTIsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoMTUzLCAxMDIsIDI1NSwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDE1OSwgNjQsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoMjU1LCA5OSwgMTMyLCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDU0LCAxNjIsIDIzNSwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDIwNiwgODYsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoNzUsIDE5MiwgMTkyLCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDE1MywgMTAyLCAyNTUsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoMjU1LCAxNTksIDY0LCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgOTksIDEzMiwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSg1NCwgMTYyLCAyMzUsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoMjU1LCAyMDYsIDg2LCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDc1LCAxOTIsIDE5MiwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSgxNTMsIDEwMiwgMjU1LCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgMTU5LCA2NCwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDk5LCAxMzIsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoNTQsIDE2MiwgMjM1LCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgMjA2LCA4NiwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSg3NSwgMTkyLCAxOTIsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoMTUzLCAxMDIsIDI1NSwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDE1OSwgNjQsIDAuMilcIixcclxuICAgICAgXSxcclxuICAgICAgYm9yZGVyQ29sb3I6IFtcclxuICAgICAgICBcInJnYmEoMjU1LCA5OSwgMTMyLCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSg1NCwgMTYyLCAyMzUsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgMjA2LCA4NiwgMSlcIixcclxuICAgICAgICBcInJnYmEoNzUsIDE5MiwgMTkyLCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSgxNTMsIDEwMiwgMjU1LCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDE1OSwgNjQsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgOTksIDEzMiwgMSlcIixcclxuICAgICAgICBcInJnYmEoNTQsIDE2MiwgMjM1LCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDIwNiwgODYsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDc1LCAxOTIsIDE5MiwgMSlcIixcclxuICAgICAgICBcInJnYmEoMTUzLCAxMDIsIDI1NSwgMSlcIixcclxuICAgICAgICBcInJnYmEoMjU1LCAxNTksIDY0LCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDk5LCAxMzIsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDU0LCAxNjIsIDIzNSwgMSlcIixcclxuICAgICAgICBcInJnYmEoMjU1LCAyMDYsIDg2LCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSg3NSwgMTkyLCAxOTIsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDE1MywgMTAyLCAyNTUsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgMTU5LCA2NCwgMSlcIixcclxuICAgICAgICBcInJnYmEoMjU1LCA5OSwgMTMyLCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSg1NCwgMTYyLCAyMzUsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgMjA2LCA4NiwgMSlcIixcclxuICAgICAgICBcInJnYmEoNzUsIDE5MiwgMTkyLCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSgxNTMsIDEwMiwgMjU1LCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDE1OSwgNjQsIDEpXCIsXHJcbiAgICAgIF0sXHJcblxyXG4gICAgICBib3JkZXJXaWR0aDogMSxcclxuICAgIH07XHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IENoYXJ0ID0gKCkgPT4ge1xyXG4gICAgbGV0IHRpbWUgPSBbXTtcclxuICAgIGxldCB0ZW1wID0gW107XHJcbiAgICBsZXQgc2Vuc29ycyA9IFtdO1xyXG4gICAgY29uc29sZS5sb2coXCJDaGFydCBGdW5jdGlvblwiKTtcclxuICAgIC8vIGZvciAoY29uc3QgZGF0YU9iaiBvZiBncmFwaCkge1xyXG4gICAgLy8gICBkYXRhT2JqPy5kYXRhLm1hcCgodCkgPT4ge1xyXG4gICAgLy8gICAgIHRpbWUucHVzaCh0LnRpbWUpO1xyXG4gICAgLy8gICB9KTtcclxuXHJcbiAgICAvLyAgIHNlbnNvcnMucHVzaChkYXRhT2JqPy5zZW5zb3IpO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIHNldENoYXJ0RGF0YSh7XHJcbiAgICAgIGxhYmVsczogW1wiQ0RVL01EVVwiLCBcIlNQRFwiLCBcIkFmRFwiLCBcIkZEUFwiLCBcIkdyw7xuZVwiLCBcIkxpbmtlXCJdLFxyXG4gICAgICBkYXRhc2V0czogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGxhYmVsOiBcIkZpcnN0IGRhdGFzZXRcIixcclxuICAgICAgICAgIGRhdGE6IHByb3BzLnJlc3VsdCxcclxuICAgICAgICAgIGZpbGw6IHRydWUsXHJcbiAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwicmdiYSg3NSwxOTIsMTkyLDAuMilcIixcclxuICAgICAgICAgIGJvcmRlckNvbG9yOiBcInJnYmEoNzUsMTkyLDE5MiwxKVwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICB9KTtcclxuICB9O1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBDaGFydCgpO1xyXG4gIH0sIFtncmFwaGRhdGEgJiYgcHJvcHMucmVzdWx0Py5sZW5ndGggPiAwXSk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxDYXJkIGNsYXNzTmFtZT1cImgtMTAwIHAtM1wiPlxyXG4gICAgICA8QnV0dG9uXHJcbiAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXN1Y2Nlc3NcIlxyXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgIENoYXJ0KCk7XHJcbiAgICAgICAgICBzZXRTaG93R3JhcGgodHJ1ZSk7XHJcbiAgICAgICAgfX1cclxuICAgICAgPlxyXG4gICAgICAgIExvYWQgR3JhcGhcclxuICAgICAgPC9CdXR0b24+XHJcbiAgICAgIDxDYXJkQm9keSBjbGFzc05hbWU9XCJwLTBcIj5cclxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHQtNCBwci00IHBsLTQgcGItMSBcIj5cclxuICAgICAgICAgIFJlc3VsdCBvZiBDb21wYW55IERhdGFcclxuICAgICAgICA8L2gzPlxyXG5cclxuICAgICAgICA8QmFyXHJcbiAgICAgICAgICBkYXRhPXtjaGFydERhdGF9XHJcbiAgICAgICAgICBvcHRpb25zPXt7XHJcbiAgICAgICAgICAgIHJlc3BvbnNpdmU6IHRydWUsXHJcbiAgICAgICAgICAgIHRpdGxlOiB7IHRleHQ6IFwiVEhJQ0NORVNTIFNDQUxFXCIsIGRpc3BsYXk6IHRydWUgfSxcclxuICAgICAgICAgICAgc2NhbGVzOiB7XHJcbiAgICAgICAgICAgICAgeUF4ZXM6IHtcclxuICAgICAgICAgICAgICAgIHRpY2tzOiB7XHJcbiAgICAgICAgICAgICAgICAgIGJlZ2luQXRaZXJvOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICAvPlxyXG4gICAgICA8L0NhcmRCb2R5PlxyXG4gICAgPC9DYXJkPlxyXG4gICk7XHJcbn07XHJcblxyXG5jb25zdCBtYXBTdGF0ZVRvUHJvcHMgPSAoc3RhdGUpID0+IHtcclxuICByZXR1cm4ge1xyXG4gICAgcmVzdWx0OiBzdGF0ZS5yZXN1bHQubWFpblJlc3VsdCxcclxuICB9O1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY29ubmVjdChtYXBTdGF0ZVRvUHJvcHMpKEJhckdyYXBoKTtcclxuIl0sIm5hbWVzIjpbIlJlYWN0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJCdXR0b24iLCJDYXJkIiwiQ2FyZEJvZHkiLCJjb25uZWN0IiwiQmFyIiwiQmFyR3JhcGgiLCJwcm9wcyIsImFjY2Vzc1Rva2VuIiwibG9naW4iLCJ0b2tlbiIsImRhdGEiLCJpZCIsInNob3dHcmFwaCIsInNldFNob3dHcmFwaCIsImNoYXJ0RGF0YSIsInNldENoYXJ0RGF0YSIsImdyYXBoIiwiZ3JhcGhkYXRhIiwicmVzdWx0IiwibWFwIiwiZ2QiLCJsYWJlbCIsImJhY2tncm91bmRDb2xvciIsImJvcmRlckNvbG9yIiwiYm9yZGVyV2lkdGgiLCJDaGFydCIsInRpbWUiLCJ0ZW1wIiwic2Vuc29ycyIsImNvbnNvbGUiLCJsb2ciLCJsYWJlbHMiLCJkYXRhc2V0cyIsImZpbGwiLCJsZW5ndGgiLCJyZXNwb25zaXZlIiwidGl0bGUiLCJ0ZXh0IiwiZGlzcGxheSIsInNjYWxlcyIsInlBeGVzIiwidGlja3MiLCJiZWdpbkF0WmVybyIsIm1hcFN0YXRlVG9Qcm9wcyIsInN0YXRlIiwibWFpblJlc3VsdCJdLCJzb3VyY2VSb290IjoiIn0=