"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var E_git_vinraj_company_test_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var E_git_vinraj_company_test_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
/* harmony import */ var _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../components/Data/Data.json */ "./components/Data/Data.json");
/* harmony import */ var _components_Data_options_json__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../components/Data/options.json */ "./components/Data/options.json");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _redux_actions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../redux/actions */ "./redux/actions/index.js");
/* harmony import */ var react_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-router */ "./node_modules/react-router/esm/react-router.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__);
/* module decorator */ module = __webpack_require__.hmd(module);



var _jsxFileName = "E:\\git vinraj\\company-test\\pages\\index.js",
    _s = $RefreshSig$();

function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,E_git_vinraj_company_test_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }












var result = new Array();
var MainResult = new Array();

function Home(props) {
  _s();

  var _this = this;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)({}),
      value = _useState[0],
      setValue = _useState[1];

  var history = (0,react_router__WEBPACK_IMPORTED_MODULE_11__.useHistory)();

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)({
    CDU: 0,
    SPD: 0,
    AfD: 0,
    FDP: 0,
    Grüne: 0,
    Linke: 0
  }),
      company = _useState2[0],
      setCompany = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(0),
      CDU = _useState3[0],
      setCDU = _useState3[1];

  var _useState4 = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(0),
      SPD = _useState4[0],
      setSPD = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(0),
      AfD = _useState5[0],
      setAfD = _useState5[1];

  var _useState6 = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(0),
      FDP = _useState6[0],
      setFDP = _useState6[1];

  var _useState7 = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(0),
      Grüne = _useState7[0],
      setGrüne = _useState7[1];

  var _useState8 = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(0),
      Linke = _useState8[0],
      setLinke = _useState8[1];

  console.log("props.result", props.result);
  console.log("value", value);
  console.log("array", result);
  console.log("CDU", CDU);
  console.log("SPD", SPD);
  console.log("AfD", AfD);
  console.log("FDP", FDP);
  console.log("Grüne", Grüne);
  console.log("Linke", Linke);
  var dataLength = _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_6__ === null || _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_6__ === void 0 ? void 0 : _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_6__.length;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)("div", {
    className: "",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_4___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)("title", {
        children: "Create Next App"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 62,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_12__.Card, {
      className: "p-5 border-2 shadow-md rounded-md",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_12__.CardBody, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_3__.Formik, {
          initialValues: {
            result: [],
            answer: ""
          },
          onSubmit: function onSubmit(values, setSubmitting) {
            var _props$result;

            setSPD(_objectSpread(_objectSpread({}, SPD), {}, {
              SPD: SPD + 1
            }));

            if (((_props$result = props.result) === null || _props$result === void 0 ? void 0 : _props$result.length) > 0) {
              var _props$result2, _props$result3;

              console.log("result length", (_props$result2 = props.result) === null || _props$result2 === void 0 ? void 0 : _props$result2.length);
              var resultLength = (_props$result3 = props.result) === null || _props$result3 === void 0 ? void 0 : _props$result3.length;

              var _iterator = _createForOfIteratorHelper(props.result),
                  _step;

              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  var r = _step.value;
                  console.log("result map");

                  var _iterator2 = _createForOfIteratorHelper(_components_Data_Data_json__WEBPACK_IMPORTED_MODULE_6__),
                      _step2;

                  try {
                    for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                      var d = _step2.value;
                      console.log("data map");

                      if (r.question_id == d.id) {
                        console.log("r.question_id", r.question_id, "d.id", d.id);

                        if (d.SPD == r.answer) {
                          console.log("SPD");
                          setSPD.apply(void 0, (0,E_git_vinraj_company_test_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__.default)(SPD).concat([SPD + 1]));
                        }

                        if (d.CDU == r.answer) {
                          console.log("CDU");
                          setCDU.apply(void 0, (0,E_git_vinraj_company_test_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__.default)(CDU).concat([CDU + 1]));
                        }

                        if (d.AfD == r.answer) {
                          console.log("AfD");
                          setAfD.apply(void 0, (0,E_git_vinraj_company_test_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__.default)(AfD).concat([AfD + 1]));
                        }

                        if (d.FDP == r.answer) {
                          console.log("FDP");
                          setFDP.apply(void 0, (0,E_git_vinraj_company_test_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__.default)(FDP).concat([FDP + 1]));
                        }

                        if (d.Grüne == r.answer) {
                          console.log("Grüne");
                          setGrüne.apply(void 0, (0,E_git_vinraj_company_test_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__.default)(Grüne).concat([Grüne + 1]));
                        }

                        if (d.Linke == r.answer) {
                          console.log("Linke");
                          setLinke.apply(void 0, (0,E_git_vinraj_company_test_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__.default)(Linke).concat([Linke + 1]));
                        } else {
                          console.log("else from last if");
                        }
                      }
                    }
                  } catch (err) {
                    _iterator2.e(err);
                  } finally {
                    _iterator2.f();
                  }
                } // props.result?.map((r) => {
                //   console.log("result map");
                //   data?.map((d) => {
                //     console.log("data map");
                //     if (r.question_id == d.id) {
                //       console.log("r.question_id", r.question_id, "d.id", d.id);
                //       if (d.SPD == r.answer) {
                //         console.log("SPD");
                //         setSPD(...SPD, SPD + 1);
                //       }
                //       if (d.CDU == r.answer) {
                //         console.log("CDU");
                //         setCDU(...CDU, CDU + 1);
                //       }
                //       if (d.AfD == r.answer) {
                //         console.log("AfD");
                //         setAfD(...AfD, AfD + 1);
                //       }
                //       if (d.FDP == r.answer) {
                //         console.log("FDP");
                //         setFDP(...FDP, FDP + 1);
                //       }
                //       if (d.Grüne == r.answer) {
                //         console.log("Grüne");
                //         setGrüne(...Grüne, Grüne + 1);
                //       }
                //       if (d.Linke == r.answer) {
                //         console.log("Linke");
                //         setLinke(...Linke, Linke + 1);
                //       } else {
                //         console.log("else from last if");
                //       }
                //     }
                //   });
                // });

              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }
            }

            console.log("submit click"); // axios
            //   .post("https://uditsolutions.in/yarn/public/api/scores", data)
            //   .then((res) => {
            //     console.log(res);
            //     console.log("intial value is submited to results");
            //     result = [];
            //     history.push("/thankyou");
            //   })
            //   .catch((err) => {
            //     console.log(err.response.data);
            //     // history.push("/exam-appeared");
            //   });
          },
          children: function children(_ref) {
            var handleSubmit = _ref.handleSubmit;
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_12__.Form, {
              onSubmit: handleSubmit,
              children: [_components_Data_Data_json__WEBPACK_IMPORTED_MODULE_6__ === null || _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_6__ === void 0 ? void 0 : _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_6__.map(function (d, id) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)("div", {
                  className: "mt-3",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_12__.CardTitle, {
                    children: [" ", d.id, "/", dataLength]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 174,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_12__.CardSubtitle, {
                    children: d.Schlagwort
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 178,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_12__.CardText, {
                    children: d.question_text
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 179,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_3__.FieldArray, {
                    name: "result",
                    render: function render(arrayHelpers) {
                      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)("div", {
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_12__.Row, {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_12__.Col, {
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_12__.FormGroup, {
                              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_12__.InputGroup, {
                                className: "flex flex-col mt-2",
                                children: _components_Data_options_json__WEBPACK_IMPORTED_MODULE_7__ === null || _components_Data_options_json__WEBPACK_IMPORTED_MODULE_7__ === void 0 ? void 0 : _components_Data_options_json__WEBPACK_IMPORTED_MODULE_7__.map(function (opt) {
                                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)("label", {
                                    className: "p-2 bg-gray-600 text-white rounded-md text-center hover:bg-yellow-300 hover:text-black mb-1",
                                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_3__.Field, {
                                      type: "radio" // name="answer"
                                      ,
                                      value: opt.option_Value,
                                      className: "hidden",
                                      onChange: function onChange() {
                                        setValue({
                                          question_id: d.id,
                                          answer: opt.option_Value
                                        });

                                        if (result.length > 0) {
                                          for (var i = 0; i < result.length; i++) {
                                            var _result$i;

                                            if (((_result$i = result[i]) === null || _result$i === void 0 ? void 0 : _result$i.question_id) == d.id) {
                                              console.log("splice");
                                              result.splice(i, 1, {
                                                question_id: d.id,
                                                answer: opt.option_Value
                                              });
                                              return;
                                            } else if (result[i].question_id !== d.id) {
                                              console.log("else_if question of data", d.id, "result q-id", result[i].question_id);
                                              result.push({
                                                question_id: d.id,
                                                answer: opt.option_Value // value,

                                              });
                                              return;
                                            }
                                          }

                                          props.resultSetData(result);
                                        } else {
                                          console.log("else");
                                          result.push({
                                            question_id: d.id,
                                            answer: opt.option_Value
                                          });
                                          props.resultSetData(result);
                                        }
                                      }
                                    }, void 0, false, {
                                      fileName: _jsxFileName,
                                      lineNumber: 195,
                                      columnNumber: 47
                                    }, _this), opt.option_text]
                                  }, opt.id, true, {
                                    fileName: _jsxFileName,
                                    lineNumber: 191,
                                    columnNumber: 45
                                  }, _this);
                                })
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 188,
                                columnNumber: 39
                              }, _this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 187,
                              columnNumber: 37
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 186,
                            columnNumber: 35
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 185,
                          columnNumber: 33
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 184,
                        columnNumber: 31
                      }, _this);
                    }
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 180,
                    columnNumber: 25
                  }, _this)]
                }, d.id, true, {
                  fileName: _jsxFileName,
                  lineNumber: 173,
                  columnNumber: 23
                }, _this);
              }), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_12__.Button, {
                  block: true,
                  className: "border-2 p-2 border-black mt-7",
                  type: "submit" // onClick={handleSubmit}
                  // disabled={formProps.isSubmitting}
                  ,
                  children: "Eegebnis zeigen"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 279,
                  columnNumber: 21
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 278,
                columnNumber: 19
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 170,
              columnNumber: 17
            }, _this);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 68,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 67,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 66,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 61,
    columnNumber: 5
  }, this);
}

_s(Home, "ea2M+Wy0wZipXmzz6sFKfCdQsqY=", false, function () {
  return [react_router__WEBPACK_IMPORTED_MODULE_11__.useHistory];
});

_c = Home;

var mapStateToProps = function mapStateToProps(state) {
  return {
    result: state.result.result
  };
};

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    resultSetData: function resultSetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_9__.resultSetData(data));
    },
    onDeleteResult: function onDeleteResult(data, id) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_9__.deleteResult(data, id));
    },
    onPostResultData: function onPostResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_9__.postResultData(data, user, toggle));
    },
    onUpdateResultData: function onUpdateResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_9__.updateResultData(data, user, toggle));
    },
    resultEditGetData: function resultEditGetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_9__.resultEditGetData(data));
    }
  };
};

/* harmony default export */ __webpack_exports__["default"] = ((0,react_redux__WEBPACK_IMPORTED_MODULE_8__.connect)(mapStateToProps, mapDispatchToProps)(Home));

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguMmI5MWI0MGNhOTU3MzI1Zjc4NzQuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFjQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLElBQUl3QixNQUFNLEdBQUcsSUFBSUMsS0FBSixFQUFiO0FBQ0EsSUFBSUMsVUFBVSxHQUFHLElBQUlELEtBQUosRUFBakI7O0FBQ0EsU0FBU0UsSUFBVCxDQUFjQyxLQUFkLEVBQXFCO0FBQUE7O0FBQUE7O0FBQ25CLGtCQUEwQnRCLCtDQUFRLENBQUMsRUFBRCxDQUFsQztBQUFBLE1BQU91QixLQUFQO0FBQUEsTUFBY0MsUUFBZDs7QUFDQSxNQUFNQyxPQUFPLEdBQUdSLHlEQUFVLEVBQTFCOztBQUVBLG1CQUE4QmpCLCtDQUFRLENBQUM7QUFDckMwQixJQUFBQSxHQUFHLEVBQUUsQ0FEZ0M7QUFFckNDLElBQUFBLEdBQUcsRUFBRSxDQUZnQztBQUdyQ0MsSUFBQUEsR0FBRyxFQUFFLENBSGdDO0FBSXJDQyxJQUFBQSxHQUFHLEVBQUUsQ0FKZ0M7QUFLckNDLElBQUFBLEtBQUssRUFBRSxDQUw4QjtBQU1yQ0MsSUFBQUEsS0FBSyxFQUFFO0FBTjhCLEdBQUQsQ0FBdEM7QUFBQSxNQUFPQyxPQUFQO0FBQUEsTUFBZ0JDLFVBQWhCOztBQVNBLG1CQUFzQmpDLCtDQUFRLENBQUMsQ0FBRCxDQUE5QjtBQUFBLE1BQU8wQixHQUFQO0FBQUEsTUFBWVEsTUFBWjs7QUFDQSxtQkFBc0JsQywrQ0FBUSxDQUFDLENBQUQsQ0FBOUI7QUFBQSxNQUFPMkIsR0FBUDtBQUFBLE1BQVlRLE1BQVo7O0FBQ0EsbUJBQXNCbkMsK0NBQVEsQ0FBQyxDQUFELENBQTlCO0FBQUEsTUFBTzRCLEdBQVA7QUFBQSxNQUFZUSxNQUFaOztBQUNBLG1CQUFzQnBDLCtDQUFRLENBQUMsQ0FBRCxDQUE5QjtBQUFBLE1BQU82QixHQUFQO0FBQUEsTUFBWVEsTUFBWjs7QUFDQSxtQkFBMEJyQywrQ0FBUSxDQUFDLENBQUQsQ0FBbEM7QUFBQSxNQUFPOEIsS0FBUDtBQUFBLE1BQWNRLFFBQWQ7O0FBQ0EsbUJBQTBCdEMsK0NBQVEsQ0FBQyxDQUFELENBQWxDO0FBQUEsTUFBTytCLEtBQVA7QUFBQSxNQUFjUSxRQUFkOztBQUVBQyxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBQTRCbkIsS0FBSyxDQUFDSixNQUFsQztBQUVBc0IsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFxQmxCLEtBQXJCO0FBRUFpQixFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQXFCdkIsTUFBckI7QUFDQXNCLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVosRUFBbUJmLEdBQW5CO0FBQ0FjLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVosRUFBbUJkLEdBQW5CO0FBQ0FhLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVosRUFBbUJiLEdBQW5CO0FBQ0FZLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVosRUFBbUJaLEdBQW5CO0FBQ0FXLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVosRUFBcUJYLEtBQXJCO0FBQ0FVLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVosRUFBcUJWLEtBQXJCO0FBRUEsTUFBTVcsVUFBVSxHQUFHN0IsdURBQUgsYUFBR0EsdURBQUgsdUJBQUdBLDhEQUFuQjtBQUNBLHNCQUNFO0FBQUssYUFBUyxFQUFDLEVBQWY7QUFBQSw0QkFDRSwrREFBQyxrREFBRDtBQUFBLDhCQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFRTtBQUFNLFdBQUcsRUFBQyxNQUFWO0FBQWlCLFlBQUksRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFLRSwrREFBQyw2Q0FBRDtBQUFNLGVBQVMsRUFBQyxtQ0FBaEI7QUFBQSw2QkFDRSwrREFBQyxpREFBRDtBQUFBLCtCQUNFLCtEQUFDLDBDQUFEO0FBQ0UsdUJBQWEsRUFBRTtBQUNiSyxZQUFBQSxNQUFNLEVBQUUsRUFESztBQUViMEIsWUFBQUEsTUFBTSxFQUFFO0FBRkssV0FEakI7QUFLRSxrQkFBUSxFQUFFLGtCQUFDQyxNQUFELEVBQVNDLGFBQVQsRUFBMkI7QUFBQTs7QUFDbkNYLFlBQUFBLE1BQU0saUNBQU1SLEdBQU47QUFBV0EsY0FBQUEsR0FBRyxFQUFFQSxHQUFHLEdBQUc7QUFBdEIsZUFBTjs7QUFDQSxnQkFBSSxrQkFBQUwsS0FBSyxDQUFDSixNQUFOLGdFQUFjeUIsTUFBZCxJQUF1QixDQUEzQixFQUE4QjtBQUFBOztBQUM1QkgsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksZUFBWixvQkFBNkJuQixLQUFLLENBQUNKLE1BQW5DLG1EQUE2QixlQUFjeUIsTUFBM0M7QUFDQSxrQkFBTUksWUFBWSxxQkFBR3pCLEtBQUssQ0FBQ0osTUFBVCxtREFBRyxlQUFjeUIsTUFBbkM7O0FBRjRCLHlEQUlackIsS0FBSyxDQUFDSixNQUpNO0FBQUE7O0FBQUE7QUFJNUIsb0VBQThCO0FBQUEsc0JBQW5COEIsQ0FBbUI7QUFDNUJSLGtCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxZQUFaOztBQUQ0Qiw4REFFWjVCLHVEQUZZO0FBQUE7O0FBQUE7QUFFNUIsMkVBQXNCO0FBQUEsMEJBQVhvQyxDQUFXO0FBQ3BCVCxzQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWjs7QUFDQSwwQkFBSU8sQ0FBQyxDQUFDRSxXQUFGLElBQWlCRCxDQUFDLENBQUNFLEVBQXZCLEVBQTJCO0FBQ3pCWCx3QkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksZUFBWixFQUE2Qk8sQ0FBQyxDQUFDRSxXQUEvQixFQUE0QyxNQUE1QyxFQUFvREQsQ0FBQyxDQUFDRSxFQUF0RDs7QUFDQSw0QkFBSUYsQ0FBQyxDQUFDdEIsR0FBRixJQUFTcUIsQ0FBQyxDQUFDSixNQUFmLEVBQXVCO0FBQ3JCSiwwQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksS0FBWjtBQUNBTiwwQkFBQUEsTUFBTSxNQUFOLHFJQUFVUixHQUFWLFVBQWVBLEdBQUcsR0FBRyxDQUFyQjtBQUNEOztBQUNELDRCQUFJc0IsQ0FBQyxDQUFDdkIsR0FBRixJQUFTc0IsQ0FBQyxDQUFDSixNQUFmLEVBQXVCO0FBQ3JCSiwwQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksS0FBWjtBQUNBUCwwQkFBQUEsTUFBTSxNQUFOLHFJQUFVUixHQUFWLFVBQWVBLEdBQUcsR0FBRyxDQUFyQjtBQUNEOztBQUNELDRCQUFJdUIsQ0FBQyxDQUFDckIsR0FBRixJQUFTb0IsQ0FBQyxDQUFDSixNQUFmLEVBQXVCO0FBQ3JCSiwwQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksS0FBWjtBQUNBTCwwQkFBQUEsTUFBTSxNQUFOLHFJQUFVUixHQUFWLFVBQWVBLEdBQUcsR0FBRyxDQUFyQjtBQUNEOztBQUNELDRCQUFJcUIsQ0FBQyxDQUFDcEIsR0FBRixJQUFTbUIsQ0FBQyxDQUFDSixNQUFmLEVBQXVCO0FBQ3JCSiwwQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksS0FBWjtBQUNBSiwwQkFBQUEsTUFBTSxNQUFOLHFJQUFVUixHQUFWLFVBQWVBLEdBQUcsR0FBRyxDQUFyQjtBQUNEOztBQUNELDRCQUFJb0IsQ0FBQyxDQUFDbkIsS0FBRixJQUFXa0IsQ0FBQyxDQUFDSixNQUFqQixFQUF5QjtBQUN2QkosMEJBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7QUFDQUgsMEJBQUFBLFFBQVEsTUFBUixxSUFBWVIsS0FBWixVQUFtQkEsS0FBSyxHQUFHLENBQTNCO0FBQ0Q7O0FBQ0QsNEJBQUltQixDQUFDLENBQUNsQixLQUFGLElBQVdpQixDQUFDLENBQUNKLE1BQWpCLEVBQXlCO0FBQ3ZCSiwwQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUNBRiwwQkFBQUEsUUFBUSxNQUFSLHFJQUFZUixLQUFaLFVBQW1CQSxLQUFLLEdBQUcsQ0FBM0I7QUFDRCx5QkFIRCxNQUdPO0FBQ0xTLDBCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxtQkFBWjtBQUNEO0FBQ0Y7QUFDRjtBQWpDMkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWtDN0IsaUJBdEMyQixDQXdDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUExRTRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUEyRTdCOztBQUVERCxZQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBL0VtQyxDQWdGbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0QsV0FsR0g7QUFBQSxvQkFvR0csd0JBQXNCO0FBQUEsZ0JBQW5CVyxZQUFtQixRQUFuQkEsWUFBbUI7QUFDckIsZ0NBQ0UsK0RBQUMsNkNBQUQ7QUFBTSxzQkFBUSxFQUFFQSxZQUFoQjtBQUFBLHlCQUNHdkMsdURBREgsYUFDR0EsdURBREgsdUJBQ0dBLDJEQUFBLENBQVUsVUFBQ29DLENBQUQsRUFBSUUsRUFBSixFQUFXO0FBQ3BCLG9DQUNFO0FBQWdCLDJCQUFTLEVBQUMsTUFBMUI7QUFBQSwwQ0FDRSwrREFBQyxrREFBRDtBQUFBLCtCQUNHLEdBREgsRUFFR0YsQ0FBQyxDQUFDRSxFQUZMLE9BRVVULFVBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURGLGVBS0UsK0RBQUMscURBQUQ7QUFBQSw4QkFBZU8sQ0FBQyxDQUFDSztBQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUxGLGVBTUUsK0RBQUMsaURBQUQ7QUFBQSw4QkFBV0wsQ0FBQyxDQUFDTTtBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTkYsZUFPRSwrREFBQyw4Q0FBRDtBQUNFLHdCQUFJLEVBQUMsUUFEUDtBQUVFLDBCQUFNLEVBQUUsZ0JBQUNDLFlBQUQsRUFBa0I7QUFDeEIsMENBQ0U7QUFBQSwrQ0FDRSwrREFBQyw0Q0FBRDtBQUFBLGlEQUNFLCtEQUFDLDRDQUFEO0FBQUEsbURBQ0UsK0RBQUMsa0RBQUQ7QUFBQSxxREFDRSwrREFBQyxtREFBRDtBQUFZLHlDQUFTLEVBQUMsb0JBQXRCO0FBQUEsMENBQ0cxQywwREFESCxhQUNHQSwwREFESCx1QkFDR0EsOERBQUEsQ0FBYSxVQUFDMkMsR0FBRCxFQUFTO0FBQ3JCLHNEQUNFO0FBRUUsNkNBQVMsRUFBQyw2RkFGWjtBQUFBLDREQUlFLCtEQUFDLHlDQUFEO0FBQ0UsMENBQUksRUFBQyxPQURQLENBRUU7QUFGRjtBQUdFLDJDQUFLLEVBQUVBLEdBQUcsQ0FBQ0MsWUFIYjtBQUlFLCtDQUFTLEVBQUMsUUFKWjtBQUtFLDhDQUFRLEVBQUUsb0JBQU07QUFDZGxDLHdDQUFBQSxRQUFRLENBQUM7QUFDUDBCLDBDQUFBQSxXQUFXLEVBQUVELENBQUMsQ0FBQ0UsRUFEUjtBQUVQUCwwQ0FBQUEsTUFBTSxFQUFFYSxHQUFHLENBQUNDO0FBRkwseUNBQUQsQ0FBUjs7QUFLQSw0Q0FBSXhDLE1BQU0sQ0FBQ3lCLE1BQVAsR0FBZ0IsQ0FBcEIsRUFBdUI7QUFDckIsK0NBQ0UsSUFBSWdCLENBQUMsR0FBRyxDQURWLEVBRUVBLENBQUMsR0FBR3pDLE1BQU0sQ0FBQ3lCLE1BRmIsRUFHRWdCLENBQUMsRUFISCxFQUlFO0FBQUE7O0FBQ0EsZ0RBQ0UsY0FBQXpDLE1BQU0sQ0FBQ3lDLENBQUQsQ0FBTix3REFDSVQsV0FESixLQUNtQkQsQ0FBQyxDQUFDRSxFQUZ2QixFQUdFO0FBQ0FYLDhDQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0FBQ0F2Qiw4Q0FBQUEsTUFBTSxDQUFDMEMsTUFBUCxDQUFjRCxDQUFkLEVBQWlCLENBQWpCLEVBQW9CO0FBQ2xCVCxnREFBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNFLEVBREc7QUFFbEJQLGdEQUFBQSxNQUFNLEVBQ0phLEdBQUcsQ0FBQ0M7QUFIWSwrQ0FBcEI7QUFLQTtBQUNELDZDQVhELE1BV08sSUFDTHhDLE1BQU0sQ0FBQ3lDLENBQUQsQ0FBTixDQUNHVCxXQURILEtBQ21CRCxDQUFDLENBQUNFLEVBRmhCLEVBR0w7QUFDQVgsOENBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUNFLDBCQURGLEVBRUVRLENBQUMsQ0FBQ0UsRUFGSixFQUdFLGFBSEYsRUFJRWpDLE1BQU0sQ0FBQ3lDLENBQUQsQ0FBTixDQUFVVCxXQUpaO0FBT0FoQyw4Q0FBQUEsTUFBTSxDQUFDMkMsSUFBUCxDQUFZO0FBQ1ZYLGdEQUFBQSxXQUFXLEVBQUVELENBQUMsQ0FBQ0UsRUFETDtBQUVWUCxnREFBQUEsTUFBTSxFQUNKYSxHQUFHLENBQUNDLFlBSEksQ0FJVjs7QUFKVSwrQ0FBWjtBQU1BO0FBQ0Q7QUFDRjs7QUFDRHBDLDBDQUFBQSxLQUFLLENBQUN3QyxhQUFOLENBQW9CNUMsTUFBcEI7QUFDRCx5Q0F0Q0QsTUFzQ087QUFDTHNCLDBDQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBQ0F2QiwwQ0FBQUEsTUFBTSxDQUFDMkMsSUFBUCxDQUFZO0FBQ1ZYLDRDQUFBQSxXQUFXLEVBQUVELENBQUMsQ0FBQ0UsRUFETDtBQUVWUCw0Q0FBQUEsTUFBTSxFQUFFYSxHQUFHLENBQUNDO0FBRkYsMkNBQVo7QUFJQXBDLDBDQUFBQSxLQUFLLENBQUN3QyxhQUFOLENBQW9CNUMsTUFBcEI7QUFDRDtBQUNGO0FBekRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkNBSkYsRUErREd1QyxHQUFHLENBQUNNLFdBL0RQO0FBQUEscUNBQ09OLEdBQUcsQ0FBQ04sRUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJDQURGO0FBbUVELGlDQXBFQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURGO0FBMEZEO0FBN0ZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBUEY7QUFBQSxtQkFBVUYsQ0FBQyxDQUFDRSxFQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREY7QUF5R0QsZUExR0EsQ0FESCxlQTRHRTtBQUFLLHlCQUFTLEVBQUMscUJBQWY7QUFBQSx1Q0FDRSwrREFBQywrQ0FBRDtBQUNFLHVCQUFLLE1BRFA7QUFFRSwyQkFBUyxFQUFDLGdDQUZaO0FBR0Usc0JBQUksRUFBQyxRQUhQLENBSUU7QUFDQTtBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE1R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGO0FBMEhEO0FBL05IO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBNk9EOztHQTlRUTlCO1VBRVNKOzs7S0FGVEk7O0FBZ1JULElBQU0yQyxlQUFlLEdBQUcsU0FBbEJBLGVBQWtCLENBQUNDLEtBQUQsRUFBVztBQUNqQyxTQUFPO0FBQ0wvQyxJQUFBQSxNQUFNLEVBQUUrQyxLQUFLLENBQUMvQyxNQUFOLENBQWFBO0FBRGhCLEdBQVA7QUFHRCxDQUpEOztBQU1BLElBQU1nRCxrQkFBa0IsR0FBRyxTQUFyQkEsa0JBQXFCLENBQUNDLFFBQUQsRUFBYztBQUN2QyxTQUFPO0FBQ0xMLElBQUFBLGFBQWEsRUFBRSx1QkFBQ2pELElBQUQ7QUFBQSxhQUFVc0QsUUFBUSxDQUFDbkQseURBQUEsQ0FBc0JILElBQXRCLENBQUQsQ0FBbEI7QUFBQSxLQURWO0FBRUx1RCxJQUFBQSxjQUFjLEVBQUUsd0JBQUN2RCxJQUFELEVBQU9zQyxFQUFQO0FBQUEsYUFBY2dCLFFBQVEsQ0FBQ25ELHdEQUFBLENBQXFCSCxJQUFyQixFQUEyQnNDLEVBQTNCLENBQUQsQ0FBdEI7QUFBQSxLQUZYO0FBR0xtQixJQUFBQSxnQkFBZ0IsRUFBRSwwQkFBQ3pELElBQUQsRUFBTzBELElBQVAsRUFBYUMsTUFBYjtBQUFBLGFBQ2hCTCxRQUFRLENBQUNuRCwwREFBQSxDQUF1QkgsSUFBdkIsRUFBNkIwRCxJQUE3QixFQUFtQ0MsTUFBbkMsQ0FBRCxDQURRO0FBQUEsS0FIYjtBQUtMRSxJQUFBQSxrQkFBa0IsRUFBRSw0QkFBQzdELElBQUQsRUFBTzBELElBQVAsRUFBYUMsTUFBYjtBQUFBLGFBQ2xCTCxRQUFRLENBQUNuRCw0REFBQSxDQUF5QkgsSUFBekIsRUFBK0IwRCxJQUEvQixFQUFxQ0MsTUFBckMsQ0FBRCxDQURVO0FBQUEsS0FMZjtBQU9MSSxJQUFBQSxpQkFBaUIsRUFBRSwyQkFBQy9ELElBQUQ7QUFBQSxhQUFVc0QsUUFBUSxDQUFDbkQsNkRBQUEsQ0FBMEJILElBQTFCLENBQUQsQ0FBbEI7QUFBQTtBQVBkLEdBQVA7QUFTRCxDQVZEOztBQVdBLCtEQUFlRSxvREFBTyxDQUFDaUQsZUFBRCxFQUFrQkUsa0JBQWxCLENBQVAsQ0FBNkM3QyxJQUE3QyxDQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3BhZ2VzL2luZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcbmltcG9ydCB7IEZpZWxkLCBGaWVsZEFycmF5LCBGb3JtaWsgfSBmcm9tIFwiZm9ybWlrXCI7XG5pbXBvcnQgSGVhZCBmcm9tIFwibmV4dC9oZWFkXCI7XG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQge1xuICBCdXR0b24sXG4gIENhcmQsXG4gIENhcmRCb2R5LFxuICBDYXJkSGVhZGVyLFxuICBDYXJkU3VidGl0bGUsXG4gIENhcmRUZXh0LFxuICBDYXJkVGl0bGUsXG4gIENvbCxcbiAgRm9ybSxcbiAgRm9ybUdyb3VwLFxuICBJbnB1dEdyb3VwLFxuICBSb3csXG59IGZyb20gXCJyZWFjdHN0cmFwXCI7XG5pbXBvcnQgZGF0YSBmcm9tIFwiLi4vY29tcG9uZW50cy9EYXRhL0RhdGEuanNvblwiO1xuaW1wb3J0IG9wdGlvbnMgZnJvbSBcIi4uL2NvbXBvbmVudHMvRGF0YS9vcHRpb25zLmpzb25cIjtcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcbmltcG9ydCAqIGFzIGFjdGlvbnMgZnJvbSBcIi4uL3JlZHV4L2FjdGlvbnNcIjtcbmltcG9ydCB7IHVzZUhpc3RvcnkgfSBmcm9tIFwicmVhY3Qtcm91dGVyXCI7XG5cbnZhciByZXN1bHQgPSBuZXcgQXJyYXkoKTtcbnZhciBNYWluUmVzdWx0ID0gbmV3IEFycmF5KCk7XG5mdW5jdGlvbiBIb21lKHByb3BzKSB7XG4gIGNvbnN0IFt2YWx1ZSwgc2V0VmFsdWVdID0gdXNlU3RhdGUoe30pO1xuICBjb25zdCBoaXN0b3J5ID0gdXNlSGlzdG9yeSgpO1xuXG4gIGNvbnN0IFtjb21wYW55LCBzZXRDb21wYW55XSA9IHVzZVN0YXRlKHtcbiAgICBDRFU6IDAsXG4gICAgU1BEOiAwLFxuICAgIEFmRDogMCxcbiAgICBGRFA6IDAsXG4gICAgR3LDvG5lOiAwLFxuICAgIExpbmtlOiAwLFxuICB9KTtcblxuICBjb25zdCBbQ0RVLCBzZXRDRFVdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtTUEQsIHNldFNQRF0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW0FmRCwgc2V0QWZEXSA9IHVzZVN0YXRlKDApO1xuICBjb25zdCBbRkRQLCBzZXRGRFBdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtHcsO8bmUsIHNldEdyw7xuZV0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW0xpbmtlLCBzZXRMaW5rZV0gPSB1c2VTdGF0ZSgwKTtcblxuICBjb25zb2xlLmxvZyhcInByb3BzLnJlc3VsdFwiLCBwcm9wcy5yZXN1bHQpO1xuXG4gIGNvbnNvbGUubG9nKFwidmFsdWVcIiwgdmFsdWUpO1xuXG4gIGNvbnNvbGUubG9nKFwiYXJyYXlcIiwgcmVzdWx0KTtcbiAgY29uc29sZS5sb2coXCJDRFVcIiwgQ0RVKTtcbiAgY29uc29sZS5sb2coXCJTUERcIiwgU1BEKTtcbiAgY29uc29sZS5sb2coXCJBZkRcIiwgQWZEKTtcbiAgY29uc29sZS5sb2coXCJGRFBcIiwgRkRQKTtcbiAgY29uc29sZS5sb2coXCJHcsO8bmVcIiwgR3LDvG5lKTtcbiAgY29uc29sZS5sb2coXCJMaW5rZVwiLCBMaW5rZSk7XG5cbiAgY29uc3QgZGF0YUxlbmd0aCA9IGRhdGE/Lmxlbmd0aDtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiPlxuICAgICAgPEhlYWQ+XG4gICAgICAgIDx0aXRsZT5DcmVhdGUgTmV4dCBBcHA8L3RpdGxlPlxuICAgICAgICA8bGluayByZWw9XCJpY29uXCIgaHJlZj1cIi9mYXZpY29uLmljb1wiIC8+XG4gICAgICA8L0hlYWQ+XG4gICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTUgYm9yZGVyLTIgc2hhZG93LW1kIHJvdW5kZWQtbWRcIj5cbiAgICAgICAgPENhcmRCb2R5PlxuICAgICAgICAgIDxGb3JtaWtcbiAgICAgICAgICAgIGluaXRpYWxWYWx1ZXM9e3tcbiAgICAgICAgICAgICAgcmVzdWx0OiBbXSxcbiAgICAgICAgICAgICAgYW5zd2VyOiBcIlwiLFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIG9uU3VibWl0PXsodmFsdWVzLCBzZXRTdWJtaXR0aW5nKSA9PiB7XG4gICAgICAgICAgICAgIHNldFNQRCh7IC4uLlNQRCwgU1BEOiBTUEQgKyAxIH0pO1xuICAgICAgICAgICAgICBpZiAocHJvcHMucmVzdWx0Py5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJyZXN1bHQgbGVuZ3RoXCIsIHByb3BzLnJlc3VsdD8ubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICBjb25zdCByZXN1bHRMZW5ndGggPSBwcm9wcy5yZXN1bHQ/Lmxlbmd0aDtcblxuICAgICAgICAgICAgICAgIGZvciAoY29uc3QgciBvZiBwcm9wcy5yZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwicmVzdWx0IG1hcFwiKTtcbiAgICAgICAgICAgICAgICAgIGZvciAoY29uc3QgZCBvZiBkYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZGF0YSBtYXBcIik7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyLnF1ZXN0aW9uX2lkID09IGQuaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInIucXVlc3Rpb25faWRcIiwgci5xdWVzdGlvbl9pZCwgXCJkLmlkXCIsIGQuaWQpO1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChkLlNQRCA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJTUERcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTUEQoLi4uU1BELCBTUEQgKyAxKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGQuQ0RVID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNEVVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldENEVSguLi5DRFUsIENEVSArIDEpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICBpZiAoZC5BZkQgPT0gci5hbnN3ZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQWZEXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0QWZEKC4uLkFmRCwgQWZEICsgMSk7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIGlmIChkLkZEUCA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJGRFBcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRGRFAoLi4uRkRQLCBGRFAgKyAxKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGQuR3LDvG5lID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkdyw7xuZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEdyw7xuZSguLi5HcsO8bmUsIEdyw7xuZSArIDEpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICBpZiAoZC5MaW5rZSA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJMaW5rZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldExpbmtlKC4uLkxpbmtlLCBMaW5rZSArIDEpO1xuICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImVsc2UgZnJvbSBsYXN0IGlmXCIpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIHByb3BzLnJlc3VsdD8ubWFwKChyKSA9PiB7XG4gICAgICAgICAgICAgICAgLy8gICBjb25zb2xlLmxvZyhcInJlc3VsdCBtYXBcIik7XG4gICAgICAgICAgICAgICAgLy8gICBkYXRhPy5tYXAoKGQpID0+IHtcbiAgICAgICAgICAgICAgICAvLyAgICAgY29uc29sZS5sb2coXCJkYXRhIG1hcFwiKTtcbiAgICAgICAgICAgICAgICAvLyAgICAgaWYgKHIucXVlc3Rpb25faWQgPT0gZC5pZCkge1xuICAgICAgICAgICAgICAgIC8vICAgICAgIGNvbnNvbGUubG9nKFwici5xdWVzdGlvbl9pZFwiLCByLnF1ZXN0aW9uX2lkLCBcImQuaWRcIiwgZC5pZCk7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgaWYgKGQuU1BEID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgICBjb25zb2xlLmxvZyhcIlNQRFwiKTtcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIHNldFNQRCguLi5TUEQsIFNQRCArIDEpO1xuICAgICAgICAgICAgICAgIC8vICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyAgICAgICBpZiAoZC5DRFUgPT0gci5hbnN3ZXIpIHtcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIGNvbnNvbGUubG9nKFwiQ0RVXCIpO1xuICAgICAgICAgICAgICAgIC8vICAgICAgICAgc2V0Q0RVKC4uLkNEVSwgQ0RVICsgMSk7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgfVxuICAgICAgICAgICAgICAgIC8vICAgICAgIGlmIChkLkFmRCA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICAgIC8vICAgICAgICAgY29uc29sZS5sb2coXCJBZkRcIik7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgICBzZXRBZkQoLi4uQWZELCBBZkQgKyAxKTtcbiAgICAgICAgICAgICAgICAvLyAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gICAgICAgaWYgKGQuRkRQID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgICBjb25zb2xlLmxvZyhcIkZEUFwiKTtcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIHNldEZEUCguLi5GRFAsIEZEUCArIDEpO1xuICAgICAgICAgICAgICAgIC8vICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyAgICAgICBpZiAoZC5HcsO8bmUgPT0gci5hbnN3ZXIpIHtcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIGNvbnNvbGUubG9nKFwiR3LDvG5lXCIpO1xuICAgICAgICAgICAgICAgIC8vICAgICAgICAgc2V0R3LDvG5lKC4uLkdyw7xuZSwgR3LDvG5lICsgMSk7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgfVxuICAgICAgICAgICAgICAgIC8vICAgICAgIGlmIChkLkxpbmtlID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgICBjb25zb2xlLmxvZyhcIkxpbmtlXCIpO1xuICAgICAgICAgICAgICAgIC8vICAgICAgICAgc2V0TGlua2UoLi4uTGlua2UsIExpbmtlICsgMSk7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIGNvbnNvbGUubG9nKFwiZWxzZSBmcm9tIGxhc3QgaWZcIik7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgfVxuICAgICAgICAgICAgICAgIC8vICAgICB9XG4gICAgICAgICAgICAgICAgLy8gICB9KTtcbiAgICAgICAgICAgICAgICAvLyB9KTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic3VibWl0IGNsaWNrXCIpO1xuICAgICAgICAgICAgICAvLyBheGlvc1xuICAgICAgICAgICAgICAvLyAgIC5wb3N0KFwiaHR0cHM6Ly91ZGl0c29sdXRpb25zLmluL3lhcm4vcHVibGljL2FwaS9zY29yZXNcIiwgZGF0YSlcbiAgICAgICAgICAgICAgLy8gICAudGhlbigocmVzKSA9PiB7XG4gICAgICAgICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhyZXMpO1xuICAgICAgICAgICAgICAvLyAgICAgY29uc29sZS5sb2coXCJpbnRpYWwgdmFsdWUgaXMgc3VibWl0ZWQgdG8gcmVzdWx0c1wiKTtcbiAgICAgICAgICAgICAgLy8gICAgIHJlc3VsdCA9IFtdO1xuICAgICAgICAgICAgICAvLyAgICAgaGlzdG9yeS5wdXNoKFwiL3RoYW5reW91XCIpO1xuICAgICAgICAgICAgICAvLyAgIH0pXG4gICAgICAgICAgICAgIC8vICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKGVyci5yZXNwb25zZS5kYXRhKTtcbiAgICAgICAgICAgICAgLy8gICAgIC8vIGhpc3RvcnkucHVzaChcIi9leGFtLWFwcGVhcmVkXCIpO1xuXG4gICAgICAgICAgICAgIC8vICAgfSk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHsoeyBoYW5kbGVTdWJtaXQgfSkgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxGb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxuICAgICAgICAgICAgICAgICAge2RhdGE/Lm1hcCgoZCwgaWQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17ZC5pZH0gY2xhc3NOYW1lPVwibXQtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcmRUaXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge1wiIFwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZC5pZH0ve2RhdGFMZW5ndGh9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NhcmRUaXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkU3VidGl0bGU+e2QuU2NobGFnd29ydH08L0NhcmRTdWJ0aXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkVGV4dD57ZC5xdWVzdGlvbl90ZXh0fTwvQ2FyZFRleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRBcnJheVxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVzdWx0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVuZGVyPXsoYXJyYXlIZWxwZXJzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSb3c+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dEdyb3VwIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcHRpb25zPy5tYXAoKG9wdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtvcHQuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGJnLWdyYXktNjAwIHRleHQtd2hpdGUgcm91bmRlZC1tZCB0ZXh0LWNlbnRlciBob3ZlcjpiZy15ZWxsb3ctMzAwIGhvdmVyOnRleHQtYmxhY2sgbWItMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBuYW1lPVwiYW5zd2VyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtvcHQub3B0aW9uX1ZhbHVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFZhbHVlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6IG9wdC5vcHRpb25fVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgaSA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpIDwgcmVzdWx0Lmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGkrK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/LnF1ZXN0aW9uX2lkID09IGQuaWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInNwbGljZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnNwbGljZShpLCAxLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25faWQ6IGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdFtpXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5xdWVzdGlvbl9pZCAhPT0gZC5pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZWxzZV9pZiBxdWVzdGlvbiBvZiBkYXRhXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInJlc3VsdCBxLWlkXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0W2ldLnF1ZXN0aW9uX2lkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uX2lkOiBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdC5vcHRpb25fVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3BzLnJlc3VsdFNldERhdGEocmVzdWx0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImVsc2VcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25faWQ6IGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6IG9wdC5vcHRpb25fVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcHMucmVzdWx0U2V0RGF0YShyZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29wdC5vcHRpb25fdGV4dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjp7XCIgXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVzdWx0Py5tYXAoKHIpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHIucXVlc3Rpb25faWQgPT0gZC5pZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByLmFuc3dlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+ICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0lucHV0R3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBibG9ja1xuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlci0yIHAtMiBib3JkZXItYmxhY2sgbXQtN1wiXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgICAgLy8gb25DbGljaz17aGFuZGxlU3VibWl0fVxuICAgICAgICAgICAgICAgICAgICAgIC8vIGRpc2FibGVkPXtmb3JtUHJvcHMuaXNTdWJtaXR0aW5nfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgRWVnZWJuaXMgemVpZ2VuXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9Gb3JtPlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICA8L0Zvcm1paz5cbiAgICAgICAgPC9DYXJkQm9keT5cbiAgICAgIDwvQ2FyZD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuY29uc3QgbWFwU3RhdGVUb1Byb3BzID0gKHN0YXRlKSA9PiB7XG4gIHJldHVybiB7XG4gICAgcmVzdWx0OiBzdGF0ZS5yZXN1bHQucmVzdWx0LFxuICB9O1xufTtcblxuY29uc3QgbWFwRGlzcGF0Y2hUb1Byb3BzID0gKGRpc3BhdGNoKSA9PiB7XG4gIHJldHVybiB7XG4gICAgcmVzdWx0U2V0RGF0YTogKGRhdGEpID0+IGRpc3BhdGNoKGFjdGlvbnMucmVzdWx0U2V0RGF0YShkYXRhKSksXG4gICAgb25EZWxldGVSZXN1bHQ6IChkYXRhLCBpZCkgPT4gZGlzcGF0Y2goYWN0aW9ucy5kZWxldGVSZXN1bHQoZGF0YSwgaWQpKSxcbiAgICBvblBvc3RSZXN1bHREYXRhOiAoZGF0YSwgdXNlciwgdG9nZ2xlKSA9PlxuICAgICAgZGlzcGF0Y2goYWN0aW9ucy5wb3N0UmVzdWx0RGF0YShkYXRhLCB1c2VyLCB0b2dnbGUpKSxcbiAgICBvblVwZGF0ZVJlc3VsdERhdGE6IChkYXRhLCB1c2VyLCB0b2dnbGUpID0+XG4gICAgICBkaXNwYXRjaChhY3Rpb25zLnVwZGF0ZVJlc3VsdERhdGEoZGF0YSwgdXNlciwgdG9nZ2xlKSksXG4gICAgcmVzdWx0RWRpdEdldERhdGE6IChkYXRhKSA9PiBkaXNwYXRjaChhY3Rpb25zLnJlc3VsdEVkaXRHZXREYXRhKGRhdGEpKSxcbiAgfTtcbn07XG5leHBvcnQgZGVmYXVsdCBjb25uZWN0KG1hcFN0YXRlVG9Qcm9wcywgbWFwRGlzcGF0Y2hUb1Byb3BzKShIb21lKTtcbiJdLCJuYW1lcyI6WyJheGlvcyIsIkZpZWxkIiwiRmllbGRBcnJheSIsIkZvcm1payIsIkhlYWQiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkJ1dHRvbiIsIkNhcmQiLCJDYXJkQm9keSIsIkNhcmRIZWFkZXIiLCJDYXJkU3VidGl0bGUiLCJDYXJkVGV4dCIsIkNhcmRUaXRsZSIsIkNvbCIsIkZvcm0iLCJGb3JtR3JvdXAiLCJJbnB1dEdyb3VwIiwiUm93IiwiZGF0YSIsIm9wdGlvbnMiLCJjb25uZWN0IiwiYWN0aW9ucyIsInVzZUhpc3RvcnkiLCJyZXN1bHQiLCJBcnJheSIsIk1haW5SZXN1bHQiLCJIb21lIiwicHJvcHMiLCJ2YWx1ZSIsInNldFZhbHVlIiwiaGlzdG9yeSIsIkNEVSIsIlNQRCIsIkFmRCIsIkZEUCIsIkdyw7xuZSIsIkxpbmtlIiwiY29tcGFueSIsInNldENvbXBhbnkiLCJzZXRDRFUiLCJzZXRTUEQiLCJzZXRBZkQiLCJzZXRGRFAiLCJzZXRHcsO8bmUiLCJzZXRMaW5rZSIsImNvbnNvbGUiLCJsb2ciLCJkYXRhTGVuZ3RoIiwibGVuZ3RoIiwiYW5zd2VyIiwidmFsdWVzIiwic2V0U3VibWl0dGluZyIsInJlc3VsdExlbmd0aCIsInIiLCJkIiwicXVlc3Rpb25faWQiLCJpZCIsImhhbmRsZVN1Ym1pdCIsIm1hcCIsIlNjaGxhZ3dvcnQiLCJxdWVzdGlvbl90ZXh0IiwiYXJyYXlIZWxwZXJzIiwib3B0Iiwib3B0aW9uX1ZhbHVlIiwiaSIsInNwbGljZSIsInB1c2giLCJyZXN1bHRTZXREYXRhIiwib3B0aW9uX3RleHQiLCJtYXBTdGF0ZVRvUHJvcHMiLCJzdGF0ZSIsIm1hcERpc3BhdGNoVG9Qcm9wcyIsImRpc3BhdGNoIiwib25EZWxldGVSZXN1bHQiLCJkZWxldGVSZXN1bHQiLCJvblBvc3RSZXN1bHREYXRhIiwidXNlciIsInRvZ2dsZSIsInBvc3RSZXN1bHREYXRhIiwib25VcGRhdGVSZXN1bHREYXRhIiwidXBkYXRlUmVzdWx0RGF0YSIsInJlc3VsdEVkaXRHZXREYXRhIl0sInNvdXJjZVJvb3QiOiIifQ==