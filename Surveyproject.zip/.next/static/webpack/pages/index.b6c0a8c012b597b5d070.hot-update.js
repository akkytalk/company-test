"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
/* harmony import */ var _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Data/Data.json */ "./components/Data/Data.json");
/* harmony import */ var _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Data/options.json */ "./components/Data/options.json");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _redux_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../redux/actions */ "./redux/actions/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "E:\\git vinraj\\company-test\\pages\\index.js",
    _s = $RefreshSig$();











var result = new Array();

function Home(props) {
  _s();

  var _this = this;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      value = _useState[0],
      setValue = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      company = _useState2[0],
      setCompany = _useState2[1];

  console.log("props.result", props.result);
  console.log("value", value);

  var handleSubmit = function handleSubmit(values, setSubmitting) {
    if (props.result) {
      var _props$result;

      (_props$result = props.result) === null || _props$result === void 0 ? void 0 : _props$result.map(function (r) {
        data === null || data === void 0 ? void 0 : data.map(function (d) {
          if (r.question_id == d.question_id) {
            if (d.CDU / CSU == r.answer) {
              console.log("aakash");
            }
          }
        });
      });
    }

    var data = {
      result: result
    };
    console.log(data);
    axios__WEBPACK_IMPORTED_MODULE_0___default().post("/test", data).then(function (res) {
      console.log(res);
      console.log("intial value is submited to results");
      result = [];
      history.push("/thankyou");
    })["catch"](function (err) {
      console.log(err.response.data); // history.push("/exam-appeared");
      // result = [];
    });
  };

  console.log("array", result);
  var dataLength = _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.length;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
    className: "",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("title", {
        children: "Create Next App"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 70,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 69,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.Card, {
      className: "p-5 border-2 shadow-md rounded-md",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.CardBody, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
          initialValues: {
            result: [],
            answer: ""
          },
          onSubmit: handleSubmit,
          children: function children(formProps) {
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.Form, {
              children: [_components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === null || _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === void 0 ? void 0 : _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.map(function (d, id) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                  className: "mt-3",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.CardTitle, {
                    children: [" ", d.id, "/", dataLength]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 88,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.CardSubtitle, {
                    children: d.Schlagwort
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 92,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.CardText, {
                    children: d.question_text
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 93,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.FieldArray, {
                    name: "result",
                    render: function render(arrayHelpers) {
                      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.Row, {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.Col, {
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.FormGroup, {
                              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.InputGroup, {
                                className: "flex flex-col mt-2",
                                children: _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === null || _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === void 0 ? void 0 : _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__.map(function (opt) {
                                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("label", {
                                    className: "p-2 bg-gray-600 text-white rounded-md text-center hover:bg-yellow-300 hover:text-black mb-1",
                                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                                      type: "radio" // name="answer"
                                      ,
                                      value: opt.option_Value,
                                      className: "hidden",
                                      onChange: function onChange() {
                                        setValue({
                                          question_id: d.id,
                                          answer: opt.option_Value
                                        });

                                        if (result.length > 0) {
                                          for (var i = 0; i < result.length; i++) {
                                            if (result[i].question_id === d.id) {
                                              console.log("splice");
                                              result.splice(i, 1, {
                                                question_id: d.id,
                                                answer: opt.option_Value
                                              });
                                              return;
                                            } else if (result[i].question_id !== d.id) {
                                              console.log("else_if");
                                              result.push({
                                                question_id: d.id,
                                                answer: opt.option_Value // value,

                                              });
                                              return;
                                            }
                                          }
                                        } else {
                                          console.log("else");
                                          result.push({
                                            question_id: d.id,
                                            answer: opt.option_Value
                                          });
                                        }
                                      }
                                    }, void 0, false, {
                                      fileName: _jsxFileName,
                                      lineNumber: 109,
                                      columnNumber: 47
                                    }, _this), opt.option_text]
                                  }, opt.id, true, {
                                    fileName: _jsxFileName,
                                    lineNumber: 105,
                                    columnNumber: 45
                                  }, _this);
                                })
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 102,
                                columnNumber: 39
                              }, _this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 101,
                              columnNumber: 37
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 100,
                            columnNumber: 35
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 99,
                          columnNumber: 33
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 98,
                        columnNumber: 31
                      }, _this);
                    }
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 94,
                    columnNumber: 25
                  }, _this)]
                }, d.id, true, {
                  fileName: _jsxFileName,
                  lineNumber: 87,
                  columnNumber: 23
                }, _this);
              }), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.Button, {
                  block: true,
                  className: "border-2 p-2 border-black mt-7",
                  type: "submit" // disabled={formProps.isSubmitting}
                  ,
                  children: "Eegebnis zeigen"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 186,
                  columnNumber: 21
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 185,
                columnNumber: 19
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 84,
              columnNumber: 17
            }, _this);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 75,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 68,
    columnNumber: 5
  }, this);
}

_s(Home, "62pMvFIaPpKakEs86W5psllgCAs=");

_c = Home;

var mapStateToProps = function mapStateToProps(state) {
  return {
    result: state.result.result
  };
};

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    resultSetData: function resultSetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultSetData(data));
    },
    onDeleteResult: function onDeleteResult(data, id) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.deleteResult(data, id));
    },
    onPostResultData: function onPostResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.postResultData(data, user, toggle));
    },
    onUpdateResultData: function onUpdateResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.updateResultData(data, user, toggle));
    },
    resultEditGetData: function resultEditGetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultEditGetData(data));
    }
  };
};

/* harmony default export */ __webpack_exports__["default"] = ((0,react_redux__WEBPACK_IMPORTED_MODULE_6__.connect)(mapStateToProps, mapDispatchToProps)(Home));

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguYjZjMGE4YzAxMmI1OTdiNWQwNzAuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLElBQUl1QixNQUFNLEdBQUcsSUFBSUMsS0FBSixFQUFiOztBQUNBLFNBQVNDLElBQVQsQ0FBY0MsS0FBZCxFQUFxQjtBQUFBOztBQUFBOztBQUNuQixrQkFBMEJwQiwrQ0FBUSxDQUFDLEVBQUQsQ0FBbEM7QUFBQSxNQUFPcUIsS0FBUDtBQUFBLE1BQWNDLFFBQWQ7O0FBRUEsbUJBQThCdEIsK0NBQVEsQ0FBQyxFQUFELENBQXRDO0FBQUEsTUFBT3VCLE9BQVA7QUFBQSxNQUFnQkMsVUFBaEI7O0FBRUFDLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGNBQVosRUFBNEJOLEtBQUssQ0FBQ0gsTUFBbEM7QUFFQVEsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFxQkwsS0FBckI7O0FBQ0EsTUFBTU0sWUFBWSxHQUFHLFNBQWZBLFlBQWUsQ0FBQ0MsTUFBRCxFQUFTQyxhQUFULEVBQTJCO0FBQzlDLFFBQUlULEtBQUssQ0FBQ0gsTUFBVixFQUFrQjtBQUFBOztBQUNoQix1QkFBQUcsS0FBSyxDQUFDSCxNQUFOLGdFQUFjYSxHQUFkLENBQWtCLFVBQUNDLENBQUQsRUFBTztBQUN2QmxCLFFBQUFBLElBQUksU0FBSixJQUFBQSxJQUFJLFdBQUosWUFBQUEsSUFBSSxDQUFFaUIsR0FBTixDQUFVLFVBQUNFLENBQUQsRUFBTztBQUNmLGNBQUlELENBQUMsQ0FBQ0UsV0FBRixJQUFpQkQsQ0FBQyxDQUFDQyxXQUF2QixFQUFvQztBQUNsQyxnQkFBSUQsQ0FBQyxDQUFDRSxHQUFGLEdBQVFDLEdBQVIsSUFBZUosQ0FBQyxDQUFDSyxNQUFyQixFQUE2QjtBQUMzQlgsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWjtBQUNEO0FBQ0Y7QUFDRixTQU5EO0FBT0QsT0FSRDtBQVNEOztBQUNELFFBQUliLElBQUksR0FBRztBQUNUSSxNQUFBQSxNQUFNLEVBQUVBO0FBREMsS0FBWDtBQUdBUSxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWWIsSUFBWjtBQUVBbkIsSUFBQUEsaURBQUEsQ0FDUSxPQURSLEVBQ2lCbUIsSUFEakIsRUFFR3lCLElBRkgsQ0FFUSxVQUFDQyxHQUFELEVBQVM7QUFDYmQsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlhLEdBQVo7QUFDQWQsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVkscUNBQVo7QUFDQVQsTUFBQUEsTUFBTSxHQUFHLEVBQVQ7QUFDQXVCLE1BQUFBLE9BQU8sQ0FBQ0MsSUFBUixDQUFhLFdBQWI7QUFDRCxLQVBILFdBUVMsVUFBQ0MsR0FBRCxFQUFTO0FBQ2RqQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWWdCLEdBQUcsQ0FBQ0MsUUFBSixDQUFhOUIsSUFBekIsRUFEYyxDQUVkO0FBQ0E7QUFDRCxLQVpIO0FBYUQsR0E5QkQ7O0FBK0JBWSxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQXFCVCxNQUFyQjtBQUNBLE1BQU0yQixVQUFVLEdBQUcvQiw4REFBbkI7QUFFQSxzQkFDRTtBQUFLLGFBQVMsRUFBQyxFQUFmO0FBQUEsNEJBQ0UsOERBQUMsa0RBQUQ7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBRUU7QUFBTSxXQUFHLEVBQUMsTUFBVjtBQUFpQixZQUFJLEVBQUM7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBS0UsOERBQUMsNENBQUQ7QUFBTSxlQUFTLEVBQUMsbUNBQWhCO0FBQUEsNkJBQ0UsOERBQUMsZ0RBQUQ7QUFBQSwrQkFDRSw4REFBQywwQ0FBRDtBQUNFLHVCQUFhLEVBQUU7QUFDYkksWUFBQUEsTUFBTSxFQUFFLEVBREs7QUFFYm1CLFlBQUFBLE1BQU0sRUFBRTtBQUZLLFdBRGpCO0FBS0Usa0JBQVEsRUFBRVQsWUFMWjtBQUFBLG9CQU9HLGtCQUFDbUIsU0FBRCxFQUFlO0FBQ2QsZ0NBQ0UsOERBQUMsNENBQUQ7QUFBQSx5QkFDR2pDLHVEQURILGFBQ0dBLHVEQURILHVCQUNHQSwyREFBQSxDQUFVLFVBQUNtQixDQUFELEVBQUllLEVBQUosRUFBVztBQUNwQixvQ0FDRTtBQUFnQiwyQkFBUyxFQUFDLE1BQTFCO0FBQUEsMENBQ0UsOERBQUMsaURBQUQ7QUFBQSwrQkFDRyxHQURILEVBRUdmLENBQUMsQ0FBQ2UsRUFGTCxPQUVVSCxVQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFERixlQUtFLDhEQUFDLG9EQUFEO0FBQUEsOEJBQWVaLENBQUMsQ0FBQ2dCO0FBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTEYsZUFNRSw4REFBQyxnREFBRDtBQUFBLDhCQUFXaEIsQ0FBQyxDQUFDaUI7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU5GLGVBT0UsOERBQUMsOENBQUQ7QUFDRSx3QkFBSSxFQUFDLFFBRFA7QUFFRSwwQkFBTSxFQUFFLGdCQUFDQyxZQUFELEVBQWtCO0FBQ3hCLDBDQUNFO0FBQUEsK0NBQ0UsOERBQUMsMkNBQUQ7QUFBQSxpREFDRSw4REFBQywyQ0FBRDtBQUFBLG1EQUNFLDhEQUFDLGlEQUFEO0FBQUEscURBQ0UsOERBQUMsa0RBQUQ7QUFBWSx5Q0FBUyxFQUFDLG9CQUF0QjtBQUFBLDBDQUNHcEMsMERBREgsYUFDR0EsMERBREgsdUJBQ0dBLDhEQUFBLENBQWEsVUFBQ3FDLEdBQUQsRUFBUztBQUNyQixzREFDRTtBQUVFLDZDQUFTLEVBQUMsNkZBRlo7QUFBQSw0REFJRSw4REFBQyx5Q0FBRDtBQUNFLDBDQUFJLEVBQUMsT0FEUCxDQUVFO0FBRkY7QUFHRSwyQ0FBSyxFQUFFQSxHQUFHLENBQUNDLFlBSGI7QUFJRSwrQ0FBUyxFQUFDLFFBSlo7QUFLRSw4Q0FBUSxFQUFFLG9CQUFNO0FBQ2Q5Qix3Q0FBQUEsUUFBUSxDQUFDO0FBQ1BXLDBDQUFBQSxXQUFXLEVBQUVELENBQUMsQ0FBQ2UsRUFEUjtBQUVQWCwwQ0FBQUEsTUFBTSxFQUFFZSxHQUFHLENBQUNDO0FBRkwseUNBQUQsQ0FBUjs7QUFLQSw0Q0FBSW5DLE1BQU0sQ0FBQzRCLE1BQVAsR0FBZ0IsQ0FBcEIsRUFBdUI7QUFDckIsK0NBQ0UsSUFBSVEsQ0FBQyxHQUFHLENBRFYsRUFFRUEsQ0FBQyxHQUFHcEMsTUFBTSxDQUFDNEIsTUFGYixFQUdFUSxDQUFDLEVBSEgsRUFJRTtBQUNBLGdEQUNFcEMsTUFBTSxDQUFDb0MsQ0FBRCxDQUFOLENBQ0dwQixXQURILEtBQ21CRCxDQUFDLENBQUNlLEVBRnZCLEVBR0U7QUFDQXRCLDhDQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0FBQ0FULDhDQUFBQSxNQUFNLENBQUNxQyxNQUFQLENBQWNELENBQWQsRUFBaUIsQ0FBakIsRUFBb0I7QUFDbEJwQixnREFBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNlLEVBREc7QUFFbEJYLGdEQUFBQSxNQUFNLEVBQ0plLEdBQUcsQ0FBQ0M7QUFIWSwrQ0FBcEI7QUFLQTtBQUNELDZDQVhELE1BV08sSUFDTG5DLE1BQU0sQ0FBQ29DLENBQUQsQ0FBTixDQUNHcEIsV0FESCxLQUNtQkQsQ0FBQyxDQUFDZSxFQUZoQixFQUdMO0FBQ0F0Qiw4Q0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWjtBQUVBVCw4Q0FBQUEsTUFBTSxDQUFDd0IsSUFBUCxDQUFZO0FBQ1ZSLGdEQUFBQSxXQUFXLEVBQUVELENBQUMsQ0FBQ2UsRUFETDtBQUVWWCxnREFBQUEsTUFBTSxFQUNKZSxHQUFHLENBQUNDLFlBSEksQ0FJVjs7QUFKVSwrQ0FBWjtBQU1BO0FBQ0Q7QUFDRjtBQUNGLHlDQWhDRCxNQWdDTztBQUNMM0IsMENBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVo7QUFDQVQsMENBQUFBLE1BQU0sQ0FBQ3dCLElBQVAsQ0FBWTtBQUNWUiw0Q0FBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNlLEVBREw7QUFFVlgsNENBQUFBLE1BQU0sRUFBRWUsR0FBRyxDQUFDQztBQUZGLDJDQUFaO0FBSUQ7QUFDRjtBQWxESDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZDQUpGLEVBd0RHRCxHQUFHLENBQUNJLFdBeERQO0FBQUEscUNBQ09KLEdBQUcsQ0FBQ0osRUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJDQURGO0FBNERELGlDQTdEQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURGO0FBbUZEO0FBdEZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBUEY7QUFBQSxtQkFBVWYsQ0FBQyxDQUFDZSxFQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREY7QUFrR0QsZUFuR0EsQ0FESCxlQXFHRTtBQUFLLHlCQUFTLEVBQUMscUJBQWY7QUFBQSx1Q0FDRSw4REFBQyw4Q0FBRDtBQUNFLHVCQUFLLE1BRFA7QUFFRSwyQkFBUyxFQUFDLGdDQUZaO0FBR0Usc0JBQUksRUFBQyxRQUhQLENBSUU7QUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBckdGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERjtBQWtIRDtBQTFISDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQXdJRDs7R0FsTFE1Qjs7S0FBQUE7O0FBb0xULElBQU1xQyxlQUFlLEdBQUcsU0FBbEJBLGVBQWtCLENBQUNDLEtBQUQsRUFBVztBQUNqQyxTQUFPO0FBQ0x4QyxJQUFBQSxNQUFNLEVBQUV3QyxLQUFLLENBQUN4QyxNQUFOLENBQWFBO0FBRGhCLEdBQVA7QUFHRCxDQUpEOztBQU1BLElBQU15QyxrQkFBa0IsR0FBRyxTQUFyQkEsa0JBQXFCLENBQUNDLFFBQUQsRUFBYztBQUN2QyxTQUFPO0FBQ0xDLElBQUFBLGFBQWEsRUFBRSx1QkFBQy9DLElBQUQ7QUFBQSxhQUFVOEMsUUFBUSxDQUFDM0MseURBQUEsQ0FBc0JILElBQXRCLENBQUQsQ0FBbEI7QUFBQSxLQURWO0FBRUxnRCxJQUFBQSxjQUFjLEVBQUUsd0JBQUNoRCxJQUFELEVBQU9rQyxFQUFQO0FBQUEsYUFBY1ksUUFBUSxDQUFDM0Msd0RBQUEsQ0FBcUJILElBQXJCLEVBQTJCa0MsRUFBM0IsQ0FBRCxDQUF0QjtBQUFBLEtBRlg7QUFHTGdCLElBQUFBLGdCQUFnQixFQUFFLDBCQUFDbEQsSUFBRCxFQUFPbUQsSUFBUCxFQUFhQyxNQUFiO0FBQUEsYUFDaEJOLFFBQVEsQ0FBQzNDLDBEQUFBLENBQXVCSCxJQUF2QixFQUE2Qm1ELElBQTdCLEVBQW1DQyxNQUFuQyxDQUFELENBRFE7QUFBQSxLQUhiO0FBS0xFLElBQUFBLGtCQUFrQixFQUFFLDRCQUFDdEQsSUFBRCxFQUFPbUQsSUFBUCxFQUFhQyxNQUFiO0FBQUEsYUFDbEJOLFFBQVEsQ0FBQzNDLDREQUFBLENBQXlCSCxJQUF6QixFQUErQm1ELElBQS9CLEVBQXFDQyxNQUFyQyxDQUFELENBRFU7QUFBQSxLQUxmO0FBT0xJLElBQUFBLGlCQUFpQixFQUFFLDJCQUFDeEQsSUFBRDtBQUFBLGFBQVU4QyxRQUFRLENBQUMzQyw2REFBQSxDQUEwQkgsSUFBMUIsQ0FBRCxDQUFsQjtBQUFBO0FBUGQsR0FBUDtBQVNELENBVkQ7O0FBV0EsK0RBQWVFLG9EQUFPLENBQUN5QyxlQUFELEVBQWtCRSxrQkFBbEIsQ0FBUCxDQUE2Q3ZDLElBQTdDLENBQWYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xuaW1wb3J0IHsgRmllbGQsIEZpZWxkQXJyYXksIEZvcm1payB9IGZyb20gXCJmb3JtaWtcIjtcbmltcG9ydCBIZWFkIGZyb20gXCJuZXh0L2hlYWRcIjtcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7XG4gIEJ1dHRvbixcbiAgQ2FyZCxcbiAgQ2FyZEJvZHksXG4gIENhcmRIZWFkZXIsXG4gIENhcmRTdWJ0aXRsZSxcbiAgQ2FyZFRleHQsXG4gIENhcmRUaXRsZSxcbiAgQ29sLFxuICBGb3JtLFxuICBGb3JtR3JvdXAsXG4gIElucHV0R3JvdXAsXG4gIFJvdyxcbn0gZnJvbSBcInJlYWN0c3RyYXBcIjtcbmltcG9ydCBkYXRhIGZyb20gXCIuLi9jb21wb25lbnRzL0RhdGEvRGF0YS5qc29uXCI7XG5pbXBvcnQgb3B0aW9ucyBmcm9tIFwiLi4vY29tcG9uZW50cy9EYXRhL29wdGlvbnMuanNvblwiO1xuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xuaW1wb3J0ICogYXMgYWN0aW9ucyBmcm9tIFwiLi4vcmVkdXgvYWN0aW9uc1wiO1xuXG52YXIgcmVzdWx0ID0gbmV3IEFycmF5KCk7XG5mdW5jdGlvbiBIb21lKHByb3BzKSB7XG4gIGNvbnN0IFt2YWx1ZSwgc2V0VmFsdWVdID0gdXNlU3RhdGUoe30pO1xuXG4gIGNvbnN0IFtjb21wYW55LCBzZXRDb21wYW55XSA9IHVzZVN0YXRlKHt9KTtcblxuICBjb25zb2xlLmxvZyhcInByb3BzLnJlc3VsdFwiLCBwcm9wcy5yZXN1bHQpO1xuXG4gIGNvbnNvbGUubG9nKFwidmFsdWVcIiwgdmFsdWUpO1xuICBjb25zdCBoYW5kbGVTdWJtaXQgPSAodmFsdWVzLCBzZXRTdWJtaXR0aW5nKSA9PiB7XG4gICAgaWYgKHByb3BzLnJlc3VsdCkge1xuICAgICAgcHJvcHMucmVzdWx0Py5tYXAoKHIpID0+IHtcbiAgICAgICAgZGF0YT8ubWFwKChkKSA9PiB7XG4gICAgICAgICAgaWYgKHIucXVlc3Rpb25faWQgPT0gZC5xdWVzdGlvbl9pZCkge1xuICAgICAgICAgICAgaWYgKGQuQ0RVIC8gQ1NVID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWFrYXNoXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgbGV0IGRhdGEgPSB7XG4gICAgICByZXN1bHQ6IHJlc3VsdCxcbiAgICB9O1xuICAgIGNvbnNvbGUubG9nKGRhdGEpO1xuXG4gICAgYXhpb3NcbiAgICAgIC5wb3N0KFwiL3Rlc3RcIiwgZGF0YSlcbiAgICAgIC50aGVuKChyZXMpID0+IHtcbiAgICAgICAgY29uc29sZS5sb2cocmVzKTtcbiAgICAgICAgY29uc29sZS5sb2coXCJpbnRpYWwgdmFsdWUgaXMgc3VibWl0ZWQgdG8gcmVzdWx0c1wiKTtcbiAgICAgICAgcmVzdWx0ID0gW107XG4gICAgICAgIGhpc3RvcnkucHVzaChcIi90aGFua3lvdVwiKTtcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyhlcnIucmVzcG9uc2UuZGF0YSk7XG4gICAgICAgIC8vIGhpc3RvcnkucHVzaChcIi9leGFtLWFwcGVhcmVkXCIpO1xuICAgICAgICAvLyByZXN1bHQgPSBbXTtcbiAgICAgIH0pO1xuICB9O1xuICBjb25zb2xlLmxvZyhcImFycmF5XCIsIHJlc3VsdCk7XG4gIGNvbnN0IGRhdGFMZW5ndGggPSBkYXRhLmxlbmd0aDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiXCI+XG4gICAgICA8SGVhZD5cbiAgICAgICAgPHRpdGxlPkNyZWF0ZSBOZXh0IEFwcDwvdGl0bGU+XG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cbiAgICAgIDwvSGVhZD5cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNSBib3JkZXItMiBzaGFkb3ctbWQgcm91bmRlZC1tZFwiPlxuICAgICAgICA8Q2FyZEJvZHk+XG4gICAgICAgICAgPEZvcm1pa1xuICAgICAgICAgICAgaW5pdGlhbFZhbHVlcz17e1xuICAgICAgICAgICAgICByZXN1bHQ6IFtdLFxuICAgICAgICAgICAgICBhbnN3ZXI6IFwiXCIsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7KGZvcm1Qcm9wcykgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxGb3JtPlxuICAgICAgICAgICAgICAgICAge2RhdGE/Lm1hcCgoZCwgaWQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17ZC5pZH0gY2xhc3NOYW1lPVwibXQtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcmRUaXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge1wiIFwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZC5pZH0ve2RhdGFMZW5ndGh9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NhcmRUaXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkU3VidGl0bGU+e2QuU2NobGFnd29ydH08L0NhcmRTdWJ0aXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkVGV4dD57ZC5xdWVzdGlvbl90ZXh0fTwvQ2FyZFRleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRBcnJheVxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVzdWx0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVuZGVyPXsoYXJyYXlIZWxwZXJzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSb3c+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dEdyb3VwIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcHRpb25zPy5tYXAoKG9wdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtvcHQuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGJnLWdyYXktNjAwIHRleHQtd2hpdGUgcm91bmRlZC1tZCB0ZXh0LWNlbnRlciBob3ZlcjpiZy15ZWxsb3ctMzAwIGhvdmVyOnRleHQtYmxhY2sgbWItMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBuYW1lPVwiYW5zd2VyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtvcHQub3B0aW9uX1ZhbHVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFZhbHVlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6IG9wdC5vcHRpb25fVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgaSA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpIDwgcmVzdWx0Lmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGkrK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucXVlc3Rpb25faWQgPT09IGQuaWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInNwbGljZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnNwbGljZShpLCAxLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25faWQ6IGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdFtpXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5xdWVzdGlvbl9pZCAhPT0gZC5pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZWxzZV9pZlwiKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25faWQ6IGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJlbHNlXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uX2lkOiBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOiBvcHQub3B0aW9uX1ZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29wdC5vcHRpb25fdGV4dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjp7XCIgXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVzdWx0Py5tYXAoKHIpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHIucXVlc3Rpb25faWQgPT0gZC5pZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByLmFuc3dlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+ICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0lucHV0R3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBibG9ja1xuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlci0yIHAtMiBib3JkZXItYmxhY2sgbXQtN1wiXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgICAgLy8gZGlzYWJsZWQ9e2Zvcm1Qcm9wcy5pc1N1Ym1pdHRpbmd9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICBFZWdlYm5pcyB6ZWlnZW5cbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L0Zvcm0+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgIDwvRm9ybWlrPlxuICAgICAgICA8L0NhcmRCb2R5PlxuICAgICAgPC9DYXJkPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5jb25zdCBtYXBTdGF0ZVRvUHJvcHMgPSAoc3RhdGUpID0+IHtcbiAgcmV0dXJuIHtcbiAgICByZXN1bHQ6IHN0YXRlLnJlc3VsdC5yZXN1bHQsXG4gIH07XG59O1xuXG5jb25zdCBtYXBEaXNwYXRjaFRvUHJvcHMgPSAoZGlzcGF0Y2gpID0+IHtcbiAgcmV0dXJuIHtcbiAgICByZXN1bHRTZXREYXRhOiAoZGF0YSkgPT4gZGlzcGF0Y2goYWN0aW9ucy5yZXN1bHRTZXREYXRhKGRhdGEpKSxcbiAgICBvbkRlbGV0ZVJlc3VsdDogKGRhdGEsIGlkKSA9PiBkaXNwYXRjaChhY3Rpb25zLmRlbGV0ZVJlc3VsdChkYXRhLCBpZCkpLFxuICAgIG9uUG9zdFJlc3VsdERhdGE6IChkYXRhLCB1c2VyLCB0b2dnbGUpID0+XG4gICAgICBkaXNwYXRjaChhY3Rpb25zLnBvc3RSZXN1bHREYXRhKGRhdGEsIHVzZXIsIHRvZ2dsZSkpLFxuICAgIG9uVXBkYXRlUmVzdWx0RGF0YTogKGRhdGEsIHVzZXIsIHRvZ2dsZSkgPT5cbiAgICAgIGRpc3BhdGNoKGFjdGlvbnMudXBkYXRlUmVzdWx0RGF0YShkYXRhLCB1c2VyLCB0b2dnbGUpKSxcbiAgICByZXN1bHRFZGl0R2V0RGF0YTogKGRhdGEpID0+IGRpc3BhdGNoKGFjdGlvbnMucmVzdWx0RWRpdEdldERhdGEoZGF0YSkpLFxuICB9O1xufTtcbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QobWFwU3RhdGVUb1Byb3BzLCBtYXBEaXNwYXRjaFRvUHJvcHMpKEhvbWUpO1xuIl0sIm5hbWVzIjpbImF4aW9zIiwiRmllbGQiLCJGaWVsZEFycmF5IiwiRm9ybWlrIiwiSGVhZCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiQnV0dG9uIiwiQ2FyZCIsIkNhcmRCb2R5IiwiQ2FyZEhlYWRlciIsIkNhcmRTdWJ0aXRsZSIsIkNhcmRUZXh0IiwiQ2FyZFRpdGxlIiwiQ29sIiwiRm9ybSIsIkZvcm1Hcm91cCIsIklucHV0R3JvdXAiLCJSb3ciLCJkYXRhIiwib3B0aW9ucyIsImNvbm5lY3QiLCJhY3Rpb25zIiwicmVzdWx0IiwiQXJyYXkiLCJIb21lIiwicHJvcHMiLCJ2YWx1ZSIsInNldFZhbHVlIiwiY29tcGFueSIsInNldENvbXBhbnkiLCJjb25zb2xlIiwibG9nIiwiaGFuZGxlU3VibWl0IiwidmFsdWVzIiwic2V0U3VibWl0dGluZyIsIm1hcCIsInIiLCJkIiwicXVlc3Rpb25faWQiLCJDRFUiLCJDU1UiLCJhbnN3ZXIiLCJwb3N0IiwidGhlbiIsInJlcyIsImhpc3RvcnkiLCJwdXNoIiwiZXJyIiwicmVzcG9uc2UiLCJkYXRhTGVuZ3RoIiwibGVuZ3RoIiwiZm9ybVByb3BzIiwiaWQiLCJTY2hsYWd3b3J0IiwicXVlc3Rpb25fdGV4dCIsImFycmF5SGVscGVycyIsIm9wdCIsIm9wdGlvbl9WYWx1ZSIsImkiLCJzcGxpY2UiLCJvcHRpb25fdGV4dCIsIm1hcFN0YXRlVG9Qcm9wcyIsInN0YXRlIiwibWFwRGlzcGF0Y2hUb1Byb3BzIiwiZGlzcGF0Y2giLCJyZXN1bHRTZXREYXRhIiwib25EZWxldGVSZXN1bHQiLCJkZWxldGVSZXN1bHQiLCJvblBvc3RSZXN1bHREYXRhIiwidXNlciIsInRvZ2dsZSIsInBvc3RSZXN1bHREYXRhIiwib25VcGRhdGVSZXN1bHREYXRhIiwidXBkYXRlUmVzdWx0RGF0YSIsInJlc3VsdEVkaXRHZXREYXRhIl0sInNvdXJjZVJvb3QiOiIifQ==