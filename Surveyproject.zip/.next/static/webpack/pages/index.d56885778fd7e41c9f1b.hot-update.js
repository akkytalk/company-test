"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
/* harmony import */ var _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Data/Data.json */ "./components/Data/Data.json");
/* harmony import */ var _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Data/options.json */ "./components/Data/options.json");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _redux_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../redux/actions */ "./redux/actions/index.js");
/* harmony import */ var react_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-router */ "./node_modules/react-router/esm/react-router.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "E:\\git vinraj\\company-test\\pages\\index.js",
    _s = $RefreshSig$();












var result = new Array();
var MainResult = new Array();

function Home(props) {
  _s();

  var _this = this;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      value = _useState[0],
      setValue = _useState[1];

  var history = (0,react_router__WEBPACK_IMPORTED_MODULE_9__.useHistory)();

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      company = _useState2[0],
      setCompany = _useState2[1];

  console.log("props.result", props.result);
  console.log("value", value);

  var handleSubmit = function handleSubmit(values, setSubmitting) {
    if (props.result) {
      var _props$result;

      (_props$result = props.result) === null || _props$result === void 0 ? void 0 : _props$result.map(function (r) {
        data === null || data === void 0 ? void 0 : data.map(function (d) {
          if (r.question_id == d.question_id) {
            if (d.CDU / CSU == r.answer) {
              console.log("aakash");
            }
          }
        });
      });
    }

    var data = {
      result: result
    };
    console.log(data);
    axios__WEBPACK_IMPORTED_MODULE_0___default().post("/test", data).then(function (res) {
      console.log(res);
      console.log("intial value is submited to results");
      result = [];
      history.push("/thankyou");
    })["catch"](function (err) {
      console.log(err.response.data); // history.push("/exam-appeared");
      // result = [];
    });
  };

  console.log("array", result);
  var dataLength = _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.length;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
    className: "",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("title", {
        children: "Create Next App"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Card, {
      className: "p-5 border-2 shadow-md rounded-md",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardBody, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
          initialValues: {
            result: [],
            answer: ""
          },
          onSubmit: function onSubmit(values, setSubmitting) {
            var _props$result2;

            if (((_props$result2 = props.result) === null || _props$result2 === void 0 ? void 0 : _props$result2.length) > 0) {
              var _props$result3, _props$result4, _props$result5;

              console.log("result length", (_props$result3 = props.result) === null || _props$result3 === void 0 ? void 0 : _props$result3.length);
              var resultLength = (_props$result4 = props.result) === null || _props$result4 === void 0 ? void 0 : _props$result4.length;

              for (var i = 0; i < resultLength; i++) {
                console.log("result map");
              }

              (_props$result5 = props.result) === null || _props$result5 === void 0 ? void 0 : _props$result5.map(function (r) {
                console.log("result map");
                return data === null || data === void 0 ? void 0 : data.map(function (d) {
                  if (r.question_id == d.id) {
                    console.log("r.question_id", r.question_id, "d.id", d.id);

                    if (d.SPD == r.answer) {
                      console.log("aakash");
                    }
                  }
                });
              });
            }

            var data = {
              result: props.result
            };
            console.log("submit click"); // axios
            //   .post("https://uditsolutions.in/yarn/public/api/scores", data)
            //   .then((res) => {
            //     console.log(res);
            //     console.log("intial value is submited to results");
            //     result = [];
            //     history.push("/thankyou");
            //   })
            //   .catch((err) => {
            //     console.log(err.response.data);
            //     // history.push("/exam-appeared");
            //   });
          },
          children: function children(_ref) {
            var handleSubmit = _ref.handleSubmit;
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Form, {
              onSubmit: handleSubmit,
              children: [_components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === null || _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === void 0 ? void 0 : _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.map(function (d, id) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                  className: "mt-3",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardTitle, {
                    children: [" ", d.id, "/", dataLength]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 128,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardSubtitle, {
                    children: d.Schlagwort
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 132,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardText, {
                    children: d.question_text
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 133,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.FieldArray, {
                    name: "result",
                    render: function render(arrayHelpers) {
                      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Row, {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Col, {
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.FormGroup, {
                              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.InputGroup, {
                                className: "flex flex-col mt-2",
                                children: _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === null || _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === void 0 ? void 0 : _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__.map(function (opt) {
                                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("label", {
                                    className: "p-2 bg-gray-600 text-white rounded-md text-center hover:bg-yellow-300 hover:text-black mb-1",
                                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                                      type: "radio" // name="answer"
                                      ,
                                      value: opt.option_Value,
                                      className: "hidden",
                                      onChange: function onChange() {
                                        setValue({
                                          question_id: d.id,
                                          answer: opt.option_Value
                                        });

                                        if (result.length > 0) {
                                          for (var i = 0; i < result.length; i++) {
                                            var _result$i;

                                            if (((_result$i = result[i]) === null || _result$i === void 0 ? void 0 : _result$i.question_id) == d.id) {
                                              console.log("splice");
                                              result.splice(i, 1, {
                                                question_id: d.id,
                                                answer: opt.option_Value
                                              });
                                              return;
                                            } else if (result[i].question_id !== d.id) {
                                              console.log("else_if question of data", d.id, "result q-id", result[i].question_id);
                                              result.push({
                                                question_id: d.id,
                                                answer: opt.option_Value // value,

                                              });
                                              return;
                                            }
                                          }

                                          props.resultSetData(result);
                                        } else {
                                          console.log("else");
                                          result.push({
                                            question_id: d.id,
                                            answer: opt.option_Value
                                          });
                                          props.resultSetData(result);
                                        }
                                      }
                                    }, void 0, false, {
                                      fileName: _jsxFileName,
                                      lineNumber: 149,
                                      columnNumber: 47
                                    }, _this), opt.option_text]
                                  }, opt.id, true, {
                                    fileName: _jsxFileName,
                                    lineNumber: 145,
                                    columnNumber: 45
                                  }, _this);
                                })
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 142,
                                columnNumber: 39
                              }, _this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 141,
                              columnNumber: 37
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 140,
                            columnNumber: 35
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 139,
                          columnNumber: 33
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 138,
                        columnNumber: 31
                      }, _this);
                    }
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 134,
                    columnNumber: 25
                  }, _this)]
                }, d.id, true, {
                  fileName: _jsxFileName,
                  lineNumber: 127,
                  columnNumber: 23
                }, _this);
              }), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Button, {
                  block: true,
                  className: "border-2 p-2 border-black mt-7",
                  type: "submit" // onClick={handleSubmit}
                  // disabled={formProps.isSubmitting}
                  ,
                  children: "Eegebnis zeigen"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 233,
                  columnNumber: 21
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 232,
                columnNumber: 19
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 124,
              columnNumber: 17
            }, _this);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 79,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 78,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 77,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 72,
    columnNumber: 5
  }, this);
}

_s(Home, "+Ok9uqErGU59sIRoYnjvw5OYqYQ=", false, function () {
  return [react_router__WEBPACK_IMPORTED_MODULE_9__.useHistory];
});

_c = Home;

var mapStateToProps = function mapStateToProps(state) {
  return {
    result: state.result.result
  };
};

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    resultSetData: function resultSetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultSetData(data));
    },
    onDeleteResult: function onDeleteResult(data, id) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.deleteResult(data, id));
    },
    onPostResultData: function onPostResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.postResultData(data, user, toggle));
    },
    onUpdateResultData: function onUpdateResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.updateResultData(data, user, toggle));
    },
    resultEditGetData: function resultEditGetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultEditGetData(data));
    }
  };
};

/* harmony default export */ __webpack_exports__["default"] = ((0,react_redux__WEBPACK_IMPORTED_MODULE_6__.connect)(mapStateToProps, mapDispatchToProps)(Home));

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguZDU2ODg1Nzc4ZmQ3ZTQxYzlmMWIuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFjQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLElBQUl3QixNQUFNLEdBQUcsSUFBSUMsS0FBSixFQUFiO0FBQ0EsSUFBSUMsVUFBVSxHQUFHLElBQUlELEtBQUosRUFBakI7O0FBQ0EsU0FBU0UsSUFBVCxDQUFjQyxLQUFkLEVBQXFCO0FBQUE7O0FBQUE7O0FBQ25CLGtCQUEwQnRCLCtDQUFRLENBQUMsRUFBRCxDQUFsQztBQUFBLE1BQU91QixLQUFQO0FBQUEsTUFBY0MsUUFBZDs7QUFDQSxNQUFNQyxPQUFPLEdBQUdSLHdEQUFVLEVBQTFCOztBQUVBLG1CQUE4QmpCLCtDQUFRLENBQUMsRUFBRCxDQUF0QztBQUFBLE1BQU8wQixPQUFQO0FBQUEsTUFBZ0JDLFVBQWhCOztBQUVBQyxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBQTRCUCxLQUFLLENBQUNKLE1BQWxDO0FBRUFVLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVosRUFBcUJOLEtBQXJCOztBQUNBLE1BQU1PLFlBQVksR0FBRyxTQUFmQSxZQUFlLENBQUNDLE1BQUQsRUFBU0MsYUFBVCxFQUEyQjtBQUM5QyxRQUFJVixLQUFLLENBQUNKLE1BQVYsRUFBa0I7QUFBQTs7QUFDaEIsdUJBQUFJLEtBQUssQ0FBQ0osTUFBTixnRUFBY2UsR0FBZCxDQUFrQixVQUFDQyxDQUFELEVBQU87QUFDdkJyQixRQUFBQSxJQUFJLFNBQUosSUFBQUEsSUFBSSxXQUFKLFlBQUFBLElBQUksQ0FBRW9CLEdBQU4sQ0FBVSxVQUFDRSxDQUFELEVBQU87QUFDZixjQUFJRCxDQUFDLENBQUNFLFdBQUYsSUFBaUJELENBQUMsQ0FBQ0MsV0FBdkIsRUFBb0M7QUFDbEMsZ0JBQUlELENBQUMsQ0FBQ0UsR0FBRixHQUFRQyxHQUFSLElBQWVKLENBQUMsQ0FBQ0ssTUFBckIsRUFBNkI7QUFDM0JYLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVo7QUFDRDtBQUNGO0FBQ0YsU0FORDtBQU9ELE9BUkQ7QUFTRDs7QUFDRCxRQUFJaEIsSUFBSSxHQUFHO0FBQ1RLLE1BQUFBLE1BQU0sRUFBRUE7QUFEQyxLQUFYO0FBR0FVLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZaEIsSUFBWjtBQUVBbkIsSUFBQUEsaURBQUEsQ0FDUSxPQURSLEVBQ2lCbUIsSUFEakIsRUFFRzRCLElBRkgsQ0FFUSxVQUFDQyxHQUFELEVBQVM7QUFDYmQsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlhLEdBQVo7QUFDQWQsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVkscUNBQVo7QUFDQVgsTUFBQUEsTUFBTSxHQUFHLEVBQVQ7QUFDQU8sTUFBQUEsT0FBTyxDQUFDa0IsSUFBUixDQUFhLFdBQWI7QUFDRCxLQVBILFdBUVMsVUFBQ0MsR0FBRCxFQUFTO0FBQ2RoQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWWUsR0FBRyxDQUFDQyxRQUFKLENBQWFoQyxJQUF6QixFQURjLENBRWQ7QUFDQTtBQUNELEtBWkg7QUFhRCxHQTlCRDs7QUFnQ0FlLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVosRUFBcUJYLE1BQXJCO0FBQ0EsTUFBTTRCLFVBQVUsR0FBR2pDLDhEQUFuQjtBQUVBLHNCQUNFO0FBQUssYUFBUyxFQUFDLEVBQWY7QUFBQSw0QkFDRSw4REFBQyxrREFBRDtBQUFBLDhCQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFRTtBQUFNLFdBQUcsRUFBQyxNQUFWO0FBQWlCLFlBQUksRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFLRSw4REFBQyw2Q0FBRDtBQUFNLGVBQVMsRUFBQyxtQ0FBaEI7QUFBQSw2QkFDRSw4REFBQyxpREFBRDtBQUFBLCtCQUNFLDhEQUFDLDBDQUFEO0FBQ0UsdUJBQWEsRUFBRTtBQUNiSyxZQUFBQSxNQUFNLEVBQUUsRUFESztBQUVicUIsWUFBQUEsTUFBTSxFQUFFO0FBRkssV0FEakI7QUFLRSxrQkFBUSxFQUFFLGtCQUFDUixNQUFELEVBQVNDLGFBQVQsRUFBMkI7QUFBQTs7QUFDbkMsZ0JBQUksbUJBQUFWLEtBQUssQ0FBQ0osTUFBTixrRUFBYzZCLE1BQWQsSUFBdUIsQ0FBM0IsRUFBOEI7QUFBQTs7QUFDNUJuQixjQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxlQUFaLG9CQUE2QlAsS0FBSyxDQUFDSixNQUFuQyxtREFBNkIsZUFBYzZCLE1BQTNDO0FBQ0Esa0JBQU1DLFlBQVkscUJBQUcxQixLQUFLLENBQUNKLE1BQVQsbURBQUcsZUFBYzZCLE1BQW5DOztBQUNBLG1CQUFLLElBQUlFLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdELFlBQXBCLEVBQWtDQyxDQUFDLEVBQW5DLEVBQXVDO0FBQ3JDckIsZ0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFlBQVo7QUFDRDs7QUFDRCxnQ0FBQVAsS0FBSyxDQUFDSixNQUFOLGtFQUFjZSxHQUFkLENBQWtCLFVBQUNDLENBQUQsRUFBTztBQUN2Qk4sZ0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFlBQVo7QUFDQSx1QkFBT2hCLElBQVAsYUFBT0EsSUFBUCx1QkFBT0EsSUFBSSxDQUFFb0IsR0FBTixDQUFVLFVBQUNFLENBQUQsRUFBTztBQUN0QixzQkFBSUQsQ0FBQyxDQUFDRSxXQUFGLElBQWlCRCxDQUFDLENBQUNlLEVBQXZCLEVBQTJCO0FBQ3pCdEIsb0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGVBQVosRUFBNkJLLENBQUMsQ0FBQ0UsV0FBL0IsRUFBNEMsTUFBNUMsRUFBb0RELENBQUMsQ0FBQ2UsRUFBdEQ7O0FBQ0Esd0JBQUlmLENBQUMsQ0FBQ2dCLEdBQUYsSUFBU2pCLENBQUMsQ0FBQ0ssTUFBZixFQUF1QjtBQUNyQlgsc0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVo7QUFDRDtBQUNGO0FBQ0YsaUJBUE0sQ0FBUDtBQVFELGVBVkQ7QUFXRDs7QUFDRCxnQkFBSWhCLElBQUksR0FBRztBQUNUSyxjQUFBQSxNQUFNLEVBQUVJLEtBQUssQ0FBQ0o7QUFETCxhQUFYO0FBR0FVLFlBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGNBQVosRUF0Qm1DLENBdUJuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDRCxXQXpDSDtBQUFBLG9CQTJDRyx3QkFBc0I7QUFBQSxnQkFBbkJDLFlBQW1CLFFBQW5CQSxZQUFtQjtBQUNyQixnQ0FDRSw4REFBQyw2Q0FBRDtBQUFNLHNCQUFRLEVBQUVBLFlBQWhCO0FBQUEseUJBQ0dqQix1REFESCxhQUNHQSx1REFESCx1QkFDR0EsMkRBQUEsQ0FBVSxVQUFDc0IsQ0FBRCxFQUFJZSxFQUFKLEVBQVc7QUFDcEIsb0NBQ0U7QUFBZ0IsMkJBQVMsRUFBQyxNQUExQjtBQUFBLDBDQUNFLDhEQUFDLGtEQUFEO0FBQUEsK0JBQ0csR0FESCxFQUVHZixDQUFDLENBQUNlLEVBRkwsT0FFVUosVUFGVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREYsZUFLRSw4REFBQyxxREFBRDtBQUFBLDhCQUFlWCxDQUFDLENBQUNpQjtBQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUxGLGVBTUUsOERBQUMsaURBQUQ7QUFBQSw4QkFBV2pCLENBQUMsQ0FBQ2tCO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFORixlQU9FLDhEQUFDLDhDQUFEO0FBQ0Usd0JBQUksRUFBQyxRQURQO0FBRUUsMEJBQU0sRUFBRSxnQkFBQ0MsWUFBRCxFQUFrQjtBQUN4QiwwQ0FDRTtBQUFBLCtDQUNFLDhEQUFDLDRDQUFEO0FBQUEsaURBQ0UsOERBQUMsNENBQUQ7QUFBQSxtREFDRSw4REFBQyxrREFBRDtBQUFBLHFEQUNFLDhEQUFDLG1EQUFEO0FBQVkseUNBQVMsRUFBQyxvQkFBdEI7QUFBQSwwQ0FDR3hDLDBEQURILGFBQ0dBLDBEQURILHVCQUNHQSw4REFBQSxDQUFhLFVBQUN5QyxHQUFELEVBQVM7QUFDckIsc0RBQ0U7QUFFRSw2Q0FBUyxFQUFDLDZGQUZaO0FBQUEsNERBSUUsOERBQUMseUNBQUQ7QUFDRSwwQ0FBSSxFQUFDLE9BRFAsQ0FFRTtBQUZGO0FBR0UsMkNBQUssRUFBRUEsR0FBRyxDQUFDQyxZQUhiO0FBSUUsK0NBQVMsRUFBQyxRQUpaO0FBS0UsOENBQVEsRUFBRSxvQkFBTTtBQUNkaEMsd0NBQUFBLFFBQVEsQ0FBQztBQUNQWSwwQ0FBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNlLEVBRFI7QUFFUFgsMENBQUFBLE1BQU0sRUFBRWdCLEdBQUcsQ0FBQ0M7QUFGTCx5Q0FBRCxDQUFSOztBQUtBLDRDQUFJdEMsTUFBTSxDQUFDNkIsTUFBUCxHQUFnQixDQUFwQixFQUF1QjtBQUNyQiwrQ0FDRSxJQUFJRSxDQUFDLEdBQUcsQ0FEVixFQUVFQSxDQUFDLEdBQUcvQixNQUFNLENBQUM2QixNQUZiLEVBR0VFLENBQUMsRUFISCxFQUlFO0FBQUE7O0FBQ0EsZ0RBQ0UsY0FBQS9CLE1BQU0sQ0FBQytCLENBQUQsQ0FBTix3REFDSWIsV0FESixLQUNtQkQsQ0FBQyxDQUFDZSxFQUZ2QixFQUdFO0FBQ0F0Qiw4Q0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWjtBQUNBWCw4Q0FBQUEsTUFBTSxDQUFDdUMsTUFBUCxDQUFjUixDQUFkLEVBQWlCLENBQWpCLEVBQW9CO0FBQ2xCYixnREFBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNlLEVBREc7QUFFbEJYLGdEQUFBQSxNQUFNLEVBQ0pnQixHQUFHLENBQUNDO0FBSFksK0NBQXBCO0FBS0E7QUFDRCw2Q0FYRCxNQVdPLElBQ0x0QyxNQUFNLENBQUMrQixDQUFELENBQU4sQ0FDR2IsV0FESCxLQUNtQkQsQ0FBQyxDQUFDZSxFQUZoQixFQUdMO0FBQ0F0Qiw4Q0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQ0UsMEJBREYsRUFFRU0sQ0FBQyxDQUFDZSxFQUZKLEVBR0UsYUFIRixFQUlFaEMsTUFBTSxDQUFDK0IsQ0FBRCxDQUFOLENBQVViLFdBSlo7QUFPQWxCLDhDQUFBQSxNQUFNLENBQUN5QixJQUFQLENBQVk7QUFDVlAsZ0RBQUFBLFdBQVcsRUFBRUQsQ0FBQyxDQUFDZSxFQURMO0FBRVZYLGdEQUFBQSxNQUFNLEVBQ0pnQixHQUFHLENBQUNDLFlBSEksQ0FJVjs7QUFKVSwrQ0FBWjtBQU1BO0FBQ0Q7QUFDRjs7QUFDRGxDLDBDQUFBQSxLQUFLLENBQUNvQyxhQUFOLENBQW9CeEMsTUFBcEI7QUFDRCx5Q0F0Q0QsTUFzQ087QUFDTFUsMENBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVo7QUFDQVgsMENBQUFBLE1BQU0sQ0FBQ3lCLElBQVAsQ0FBWTtBQUNWUCw0Q0FBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNlLEVBREw7QUFFVlgsNENBQUFBLE1BQU0sRUFBRWdCLEdBQUcsQ0FBQ0M7QUFGRiwyQ0FBWjtBQUlBbEMsMENBQUFBLEtBQUssQ0FBQ29DLGFBQU4sQ0FBb0J4QyxNQUFwQjtBQUNEO0FBQ0Y7QUF6REg7QUFBQTtBQUFBO0FBQUE7QUFBQSw2Q0FKRixFQStER3FDLEdBQUcsQ0FBQ0ksV0EvRFA7QUFBQSxxQ0FDT0osR0FBRyxDQUFDTCxFQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkNBREY7QUFtRUQsaUNBcEVBO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBREY7QUEwRkQ7QUE3Rkg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFQRjtBQUFBLG1CQUFVZixDQUFDLENBQUNlLEVBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERjtBQXlHRCxlQTFHQSxDQURILGVBNEdFO0FBQUsseUJBQVMsRUFBQyxxQkFBZjtBQUFBLHVDQUNFLDhEQUFDLCtDQUFEO0FBQ0UsdUJBQUssTUFEUDtBQUVFLDJCQUFTLEVBQUMsZ0NBRlo7QUFHRSxzQkFBSSxFQUFDLFFBSFAsQ0FJRTtBQUNBO0FBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTVHRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREY7QUEwSEQ7QUF0S0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFvTEQ7O0dBaE9RN0I7VUFFU0o7OztLQUZUSTs7QUFrT1QsSUFBTXVDLGVBQWUsR0FBRyxTQUFsQkEsZUFBa0IsQ0FBQ0MsS0FBRCxFQUFXO0FBQ2pDLFNBQU87QUFDTDNDLElBQUFBLE1BQU0sRUFBRTJDLEtBQUssQ0FBQzNDLE1BQU4sQ0FBYUE7QUFEaEIsR0FBUDtBQUdELENBSkQ7O0FBTUEsSUFBTTRDLGtCQUFrQixHQUFHLFNBQXJCQSxrQkFBcUIsQ0FBQ0MsUUFBRCxFQUFjO0FBQ3ZDLFNBQU87QUFDTEwsSUFBQUEsYUFBYSxFQUFFLHVCQUFDN0MsSUFBRDtBQUFBLGFBQVVrRCxRQUFRLENBQUMvQyx5REFBQSxDQUFzQkgsSUFBdEIsQ0FBRCxDQUFsQjtBQUFBLEtBRFY7QUFFTG1ELElBQUFBLGNBQWMsRUFBRSx3QkFBQ25ELElBQUQsRUFBT3FDLEVBQVA7QUFBQSxhQUFjYSxRQUFRLENBQUMvQyx3REFBQSxDQUFxQkgsSUFBckIsRUFBMkJxQyxFQUEzQixDQUFELENBQXRCO0FBQUEsS0FGWDtBQUdMZ0IsSUFBQUEsZ0JBQWdCLEVBQUUsMEJBQUNyRCxJQUFELEVBQU9zRCxJQUFQLEVBQWFDLE1BQWI7QUFBQSxhQUNoQkwsUUFBUSxDQUFDL0MsMERBQUEsQ0FBdUJILElBQXZCLEVBQTZCc0QsSUFBN0IsRUFBbUNDLE1BQW5DLENBQUQsQ0FEUTtBQUFBLEtBSGI7QUFLTEUsSUFBQUEsa0JBQWtCLEVBQUUsNEJBQUN6RCxJQUFELEVBQU9zRCxJQUFQLEVBQWFDLE1BQWI7QUFBQSxhQUNsQkwsUUFBUSxDQUFDL0MsNERBQUEsQ0FBeUJILElBQXpCLEVBQStCc0QsSUFBL0IsRUFBcUNDLE1BQXJDLENBQUQsQ0FEVTtBQUFBLEtBTGY7QUFPTEksSUFBQUEsaUJBQWlCLEVBQUUsMkJBQUMzRCxJQUFEO0FBQUEsYUFBVWtELFFBQVEsQ0FBQy9DLDZEQUFBLENBQTBCSCxJQUExQixDQUFELENBQWxCO0FBQUE7QUFQZCxHQUFQO0FBU0QsQ0FWRDs7QUFXQSwrREFBZUUsb0RBQU8sQ0FBQzZDLGVBQUQsRUFBa0JFLGtCQUFsQixDQUFQLENBQTZDekMsSUFBN0MsQ0FBZiIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9wYWdlcy9pbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XG5pbXBvcnQgeyBGaWVsZCwgRmllbGRBcnJheSwgRm9ybWlrIH0gZnJvbSBcImZvcm1pa1wiO1xuaW1wb3J0IEhlYWQgZnJvbSBcIm5leHQvaGVhZFwiO1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHtcbiAgQnV0dG9uLFxuICBDYXJkLFxuICBDYXJkQm9keSxcbiAgQ2FyZEhlYWRlcixcbiAgQ2FyZFN1YnRpdGxlLFxuICBDYXJkVGV4dCxcbiAgQ2FyZFRpdGxlLFxuICBDb2wsXG4gIEZvcm0sXG4gIEZvcm1Hcm91cCxcbiAgSW5wdXRHcm91cCxcbiAgUm93LFxufSBmcm9tIFwicmVhY3RzdHJhcFwiO1xuaW1wb3J0IGRhdGEgZnJvbSBcIi4uL2NvbXBvbmVudHMvRGF0YS9EYXRhLmpzb25cIjtcbmltcG9ydCBvcHRpb25zIGZyb20gXCIuLi9jb21wb25lbnRzL0RhdGEvb3B0aW9ucy5qc29uXCI7XG5pbXBvcnQgeyBjb25uZWN0IH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XG5pbXBvcnQgKiBhcyBhY3Rpb25zIGZyb20gXCIuLi9yZWR1eC9hY3Rpb25zXCI7XG5pbXBvcnQgeyB1c2VIaXN0b3J5IH0gZnJvbSBcInJlYWN0LXJvdXRlclwiO1xuXG52YXIgcmVzdWx0ID0gbmV3IEFycmF5KCk7XG52YXIgTWFpblJlc3VsdCA9IG5ldyBBcnJheSgpO1xuZnVuY3Rpb24gSG9tZShwcm9wcykge1xuICBjb25zdCBbdmFsdWUsIHNldFZhbHVlXSA9IHVzZVN0YXRlKHt9KTtcbiAgY29uc3QgaGlzdG9yeSA9IHVzZUhpc3RvcnkoKTtcblxuICBjb25zdCBbY29tcGFueSwgc2V0Q29tcGFueV0gPSB1c2VTdGF0ZSh7fSk7XG5cbiAgY29uc29sZS5sb2coXCJwcm9wcy5yZXN1bHRcIiwgcHJvcHMucmVzdWx0KTtcblxuICBjb25zb2xlLmxvZyhcInZhbHVlXCIsIHZhbHVlKTtcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gKHZhbHVlcywgc2V0U3VibWl0dGluZykgPT4ge1xuICAgIGlmIChwcm9wcy5yZXN1bHQpIHtcbiAgICAgIHByb3BzLnJlc3VsdD8ubWFwKChyKSA9PiB7XG4gICAgICAgIGRhdGE/Lm1hcCgoZCkgPT4ge1xuICAgICAgICAgIGlmIChyLnF1ZXN0aW9uX2lkID09IGQucXVlc3Rpb25faWQpIHtcbiAgICAgICAgICAgIGlmIChkLkNEVSAvIENTVSA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImFha2FzaFwiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGxldCBkYXRhID0ge1xuICAgICAgcmVzdWx0OiByZXN1bHQsXG4gICAgfTtcbiAgICBjb25zb2xlLmxvZyhkYXRhKTtcblxuICAgIGF4aW9zXG4gICAgICAucG9zdChcIi90ZXN0XCIsIGRhdGEpXG4gICAgICAudGhlbigocmVzKSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKHJlcyk7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiaW50aWFsIHZhbHVlIGlzIHN1Ym1pdGVkIHRvIHJlc3VsdHNcIik7XG4gICAgICAgIHJlc3VsdCA9IFtdO1xuICAgICAgICBoaXN0b3J5LnB1c2goXCIvdGhhbmt5b3VcIik7XG4gICAgICB9KVxuICAgICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgY29uc29sZS5sb2coZXJyLnJlc3BvbnNlLmRhdGEpO1xuICAgICAgICAvLyBoaXN0b3J5LnB1c2goXCIvZXhhbS1hcHBlYXJlZFwiKTtcbiAgICAgICAgLy8gcmVzdWx0ID0gW107XG4gICAgICB9KTtcbiAgfTtcblxuICBjb25zb2xlLmxvZyhcImFycmF5XCIsIHJlc3VsdCk7XG4gIGNvbnN0IGRhdGFMZW5ndGggPSBkYXRhLmxlbmd0aDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiXCI+XG4gICAgICA8SGVhZD5cbiAgICAgICAgPHRpdGxlPkNyZWF0ZSBOZXh0IEFwcDwvdGl0bGU+XG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cbiAgICAgIDwvSGVhZD5cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNSBib3JkZXItMiBzaGFkb3ctbWQgcm91bmRlZC1tZFwiPlxuICAgICAgICA8Q2FyZEJvZHk+XG4gICAgICAgICAgPEZvcm1pa1xuICAgICAgICAgICAgaW5pdGlhbFZhbHVlcz17e1xuICAgICAgICAgICAgICByZXN1bHQ6IFtdLFxuICAgICAgICAgICAgICBhbnN3ZXI6IFwiXCIsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgb25TdWJtaXQ9eyh2YWx1ZXMsIHNldFN1Ym1pdHRpbmcpID0+IHtcbiAgICAgICAgICAgICAgaWYgKHByb3BzLnJlc3VsdD8ubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwicmVzdWx0IGxlbmd0aFwiLCBwcm9wcy5yZXN1bHQ/Lmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0TGVuZ3RoID0gcHJvcHMucmVzdWx0Py5sZW5ndGg7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByZXN1bHRMZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJyZXN1bHQgbWFwXCIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBwcm9wcy5yZXN1bHQ/Lm1hcCgocikgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJyZXN1bHQgbWFwXCIpO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGRhdGE/Lm1hcCgoZCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAoci5xdWVzdGlvbl9pZCA9PSBkLmlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJyLnF1ZXN0aW9uX2lkXCIsIHIucXVlc3Rpb25faWQsIFwiZC5pZFwiLCBkLmlkKTtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoZC5TUEQgPT0gci5hbnN3ZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWFrYXNoXCIpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgbGV0IGRhdGEgPSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0OiBwcm9wcy5yZXN1bHQsXG4gICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic3VibWl0IGNsaWNrXCIpO1xuICAgICAgICAgICAgICAvLyBheGlvc1xuICAgICAgICAgICAgICAvLyAgIC5wb3N0KFwiaHR0cHM6Ly91ZGl0c29sdXRpb25zLmluL3lhcm4vcHVibGljL2FwaS9zY29yZXNcIiwgZGF0YSlcbiAgICAgICAgICAgICAgLy8gICAudGhlbigocmVzKSA9PiB7XG4gICAgICAgICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhyZXMpO1xuICAgICAgICAgICAgICAvLyAgICAgY29uc29sZS5sb2coXCJpbnRpYWwgdmFsdWUgaXMgc3VibWl0ZWQgdG8gcmVzdWx0c1wiKTtcbiAgICAgICAgICAgICAgLy8gICAgIHJlc3VsdCA9IFtdO1xuICAgICAgICAgICAgICAvLyAgICAgaGlzdG9yeS5wdXNoKFwiL3RoYW5reW91XCIpO1xuICAgICAgICAgICAgICAvLyAgIH0pXG4gICAgICAgICAgICAgIC8vICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKGVyci5yZXNwb25zZS5kYXRhKTtcbiAgICAgICAgICAgICAgLy8gICAgIC8vIGhpc3RvcnkucHVzaChcIi9leGFtLWFwcGVhcmVkXCIpO1xuXG4gICAgICAgICAgICAgIC8vICAgfSk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHsoeyBoYW5kbGVTdWJtaXQgfSkgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxGb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxuICAgICAgICAgICAgICAgICAge2RhdGE/Lm1hcCgoZCwgaWQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17ZC5pZH0gY2xhc3NOYW1lPVwibXQtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcmRUaXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge1wiIFwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZC5pZH0ve2RhdGFMZW5ndGh9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NhcmRUaXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkU3VidGl0bGU+e2QuU2NobGFnd29ydH08L0NhcmRTdWJ0aXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkVGV4dD57ZC5xdWVzdGlvbl90ZXh0fTwvQ2FyZFRleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRBcnJheVxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVzdWx0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVuZGVyPXsoYXJyYXlIZWxwZXJzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSb3c+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dEdyb3VwIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcHRpb25zPy5tYXAoKG9wdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtvcHQuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGJnLWdyYXktNjAwIHRleHQtd2hpdGUgcm91bmRlZC1tZCB0ZXh0LWNlbnRlciBob3ZlcjpiZy15ZWxsb3ctMzAwIGhvdmVyOnRleHQtYmxhY2sgbWItMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBuYW1lPVwiYW5zd2VyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtvcHQub3B0aW9uX1ZhbHVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFZhbHVlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6IG9wdC5vcHRpb25fVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgaSA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpIDwgcmVzdWx0Lmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGkrK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/LnF1ZXN0aW9uX2lkID09IGQuaWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInNwbGljZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnNwbGljZShpLCAxLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25faWQ6IGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdFtpXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5xdWVzdGlvbl9pZCAhPT0gZC5pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZWxzZV9pZiBxdWVzdGlvbiBvZiBkYXRhXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInJlc3VsdCBxLWlkXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0W2ldLnF1ZXN0aW9uX2lkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uX2lkOiBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdC5vcHRpb25fVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3BzLnJlc3VsdFNldERhdGEocmVzdWx0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImVsc2VcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25faWQ6IGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6IG9wdC5vcHRpb25fVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcHMucmVzdWx0U2V0RGF0YShyZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29wdC5vcHRpb25fdGV4dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjp7XCIgXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVzdWx0Py5tYXAoKHIpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHIucXVlc3Rpb25faWQgPT0gZC5pZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByLmFuc3dlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+ICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0lucHV0R3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBibG9ja1xuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlci0yIHAtMiBib3JkZXItYmxhY2sgbXQtN1wiXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgICAgLy8gb25DbGljaz17aGFuZGxlU3VibWl0fVxuICAgICAgICAgICAgICAgICAgICAgIC8vIGRpc2FibGVkPXtmb3JtUHJvcHMuaXNTdWJtaXR0aW5nfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgRWVnZWJuaXMgemVpZ2VuXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9Gb3JtPlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICA8L0Zvcm1paz5cbiAgICAgICAgPC9DYXJkQm9keT5cbiAgICAgIDwvQ2FyZD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuY29uc3QgbWFwU3RhdGVUb1Byb3BzID0gKHN0YXRlKSA9PiB7XG4gIHJldHVybiB7XG4gICAgcmVzdWx0OiBzdGF0ZS5yZXN1bHQucmVzdWx0LFxuICB9O1xufTtcblxuY29uc3QgbWFwRGlzcGF0Y2hUb1Byb3BzID0gKGRpc3BhdGNoKSA9PiB7XG4gIHJldHVybiB7XG4gICAgcmVzdWx0U2V0RGF0YTogKGRhdGEpID0+IGRpc3BhdGNoKGFjdGlvbnMucmVzdWx0U2V0RGF0YShkYXRhKSksXG4gICAgb25EZWxldGVSZXN1bHQ6IChkYXRhLCBpZCkgPT4gZGlzcGF0Y2goYWN0aW9ucy5kZWxldGVSZXN1bHQoZGF0YSwgaWQpKSxcbiAgICBvblBvc3RSZXN1bHREYXRhOiAoZGF0YSwgdXNlciwgdG9nZ2xlKSA9PlxuICAgICAgZGlzcGF0Y2goYWN0aW9ucy5wb3N0UmVzdWx0RGF0YShkYXRhLCB1c2VyLCB0b2dnbGUpKSxcbiAgICBvblVwZGF0ZVJlc3VsdERhdGE6IChkYXRhLCB1c2VyLCB0b2dnbGUpID0+XG4gICAgICBkaXNwYXRjaChhY3Rpb25zLnVwZGF0ZVJlc3VsdERhdGEoZGF0YSwgdXNlciwgdG9nZ2xlKSksXG4gICAgcmVzdWx0RWRpdEdldERhdGE6IChkYXRhKSA9PiBkaXNwYXRjaChhY3Rpb25zLnJlc3VsdEVkaXRHZXREYXRhKGRhdGEpKSxcbiAgfTtcbn07XG5leHBvcnQgZGVmYXVsdCBjb25uZWN0KG1hcFN0YXRlVG9Qcm9wcywgbWFwRGlzcGF0Y2hUb1Byb3BzKShIb21lKTtcbiJdLCJuYW1lcyI6WyJheGlvcyIsIkZpZWxkIiwiRmllbGRBcnJheSIsIkZvcm1payIsIkhlYWQiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkJ1dHRvbiIsIkNhcmQiLCJDYXJkQm9keSIsIkNhcmRIZWFkZXIiLCJDYXJkU3VidGl0bGUiLCJDYXJkVGV4dCIsIkNhcmRUaXRsZSIsIkNvbCIsIkZvcm0iLCJGb3JtR3JvdXAiLCJJbnB1dEdyb3VwIiwiUm93IiwiZGF0YSIsIm9wdGlvbnMiLCJjb25uZWN0IiwiYWN0aW9ucyIsInVzZUhpc3RvcnkiLCJyZXN1bHQiLCJBcnJheSIsIk1haW5SZXN1bHQiLCJIb21lIiwicHJvcHMiLCJ2YWx1ZSIsInNldFZhbHVlIiwiaGlzdG9yeSIsImNvbXBhbnkiLCJzZXRDb21wYW55IiwiY29uc29sZSIsImxvZyIsImhhbmRsZVN1Ym1pdCIsInZhbHVlcyIsInNldFN1Ym1pdHRpbmciLCJtYXAiLCJyIiwiZCIsInF1ZXN0aW9uX2lkIiwiQ0RVIiwiQ1NVIiwiYW5zd2VyIiwicG9zdCIsInRoZW4iLCJyZXMiLCJwdXNoIiwiZXJyIiwicmVzcG9uc2UiLCJkYXRhTGVuZ3RoIiwibGVuZ3RoIiwicmVzdWx0TGVuZ3RoIiwiaSIsImlkIiwiU1BEIiwiU2NobGFnd29ydCIsInF1ZXN0aW9uX3RleHQiLCJhcnJheUhlbHBlcnMiLCJvcHQiLCJvcHRpb25fVmFsdWUiLCJzcGxpY2UiLCJyZXN1bHRTZXREYXRhIiwib3B0aW9uX3RleHQiLCJtYXBTdGF0ZVRvUHJvcHMiLCJzdGF0ZSIsIm1hcERpc3BhdGNoVG9Qcm9wcyIsImRpc3BhdGNoIiwib25EZWxldGVSZXN1bHQiLCJkZWxldGVSZXN1bHQiLCJvblBvc3RSZXN1bHREYXRhIiwidXNlciIsInRvZ2dsZSIsInBvc3RSZXN1bHREYXRhIiwib25VcGRhdGVSZXN1bHREYXRhIiwidXBkYXRlUmVzdWx0RGF0YSIsInJlc3VsdEVkaXRHZXREYXRhIl0sInNvdXJjZVJvb3QiOiIifQ==