"use strict";
self["webpackHotUpdate_N_E"]("pages/_app",{

/***/ "./redux/reducers/RResult.js":
/*!***********************************!*\
  !*** ./redux/reducers/RResult.js ***!
  \***********************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var E_git_vinraj_company_test_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _actions_ActionTypes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../actions/ActionTypes */ "./redux/actions/ActionTypes.js");
/* module decorator */ module = __webpack_require__.hmd(module);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,E_git_vinraj_company_test_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }


var initialState = {
  result: [],
  error: false,
  mainResult: [],
  isLoading: false
};

var reducer = function reducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;
  var action = arguments.length > 1 ? arguments[1] : undefined;

  switch (action.type) {
    case _actions_ActionTypes__WEBPACK_IMPORTED_MODULE_1__.RESULT_SET_DATA:
      return _objectSpread(_objectSpread({}, state), {}, {
        result: action.result,
        isLoading: false,
        error: false
      });

    case _actions_ActionTypes__WEBPACK_IMPORTED_MODULE_1__.RESULT_FAIL_DATA:
      return _objectSpread(_objectSpread({}, state), {}, {
        isLoading: false,
        error: action.error // result: [],

      });

    case _actions_ActionTypes__WEBPACK_IMPORTED_MODULE_1__.RESULT_LOADING:
      return _objectSpread(_objectSpread({}, state), {}, {
        isLoading: true,
        error: false // result: [],
        // mainResult: [],

      });

    case _actions_ActionTypes__WEBPACK_IMPORTED_MODULE_1__.POST_RESULT_DATA_FAIL:
      return _objectSpread(_objectSpread({}, state), {}, {
        isLoading: false,
        error: action.error
      });

    case _actions_ActionTypes__WEBPACK_IMPORTED_MODULE_1__.RESULT_EDIT_SET_DATA:
      return _objectSpread(_objectSpread({}, state), {}, {
        isLoading: false,
        error: false,
        mainResult: action.mainResult
      });

    case _actions_ActionTypes__WEBPACK_IMPORTED_MODULE_1__.RESULT_EDIT_FAIL_DATA:
      return _objectSpread(_objectSpread({}, state), {}, {
        isLoading: false,
        error: action.error // mainResult: [],

      });

    case _actions_ActionTypes__WEBPACK_IMPORTED_MODULE_1__.UPDATE_RESULT_DATA_START:
      return _objectSpread(_objectSpread({}, state), {}, {
        isLoading: false
      });

    default:
      return state;
  }
};

/* harmony default export */ __webpack_exports__["default"] = (reducer);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvX2FwcC4zNGFmNjA4OTRhMDk3NDlhZWVhOC5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUVBLElBQU1DLFlBQVksR0FBRztBQUNuQkMsRUFBQUEsTUFBTSxFQUFFLEVBRFc7QUFFbkJDLEVBQUFBLEtBQUssRUFBRSxLQUZZO0FBR25CQyxFQUFBQSxVQUFVLEVBQUUsRUFITztBQUluQkMsRUFBQUEsU0FBUyxFQUFFO0FBSlEsQ0FBckI7O0FBT0EsSUFBTUMsT0FBTyxHQUFHLFNBQVZBLE9BQVUsR0FBa0M7QUFBQSxNQUFqQ0MsS0FBaUMsdUVBQXpCTixZQUF5QjtBQUFBLE1BQVhPLE1BQVc7O0FBQ2hELFVBQVFBLE1BQU0sQ0FBQ0MsSUFBZjtBQUNFLFNBQUtULGlFQUFMO0FBQ0UsNkNBQ0tPLEtBREw7QUFFRUwsUUFBQUEsTUFBTSxFQUFFTSxNQUFNLENBQUNOLE1BRmpCO0FBR0VHLFFBQUFBLFNBQVMsRUFBRSxLQUhiO0FBSUVGLFFBQUFBLEtBQUssRUFBRTtBQUpUOztBQU9GLFNBQUtILGtFQUFMO0FBQ0UsNkNBQ0tPLEtBREw7QUFFRUYsUUFBQUEsU0FBUyxFQUFFLEtBRmI7QUFHRUYsUUFBQUEsS0FBSyxFQUFFSyxNQUFNLENBQUNMLEtBSGhCLENBSUU7O0FBSkY7O0FBTUYsU0FBS0gsZ0VBQUw7QUFDRSw2Q0FDS08sS0FETDtBQUVFRixRQUFBQSxTQUFTLEVBQUUsSUFGYjtBQUdFRixRQUFBQSxLQUFLLEVBQUUsS0FIVCxDQUlFO0FBQ0E7O0FBTEY7O0FBUUYsU0FBS0gsdUVBQUw7QUFDRSw2Q0FDS08sS0FETDtBQUVFRixRQUFBQSxTQUFTLEVBQUUsS0FGYjtBQUdFRixRQUFBQSxLQUFLLEVBQUVLLE1BQU0sQ0FBQ0w7QUFIaEI7O0FBS0YsU0FBS0gsc0VBQUw7QUFDRSw2Q0FDS08sS0FETDtBQUVFRixRQUFBQSxTQUFTLEVBQUUsS0FGYjtBQUdFRixRQUFBQSxLQUFLLEVBQUUsS0FIVDtBQUlFQyxRQUFBQSxVQUFVLEVBQUVJLE1BQU0sQ0FBQ0o7QUFKckI7O0FBTUYsU0FBS0osdUVBQUw7QUFDRSw2Q0FDS08sS0FETDtBQUVFRixRQUFBQSxTQUFTLEVBQUUsS0FGYjtBQUdFRixRQUFBQSxLQUFLLEVBQUVLLE1BQU0sQ0FBQ0wsS0FIaEIsQ0FJRTs7QUFKRjs7QUFNRixTQUFLSCwwRUFBTDtBQUNFLDZDQUNLTyxLQURMO0FBRUVGLFFBQUFBLFNBQVMsRUFBRTtBQUZiOztBQUtGO0FBQ0UsYUFBT0UsS0FBUDtBQXBESjtBQXNERCxDQXZERDs7QUF5REEsK0RBQWVELE9BQWYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcmVkdXgvcmVkdWNlcnMvUlJlc3VsdC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBhY3Rpb25UeXBlIGZyb20gXCIuLi9hY3Rpb25zL0FjdGlvblR5cGVzXCI7XHJcblxyXG5jb25zdCBpbml0aWFsU3RhdGUgPSB7XHJcbiAgcmVzdWx0OiBbXSxcclxuICBlcnJvcjogZmFsc2UsXHJcbiAgbWFpblJlc3VsdDogW10sXHJcbiAgaXNMb2FkaW5nOiBmYWxzZSxcclxufTtcclxuXHJcbmNvbnN0IHJlZHVjZXIgPSAoc3RhdGUgPSBpbml0aWFsU3RhdGUsIGFjdGlvbikgPT4ge1xyXG4gIHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcclxuICAgIGNhc2UgYWN0aW9uVHlwZS5SRVNVTFRfU0VUX0RBVEE6XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgcmVzdWx0OiBhY3Rpb24ucmVzdWx0LFxyXG4gICAgICAgIGlzTG9hZGluZzogZmFsc2UsXHJcbiAgICAgICAgZXJyb3I6IGZhbHNlLFxyXG4gICAgICB9O1xyXG5cclxuICAgIGNhc2UgYWN0aW9uVHlwZS5SRVNVTFRfRkFJTF9EQVRBOlxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgIGlzTG9hZGluZzogZmFsc2UsXHJcbiAgICAgICAgZXJyb3I6IGFjdGlvbi5lcnJvcixcclxuICAgICAgICAvLyByZXN1bHQ6IFtdLFxyXG4gICAgICB9O1xyXG4gICAgY2FzZSBhY3Rpb25UeXBlLlJFU1VMVF9MT0FESU5HOlxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgIGlzTG9hZGluZzogdHJ1ZSxcclxuICAgICAgICBlcnJvcjogZmFsc2UsXHJcbiAgICAgICAgLy8gcmVzdWx0OiBbXSxcclxuICAgICAgICAvLyBtYWluUmVzdWx0OiBbXSxcclxuICAgICAgfTtcclxuXHJcbiAgICBjYXNlIGFjdGlvblR5cGUuUE9TVF9SRVNVTFRfREFUQV9GQUlMOlxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgIGlzTG9hZGluZzogZmFsc2UsXHJcbiAgICAgICAgZXJyb3I6IGFjdGlvbi5lcnJvcixcclxuICAgICAgfTtcclxuICAgIGNhc2UgYWN0aW9uVHlwZS5SRVNVTFRfRURJVF9TRVRfREFUQTpcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICBpc0xvYWRpbmc6IGZhbHNlLFxyXG4gICAgICAgIGVycm9yOiBmYWxzZSxcclxuICAgICAgICBtYWluUmVzdWx0OiBhY3Rpb24ubWFpblJlc3VsdCxcclxuICAgICAgfTtcclxuICAgIGNhc2UgYWN0aW9uVHlwZS5SRVNVTFRfRURJVF9GQUlMX0RBVEE6XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgaXNMb2FkaW5nOiBmYWxzZSxcclxuICAgICAgICBlcnJvcjogYWN0aW9uLmVycm9yLFxyXG4gICAgICAgIC8vIG1haW5SZXN1bHQ6IFtdLFxyXG4gICAgICB9O1xyXG4gICAgY2FzZSBhY3Rpb25UeXBlLlVQREFURV9SRVNVTFRfREFUQV9TVEFSVDpcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICBpc0xvYWRpbmc6IGZhbHNlLFxyXG4gICAgICB9O1xyXG5cclxuICAgIGRlZmF1bHQ6XHJcbiAgICAgIHJldHVybiBzdGF0ZTtcclxuICB9XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCByZWR1Y2VyO1xyXG4iXSwibmFtZXMiOlsiYWN0aW9uVHlwZSIsImluaXRpYWxTdGF0ZSIsInJlc3VsdCIsImVycm9yIiwibWFpblJlc3VsdCIsImlzTG9hZGluZyIsInJlZHVjZXIiLCJzdGF0ZSIsImFjdGlvbiIsInR5cGUiLCJSRVNVTFRfU0VUX0RBVEEiLCJSRVNVTFRfRkFJTF9EQVRBIiwiUkVTVUxUX0xPQURJTkciLCJQT1NUX1JFU1VMVF9EQVRBX0ZBSUwiLCJSRVNVTFRfRURJVF9TRVRfREFUQSIsIlJFU1VMVF9FRElUX0ZBSUxfREFUQSIsIlVQREFURV9SRVNVTFRfREFUQV9TVEFSVCJdLCJzb3VyY2VSb290IjoiIn0=