"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
/* harmony import */ var _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Data/Data.json */ "./components/Data/Data.json");
/* harmony import */ var _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Data/options.json */ "./components/Data/options.json");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _redux_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../redux/actions */ "./redux/actions/index.js");
/* harmony import */ var react_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-router */ "./node_modules/react-router/esm/react-router.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "E:\\git vinraj\\company-test\\pages\\index.js",
    _s = $RefreshSig$();












var result = new Array();
var MainResult = new Array();

function Home(props) {
  _s();

  var _this = this;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      value = _useState[0],
      setValue = _useState[1];

  var history = (0,react_router__WEBPACK_IMPORTED_MODULE_9__.useHistory)();

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      company = _useState2[0],
      setCompany = _useState2[1];

  console.log("props.result", props.result);
  console.log("value", value);

  var handleSubmit = function handleSubmit(values, setSubmitting) {
    if (props.result) {
      var _props$result;

      (_props$result = props.result) === null || _props$result === void 0 ? void 0 : _props$result.map(function (r) {
        data === null || data === void 0 ? void 0 : data.map(function (d) {
          if (r.question_id == d.question_id) {
            if (d.CDU / CSU == r.answer) {
              console.log("aakash");
            }
          }
        });
      });
    }

    var data = {
      result: result
    };
    console.log(data);
    axios__WEBPACK_IMPORTED_MODULE_0___default().post("/test", data).then(function (res) {
      console.log(res);
      console.log("intial value is submited to results");
      result = [];
      history.push("/thankyou");
    })["catch"](function (err) {
      console.log(err.response.data); // history.push("/exam-appeared");
      // result = [];
    });
  };

  console.log("array", result);
  var dataLength = _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.length;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
    className: "",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("title", {
        children: "Create Next App"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Card, {
      className: "p-5 border-2 shadow-md rounded-md",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardBody, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
          initialValues: {
            result: [],
            answer: ""
          },
          onSubmit: function onSubmit(values, setSubmitting) {
            var _props$result2;

            if (((_props$result2 = props.result) === null || _props$result2 === void 0 ? void 0 : _props$result2.length) > 0) {
              var _props$result3, _props$result4;

              console.log("result length", (_props$result3 = props.result) === null || _props$result3 === void 0 ? void 0 : _props$result3.length);
              var resultLength = (_props$result4 = props.result) === null || _props$result4 === void 0 ? void 0 : _props$result4.length; // for (let i = 0; i < resultLength; i++) {
              //   console.log("result map");
              // }

              data === null || data === void 0 ? void 0 : data.map(function (d) {
                var _props$result5;

                console.log("data map");
                (_props$result5 = props.result) === null || _props$result5 === void 0 ? void 0 : _props$result5.map(function (r) {
                  console.log("result map");

                  if (r.question_id == d.id) {
                    console.log("r.question_id", r.question_id, "d.id", d.id);

                    if (d.SPD == r.answer) {
                      console.log("aakash");
                    }
                  }
                });
              });
            }

            var data = {
              result: props.result
            };
            console.log("submit click"); // axios
            //   .post("https://uditsolutions.in/yarn/public/api/scores", data)
            //   .then((res) => {
            //     console.log(res);
            //     console.log("intial value is submited to results");
            //     result = [];
            //     history.push("/thankyou");
            //   })
            //   .catch((err) => {
            //     console.log(err.response.data);
            //     // history.push("/exam-appeared");
            //   });
          },
          children: function children(_ref) {
            var handleSubmit = _ref.handleSubmit;
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Form, {
              onSubmit: handleSubmit,
              children: [_components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === null || _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === void 0 ? void 0 : _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.map(function (d, id) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                  className: "mt-3",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardTitle, {
                    children: [" ", d.id, "/", dataLength]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 130,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardSubtitle, {
                    children: d.Schlagwort
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 134,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardText, {
                    children: d.question_text
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 135,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.FieldArray, {
                    name: "result",
                    render: function render(arrayHelpers) {
                      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Row, {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Col, {
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.FormGroup, {
                              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.InputGroup, {
                                className: "flex flex-col mt-2",
                                children: _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === null || _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === void 0 ? void 0 : _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__.map(function (opt) {
                                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("label", {
                                    className: "p-2 bg-gray-600 text-white rounded-md text-center hover:bg-yellow-300 hover:text-black mb-1",
                                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                                      type: "radio" // name="answer"
                                      ,
                                      value: opt.option_Value,
                                      className: "hidden",
                                      onChange: function onChange() {
                                        setValue({
                                          question_id: d.id,
                                          answer: opt.option_Value
                                        });

                                        if (result.length > 0) {
                                          for (var i = 0; i < result.length; i++) {
                                            var _result$i;

                                            if (((_result$i = result[i]) === null || _result$i === void 0 ? void 0 : _result$i.question_id) == d.id) {
                                              console.log("splice");
                                              result.splice(i, 1, {
                                                question_id: d.id,
                                                answer: opt.option_Value
                                              });
                                              return;
                                            } else if (result[i].question_id !== d.id) {
                                              console.log("else_if question of data", d.id, "result q-id", result[i].question_id);
                                              result.push({
                                                question_id: d.id,
                                                answer: opt.option_Value // value,

                                              });
                                              return;
                                            }
                                          }

                                          props.resultSetData(result);
                                        } else {
                                          console.log("else");
                                          result.push({
                                            question_id: d.id,
                                            answer: opt.option_Value
                                          });
                                          props.resultSetData(result);
                                        }
                                      }
                                    }, void 0, false, {
                                      fileName: _jsxFileName,
                                      lineNumber: 151,
                                      columnNumber: 47
                                    }, _this), opt.option_text]
                                  }, opt.id, true, {
                                    fileName: _jsxFileName,
                                    lineNumber: 147,
                                    columnNumber: 45
                                  }, _this);
                                })
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 144,
                                columnNumber: 39
                              }, _this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 143,
                              columnNumber: 37
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 142,
                            columnNumber: 35
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 141,
                          columnNumber: 33
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 140,
                        columnNumber: 31
                      }, _this);
                    }
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 136,
                    columnNumber: 25
                  }, _this)]
                }, d.id, true, {
                  fileName: _jsxFileName,
                  lineNumber: 129,
                  columnNumber: 23
                }, _this);
              }), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Button, {
                  block: true,
                  className: "border-2 p-2 border-black mt-7",
                  type: "submit" // onClick={handleSubmit}
                  // disabled={formProps.isSubmitting}
                  ,
                  children: "Eegebnis zeigen"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 235,
                  columnNumber: 21
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 234,
                columnNumber: 19
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 126,
              columnNumber: 17
            }, _this);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 79,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 78,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 77,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 72,
    columnNumber: 5
  }, this);
}

_s(Home, "+Ok9uqErGU59sIRoYnjvw5OYqYQ=", false, function () {
  return [react_router__WEBPACK_IMPORTED_MODULE_9__.useHistory];
});

_c = Home;

var mapStateToProps = function mapStateToProps(state) {
  return {
    result: state.result.result
  };
};

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    resultSetData: function resultSetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultSetData(data));
    },
    onDeleteResult: function onDeleteResult(data, id) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.deleteResult(data, id));
    },
    onPostResultData: function onPostResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.postResultData(data, user, toggle));
    },
    onUpdateResultData: function onUpdateResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.updateResultData(data, user, toggle));
    },
    resultEditGetData: function resultEditGetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultEditGetData(data));
    }
  };
};

/* harmony default export */ __webpack_exports__["default"] = ((0,react_redux__WEBPACK_IMPORTED_MODULE_6__.connect)(mapStateToProps, mapDispatchToProps)(Home));

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguYmQ1YWI2NDA2ODFjOWRiNDM3NDYuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFjQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLElBQUl3QixNQUFNLEdBQUcsSUFBSUMsS0FBSixFQUFiO0FBQ0EsSUFBSUMsVUFBVSxHQUFHLElBQUlELEtBQUosRUFBakI7O0FBQ0EsU0FBU0UsSUFBVCxDQUFjQyxLQUFkLEVBQXFCO0FBQUE7O0FBQUE7O0FBQ25CLGtCQUEwQnRCLCtDQUFRLENBQUMsRUFBRCxDQUFsQztBQUFBLE1BQU91QixLQUFQO0FBQUEsTUFBY0MsUUFBZDs7QUFDQSxNQUFNQyxPQUFPLEdBQUdSLHdEQUFVLEVBQTFCOztBQUVBLG1CQUE4QmpCLCtDQUFRLENBQUMsRUFBRCxDQUF0QztBQUFBLE1BQU8wQixPQUFQO0FBQUEsTUFBZ0JDLFVBQWhCOztBQUVBQyxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBQTRCUCxLQUFLLENBQUNKLE1BQWxDO0FBRUFVLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVosRUFBcUJOLEtBQXJCOztBQUNBLE1BQU1PLFlBQVksR0FBRyxTQUFmQSxZQUFlLENBQUNDLE1BQUQsRUFBU0MsYUFBVCxFQUEyQjtBQUM5QyxRQUFJVixLQUFLLENBQUNKLE1BQVYsRUFBa0I7QUFBQTs7QUFDaEIsdUJBQUFJLEtBQUssQ0FBQ0osTUFBTixnRUFBY2UsR0FBZCxDQUFrQixVQUFDQyxDQUFELEVBQU87QUFDdkJyQixRQUFBQSxJQUFJLFNBQUosSUFBQUEsSUFBSSxXQUFKLFlBQUFBLElBQUksQ0FBRW9CLEdBQU4sQ0FBVSxVQUFDRSxDQUFELEVBQU87QUFDZixjQUFJRCxDQUFDLENBQUNFLFdBQUYsSUFBaUJELENBQUMsQ0FBQ0MsV0FBdkIsRUFBb0M7QUFDbEMsZ0JBQUlELENBQUMsQ0FBQ0UsR0FBRixHQUFRQyxHQUFSLElBQWVKLENBQUMsQ0FBQ0ssTUFBckIsRUFBNkI7QUFDM0JYLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVo7QUFDRDtBQUNGO0FBQ0YsU0FORDtBQU9ELE9BUkQ7QUFTRDs7QUFDRCxRQUFJaEIsSUFBSSxHQUFHO0FBQ1RLLE1BQUFBLE1BQU0sRUFBRUE7QUFEQyxLQUFYO0FBR0FVLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZaEIsSUFBWjtBQUVBbkIsSUFBQUEsaURBQUEsQ0FDUSxPQURSLEVBQ2lCbUIsSUFEakIsRUFFRzRCLElBRkgsQ0FFUSxVQUFDQyxHQUFELEVBQVM7QUFDYmQsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlhLEdBQVo7QUFDQWQsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVkscUNBQVo7QUFDQVgsTUFBQUEsTUFBTSxHQUFHLEVBQVQ7QUFDQU8sTUFBQUEsT0FBTyxDQUFDa0IsSUFBUixDQUFhLFdBQWI7QUFDRCxLQVBILFdBUVMsVUFBQ0MsR0FBRCxFQUFTO0FBQ2RoQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWWUsR0FBRyxDQUFDQyxRQUFKLENBQWFoQyxJQUF6QixFQURjLENBRWQ7QUFDQTtBQUNELEtBWkg7QUFhRCxHQTlCRDs7QUFnQ0FlLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVosRUFBcUJYLE1BQXJCO0FBQ0EsTUFBTTRCLFVBQVUsR0FBR2pDLDhEQUFuQjtBQUVBLHNCQUNFO0FBQUssYUFBUyxFQUFDLEVBQWY7QUFBQSw0QkFDRSw4REFBQyxrREFBRDtBQUFBLDhCQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFRTtBQUFNLFdBQUcsRUFBQyxNQUFWO0FBQWlCLFlBQUksRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFLRSw4REFBQyw2Q0FBRDtBQUFNLGVBQVMsRUFBQyxtQ0FBaEI7QUFBQSw2QkFDRSw4REFBQyxpREFBRDtBQUFBLCtCQUNFLDhEQUFDLDBDQUFEO0FBQ0UsdUJBQWEsRUFBRTtBQUNiSyxZQUFBQSxNQUFNLEVBQUUsRUFESztBQUVicUIsWUFBQUEsTUFBTSxFQUFFO0FBRkssV0FEakI7QUFLRSxrQkFBUSxFQUFFLGtCQUFDUixNQUFELEVBQVNDLGFBQVQsRUFBMkI7QUFBQTs7QUFDbkMsZ0JBQUksbUJBQUFWLEtBQUssQ0FBQ0osTUFBTixrRUFBYzZCLE1BQWQsSUFBdUIsQ0FBM0IsRUFBOEI7QUFBQTs7QUFDNUJuQixjQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxlQUFaLG9CQUE2QlAsS0FBSyxDQUFDSixNQUFuQyxtREFBNkIsZUFBYzZCLE1BQTNDO0FBQ0Esa0JBQU1DLFlBQVkscUJBQUcxQixLQUFLLENBQUNKLE1BQVQsbURBQUcsZUFBYzZCLE1BQW5DLENBRjRCLENBRzVCO0FBQ0E7QUFDQTs7QUFFQWxDLGNBQUFBLElBQUksU0FBSixJQUFBQSxJQUFJLFdBQUosWUFBQUEsSUFBSSxDQUFFb0IsR0FBTixDQUFVLFVBQUNFLENBQUQsRUFBTztBQUFBOztBQUNmUCxnQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWjtBQUNBLGtDQUFBUCxLQUFLLENBQUNKLE1BQU4sa0VBQWNlLEdBQWQsQ0FBa0IsVUFBQ0MsQ0FBRCxFQUFPO0FBQ3ZCTixrQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksWUFBWjs7QUFDQSxzQkFBSUssQ0FBQyxDQUFDRSxXQUFGLElBQWlCRCxDQUFDLENBQUNjLEVBQXZCLEVBQTJCO0FBQ3pCckIsb0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGVBQVosRUFBNkJLLENBQUMsQ0FBQ0UsV0FBL0IsRUFBNEMsTUFBNUMsRUFBb0RELENBQUMsQ0FBQ2MsRUFBdEQ7O0FBQ0Esd0JBQUlkLENBQUMsQ0FBQ2UsR0FBRixJQUFTaEIsQ0FBQyxDQUFDSyxNQUFmLEVBQXVCO0FBQ3JCWCxzQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWjtBQUNEO0FBQ0Y7QUFDRixpQkFSRDtBQVNELGVBWEQ7QUFZRDs7QUFDRCxnQkFBSWhCLElBQUksR0FBRztBQUNUSyxjQUFBQSxNQUFNLEVBQUVJLEtBQUssQ0FBQ0o7QUFETCxhQUFYO0FBR0FVLFlBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGNBQVosRUF4Qm1DLENBeUJuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDRCxXQTNDSDtBQUFBLG9CQTZDRyx3QkFBc0I7QUFBQSxnQkFBbkJDLFlBQW1CLFFBQW5CQSxZQUFtQjtBQUNyQixnQ0FDRSw4REFBQyw2Q0FBRDtBQUFNLHNCQUFRLEVBQUVBLFlBQWhCO0FBQUEseUJBQ0dqQix1REFESCxhQUNHQSx1REFESCx1QkFDR0EsMkRBQUEsQ0FBVSxVQUFDc0IsQ0FBRCxFQUFJYyxFQUFKLEVBQVc7QUFDcEIsb0NBQ0U7QUFBZ0IsMkJBQVMsRUFBQyxNQUExQjtBQUFBLDBDQUNFLDhEQUFDLGtEQUFEO0FBQUEsK0JBQ0csR0FESCxFQUVHZCxDQUFDLENBQUNjLEVBRkwsT0FFVUgsVUFGVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREYsZUFLRSw4REFBQyxxREFBRDtBQUFBLDhCQUFlWCxDQUFDLENBQUNnQjtBQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUxGLGVBTUUsOERBQUMsaURBQUQ7QUFBQSw4QkFBV2hCLENBQUMsQ0FBQ2lCO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFORixlQU9FLDhEQUFDLDhDQUFEO0FBQ0Usd0JBQUksRUFBQyxRQURQO0FBRUUsMEJBQU0sRUFBRSxnQkFBQ0MsWUFBRCxFQUFrQjtBQUN4QiwwQ0FDRTtBQUFBLCtDQUNFLDhEQUFDLDRDQUFEO0FBQUEsaURBQ0UsOERBQUMsNENBQUQ7QUFBQSxtREFDRSw4REFBQyxrREFBRDtBQUFBLHFEQUNFLDhEQUFDLG1EQUFEO0FBQVkseUNBQVMsRUFBQyxvQkFBdEI7QUFBQSwwQ0FDR3ZDLDBEQURILGFBQ0dBLDBEQURILHVCQUNHQSw4REFBQSxDQUFhLFVBQUN3QyxHQUFELEVBQVM7QUFDckIsc0RBQ0U7QUFFRSw2Q0FBUyxFQUFDLDZGQUZaO0FBQUEsNERBSUUsOERBQUMseUNBQUQ7QUFDRSwwQ0FBSSxFQUFDLE9BRFAsQ0FFRTtBQUZGO0FBR0UsMkNBQUssRUFBRUEsR0FBRyxDQUFDQyxZQUhiO0FBSUUsK0NBQVMsRUFBQyxRQUpaO0FBS0UsOENBQVEsRUFBRSxvQkFBTTtBQUNkL0Isd0NBQUFBLFFBQVEsQ0FBQztBQUNQWSwwQ0FBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNjLEVBRFI7QUFFUFYsMENBQUFBLE1BQU0sRUFBRWUsR0FBRyxDQUFDQztBQUZMLHlDQUFELENBQVI7O0FBS0EsNENBQUlyQyxNQUFNLENBQUM2QixNQUFQLEdBQWdCLENBQXBCLEVBQXVCO0FBQ3JCLCtDQUNFLElBQUlTLENBQUMsR0FBRyxDQURWLEVBRUVBLENBQUMsR0FBR3RDLE1BQU0sQ0FBQzZCLE1BRmIsRUFHRVMsQ0FBQyxFQUhILEVBSUU7QUFBQTs7QUFDQSxnREFDRSxjQUFBdEMsTUFBTSxDQUFDc0MsQ0FBRCxDQUFOLHdEQUNJcEIsV0FESixLQUNtQkQsQ0FBQyxDQUFDYyxFQUZ2QixFQUdFO0FBQ0FyQiw4Q0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWjtBQUNBWCw4Q0FBQUEsTUFBTSxDQUFDdUMsTUFBUCxDQUFjRCxDQUFkLEVBQWlCLENBQWpCLEVBQW9CO0FBQ2xCcEIsZ0RBQUFBLFdBQVcsRUFBRUQsQ0FBQyxDQUFDYyxFQURHO0FBRWxCVixnREFBQUEsTUFBTSxFQUNKZSxHQUFHLENBQUNDO0FBSFksK0NBQXBCO0FBS0E7QUFDRCw2Q0FYRCxNQVdPLElBQ0xyQyxNQUFNLENBQUNzQyxDQUFELENBQU4sQ0FDR3BCLFdBREgsS0FDbUJELENBQUMsQ0FBQ2MsRUFGaEIsRUFHTDtBQUNBckIsOENBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUNFLDBCQURGLEVBRUVNLENBQUMsQ0FBQ2MsRUFGSixFQUdFLGFBSEYsRUFJRS9CLE1BQU0sQ0FBQ3NDLENBQUQsQ0FBTixDQUFVcEIsV0FKWjtBQU9BbEIsOENBQUFBLE1BQU0sQ0FBQ3lCLElBQVAsQ0FBWTtBQUNWUCxnREFBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNjLEVBREw7QUFFVlYsZ0RBQUFBLE1BQU0sRUFDSmUsR0FBRyxDQUFDQyxZQUhJLENBSVY7O0FBSlUsK0NBQVo7QUFNQTtBQUNEO0FBQ0Y7O0FBQ0RqQywwQ0FBQUEsS0FBSyxDQUFDb0MsYUFBTixDQUFvQnhDLE1BQXBCO0FBQ0QseUNBdENELE1Bc0NPO0FBQ0xVLDBDQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBQ0FYLDBDQUFBQSxNQUFNLENBQUN5QixJQUFQLENBQVk7QUFDVlAsNENBQUFBLFdBQVcsRUFBRUQsQ0FBQyxDQUFDYyxFQURMO0FBRVZWLDRDQUFBQSxNQUFNLEVBQUVlLEdBQUcsQ0FBQ0M7QUFGRiwyQ0FBWjtBQUlBakMsMENBQUFBLEtBQUssQ0FBQ29DLGFBQU4sQ0FBb0J4QyxNQUFwQjtBQUNEO0FBQ0Y7QUF6REg7QUFBQTtBQUFBO0FBQUE7QUFBQSw2Q0FKRixFQStER29DLEdBQUcsQ0FBQ0ssV0EvRFA7QUFBQSxxQ0FDT0wsR0FBRyxDQUFDTCxFQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkNBREY7QUFtRUQsaUNBcEVBO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBREY7QUEwRkQ7QUE3Rkg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFQRjtBQUFBLG1CQUFVZCxDQUFDLENBQUNjLEVBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERjtBQXlHRCxlQTFHQSxDQURILGVBNEdFO0FBQUsseUJBQVMsRUFBQyxxQkFBZjtBQUFBLHVDQUNFLDhEQUFDLCtDQUFEO0FBQ0UsdUJBQUssTUFEUDtBQUVFLDJCQUFTLEVBQUMsZ0NBRlo7QUFHRSxzQkFBSSxFQUFDLFFBSFAsQ0FJRTtBQUNBO0FBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTVHRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREY7QUEwSEQ7QUF4S0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFzTEQ7O0dBbE9RNUI7VUFFU0o7OztLQUZUSTs7QUFvT1QsSUFBTXVDLGVBQWUsR0FBRyxTQUFsQkEsZUFBa0IsQ0FBQ0MsS0FBRCxFQUFXO0FBQ2pDLFNBQU87QUFDTDNDLElBQUFBLE1BQU0sRUFBRTJDLEtBQUssQ0FBQzNDLE1BQU4sQ0FBYUE7QUFEaEIsR0FBUDtBQUdELENBSkQ7O0FBTUEsSUFBTTRDLGtCQUFrQixHQUFHLFNBQXJCQSxrQkFBcUIsQ0FBQ0MsUUFBRCxFQUFjO0FBQ3ZDLFNBQU87QUFDTEwsSUFBQUEsYUFBYSxFQUFFLHVCQUFDN0MsSUFBRDtBQUFBLGFBQVVrRCxRQUFRLENBQUMvQyx5REFBQSxDQUFzQkgsSUFBdEIsQ0FBRCxDQUFsQjtBQUFBLEtBRFY7QUFFTG1ELElBQUFBLGNBQWMsRUFBRSx3QkFBQ25ELElBQUQsRUFBT29DLEVBQVA7QUFBQSxhQUFjYyxRQUFRLENBQUMvQyx3REFBQSxDQUFxQkgsSUFBckIsRUFBMkJvQyxFQUEzQixDQUFELENBQXRCO0FBQUEsS0FGWDtBQUdMaUIsSUFBQUEsZ0JBQWdCLEVBQUUsMEJBQUNyRCxJQUFELEVBQU9zRCxJQUFQLEVBQWFDLE1BQWI7QUFBQSxhQUNoQkwsUUFBUSxDQUFDL0MsMERBQUEsQ0FBdUJILElBQXZCLEVBQTZCc0QsSUFBN0IsRUFBbUNDLE1BQW5DLENBQUQsQ0FEUTtBQUFBLEtBSGI7QUFLTEUsSUFBQUEsa0JBQWtCLEVBQUUsNEJBQUN6RCxJQUFELEVBQU9zRCxJQUFQLEVBQWFDLE1BQWI7QUFBQSxhQUNsQkwsUUFBUSxDQUFDL0MsNERBQUEsQ0FBeUJILElBQXpCLEVBQStCc0QsSUFBL0IsRUFBcUNDLE1BQXJDLENBQUQsQ0FEVTtBQUFBLEtBTGY7QUFPTEksSUFBQUEsaUJBQWlCLEVBQUUsMkJBQUMzRCxJQUFEO0FBQUEsYUFBVWtELFFBQVEsQ0FBQy9DLDZEQUFBLENBQTBCSCxJQUExQixDQUFELENBQWxCO0FBQUE7QUFQZCxHQUFQO0FBU0QsQ0FWRDs7QUFXQSwrREFBZUUsb0RBQU8sQ0FBQzZDLGVBQUQsRUFBa0JFLGtCQUFsQixDQUFQLENBQTZDekMsSUFBN0MsQ0FBZiIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9wYWdlcy9pbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XG5pbXBvcnQgeyBGaWVsZCwgRmllbGRBcnJheSwgRm9ybWlrIH0gZnJvbSBcImZvcm1pa1wiO1xuaW1wb3J0IEhlYWQgZnJvbSBcIm5leHQvaGVhZFwiO1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHtcbiAgQnV0dG9uLFxuICBDYXJkLFxuICBDYXJkQm9keSxcbiAgQ2FyZEhlYWRlcixcbiAgQ2FyZFN1YnRpdGxlLFxuICBDYXJkVGV4dCxcbiAgQ2FyZFRpdGxlLFxuICBDb2wsXG4gIEZvcm0sXG4gIEZvcm1Hcm91cCxcbiAgSW5wdXRHcm91cCxcbiAgUm93LFxufSBmcm9tIFwicmVhY3RzdHJhcFwiO1xuaW1wb3J0IGRhdGEgZnJvbSBcIi4uL2NvbXBvbmVudHMvRGF0YS9EYXRhLmpzb25cIjtcbmltcG9ydCBvcHRpb25zIGZyb20gXCIuLi9jb21wb25lbnRzL0RhdGEvb3B0aW9ucy5qc29uXCI7XG5pbXBvcnQgeyBjb25uZWN0IH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XG5pbXBvcnQgKiBhcyBhY3Rpb25zIGZyb20gXCIuLi9yZWR1eC9hY3Rpb25zXCI7XG5pbXBvcnQgeyB1c2VIaXN0b3J5IH0gZnJvbSBcInJlYWN0LXJvdXRlclwiO1xuXG52YXIgcmVzdWx0ID0gbmV3IEFycmF5KCk7XG52YXIgTWFpblJlc3VsdCA9IG5ldyBBcnJheSgpO1xuZnVuY3Rpb24gSG9tZShwcm9wcykge1xuICBjb25zdCBbdmFsdWUsIHNldFZhbHVlXSA9IHVzZVN0YXRlKHt9KTtcbiAgY29uc3QgaGlzdG9yeSA9IHVzZUhpc3RvcnkoKTtcblxuICBjb25zdCBbY29tcGFueSwgc2V0Q29tcGFueV0gPSB1c2VTdGF0ZSh7fSk7XG5cbiAgY29uc29sZS5sb2coXCJwcm9wcy5yZXN1bHRcIiwgcHJvcHMucmVzdWx0KTtcblxuICBjb25zb2xlLmxvZyhcInZhbHVlXCIsIHZhbHVlKTtcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gKHZhbHVlcywgc2V0U3VibWl0dGluZykgPT4ge1xuICAgIGlmIChwcm9wcy5yZXN1bHQpIHtcbiAgICAgIHByb3BzLnJlc3VsdD8ubWFwKChyKSA9PiB7XG4gICAgICAgIGRhdGE/Lm1hcCgoZCkgPT4ge1xuICAgICAgICAgIGlmIChyLnF1ZXN0aW9uX2lkID09IGQucXVlc3Rpb25faWQpIHtcbiAgICAgICAgICAgIGlmIChkLkNEVSAvIENTVSA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImFha2FzaFwiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGxldCBkYXRhID0ge1xuICAgICAgcmVzdWx0OiByZXN1bHQsXG4gICAgfTtcbiAgICBjb25zb2xlLmxvZyhkYXRhKTtcblxuICAgIGF4aW9zXG4gICAgICAucG9zdChcIi90ZXN0XCIsIGRhdGEpXG4gICAgICAudGhlbigocmVzKSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKHJlcyk7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiaW50aWFsIHZhbHVlIGlzIHN1Ym1pdGVkIHRvIHJlc3VsdHNcIik7XG4gICAgICAgIHJlc3VsdCA9IFtdO1xuICAgICAgICBoaXN0b3J5LnB1c2goXCIvdGhhbmt5b3VcIik7XG4gICAgICB9KVxuICAgICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgY29uc29sZS5sb2coZXJyLnJlc3BvbnNlLmRhdGEpO1xuICAgICAgICAvLyBoaXN0b3J5LnB1c2goXCIvZXhhbS1hcHBlYXJlZFwiKTtcbiAgICAgICAgLy8gcmVzdWx0ID0gW107XG4gICAgICB9KTtcbiAgfTtcblxuICBjb25zb2xlLmxvZyhcImFycmF5XCIsIHJlc3VsdCk7XG4gIGNvbnN0IGRhdGFMZW5ndGggPSBkYXRhLmxlbmd0aDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiXCI+XG4gICAgICA8SGVhZD5cbiAgICAgICAgPHRpdGxlPkNyZWF0ZSBOZXh0IEFwcDwvdGl0bGU+XG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cbiAgICAgIDwvSGVhZD5cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNSBib3JkZXItMiBzaGFkb3ctbWQgcm91bmRlZC1tZFwiPlxuICAgICAgICA8Q2FyZEJvZHk+XG4gICAgICAgICAgPEZvcm1pa1xuICAgICAgICAgICAgaW5pdGlhbFZhbHVlcz17e1xuICAgICAgICAgICAgICByZXN1bHQ6IFtdLFxuICAgICAgICAgICAgICBhbnN3ZXI6IFwiXCIsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgb25TdWJtaXQ9eyh2YWx1ZXMsIHNldFN1Ym1pdHRpbmcpID0+IHtcbiAgICAgICAgICAgICAgaWYgKHByb3BzLnJlc3VsdD8ubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwicmVzdWx0IGxlbmd0aFwiLCBwcm9wcy5yZXN1bHQ/Lmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0TGVuZ3RoID0gcHJvcHMucmVzdWx0Py5sZW5ndGg7XG4gICAgICAgICAgICAgICAgLy8gZm9yIChsZXQgaSA9IDA7IGkgPCByZXN1bHRMZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIC8vICAgY29uc29sZS5sb2coXCJyZXN1bHQgbWFwXCIpO1xuICAgICAgICAgICAgICAgIC8vIH1cblxuICAgICAgICAgICAgICAgIGRhdGE/Lm1hcCgoZCkgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJkYXRhIG1hcFwiKTtcbiAgICAgICAgICAgICAgICAgIHByb3BzLnJlc3VsdD8ubWFwKChyKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwicmVzdWx0IG1hcFwiKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHIucXVlc3Rpb25faWQgPT0gZC5pZCkge1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwici5xdWVzdGlvbl9pZFwiLCByLnF1ZXN0aW9uX2lkLCBcImQuaWRcIiwgZC5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGQuU1BEID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImFha2FzaFwiKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGxldCBkYXRhID0ge1xuICAgICAgICAgICAgICAgIHJlc3VsdDogcHJvcHMucmVzdWx0LFxuICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInN1Ym1pdCBjbGlja1wiKTtcbiAgICAgICAgICAgICAgLy8gYXhpb3NcbiAgICAgICAgICAgICAgLy8gICAucG9zdChcImh0dHBzOi8vdWRpdHNvbHV0aW9ucy5pbi95YXJuL3B1YmxpYy9hcGkvc2NvcmVzXCIsIGRhdGEpXG4gICAgICAgICAgICAgIC8vICAgLnRoZW4oKHJlcykgPT4ge1xuICAgICAgICAgICAgICAvLyAgICAgY29uc29sZS5sb2cocmVzKTtcbiAgICAgICAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKFwiaW50aWFsIHZhbHVlIGlzIHN1Ym1pdGVkIHRvIHJlc3VsdHNcIik7XG4gICAgICAgICAgICAgIC8vICAgICByZXN1bHQgPSBbXTtcbiAgICAgICAgICAgICAgLy8gICAgIGhpc3RvcnkucHVzaChcIi90aGFua3lvdVwiKTtcbiAgICAgICAgICAgICAgLy8gICB9KVxuICAgICAgICAgICAgICAvLyAgIC5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhlcnIucmVzcG9uc2UuZGF0YSk7XG4gICAgICAgICAgICAgIC8vICAgICAvLyBoaXN0b3J5LnB1c2goXCIvZXhhbS1hcHBlYXJlZFwiKTtcblxuICAgICAgICAgICAgICAvLyAgIH0pO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7KHsgaGFuZGxlU3VibWl0IH0pID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8Rm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cbiAgICAgICAgICAgICAgICAgIHtkYXRhPy5tYXAoKGQsIGlkKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2QuaWR9IGNsYXNzTmFtZT1cIm10LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkVGl0bGU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtcIiBcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2QuaWR9L3tkYXRhTGVuZ3RofVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9DYXJkVGl0bGU+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2FyZFN1YnRpdGxlPntkLlNjaGxhZ3dvcnR9PC9DYXJkU3VidGl0bGU+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2FyZFRleHQ+e2QucXVlc3Rpb25fdGV4dH08L0NhcmRUZXh0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZpZWxkQXJyYXlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInJlc3VsdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlbmRlcj17KGFycmF5SGVscGVycykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Um93PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDb2w+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRHcm91cCBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG10LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3B0aW9ucz8ubWFwKChvcHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17b3B0LmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiBiZy1ncmF5LTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbWQgdGV4dC1jZW50ZXIgaG92ZXI6YmcteWVsbG93LTMwMCBob3Zlcjp0ZXh0LWJsYWNrIG1iLTFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicmFkaW9cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbmFtZT1cImFuc3dlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17b3B0Lm9wdGlvbl9WYWx1ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRWYWx1ZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25faWQ6IGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOiBvcHQub3B0aW9uX1ZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGkgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaSA8IHJlc3VsdC5sZW5ndGg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpKytcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0W2ldXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPy5xdWVzdGlvbl9pZCA9PSBkLmlkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJzcGxpY2VcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC5zcGxpY2UoaSwgMSwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uX2lkOiBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdC5vcHRpb25fVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucXVlc3Rpb25faWQgIT09IGQuaWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVsc2VfaWYgcXVlc3Rpb24gb2YgZGF0YVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJyZXN1bHQgcS1pZFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdFtpXS5xdWVzdGlvbl9pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHQub3B0aW9uX1ZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wcy5yZXN1bHRTZXREYXRhKHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJlbHNlXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uX2lkOiBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOiBvcHQub3B0aW9uX1ZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3BzLnJlc3VsdFNldERhdGEocmVzdWx0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcHQub3B0aW9uX3RleHR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6e1wiIFwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Jlc3VsdD8ubWFwKChyKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyLnF1ZXN0aW9uX2lkID09IGQuaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gci5hbnN3ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PiAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9JbnB1dEdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvUm93PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgYmxvY2tcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItMiBwLTIgYm9yZGVyLWJsYWNrIG10LTdcIlxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICAgIC8vIG9uQ2xpY2s9e2hhbmRsZVN1Ym1pdH1cbiAgICAgICAgICAgICAgICAgICAgICAvLyBkaXNhYmxlZD17Zm9ybVByb3BzLmlzU3VibWl0dGluZ31cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIEVlZ2VibmlzIHplaWdlblxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvRm9ybT5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPC9Gb3JtaWs+XG4gICAgICAgIDwvQ2FyZEJvZHk+XG4gICAgICA8L0NhcmQ+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IChzdGF0ZSkgPT4ge1xuICByZXR1cm4ge1xuICAgIHJlc3VsdDogc3RhdGUucmVzdWx0LnJlc3VsdCxcbiAgfTtcbn07XG5cbmNvbnN0IG1hcERpc3BhdGNoVG9Qcm9wcyA9IChkaXNwYXRjaCkgPT4ge1xuICByZXR1cm4ge1xuICAgIHJlc3VsdFNldERhdGE6IChkYXRhKSA9PiBkaXNwYXRjaChhY3Rpb25zLnJlc3VsdFNldERhdGEoZGF0YSkpLFxuICAgIG9uRGVsZXRlUmVzdWx0OiAoZGF0YSwgaWQpID0+IGRpc3BhdGNoKGFjdGlvbnMuZGVsZXRlUmVzdWx0KGRhdGEsIGlkKSksXG4gICAgb25Qb3N0UmVzdWx0RGF0YTogKGRhdGEsIHVzZXIsIHRvZ2dsZSkgPT5cbiAgICAgIGRpc3BhdGNoKGFjdGlvbnMucG9zdFJlc3VsdERhdGEoZGF0YSwgdXNlciwgdG9nZ2xlKSksXG4gICAgb25VcGRhdGVSZXN1bHREYXRhOiAoZGF0YSwgdXNlciwgdG9nZ2xlKSA9PlxuICAgICAgZGlzcGF0Y2goYWN0aW9ucy51cGRhdGVSZXN1bHREYXRhKGRhdGEsIHVzZXIsIHRvZ2dsZSkpLFxuICAgIHJlc3VsdEVkaXRHZXREYXRhOiAoZGF0YSkgPT4gZGlzcGF0Y2goYWN0aW9ucy5yZXN1bHRFZGl0R2V0RGF0YShkYXRhKSksXG4gIH07XG59O1xuZXhwb3J0IGRlZmF1bHQgY29ubmVjdChtYXBTdGF0ZVRvUHJvcHMsIG1hcERpc3BhdGNoVG9Qcm9wcykoSG9tZSk7XG4iXSwibmFtZXMiOlsiYXhpb3MiLCJGaWVsZCIsIkZpZWxkQXJyYXkiLCJGb3JtaWsiLCJIZWFkIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJCdXR0b24iLCJDYXJkIiwiQ2FyZEJvZHkiLCJDYXJkSGVhZGVyIiwiQ2FyZFN1YnRpdGxlIiwiQ2FyZFRleHQiLCJDYXJkVGl0bGUiLCJDb2wiLCJGb3JtIiwiRm9ybUdyb3VwIiwiSW5wdXRHcm91cCIsIlJvdyIsImRhdGEiLCJvcHRpb25zIiwiY29ubmVjdCIsImFjdGlvbnMiLCJ1c2VIaXN0b3J5IiwicmVzdWx0IiwiQXJyYXkiLCJNYWluUmVzdWx0IiwiSG9tZSIsInByb3BzIiwidmFsdWUiLCJzZXRWYWx1ZSIsImhpc3RvcnkiLCJjb21wYW55Iiwic2V0Q29tcGFueSIsImNvbnNvbGUiLCJsb2ciLCJoYW5kbGVTdWJtaXQiLCJ2YWx1ZXMiLCJzZXRTdWJtaXR0aW5nIiwibWFwIiwiciIsImQiLCJxdWVzdGlvbl9pZCIsIkNEVSIsIkNTVSIsImFuc3dlciIsInBvc3QiLCJ0aGVuIiwicmVzIiwicHVzaCIsImVyciIsInJlc3BvbnNlIiwiZGF0YUxlbmd0aCIsImxlbmd0aCIsInJlc3VsdExlbmd0aCIsImlkIiwiU1BEIiwiU2NobGFnd29ydCIsInF1ZXN0aW9uX3RleHQiLCJhcnJheUhlbHBlcnMiLCJvcHQiLCJvcHRpb25fVmFsdWUiLCJpIiwic3BsaWNlIiwicmVzdWx0U2V0RGF0YSIsIm9wdGlvbl90ZXh0IiwibWFwU3RhdGVUb1Byb3BzIiwic3RhdGUiLCJtYXBEaXNwYXRjaFRvUHJvcHMiLCJkaXNwYXRjaCIsIm9uRGVsZXRlUmVzdWx0IiwiZGVsZXRlUmVzdWx0Iiwib25Qb3N0UmVzdWx0RGF0YSIsInVzZXIiLCJ0b2dnbGUiLCJwb3N0UmVzdWx0RGF0YSIsIm9uVXBkYXRlUmVzdWx0RGF0YSIsInVwZGF0ZVJlc3VsdERhdGEiLCJyZXN1bHRFZGl0R2V0RGF0YSJdLCJzb3VyY2VSb290IjoiIn0=