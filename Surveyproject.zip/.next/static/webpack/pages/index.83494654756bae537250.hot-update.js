"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
/* harmony import */ var _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Data/Data.json */ "./components/Data/Data.json");
/* harmony import */ var _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Data/options.json */ "./components/Data/options.json");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _redux_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../redux/actions */ "./redux/actions/index.js");
/* harmony import */ var react_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-router */ "./node_modules/react-router/esm/react-router.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "E:\\git vinraj\\company-test\\pages\\index.js",
    _s = $RefreshSig$();












var result = new Array();

function Home(props) {
  _s();

  var _this = this;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      value = _useState[0],
      setValue = _useState[1];

  var history = (0,react_router__WEBPACK_IMPORTED_MODULE_9__.useHistory)();

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      company = _useState2[0],
      setCompany = _useState2[1];

  console.log("props.result", props.result);
  console.log("value", value);

  var handleSubmit = function handleSubmit(event, values, setSubmitting) {
    event.preventDefault(); // setSubmitting(true);

    if (props.result) {
      var _props$result;

      (_props$result = props.result) === null || _props$result === void 0 ? void 0 : _props$result.map(function (r) {
        data === null || data === void 0 ? void 0 : data.map(function (d) {
          if (r.question_id == d.question_id) {
            if (d.CDU / CSU == r.answer) {
              console.log("aakash");
            }
          }
        });
      });
    }

    var data = {
      result: result
    };
    console.log(data);
    axios__WEBPACK_IMPORTED_MODULE_0___default().post("/test", data).then(function (res) {
      console.log(res);
      console.log("intial value is submited to results");
      result = [];
      history.push("/thankyou");
    })["catch"](function (err) {
      console.log(err.response.data); // history.push("/exam-appeared");
      // result = [];
    });
  };

  console.log("array", result);
  var dataLength = _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.length;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
    className: "",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("title", {
        children: "Create Next App"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Card, {
      className: "p-5 border-2 shadow-md rounded-md",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardBody, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
          initialValues: {
            result: [],
            answer: ""
          },
          onSubmit: function onSubmit(values) {},
          children: function children(_ref) {
            var handleSubmit = _ref.handleSubmit;
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Form, {
              onSubmit: handleSubmit,
              children: [_components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === null || _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === void 0 ? void 0 : _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.map(function (d, id) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                  className: "mt-3",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardTitle, {
                    children: [" ", d.id, "/", dataLength]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 92,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardSubtitle, {
                    children: d.Schlagwort
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 96,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardText, {
                    children: d.question_text
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 97,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.FieldArray, {
                    name: "result",
                    render: function render(arrayHelpers) {
                      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Row, {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Col, {
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.FormGroup, {
                              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.InputGroup, {
                                className: "flex flex-col mt-2",
                                children: _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === null || _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === void 0 ? void 0 : _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__.map(function (opt) {
                                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("label", {
                                    className: "p-2 bg-gray-600 text-white rounded-md text-center hover:bg-yellow-300 hover:text-black mb-1",
                                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                                      type: "radio" // name="answer"
                                      ,
                                      value: opt.option_Value,
                                      className: "hidden",
                                      onChange: function onChange() {
                                        setValue({
                                          question_id: d.id,
                                          answer: opt.option_Value
                                        });

                                        if (result.length > 0) {
                                          for (var i = 0; i < result.length; i++) {
                                            var _result$i;

                                            if (((_result$i = result[i]) === null || _result$i === void 0 ? void 0 : _result$i.question_id) == d.id) {
                                              console.log("splice");
                                              result.splice(i, 1, {
                                                question_id: d.id,
                                                answer: opt.option_Value
                                              });
                                              return;
                                            } else if (result[i].question_id !== d.id) {
                                              console.log("else_if question of data", d.id, "result q-id", result[i].question_id);
                                              result.push({
                                                question_id: d.id,
                                                answer: opt.option_Value // value,

                                              });
                                              return;
                                            }
                                          }
                                        } else {
                                          console.log("else");
                                          result.push({
                                            question_id: d.id,
                                            answer: opt.option_Value
                                          });
                                        }
                                      }
                                    }, void 0, false, {
                                      fileName: _jsxFileName,
                                      lineNumber: 113,
                                      columnNumber: 47
                                    }, _this), opt.option_text]
                                  }, opt.id, true, {
                                    fileName: _jsxFileName,
                                    lineNumber: 109,
                                    columnNumber: 45
                                  }, _this);
                                })
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 106,
                                columnNumber: 39
                              }, _this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 105,
                              columnNumber: 37
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 104,
                            columnNumber: 35
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 103,
                          columnNumber: 33
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 102,
                        columnNumber: 31
                      }, _this);
                    }
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 98,
                    columnNumber: 25
                  }, _this)]
                }, d.id, true, {
                  fileName: _jsxFileName,
                  lineNumber: 91,
                  columnNumber: 23
                }, _this);
              }), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Button, {
                  block: true,
                  className: "border-2 p-2 border-black mt-7",
                  type: "submit" // onClick={handleSubmit}
                  // disabled={formProps.isSubmitting}
                  ,
                  children: "Eegebnis zeigen"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 195,
                  columnNumber: 21
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 194,
                columnNumber: 19
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 88,
              columnNumber: 17
            }, _this);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 79,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 78,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 77,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 72,
    columnNumber: 5
  }, this);
}

_s(Home, "+Ok9uqErGU59sIRoYnjvw5OYqYQ=", false, function () {
  return [react_router__WEBPACK_IMPORTED_MODULE_9__.useHistory];
});

_c = Home;

var mapStateToProps = function mapStateToProps(state) {
  return {
    result: state.result.result
  };
};

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    resultSetData: function resultSetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultSetData(data));
    },
    onDeleteResult: function onDeleteResult(data, id) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.deleteResult(data, id));
    },
    onPostResultData: function onPostResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.postResultData(data, user, toggle));
    },
    onUpdateResultData: function onUpdateResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.updateResultData(data, user, toggle));
    },
    resultEditGetData: function resultEditGetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultEditGetData(data));
    }
  };
};

/* harmony default export */ __webpack_exports__["default"] = ((0,react_redux__WEBPACK_IMPORTED_MODULE_6__.connect)(mapStateToProps, mapDispatchToProps)(Home));

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguODM0OTQ2NTQ3NTZiYWU1MzcyNTAuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFjQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLElBQUl3QixNQUFNLEdBQUcsSUFBSUMsS0FBSixFQUFiOztBQUNBLFNBQVNDLElBQVQsQ0FBY0MsS0FBZCxFQUFxQjtBQUFBOztBQUFBOztBQUNuQixrQkFBMEJyQiwrQ0FBUSxDQUFDLEVBQUQsQ0FBbEM7QUFBQSxNQUFPc0IsS0FBUDtBQUFBLE1BQWNDLFFBQWQ7O0FBQ0EsTUFBTUMsT0FBTyxHQUFHUCx3REFBVSxFQUExQjs7QUFFQSxtQkFBOEJqQiwrQ0FBUSxDQUFDLEVBQUQsQ0FBdEM7QUFBQSxNQUFPeUIsT0FBUDtBQUFBLE1BQWdCQyxVQUFoQjs7QUFFQUMsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUE0QlAsS0FBSyxDQUFDSCxNQUFsQztBQUVBUyxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQXFCTixLQUFyQjs7QUFDQSxNQUFNTyxZQUFZLEdBQUcsU0FBZkEsWUFBZSxDQUFDQyxLQUFELEVBQVFDLE1BQVIsRUFBZ0JDLGFBQWhCLEVBQWtDO0FBQ3JERixJQUFBQSxLQUFLLENBQUNHLGNBQU4sR0FEcUQsQ0FFckQ7O0FBQ0EsUUFBSVosS0FBSyxDQUFDSCxNQUFWLEVBQWtCO0FBQUE7O0FBQ2hCLHVCQUFBRyxLQUFLLENBQUNILE1BQU4sZ0VBQWNnQixHQUFkLENBQWtCLFVBQUNDLENBQUQsRUFBTztBQUN2QnRCLFFBQUFBLElBQUksU0FBSixJQUFBQSxJQUFJLFdBQUosWUFBQUEsSUFBSSxDQUFFcUIsR0FBTixDQUFVLFVBQUNFLENBQUQsRUFBTztBQUNmLGNBQUlELENBQUMsQ0FBQ0UsV0FBRixJQUFpQkQsQ0FBQyxDQUFDQyxXQUF2QixFQUFvQztBQUNsQyxnQkFBSUQsQ0FBQyxDQUFDRSxHQUFGLEdBQVFDLEdBQVIsSUFBZUosQ0FBQyxDQUFDSyxNQUFyQixFQUE2QjtBQUMzQmIsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWjtBQUNEO0FBQ0Y7QUFDRixTQU5EO0FBT0QsT0FSRDtBQVNEOztBQUNELFFBQUlmLElBQUksR0FBRztBQUNUSyxNQUFBQSxNQUFNLEVBQUVBO0FBREMsS0FBWDtBQUdBUyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWWYsSUFBWjtBQUVBbkIsSUFBQUEsaURBQUEsQ0FDUSxPQURSLEVBQ2lCbUIsSUFEakIsRUFFRzZCLElBRkgsQ0FFUSxVQUFDQyxHQUFELEVBQVM7QUFDYmhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZZSxHQUFaO0FBQ0FoQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxxQ0FBWjtBQUNBVixNQUFBQSxNQUFNLEdBQUcsRUFBVDtBQUNBTSxNQUFBQSxPQUFPLENBQUNvQixJQUFSLENBQWEsV0FBYjtBQUNELEtBUEgsV0FRUyxVQUFDQyxHQUFELEVBQVM7QUFDZGxCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZaUIsR0FBRyxDQUFDQyxRQUFKLENBQWFqQyxJQUF6QixFQURjLENBRWQ7QUFDQTtBQUNELEtBWkg7QUFhRCxHQWhDRDs7QUFpQ0FjLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVosRUFBcUJWLE1BQXJCO0FBQ0EsTUFBTTZCLFVBQVUsR0FBR2xDLDhEQUFuQjtBQUVBLHNCQUNFO0FBQUssYUFBUyxFQUFDLEVBQWY7QUFBQSw0QkFDRSw4REFBQyxrREFBRDtBQUFBLDhCQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFRTtBQUFNLFdBQUcsRUFBQyxNQUFWO0FBQWlCLFlBQUksRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFLRSw4REFBQyw2Q0FBRDtBQUFNLGVBQVMsRUFBQyxtQ0FBaEI7QUFBQSw2QkFDRSw4REFBQyxpREFBRDtBQUFBLCtCQUNFLDhEQUFDLDBDQUFEO0FBQ0UsdUJBQWEsRUFBRTtBQUNiSyxZQUFBQSxNQUFNLEVBQUUsRUFESztBQUVic0IsWUFBQUEsTUFBTSxFQUFFO0FBRkssV0FEakI7QUFLRSxrQkFBUSxFQUFFLGtCQUFDVCxNQUFELEVBQVksQ0FBRSxDQUwxQjtBQUFBLG9CQU9HLHdCQUFzQjtBQUFBLGdCQUFuQkYsWUFBbUIsUUFBbkJBLFlBQW1CO0FBQ3JCLGdDQUNFLDhEQUFDLDZDQUFEO0FBQU0sc0JBQVEsRUFBRUEsWUFBaEI7QUFBQSx5QkFDR2hCLHVEQURILGFBQ0dBLHVEQURILHVCQUNHQSwyREFBQSxDQUFVLFVBQUN1QixDQUFELEVBQUlhLEVBQUosRUFBVztBQUNwQixvQ0FDRTtBQUFnQiwyQkFBUyxFQUFDLE1BQTFCO0FBQUEsMENBQ0UsOERBQUMsa0RBQUQ7QUFBQSwrQkFDRyxHQURILEVBRUdiLENBQUMsQ0FBQ2EsRUFGTCxPQUVVRixVQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFERixlQUtFLDhEQUFDLHFEQUFEO0FBQUEsOEJBQWVYLENBQUMsQ0FBQ2M7QUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFMRixlQU1FLDhEQUFDLGlEQUFEO0FBQUEsOEJBQVdkLENBQUMsQ0FBQ2U7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU5GLGVBT0UsOERBQUMsOENBQUQ7QUFDRSx3QkFBSSxFQUFDLFFBRFA7QUFFRSwwQkFBTSxFQUFFLGdCQUFDQyxZQUFELEVBQWtCO0FBQ3hCLDBDQUNFO0FBQUEsK0NBQ0UsOERBQUMsNENBQUQ7QUFBQSxpREFDRSw4REFBQyw0Q0FBRDtBQUFBLG1EQUNFLDhEQUFDLGtEQUFEO0FBQUEscURBQ0UsOERBQUMsbURBQUQ7QUFBWSx5Q0FBUyxFQUFDLG9CQUF0QjtBQUFBLDBDQUNHdEMsMERBREgsYUFDR0EsMERBREgsdUJBQ0dBLDhEQUFBLENBQWEsVUFBQ3VDLEdBQUQsRUFBUztBQUNyQixzREFDRTtBQUVFLDZDQUFTLEVBQUMsNkZBRlo7QUFBQSw0REFJRSw4REFBQyx5Q0FBRDtBQUNFLDBDQUFJLEVBQUMsT0FEUCxDQUVFO0FBRkY7QUFHRSwyQ0FBSyxFQUFFQSxHQUFHLENBQUNDLFlBSGI7QUFJRSwrQ0FBUyxFQUFDLFFBSlo7QUFLRSw4Q0FBUSxFQUFFLG9CQUFNO0FBQ2QvQix3Q0FBQUEsUUFBUSxDQUFDO0FBQ1BjLDBDQUFBQSxXQUFXLEVBQUVELENBQUMsQ0FBQ2EsRUFEUjtBQUVQVCwwQ0FBQUEsTUFBTSxFQUFFYSxHQUFHLENBQUNDO0FBRkwseUNBQUQsQ0FBUjs7QUFLQSw0Q0FBSXBDLE1BQU0sQ0FBQzhCLE1BQVAsR0FBZ0IsQ0FBcEIsRUFBdUI7QUFDckIsK0NBQ0UsSUFBSU8sQ0FBQyxHQUFHLENBRFYsRUFFRUEsQ0FBQyxHQUFHckMsTUFBTSxDQUFDOEIsTUFGYixFQUdFTyxDQUFDLEVBSEgsRUFJRTtBQUFBOztBQUNBLGdEQUNFLGNBQUFyQyxNQUFNLENBQUNxQyxDQUFELENBQU4sd0RBQ0lsQixXQURKLEtBQ21CRCxDQUFDLENBQUNhLEVBRnZCLEVBR0U7QUFDQXRCLDhDQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0FBQ0FWLDhDQUFBQSxNQUFNLENBQUNzQyxNQUFQLENBQWNELENBQWQsRUFBaUIsQ0FBakIsRUFBb0I7QUFDbEJsQixnREFBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNhLEVBREc7QUFFbEJULGdEQUFBQSxNQUFNLEVBQ0phLEdBQUcsQ0FBQ0M7QUFIWSwrQ0FBcEI7QUFLQTtBQUNELDZDQVhELE1BV08sSUFDTHBDLE1BQU0sQ0FBQ3FDLENBQUQsQ0FBTixDQUNHbEIsV0FESCxLQUNtQkQsQ0FBQyxDQUFDYSxFQUZoQixFQUdMO0FBQ0F0Qiw4Q0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQ0UsMEJBREYsRUFFRVEsQ0FBQyxDQUFDYSxFQUZKLEVBR0UsYUFIRixFQUlFL0IsTUFBTSxDQUFDcUMsQ0FBRCxDQUFOLENBQVVsQixXQUpaO0FBT0FuQiw4Q0FBQUEsTUFBTSxDQUFDMEIsSUFBUCxDQUFZO0FBQ1ZQLGdEQUFBQSxXQUFXLEVBQUVELENBQUMsQ0FBQ2EsRUFETDtBQUVWVCxnREFBQUEsTUFBTSxFQUNKYSxHQUFHLENBQUNDLFlBSEksQ0FJVjs7QUFKVSwrQ0FBWjtBQU1BO0FBQ0Q7QUFDRjtBQUNGLHlDQXJDRCxNQXFDTztBQUNMM0IsMENBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVo7QUFDQVYsMENBQUFBLE1BQU0sQ0FBQzBCLElBQVAsQ0FBWTtBQUNWUCw0Q0FBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNhLEVBREw7QUFFVlQsNENBQUFBLE1BQU0sRUFBRWEsR0FBRyxDQUFDQztBQUZGLDJDQUFaO0FBSUQ7QUFDRjtBQXZESDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZDQUpGLEVBNkRHRCxHQUFHLENBQUNJLFdBN0RQO0FBQUEscUNBQ09KLEdBQUcsQ0FBQ0osRUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJDQURGO0FBaUVELGlDQWxFQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURGO0FBd0ZEO0FBM0ZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBUEY7QUFBQSxtQkFBVWIsQ0FBQyxDQUFDYSxFQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREY7QUF1R0QsZUF4R0EsQ0FESCxlQTBHRTtBQUFLLHlCQUFTLEVBQUMscUJBQWY7QUFBQSx1Q0FDRSw4REFBQywrQ0FBRDtBQUNFLHVCQUFLLE1BRFA7QUFFRSwyQkFBUyxFQUFDLGdDQUZaO0FBR0Usc0JBQUksRUFBQyxRQUhQLENBSUU7QUFDQTtBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkExR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGO0FBd0hEO0FBaElIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBOElEOztHQTNMUTdCO1VBRVNIOzs7S0FGVEc7O0FBNkxULElBQU1zQyxlQUFlLEdBQUcsU0FBbEJBLGVBQWtCLENBQUNDLEtBQUQsRUFBVztBQUNqQyxTQUFPO0FBQ0x6QyxJQUFBQSxNQUFNLEVBQUV5QyxLQUFLLENBQUN6QyxNQUFOLENBQWFBO0FBRGhCLEdBQVA7QUFHRCxDQUpEOztBQU1BLElBQU0wQyxrQkFBa0IsR0FBRyxTQUFyQkEsa0JBQXFCLENBQUNDLFFBQUQsRUFBYztBQUN2QyxTQUFPO0FBQ0xDLElBQUFBLGFBQWEsRUFBRSx1QkFBQ2pELElBQUQ7QUFBQSxhQUFVZ0QsUUFBUSxDQUFDN0MseURBQUEsQ0FBc0JILElBQXRCLENBQUQsQ0FBbEI7QUFBQSxLQURWO0FBRUxrRCxJQUFBQSxjQUFjLEVBQUUsd0JBQUNsRCxJQUFELEVBQU9vQyxFQUFQO0FBQUEsYUFBY1ksUUFBUSxDQUFDN0Msd0RBQUEsQ0FBcUJILElBQXJCLEVBQTJCb0MsRUFBM0IsQ0FBRCxDQUF0QjtBQUFBLEtBRlg7QUFHTGdCLElBQUFBLGdCQUFnQixFQUFFLDBCQUFDcEQsSUFBRCxFQUFPcUQsSUFBUCxFQUFhQyxNQUFiO0FBQUEsYUFDaEJOLFFBQVEsQ0FBQzdDLDBEQUFBLENBQXVCSCxJQUF2QixFQUE2QnFELElBQTdCLEVBQW1DQyxNQUFuQyxDQUFELENBRFE7QUFBQSxLQUhiO0FBS0xFLElBQUFBLGtCQUFrQixFQUFFLDRCQUFDeEQsSUFBRCxFQUFPcUQsSUFBUCxFQUFhQyxNQUFiO0FBQUEsYUFDbEJOLFFBQVEsQ0FBQzdDLDREQUFBLENBQXlCSCxJQUF6QixFQUErQnFELElBQS9CLEVBQXFDQyxNQUFyQyxDQUFELENBRFU7QUFBQSxLQUxmO0FBT0xJLElBQUFBLGlCQUFpQixFQUFFLDJCQUFDMUQsSUFBRDtBQUFBLGFBQVVnRCxRQUFRLENBQUM3Qyw2REFBQSxDQUEwQkgsSUFBMUIsQ0FBRCxDQUFsQjtBQUFBO0FBUGQsR0FBUDtBQVNELENBVkQ7O0FBV0EsK0RBQWVFLG9EQUFPLENBQUMyQyxlQUFELEVBQWtCRSxrQkFBbEIsQ0FBUCxDQUE2Q3hDLElBQTdDLENBQWYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xuaW1wb3J0IHsgRmllbGQsIEZpZWxkQXJyYXksIEZvcm1payB9IGZyb20gXCJmb3JtaWtcIjtcbmltcG9ydCBIZWFkIGZyb20gXCJuZXh0L2hlYWRcIjtcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7XG4gIEJ1dHRvbixcbiAgQ2FyZCxcbiAgQ2FyZEJvZHksXG4gIENhcmRIZWFkZXIsXG4gIENhcmRTdWJ0aXRsZSxcbiAgQ2FyZFRleHQsXG4gIENhcmRUaXRsZSxcbiAgQ29sLFxuICBGb3JtLFxuICBGb3JtR3JvdXAsXG4gIElucHV0R3JvdXAsXG4gIFJvdyxcbn0gZnJvbSBcInJlYWN0c3RyYXBcIjtcbmltcG9ydCBkYXRhIGZyb20gXCIuLi9jb21wb25lbnRzL0RhdGEvRGF0YS5qc29uXCI7XG5pbXBvcnQgb3B0aW9ucyBmcm9tIFwiLi4vY29tcG9uZW50cy9EYXRhL29wdGlvbnMuanNvblwiO1xuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xuaW1wb3J0ICogYXMgYWN0aW9ucyBmcm9tIFwiLi4vcmVkdXgvYWN0aW9uc1wiO1xuaW1wb3J0IHsgdXNlSGlzdG9yeSB9IGZyb20gXCJyZWFjdC1yb3V0ZXJcIjtcblxudmFyIHJlc3VsdCA9IG5ldyBBcnJheSgpO1xuZnVuY3Rpb24gSG9tZShwcm9wcykge1xuICBjb25zdCBbdmFsdWUsIHNldFZhbHVlXSA9IHVzZVN0YXRlKHt9KTtcbiAgY29uc3QgaGlzdG9yeSA9IHVzZUhpc3RvcnkoKTtcblxuICBjb25zdCBbY29tcGFueSwgc2V0Q29tcGFueV0gPSB1c2VTdGF0ZSh7fSk7XG5cbiAgY29uc29sZS5sb2coXCJwcm9wcy5yZXN1bHRcIiwgcHJvcHMucmVzdWx0KTtcblxuICBjb25zb2xlLmxvZyhcInZhbHVlXCIsIHZhbHVlKTtcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gKGV2ZW50LCB2YWx1ZXMsIHNldFN1Ym1pdHRpbmcpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIC8vIHNldFN1Ym1pdHRpbmcodHJ1ZSk7XG4gICAgaWYgKHByb3BzLnJlc3VsdCkge1xuICAgICAgcHJvcHMucmVzdWx0Py5tYXAoKHIpID0+IHtcbiAgICAgICAgZGF0YT8ubWFwKChkKSA9PiB7XG4gICAgICAgICAgaWYgKHIucXVlc3Rpb25faWQgPT0gZC5xdWVzdGlvbl9pZCkge1xuICAgICAgICAgICAgaWYgKGQuQ0RVIC8gQ1NVID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWFrYXNoXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgbGV0IGRhdGEgPSB7XG4gICAgICByZXN1bHQ6IHJlc3VsdCxcbiAgICB9O1xuICAgIGNvbnNvbGUubG9nKGRhdGEpO1xuXG4gICAgYXhpb3NcbiAgICAgIC5wb3N0KFwiL3Rlc3RcIiwgZGF0YSlcbiAgICAgIC50aGVuKChyZXMpID0+IHtcbiAgICAgICAgY29uc29sZS5sb2cocmVzKTtcbiAgICAgICAgY29uc29sZS5sb2coXCJpbnRpYWwgdmFsdWUgaXMgc3VibWl0ZWQgdG8gcmVzdWx0c1wiKTtcbiAgICAgICAgcmVzdWx0ID0gW107XG4gICAgICAgIGhpc3RvcnkucHVzaChcIi90aGFua3lvdVwiKTtcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyhlcnIucmVzcG9uc2UuZGF0YSk7XG4gICAgICAgIC8vIGhpc3RvcnkucHVzaChcIi9leGFtLWFwcGVhcmVkXCIpO1xuICAgICAgICAvLyByZXN1bHQgPSBbXTtcbiAgICAgIH0pO1xuICB9O1xuICBjb25zb2xlLmxvZyhcImFycmF5XCIsIHJlc3VsdCk7XG4gIGNvbnN0IGRhdGFMZW5ndGggPSBkYXRhLmxlbmd0aDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiXCI+XG4gICAgICA8SGVhZD5cbiAgICAgICAgPHRpdGxlPkNyZWF0ZSBOZXh0IEFwcDwvdGl0bGU+XG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cbiAgICAgIDwvSGVhZD5cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNSBib3JkZXItMiBzaGFkb3ctbWQgcm91bmRlZC1tZFwiPlxuICAgICAgICA8Q2FyZEJvZHk+XG4gICAgICAgICAgPEZvcm1pa1xuICAgICAgICAgICAgaW5pdGlhbFZhbHVlcz17e1xuICAgICAgICAgICAgICByZXN1bHQ6IFtdLFxuICAgICAgICAgICAgICBhbnN3ZXI6IFwiXCIsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgb25TdWJtaXQ9eyh2YWx1ZXMpID0+IHt9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHsoeyBoYW5kbGVTdWJtaXQgfSkgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxGb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxuICAgICAgICAgICAgICAgICAge2RhdGE/Lm1hcCgoZCwgaWQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17ZC5pZH0gY2xhc3NOYW1lPVwibXQtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcmRUaXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge1wiIFwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZC5pZH0ve2RhdGFMZW5ndGh9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NhcmRUaXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkU3VidGl0bGU+e2QuU2NobGFnd29ydH08L0NhcmRTdWJ0aXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkVGV4dD57ZC5xdWVzdGlvbl90ZXh0fTwvQ2FyZFRleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRBcnJheVxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVzdWx0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVuZGVyPXsoYXJyYXlIZWxwZXJzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSb3c+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dEdyb3VwIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcHRpb25zPy5tYXAoKG9wdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtvcHQuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGJnLWdyYXktNjAwIHRleHQtd2hpdGUgcm91bmRlZC1tZCB0ZXh0LWNlbnRlciBob3ZlcjpiZy15ZWxsb3ctMzAwIGhvdmVyOnRleHQtYmxhY2sgbWItMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBuYW1lPVwiYW5zd2VyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtvcHQub3B0aW9uX1ZhbHVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFZhbHVlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6IG9wdC5vcHRpb25fVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgaSA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpIDwgcmVzdWx0Lmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGkrK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/LnF1ZXN0aW9uX2lkID09IGQuaWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInNwbGljZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnNwbGljZShpLCAxLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25faWQ6IGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdFtpXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5xdWVzdGlvbl9pZCAhPT0gZC5pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZWxzZV9pZiBxdWVzdGlvbiBvZiBkYXRhXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInJlc3VsdCBxLWlkXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0W2ldLnF1ZXN0aW9uX2lkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uX2lkOiBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdC5vcHRpb25fVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZWxzZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjogb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcHQub3B0aW9uX3RleHR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6e1wiIFwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Jlc3VsdD8ubWFwKChyKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyLnF1ZXN0aW9uX2lkID09IGQuaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gci5hbnN3ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PiAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9JbnB1dEdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvUm93PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgYmxvY2tcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItMiBwLTIgYm9yZGVyLWJsYWNrIG10LTdcIlxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICAgIC8vIG9uQ2xpY2s9e2hhbmRsZVN1Ym1pdH1cbiAgICAgICAgICAgICAgICAgICAgICAvLyBkaXNhYmxlZD17Zm9ybVByb3BzLmlzU3VibWl0dGluZ31cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIEVlZ2VibmlzIHplaWdlblxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvRm9ybT5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPC9Gb3JtaWs+XG4gICAgICAgIDwvQ2FyZEJvZHk+XG4gICAgICA8L0NhcmQ+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IChzdGF0ZSkgPT4ge1xuICByZXR1cm4ge1xuICAgIHJlc3VsdDogc3RhdGUucmVzdWx0LnJlc3VsdCxcbiAgfTtcbn07XG5cbmNvbnN0IG1hcERpc3BhdGNoVG9Qcm9wcyA9IChkaXNwYXRjaCkgPT4ge1xuICByZXR1cm4ge1xuICAgIHJlc3VsdFNldERhdGE6IChkYXRhKSA9PiBkaXNwYXRjaChhY3Rpb25zLnJlc3VsdFNldERhdGEoZGF0YSkpLFxuICAgIG9uRGVsZXRlUmVzdWx0OiAoZGF0YSwgaWQpID0+IGRpc3BhdGNoKGFjdGlvbnMuZGVsZXRlUmVzdWx0KGRhdGEsIGlkKSksXG4gICAgb25Qb3N0UmVzdWx0RGF0YTogKGRhdGEsIHVzZXIsIHRvZ2dsZSkgPT5cbiAgICAgIGRpc3BhdGNoKGFjdGlvbnMucG9zdFJlc3VsdERhdGEoZGF0YSwgdXNlciwgdG9nZ2xlKSksXG4gICAgb25VcGRhdGVSZXN1bHREYXRhOiAoZGF0YSwgdXNlciwgdG9nZ2xlKSA9PlxuICAgICAgZGlzcGF0Y2goYWN0aW9ucy51cGRhdGVSZXN1bHREYXRhKGRhdGEsIHVzZXIsIHRvZ2dsZSkpLFxuICAgIHJlc3VsdEVkaXRHZXREYXRhOiAoZGF0YSkgPT4gZGlzcGF0Y2goYWN0aW9ucy5yZXN1bHRFZGl0R2V0RGF0YShkYXRhKSksXG4gIH07XG59O1xuZXhwb3J0IGRlZmF1bHQgY29ubmVjdChtYXBTdGF0ZVRvUHJvcHMsIG1hcERpc3BhdGNoVG9Qcm9wcykoSG9tZSk7XG4iXSwibmFtZXMiOlsiYXhpb3MiLCJGaWVsZCIsIkZpZWxkQXJyYXkiLCJGb3JtaWsiLCJIZWFkIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJCdXR0b24iLCJDYXJkIiwiQ2FyZEJvZHkiLCJDYXJkSGVhZGVyIiwiQ2FyZFN1YnRpdGxlIiwiQ2FyZFRleHQiLCJDYXJkVGl0bGUiLCJDb2wiLCJGb3JtIiwiRm9ybUdyb3VwIiwiSW5wdXRHcm91cCIsIlJvdyIsImRhdGEiLCJvcHRpb25zIiwiY29ubmVjdCIsImFjdGlvbnMiLCJ1c2VIaXN0b3J5IiwicmVzdWx0IiwiQXJyYXkiLCJIb21lIiwicHJvcHMiLCJ2YWx1ZSIsInNldFZhbHVlIiwiaGlzdG9yeSIsImNvbXBhbnkiLCJzZXRDb21wYW55IiwiY29uc29sZSIsImxvZyIsImhhbmRsZVN1Ym1pdCIsImV2ZW50IiwidmFsdWVzIiwic2V0U3VibWl0dGluZyIsInByZXZlbnREZWZhdWx0IiwibWFwIiwiciIsImQiLCJxdWVzdGlvbl9pZCIsIkNEVSIsIkNTVSIsImFuc3dlciIsInBvc3QiLCJ0aGVuIiwicmVzIiwicHVzaCIsImVyciIsInJlc3BvbnNlIiwiZGF0YUxlbmd0aCIsImxlbmd0aCIsImlkIiwiU2NobGFnd29ydCIsInF1ZXN0aW9uX3RleHQiLCJhcnJheUhlbHBlcnMiLCJvcHQiLCJvcHRpb25fVmFsdWUiLCJpIiwic3BsaWNlIiwib3B0aW9uX3RleHQiLCJtYXBTdGF0ZVRvUHJvcHMiLCJzdGF0ZSIsIm1hcERpc3BhdGNoVG9Qcm9wcyIsImRpc3BhdGNoIiwicmVzdWx0U2V0RGF0YSIsIm9uRGVsZXRlUmVzdWx0IiwiZGVsZXRlUmVzdWx0Iiwib25Qb3N0UmVzdWx0RGF0YSIsInVzZXIiLCJ0b2dnbGUiLCJwb3N0UmVzdWx0RGF0YSIsIm9uVXBkYXRlUmVzdWx0RGF0YSIsInVwZGF0ZVJlc3VsdERhdGEiLCJyZXN1bHRFZGl0R2V0RGF0YSJdLCJzb3VyY2VSb290IjoiIn0=