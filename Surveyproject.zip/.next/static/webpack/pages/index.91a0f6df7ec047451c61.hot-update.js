"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
/* harmony import */ var _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Data/Data.json */ "./components/Data/Data.json");
/* harmony import */ var _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Data/options.json */ "./components/Data/options.json");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _redux_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../redux/actions */ "./redux/actions/index.js");
/* harmony import */ var react_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-router */ "./node_modules/react-router/esm/react-router.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "E:\\git vinraj\\company-test\\pages\\index.js",
    _s = $RefreshSig$();












var result = new Array();

function Home(props) {
  _s();

  var _this = this;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      value = _useState[0],
      setValue = _useState[1];

  var history = (0,react_router__WEBPACK_IMPORTED_MODULE_9__.useHistory)();

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      company = _useState2[0],
      setCompany = _useState2[1];

  console.log("props.result", props.result);
  console.log("value", value);

  var handleSubmit = function handleSubmit(values, setSubmitting) {
    if (props.result) {
      var _props$result;

      (_props$result = props.result) === null || _props$result === void 0 ? void 0 : _props$result.map(function (r) {
        data === null || data === void 0 ? void 0 : data.map(function (d) {
          if (r.question_id == d.question_id) {
            if (d.CDU / CSU == r.answer) {
              console.log("aakash");
            }
          }
        });
      });
    }

    var data = {
      result: result
    };
    console.log(data);
    axios__WEBPACK_IMPORTED_MODULE_0___default().post("/test", data).then(function (res) {
      console.log(res);
      console.log("intial value is submited to results");
      result = [];
      history.push("/thankyou");
    })["catch"](function (err) {
      console.log(err.response.data); // history.push("/exam-appeared");
      // result = [];
    });
  };

  console.log("array", result);
  var dataLength = _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.length;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
    className: "",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("title", {
        children: "Create Next App"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 72,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 73,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 71,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Card, {
      className: "p-5 border-2 shadow-md rounded-md",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardBody, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
          initialValues: {
            result: [],
            answer: ""
          },
          onSubmit: function onSubmit(values, setSubmitting) {
            if (props.result) {
              var _props$result2;

              (_props$result2 = props.result) === null || _props$result2 === void 0 ? void 0 : _props$result2.map(function (r) {
                return data === null || data === void 0 ? void 0 : data.map(function (d) {
                  if (r.question_id == d.question_id) {
                    if (d.CDU / CSU == r.answer) {
                      console.log("aakash");
                    }
                  }
                });
              });
            }

            var data = {
              result: props.result
            }; // axios
            //   .post("https://uditsolutions.in/yarn/public/api/scores", data)
            //   .then((res) => {
            //     console.log(res);
            //     console.log("intial value is submited to results");
            //     result = [];
            //     history.push("/thankyou");
            //   })
            //   .catch((err) => {
            //     console.log(err.response.data);
            //     // history.push("/exam-appeared");
            //   });
          },
          children: function children(_ref) {
            var handleSubmit = _ref.handleSubmit;
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Form, {
              onSubmit: handleSubmit,
              children: [_components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === null || _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === void 0 ? void 0 : _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.map(function (d, id) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                  className: "mt-3",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardTitle, {
                    children: [" ", d.id, "/", dataLength]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 119,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardSubtitle, {
                    children: d.Schlagwort
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 123,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.CardText, {
                    children: d.question_text
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 124,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.FieldArray, {
                    name: "result",
                    render: function render(arrayHelpers) {
                      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Row, {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Col, {
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.FormGroup, {
                              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.InputGroup, {
                                className: "flex flex-col mt-2",
                                children: _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === null || _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === void 0 ? void 0 : _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__.map(function (opt) {
                                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("label", {
                                    className: "p-2 bg-gray-600 text-white rounded-md text-center hover:bg-yellow-300 hover:text-black mb-1",
                                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                                      type: "radio" // name="answer"
                                      ,
                                      value: opt.option_Value,
                                      className: "hidden",
                                      onChange: function onChange() {
                                        setValue({
                                          question_id: d.id,
                                          answer: opt.option_Value
                                        });

                                        if (result.length > 0) {
                                          for (var i = 0; i < result.length; i++) {
                                            var _result$i;

                                            if (((_result$i = result[i]) === null || _result$i === void 0 ? void 0 : _result$i.question_id) == d.id) {
                                              console.log("splice");
                                              result.splice(i, 1, {
                                                question_id: d.id,
                                                answer: opt.option_Value
                                              });
                                              return;
                                            } else if (result[i].question_id !== d.id) {
                                              console.log("else_if question of data", d.id, "result q-id", result[i].question_id);
                                              result.push({
                                                question_id: d.id,
                                                answer: opt.option_Value // value,

                                              });
                                              return;
                                            }
                                          }
                                        } else {
                                          console.log("else");
                                          result.push({
                                            question_id: d.id,
                                            answer: opt.option_Value
                                          });
                                        }
                                      }
                                    }, void 0, false, {
                                      fileName: _jsxFileName,
                                      lineNumber: 140,
                                      columnNumber: 47
                                    }, _this), opt.option_text]
                                  }, opt.id, true, {
                                    fileName: _jsxFileName,
                                    lineNumber: 136,
                                    columnNumber: 45
                                  }, _this);
                                })
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 133,
                                columnNumber: 39
                              }, _this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 132,
                              columnNumber: 37
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 131,
                            columnNumber: 35
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 130,
                          columnNumber: 33
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 129,
                        columnNumber: 31
                      }, _this);
                    }
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 125,
                    columnNumber: 25
                  }, _this)]
                }, d.id, true, {
                  fileName: _jsxFileName,
                  lineNumber: 118,
                  columnNumber: 23
                }, _this);
              }), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_10__.Button, {
                  block: true,
                  className: "border-2 p-2 border-black mt-7",
                  type: "submit" // onClick={handleSubmit}
                  // disabled={formProps.isSubmitting}
                  ,
                  children: "Eegebnis zeigen"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 222,
                  columnNumber: 21
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 221,
                columnNumber: 19
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 115,
              columnNumber: 17
            }, _this);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 77,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 76,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 75,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 70,
    columnNumber: 5
  }, this);
}

_s(Home, "+Ok9uqErGU59sIRoYnjvw5OYqYQ=", false, function () {
  return [react_router__WEBPACK_IMPORTED_MODULE_9__.useHistory];
});

_c = Home;

var mapStateToProps = function mapStateToProps(state) {
  return {
    result: state.result.result
  };
};

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    resultSetData: function resultSetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultSetData(data));
    },
    onDeleteResult: function onDeleteResult(data, id) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.deleteResult(data, id));
    },
    onPostResultData: function onPostResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.postResultData(data, user, toggle));
    },
    onUpdateResultData: function onUpdateResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.updateResultData(data, user, toggle));
    },
    resultEditGetData: function resultEditGetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultEditGetData(data));
    }
  };
};

/* harmony default export */ __webpack_exports__["default"] = ((0,react_redux__WEBPACK_IMPORTED_MODULE_6__.connect)(mapStateToProps, mapDispatchToProps)(Home));

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguOTFhMGY2ZGY3ZWMwNDc0NTFjNjEuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFjQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLElBQUl3QixNQUFNLEdBQUcsSUFBSUMsS0FBSixFQUFiOztBQUNBLFNBQVNDLElBQVQsQ0FBY0MsS0FBZCxFQUFxQjtBQUFBOztBQUFBOztBQUNuQixrQkFBMEJyQiwrQ0FBUSxDQUFDLEVBQUQsQ0FBbEM7QUFBQSxNQUFPc0IsS0FBUDtBQUFBLE1BQWNDLFFBQWQ7O0FBQ0EsTUFBTUMsT0FBTyxHQUFHUCx3REFBVSxFQUExQjs7QUFFQSxtQkFBOEJqQiwrQ0FBUSxDQUFDLEVBQUQsQ0FBdEM7QUFBQSxNQUFPeUIsT0FBUDtBQUFBLE1BQWdCQyxVQUFoQjs7QUFFQUMsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUE0QlAsS0FBSyxDQUFDSCxNQUFsQztBQUVBUyxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQXFCTixLQUFyQjs7QUFDQSxNQUFNTyxZQUFZLEdBQUcsU0FBZkEsWUFBZSxDQUFDQyxNQUFELEVBQVNDLGFBQVQsRUFBMkI7QUFDOUMsUUFBSVYsS0FBSyxDQUFDSCxNQUFWLEVBQWtCO0FBQUE7O0FBQ2hCLHVCQUFBRyxLQUFLLENBQUNILE1BQU4sZ0VBQWNjLEdBQWQsQ0FBa0IsVUFBQ0MsQ0FBRCxFQUFPO0FBQ3ZCcEIsUUFBQUEsSUFBSSxTQUFKLElBQUFBLElBQUksV0FBSixZQUFBQSxJQUFJLENBQUVtQixHQUFOLENBQVUsVUFBQ0UsQ0FBRCxFQUFPO0FBQ2YsY0FBSUQsQ0FBQyxDQUFDRSxXQUFGLElBQWlCRCxDQUFDLENBQUNDLFdBQXZCLEVBQW9DO0FBQ2xDLGdCQUFJRCxDQUFDLENBQUNFLEdBQUYsR0FBUUMsR0FBUixJQUFlSixDQUFDLENBQUNLLE1BQXJCLEVBQTZCO0FBQzNCWCxjQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0FBQ0Q7QUFDRjtBQUNGLFNBTkQ7QUFPRCxPQVJEO0FBU0Q7O0FBQ0QsUUFBSWYsSUFBSSxHQUFHO0FBQ1RLLE1BQUFBLE1BQU0sRUFBRUE7QUFEQyxLQUFYO0FBR0FTLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZZixJQUFaO0FBRUFuQixJQUFBQSxpREFBQSxDQUNRLE9BRFIsRUFDaUJtQixJQURqQixFQUVHMkIsSUFGSCxDQUVRLFVBQUNDLEdBQUQsRUFBUztBQUNiZCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWWEsR0FBWjtBQUNBZCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxxQ0FBWjtBQUNBVixNQUFBQSxNQUFNLEdBQUcsRUFBVDtBQUNBTSxNQUFBQSxPQUFPLENBQUNrQixJQUFSLENBQWEsV0FBYjtBQUNELEtBUEgsV0FRUyxVQUFDQyxHQUFELEVBQVM7QUFDZGhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZZSxHQUFHLENBQUNDLFFBQUosQ0FBYS9CLElBQXpCLEVBRGMsQ0FFZDtBQUNBO0FBQ0QsS0FaSDtBQWFELEdBOUJEOztBQStCQWMsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFxQlYsTUFBckI7QUFDQSxNQUFNMkIsVUFBVSxHQUFHaEMsOERBQW5CO0FBRUEsc0JBQ0U7QUFBSyxhQUFTLEVBQUMsRUFBZjtBQUFBLDRCQUNFLDhEQUFDLGtEQUFEO0FBQUEsOEJBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUVFO0FBQU0sV0FBRyxFQUFDLE1BQVY7QUFBaUIsWUFBSSxFQUFDO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQUtFLDhEQUFDLDZDQUFEO0FBQU0sZUFBUyxFQUFDLG1DQUFoQjtBQUFBLDZCQUNFLDhEQUFDLGlEQUFEO0FBQUEsK0JBQ0UsOERBQUMsMENBQUQ7QUFDRSx1QkFBYSxFQUFFO0FBQ2JLLFlBQUFBLE1BQU0sRUFBRSxFQURLO0FBRWJvQixZQUFBQSxNQUFNLEVBQUU7QUFGSyxXQURqQjtBQUtFLGtCQUFRLEVBQUUsa0JBQUNSLE1BQUQsRUFBU0MsYUFBVCxFQUEyQjtBQUNuQyxnQkFBSVYsS0FBSyxDQUFDSCxNQUFWLEVBQWtCO0FBQUE7O0FBQ2hCLGdDQUFBRyxLQUFLLENBQUNILE1BQU4sa0VBQWNjLEdBQWQsQ0FBa0IsVUFBQ0MsQ0FBRCxFQUFPO0FBQ3ZCLHVCQUFPcEIsSUFBUCxhQUFPQSxJQUFQLHVCQUFPQSxJQUFJLENBQUVtQixHQUFOLENBQVUsVUFBQ0UsQ0FBRCxFQUFPO0FBQ3RCLHNCQUFJRCxDQUFDLENBQUNFLFdBQUYsSUFBaUJELENBQUMsQ0FBQ0MsV0FBdkIsRUFBb0M7QUFDbEMsd0JBQUlELENBQUMsQ0FBQ0UsR0FBRixHQUFRQyxHQUFSLElBQWVKLENBQUMsQ0FBQ0ssTUFBckIsRUFBNkI7QUFDM0JYLHNCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0FBQ0Q7QUFDRjtBQUNGLGlCQU5NLENBQVA7QUFPRCxlQVJEO0FBU0Q7O0FBQ0QsZ0JBQUlmLElBQUksR0FBRztBQUNUSyxjQUFBQSxNQUFNLEVBQUVHLEtBQUssQ0FBQ0g7QUFETCxhQUFYLENBWm1DLENBZ0JuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDRCxXQWxDSDtBQUFBLG9CQW9DRyx3QkFBc0I7QUFBQSxnQkFBbkJXLFlBQW1CLFFBQW5CQSxZQUFtQjtBQUNyQixnQ0FDRSw4REFBQyw2Q0FBRDtBQUFNLHNCQUFRLEVBQUVBLFlBQWhCO0FBQUEseUJBQ0doQix1REFESCxhQUNHQSx1REFESCx1QkFDR0EsMkRBQUEsQ0FBVSxVQUFDcUIsQ0FBRCxFQUFJYSxFQUFKLEVBQVc7QUFDcEIsb0NBQ0U7QUFBZ0IsMkJBQVMsRUFBQyxNQUExQjtBQUFBLDBDQUNFLDhEQUFDLGtEQUFEO0FBQUEsK0JBQ0csR0FESCxFQUVHYixDQUFDLENBQUNhLEVBRkwsT0FFVUYsVUFGVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREYsZUFLRSw4REFBQyxxREFBRDtBQUFBLDhCQUFlWCxDQUFDLENBQUNjO0FBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTEYsZUFNRSw4REFBQyxpREFBRDtBQUFBLDhCQUFXZCxDQUFDLENBQUNlO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFORixlQU9FLDhEQUFDLDhDQUFEO0FBQ0Usd0JBQUksRUFBQyxRQURQO0FBRUUsMEJBQU0sRUFBRSxnQkFBQ0MsWUFBRCxFQUFrQjtBQUN4QiwwQ0FDRTtBQUFBLCtDQUNFLDhEQUFDLDRDQUFEO0FBQUEsaURBQ0UsOERBQUMsNENBQUQ7QUFBQSxtREFDRSw4REFBQyxrREFBRDtBQUFBLHFEQUNFLDhEQUFDLG1EQUFEO0FBQVkseUNBQVMsRUFBQyxvQkFBdEI7QUFBQSwwQ0FDR3BDLDBEQURILGFBQ0dBLDBEQURILHVCQUNHQSw4REFBQSxDQUFhLFVBQUNxQyxHQUFELEVBQVM7QUFDckIsc0RBQ0U7QUFFRSw2Q0FBUyxFQUFDLDZGQUZaO0FBQUEsNERBSUUsOERBQUMseUNBQUQ7QUFDRSwwQ0FBSSxFQUFDLE9BRFAsQ0FFRTtBQUZGO0FBR0UsMkNBQUssRUFBRUEsR0FBRyxDQUFDQyxZQUhiO0FBSUUsK0NBQVMsRUFBQyxRQUpaO0FBS0UsOENBQVEsRUFBRSxvQkFBTTtBQUNkN0Isd0NBQUFBLFFBQVEsQ0FBQztBQUNQWSwwQ0FBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNhLEVBRFI7QUFFUFQsMENBQUFBLE1BQU0sRUFBRWEsR0FBRyxDQUFDQztBQUZMLHlDQUFELENBQVI7O0FBS0EsNENBQUlsQyxNQUFNLENBQUM0QixNQUFQLEdBQWdCLENBQXBCLEVBQXVCO0FBQ3JCLCtDQUNFLElBQUlPLENBQUMsR0FBRyxDQURWLEVBRUVBLENBQUMsR0FBR25DLE1BQU0sQ0FBQzRCLE1BRmIsRUFHRU8sQ0FBQyxFQUhILEVBSUU7QUFBQTs7QUFDQSxnREFDRSxjQUFBbkMsTUFBTSxDQUFDbUMsQ0FBRCxDQUFOLHdEQUNJbEIsV0FESixLQUNtQkQsQ0FBQyxDQUFDYSxFQUZ2QixFQUdFO0FBQ0FwQiw4Q0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWjtBQUNBViw4Q0FBQUEsTUFBTSxDQUFDb0MsTUFBUCxDQUFjRCxDQUFkLEVBQWlCLENBQWpCLEVBQW9CO0FBQ2xCbEIsZ0RBQUFBLFdBQVcsRUFBRUQsQ0FBQyxDQUFDYSxFQURHO0FBRWxCVCxnREFBQUEsTUFBTSxFQUNKYSxHQUFHLENBQUNDO0FBSFksK0NBQXBCO0FBS0E7QUFDRCw2Q0FYRCxNQVdPLElBQ0xsQyxNQUFNLENBQUNtQyxDQUFELENBQU4sQ0FDR2xCLFdBREgsS0FDbUJELENBQUMsQ0FBQ2EsRUFGaEIsRUFHTDtBQUNBcEIsOENBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUNFLDBCQURGLEVBRUVNLENBQUMsQ0FBQ2EsRUFGSixFQUdFLGFBSEYsRUFJRTdCLE1BQU0sQ0FBQ21DLENBQUQsQ0FBTixDQUFVbEIsV0FKWjtBQU9BakIsOENBQUFBLE1BQU0sQ0FBQ3dCLElBQVAsQ0FBWTtBQUNWUCxnREFBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNhLEVBREw7QUFFVlQsZ0RBQUFBLE1BQU0sRUFDSmEsR0FBRyxDQUFDQyxZQUhJLENBSVY7O0FBSlUsK0NBQVo7QUFNQTtBQUNEO0FBQ0Y7QUFDRix5Q0FyQ0QsTUFxQ087QUFDTHpCLDBDQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBQ0FWLDBDQUFBQSxNQUFNLENBQUN3QixJQUFQLENBQVk7QUFDVlAsNENBQUFBLFdBQVcsRUFBRUQsQ0FBQyxDQUFDYSxFQURMO0FBRVZULDRDQUFBQSxNQUFNLEVBQUVhLEdBQUcsQ0FBQ0M7QUFGRiwyQ0FBWjtBQUlEO0FBQ0Y7QUF2REg7QUFBQTtBQUFBO0FBQUE7QUFBQSw2Q0FKRixFQTZER0QsR0FBRyxDQUFDSSxXQTdEUDtBQUFBLHFDQUNPSixHQUFHLENBQUNKLEVBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQ0FERjtBQWlFRCxpQ0FsRUE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFERjtBQXdGRDtBQTNGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVBGO0FBQUEsbUJBQVViLENBQUMsQ0FBQ2EsRUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGO0FBdUdELGVBeEdBLENBREgsZUEwR0U7QUFBSyx5QkFBUyxFQUFDLHFCQUFmO0FBQUEsdUNBQ0UsOERBQUMsK0NBQUQ7QUFDRSx1QkFBSyxNQURQO0FBRUUsMkJBQVMsRUFBQyxnQ0FGWjtBQUdFLHNCQUFJLEVBQUMsUUFIUCxDQUlFO0FBQ0E7QUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMUdGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERjtBQXdIRDtBQTdKSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQTJLRDs7R0F0TlEzQjtVQUVTSDs7O0tBRlRHOztBQXdOVCxJQUFNb0MsZUFBZSxHQUFHLFNBQWxCQSxlQUFrQixDQUFDQyxLQUFELEVBQVc7QUFDakMsU0FBTztBQUNMdkMsSUFBQUEsTUFBTSxFQUFFdUMsS0FBSyxDQUFDdkMsTUFBTixDQUFhQTtBQURoQixHQUFQO0FBR0QsQ0FKRDs7QUFNQSxJQUFNd0Msa0JBQWtCLEdBQUcsU0FBckJBLGtCQUFxQixDQUFDQyxRQUFELEVBQWM7QUFDdkMsU0FBTztBQUNMQyxJQUFBQSxhQUFhLEVBQUUsdUJBQUMvQyxJQUFEO0FBQUEsYUFBVThDLFFBQVEsQ0FBQzNDLHlEQUFBLENBQXNCSCxJQUF0QixDQUFELENBQWxCO0FBQUEsS0FEVjtBQUVMZ0QsSUFBQUEsY0FBYyxFQUFFLHdCQUFDaEQsSUFBRCxFQUFPa0MsRUFBUDtBQUFBLGFBQWNZLFFBQVEsQ0FBQzNDLHdEQUFBLENBQXFCSCxJQUFyQixFQUEyQmtDLEVBQTNCLENBQUQsQ0FBdEI7QUFBQSxLQUZYO0FBR0xnQixJQUFBQSxnQkFBZ0IsRUFBRSwwQkFBQ2xELElBQUQsRUFBT21ELElBQVAsRUFBYUMsTUFBYjtBQUFBLGFBQ2hCTixRQUFRLENBQUMzQywwREFBQSxDQUF1QkgsSUFBdkIsRUFBNkJtRCxJQUE3QixFQUFtQ0MsTUFBbkMsQ0FBRCxDQURRO0FBQUEsS0FIYjtBQUtMRSxJQUFBQSxrQkFBa0IsRUFBRSw0QkFBQ3RELElBQUQsRUFBT21ELElBQVAsRUFBYUMsTUFBYjtBQUFBLGFBQ2xCTixRQUFRLENBQUMzQyw0REFBQSxDQUF5QkgsSUFBekIsRUFBK0JtRCxJQUEvQixFQUFxQ0MsTUFBckMsQ0FBRCxDQURVO0FBQUEsS0FMZjtBQU9MSSxJQUFBQSxpQkFBaUIsRUFBRSwyQkFBQ3hELElBQUQ7QUFBQSxhQUFVOEMsUUFBUSxDQUFDM0MsNkRBQUEsQ0FBMEJILElBQTFCLENBQUQsQ0FBbEI7QUFBQTtBQVBkLEdBQVA7QUFTRCxDQVZEOztBQVdBLCtEQUFlRSxvREFBTyxDQUFDeUMsZUFBRCxFQUFrQkUsa0JBQWxCLENBQVAsQ0FBNkN0QyxJQUE3QyxDQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3BhZ2VzL2luZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcbmltcG9ydCB7IEZpZWxkLCBGaWVsZEFycmF5LCBGb3JtaWsgfSBmcm9tIFwiZm9ybWlrXCI7XG5pbXBvcnQgSGVhZCBmcm9tIFwibmV4dC9oZWFkXCI7XG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQge1xuICBCdXR0b24sXG4gIENhcmQsXG4gIENhcmRCb2R5LFxuICBDYXJkSGVhZGVyLFxuICBDYXJkU3VidGl0bGUsXG4gIENhcmRUZXh0LFxuICBDYXJkVGl0bGUsXG4gIENvbCxcbiAgRm9ybSxcbiAgRm9ybUdyb3VwLFxuICBJbnB1dEdyb3VwLFxuICBSb3csXG59IGZyb20gXCJyZWFjdHN0cmFwXCI7XG5pbXBvcnQgZGF0YSBmcm9tIFwiLi4vY29tcG9uZW50cy9EYXRhL0RhdGEuanNvblwiO1xuaW1wb3J0IG9wdGlvbnMgZnJvbSBcIi4uL2NvbXBvbmVudHMvRGF0YS9vcHRpb25zLmpzb25cIjtcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcbmltcG9ydCAqIGFzIGFjdGlvbnMgZnJvbSBcIi4uL3JlZHV4L2FjdGlvbnNcIjtcbmltcG9ydCB7IHVzZUhpc3RvcnkgfSBmcm9tIFwicmVhY3Qtcm91dGVyXCI7XG5cbnZhciByZXN1bHQgPSBuZXcgQXJyYXkoKTtcbmZ1bmN0aW9uIEhvbWUocHJvcHMpIHtcbiAgY29uc3QgW3ZhbHVlLCBzZXRWYWx1ZV0gPSB1c2VTdGF0ZSh7fSk7XG4gIGNvbnN0IGhpc3RvcnkgPSB1c2VIaXN0b3J5KCk7XG5cbiAgY29uc3QgW2NvbXBhbnksIHNldENvbXBhbnldID0gdXNlU3RhdGUoe30pO1xuXG4gIGNvbnNvbGUubG9nKFwicHJvcHMucmVzdWx0XCIsIHByb3BzLnJlc3VsdCk7XG5cbiAgY29uc29sZS5sb2coXCJ2YWx1ZVwiLCB2YWx1ZSk7XG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9ICh2YWx1ZXMsIHNldFN1Ym1pdHRpbmcpID0+IHtcbiAgICBpZiAocHJvcHMucmVzdWx0KSB7XG4gICAgICBwcm9wcy5yZXN1bHQ/Lm1hcCgocikgPT4ge1xuICAgICAgICBkYXRhPy5tYXAoKGQpID0+IHtcbiAgICAgICAgICBpZiAoci5xdWVzdGlvbl9pZCA9PSBkLnF1ZXN0aW9uX2lkKSB7XG4gICAgICAgICAgICBpZiAoZC5DRFUgLyBDU1UgPT0gci5hbnN3ZXIpIHtcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJhYWthc2hcIik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBsZXQgZGF0YSA9IHtcbiAgICAgIHJlc3VsdDogcmVzdWx0LFxuICAgIH07XG4gICAgY29uc29sZS5sb2coZGF0YSk7XG5cbiAgICBheGlvc1xuICAgICAgLnBvc3QoXCIvdGVzdFwiLCBkYXRhKVxuICAgICAgLnRoZW4oKHJlcykgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyhyZXMpO1xuICAgICAgICBjb25zb2xlLmxvZyhcImludGlhbCB2YWx1ZSBpcyBzdWJtaXRlZCB0byByZXN1bHRzXCIpO1xuICAgICAgICByZXN1bHQgPSBbXTtcbiAgICAgICAgaGlzdG9yeS5wdXNoKFwiL3RoYW5reW91XCIpO1xuICAgICAgfSlcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKGVyci5yZXNwb25zZS5kYXRhKTtcbiAgICAgICAgLy8gaGlzdG9yeS5wdXNoKFwiL2V4YW0tYXBwZWFyZWRcIik7XG4gICAgICAgIC8vIHJlc3VsdCA9IFtdO1xuICAgICAgfSk7XG4gIH07XG4gIGNvbnNvbGUubG9nKFwiYXJyYXlcIiwgcmVzdWx0KTtcbiAgY29uc3QgZGF0YUxlbmd0aCA9IGRhdGEubGVuZ3RoO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJcIj5cbiAgICAgIDxIZWFkPlxuICAgICAgICA8dGl0bGU+Q3JlYXRlIE5leHQgQXBwPC90aXRsZT5cbiAgICAgICAgPGxpbmsgcmVsPVwiaWNvblwiIGhyZWY9XCIvZmF2aWNvbi5pY29cIiAvPlxuICAgICAgPC9IZWFkPlxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC01IGJvcmRlci0yIHNoYWRvdy1tZCByb3VuZGVkLW1kXCI+XG4gICAgICAgIDxDYXJkQm9keT5cbiAgICAgICAgICA8Rm9ybWlrXG4gICAgICAgICAgICBpbml0aWFsVmFsdWVzPXt7XG4gICAgICAgICAgICAgIHJlc3VsdDogW10sXG4gICAgICAgICAgICAgIGFuc3dlcjogXCJcIixcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBvblN1Ym1pdD17KHZhbHVlcywgc2V0U3VibWl0dGluZykgPT4ge1xuICAgICAgICAgICAgICBpZiAocHJvcHMucmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgcHJvcHMucmVzdWx0Py5tYXAoKHIpID0+IHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBkYXRhPy5tYXAoKGQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHIucXVlc3Rpb25faWQgPT0gZC5xdWVzdGlvbl9pZCkge1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChkLkNEVSAvIENTVSA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJhYWthc2hcIik7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBsZXQgZGF0YSA9IHtcbiAgICAgICAgICAgICAgICByZXN1bHQ6IHByb3BzLnJlc3VsdCxcbiAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAvLyBheGlvc1xuICAgICAgICAgICAgICAvLyAgIC5wb3N0KFwiaHR0cHM6Ly91ZGl0c29sdXRpb25zLmluL3lhcm4vcHVibGljL2FwaS9zY29yZXNcIiwgZGF0YSlcbiAgICAgICAgICAgICAgLy8gICAudGhlbigocmVzKSA9PiB7XG4gICAgICAgICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhyZXMpO1xuICAgICAgICAgICAgICAvLyAgICAgY29uc29sZS5sb2coXCJpbnRpYWwgdmFsdWUgaXMgc3VibWl0ZWQgdG8gcmVzdWx0c1wiKTtcbiAgICAgICAgICAgICAgLy8gICAgIHJlc3VsdCA9IFtdO1xuICAgICAgICAgICAgICAvLyAgICAgaGlzdG9yeS5wdXNoKFwiL3RoYW5reW91XCIpO1xuICAgICAgICAgICAgICAvLyAgIH0pXG4gICAgICAgICAgICAgIC8vICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKGVyci5yZXNwb25zZS5kYXRhKTtcbiAgICAgICAgICAgICAgLy8gICAgIC8vIGhpc3RvcnkucHVzaChcIi9leGFtLWFwcGVhcmVkXCIpO1xuXG4gICAgICAgICAgICAgIC8vICAgfSk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHsoeyBoYW5kbGVTdWJtaXQgfSkgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxGb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxuICAgICAgICAgICAgICAgICAge2RhdGE/Lm1hcCgoZCwgaWQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17ZC5pZH0gY2xhc3NOYW1lPVwibXQtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcmRUaXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge1wiIFwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZC5pZH0ve2RhdGFMZW5ndGh9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NhcmRUaXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkU3VidGl0bGU+e2QuU2NobGFnd29ydH08L0NhcmRTdWJ0aXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkVGV4dD57ZC5xdWVzdGlvbl90ZXh0fTwvQ2FyZFRleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRBcnJheVxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVzdWx0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVuZGVyPXsoYXJyYXlIZWxwZXJzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSb3c+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dEdyb3VwIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcHRpb25zPy5tYXAoKG9wdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtvcHQuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGJnLWdyYXktNjAwIHRleHQtd2hpdGUgcm91bmRlZC1tZCB0ZXh0LWNlbnRlciBob3ZlcjpiZy15ZWxsb3ctMzAwIGhvdmVyOnRleHQtYmxhY2sgbWItMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBuYW1lPVwiYW5zd2VyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtvcHQub3B0aW9uX1ZhbHVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFZhbHVlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6IG9wdC5vcHRpb25fVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgaSA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpIDwgcmVzdWx0Lmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGkrK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/LnF1ZXN0aW9uX2lkID09IGQuaWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInNwbGljZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnNwbGljZShpLCAxLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25faWQ6IGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdFtpXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5xdWVzdGlvbl9pZCAhPT0gZC5pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZWxzZV9pZiBxdWVzdGlvbiBvZiBkYXRhXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInJlc3VsdCBxLWlkXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0W2ldLnF1ZXN0aW9uX2lkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uX2lkOiBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdC5vcHRpb25fVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZWxzZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjogb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcHQub3B0aW9uX3RleHR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6e1wiIFwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Jlc3VsdD8ubWFwKChyKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyLnF1ZXN0aW9uX2lkID09IGQuaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gci5hbnN3ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PiAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9JbnB1dEdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvUm93PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgYmxvY2tcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItMiBwLTIgYm9yZGVyLWJsYWNrIG10LTdcIlxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICAgIC8vIG9uQ2xpY2s9e2hhbmRsZVN1Ym1pdH1cbiAgICAgICAgICAgICAgICAgICAgICAvLyBkaXNhYmxlZD17Zm9ybVByb3BzLmlzU3VibWl0dGluZ31cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIEVlZ2VibmlzIHplaWdlblxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvRm9ybT5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPC9Gb3JtaWs+XG4gICAgICAgIDwvQ2FyZEJvZHk+XG4gICAgICA8L0NhcmQ+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IChzdGF0ZSkgPT4ge1xuICByZXR1cm4ge1xuICAgIHJlc3VsdDogc3RhdGUucmVzdWx0LnJlc3VsdCxcbiAgfTtcbn07XG5cbmNvbnN0IG1hcERpc3BhdGNoVG9Qcm9wcyA9IChkaXNwYXRjaCkgPT4ge1xuICByZXR1cm4ge1xuICAgIHJlc3VsdFNldERhdGE6IChkYXRhKSA9PiBkaXNwYXRjaChhY3Rpb25zLnJlc3VsdFNldERhdGEoZGF0YSkpLFxuICAgIG9uRGVsZXRlUmVzdWx0OiAoZGF0YSwgaWQpID0+IGRpc3BhdGNoKGFjdGlvbnMuZGVsZXRlUmVzdWx0KGRhdGEsIGlkKSksXG4gICAgb25Qb3N0UmVzdWx0RGF0YTogKGRhdGEsIHVzZXIsIHRvZ2dsZSkgPT5cbiAgICAgIGRpc3BhdGNoKGFjdGlvbnMucG9zdFJlc3VsdERhdGEoZGF0YSwgdXNlciwgdG9nZ2xlKSksXG4gICAgb25VcGRhdGVSZXN1bHREYXRhOiAoZGF0YSwgdXNlciwgdG9nZ2xlKSA9PlxuICAgICAgZGlzcGF0Y2goYWN0aW9ucy51cGRhdGVSZXN1bHREYXRhKGRhdGEsIHVzZXIsIHRvZ2dsZSkpLFxuICAgIHJlc3VsdEVkaXRHZXREYXRhOiAoZGF0YSkgPT4gZGlzcGF0Y2goYWN0aW9ucy5yZXN1bHRFZGl0R2V0RGF0YShkYXRhKSksXG4gIH07XG59O1xuZXhwb3J0IGRlZmF1bHQgY29ubmVjdChtYXBTdGF0ZVRvUHJvcHMsIG1hcERpc3BhdGNoVG9Qcm9wcykoSG9tZSk7XG4iXSwibmFtZXMiOlsiYXhpb3MiLCJGaWVsZCIsIkZpZWxkQXJyYXkiLCJGb3JtaWsiLCJIZWFkIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJCdXR0b24iLCJDYXJkIiwiQ2FyZEJvZHkiLCJDYXJkSGVhZGVyIiwiQ2FyZFN1YnRpdGxlIiwiQ2FyZFRleHQiLCJDYXJkVGl0bGUiLCJDb2wiLCJGb3JtIiwiRm9ybUdyb3VwIiwiSW5wdXRHcm91cCIsIlJvdyIsImRhdGEiLCJvcHRpb25zIiwiY29ubmVjdCIsImFjdGlvbnMiLCJ1c2VIaXN0b3J5IiwicmVzdWx0IiwiQXJyYXkiLCJIb21lIiwicHJvcHMiLCJ2YWx1ZSIsInNldFZhbHVlIiwiaGlzdG9yeSIsImNvbXBhbnkiLCJzZXRDb21wYW55IiwiY29uc29sZSIsImxvZyIsImhhbmRsZVN1Ym1pdCIsInZhbHVlcyIsInNldFN1Ym1pdHRpbmciLCJtYXAiLCJyIiwiZCIsInF1ZXN0aW9uX2lkIiwiQ0RVIiwiQ1NVIiwiYW5zd2VyIiwicG9zdCIsInRoZW4iLCJyZXMiLCJwdXNoIiwiZXJyIiwicmVzcG9uc2UiLCJkYXRhTGVuZ3RoIiwibGVuZ3RoIiwiaWQiLCJTY2hsYWd3b3J0IiwicXVlc3Rpb25fdGV4dCIsImFycmF5SGVscGVycyIsIm9wdCIsIm9wdGlvbl9WYWx1ZSIsImkiLCJzcGxpY2UiLCJvcHRpb25fdGV4dCIsIm1hcFN0YXRlVG9Qcm9wcyIsInN0YXRlIiwibWFwRGlzcGF0Y2hUb1Byb3BzIiwiZGlzcGF0Y2giLCJyZXN1bHRTZXREYXRhIiwib25EZWxldGVSZXN1bHQiLCJkZWxldGVSZXN1bHQiLCJvblBvc3RSZXN1bHREYXRhIiwidXNlciIsInRvZ2dsZSIsInBvc3RSZXN1bHREYXRhIiwib25VcGRhdGVSZXN1bHREYXRhIiwidXBkYXRlUmVzdWx0RGF0YSIsInJlc3VsdEVkaXRHZXREYXRhIl0sInNvdXJjZVJvb3QiOiIifQ==