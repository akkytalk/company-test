"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
/* harmony import */ var _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Data/Data.json */ "./components/Data/Data.json");
/* harmony import */ var _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Data/options.json */ "./components/Data/options.json");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _redux_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../redux/actions */ "./redux/actions/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "E:\\git vinraj\\company-test\\pages\\index.js",
    _s = $RefreshSig$();











var result = new Array();

function Home(props) {
  _s();

  var _this = this;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      value = _useState[0],
      setValue = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      company = _useState2[0],
      setCompany = _useState2[1];

  console.log("props.result", props.result);
  console.log("value", value);

  var handleSubmit = function handleSubmit(values, setSubmitting) {
    // if(props.result) {
    //     props.result?.map((r) => {
    //       data?.map((d) => {
    //         if(r.question_id == d.question_id) {
    //           if(d.CDU/CSU == )
    //         }
    //       })
    //     })
    // }
    var data = {
      result: result
    };
    console.log(data);
    axios__WEBPACK_IMPORTED_MODULE_0___default().post("/test", data).then(function (res) {
      console.log(res);
      console.log("intial value is submited to results");
      result = [];
      history.push("/thankyou");
    })["catch"](function (err) {
      console.log(err.response.data); // history.push("/exam-appeared");
      // result = [];
    });
  };

  console.log("array", result);
  var dataLength = _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.length;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
    className: "",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("title", {
        children: "Create Next App"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 70,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 69,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.Card, {
      className: "p-5 border-2 shadow-md rounded-md",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.CardBody, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
          initialValues: {
            result: [],
            answer: ""
          },
          onSubmit: handleSubmit,
          children: function children(formProps) {
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.Form, {
              children: [_components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === null || _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__ === void 0 ? void 0 : _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_4__.map(function (d, id) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                  className: "mt-3",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.CardTitle, {
                    children: [" ", d.id, "/", dataLength]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 88,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.CardSubtitle, {
                    children: d.Schlagwort
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 92,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.CardText, {
                    children: d.question_text
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 93,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.FieldArray, {
                    name: "result",
                    render: function render(arrayHelpers) {
                      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.Row, {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.Col, {
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.FormGroup, {
                              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.InputGroup, {
                                className: "flex flex-col mt-2",
                                children: _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === null || _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__ === void 0 ? void 0 : _components_Data_options_json__WEBPACK_IMPORTED_MODULE_5__.map(function (opt) {
                                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("label", {
                                    className: "p-2 bg-gray-600 text-white rounded-md text-center hover:bg-yellow-300 hover:text-black mb-1",
                                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                                      type: "radio" // name="answer"
                                      ,
                                      value: opt.option_Value,
                                      className: "hidden",
                                      onChange: function onChange() {
                                        setValue({
                                          question_id: d.id,
                                          answer: opt.option_Value
                                        });

                                        if (result.length > 0) {
                                          for (var i = 0; i < result.length; i++) {
                                            if (result[i].question_id == d.id) {
                                              console.log("splice");
                                              result.splice(i, 1, {
                                                question_id: d.id,
                                                answer: opt.option_Value
                                              });
                                              props.resultSetData(result);
                                              return;
                                            } else if (result[i].question_id !== d.id) {
                                              console.log("else_if");
                                              result.push({
                                                question_id: d.id,
                                                answer: opt.option_Value // value,

                                              });
                                              props.resultSetData(result);
                                              return;
                                            }
                                          }
                                        } else {
                                          console.log("else");
                                          result.push({
                                            question_id: d.id,
                                            answer: opt.option_Value
                                          });
                                          props.resultSetData(result);
                                        }
                                      }
                                    }, void 0, false, {
                                      fileName: _jsxFileName,
                                      lineNumber: 109,
                                      columnNumber: 47
                                    }, _this), opt.option_text]
                                  }, opt.id, true, {
                                    fileName: _jsxFileName,
                                    lineNumber: 105,
                                    columnNumber: 45
                                  }, _this);
                                })
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 102,
                                columnNumber: 39
                              }, _this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 101,
                              columnNumber: 37
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 100,
                            columnNumber: 35
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 99,
                          columnNumber: 33
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 98,
                        columnNumber: 31
                      }, _this);
                    }
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 94,
                    columnNumber: 25
                  }, _this)]
                }, d.id, true, {
                  fileName: _jsxFileName,
                  lineNumber: 87,
                  columnNumber: 23
                }, _this);
              }), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_9__.Button, {
                  block: true,
                  className: "border-2 p-2 border-black mt-7",
                  type: "submit" // disabled={formProps.isSubmitting}
                  ,
                  children: "Eegebnis zeigen"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 189,
                  columnNumber: 21
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 188,
                columnNumber: 19
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 84,
              columnNumber: 17
            }, _this);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 75,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 68,
    columnNumber: 5
  }, this);
}

_s(Home, "62pMvFIaPpKakEs86W5psllgCAs=");

_c = Home;

var mapStateToProps = function mapStateToProps(state) {
  return {
    result: state.result.result
  };
};

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    resultSetData: function resultSetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultSetData(data));
    },
    onDeleteResult: function onDeleteResult(data, id) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.deleteResult(data, id));
    },
    onPostResultData: function onPostResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.postResultData(data, user, toggle));
    },
    onUpdateResultData: function onUpdateResultData(data, user, toggle) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.updateResultData(data, user, toggle));
    },
    resultEditGetData: function resultEditGetData(data) {
      return dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_7__.resultEditGetData(data));
    }
  };
};

/* harmony default export */ __webpack_exports__["default"] = ((0,react_redux__WEBPACK_IMPORTED_MODULE_6__.connect)(mapStateToProps, mapDispatchToProps)(Home));

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ }),

/***/ "./redux/actions/ResultCreators.js":
/*!*****************************************!*\
  !*** ./redux/actions/ResultCreators.js ***!
  \*****************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "resultSetData": function() { return /* binding */ resultSetData; },
/* harmony export */   "resultFailData": function() { return /* binding */ resultFailData; },
/* harmony export */   "resultLoading": function() { return /* binding */ resultLoading; },
/* harmony export */   "resultGetData": function() { return /* binding */ resultGetData; },
/* harmony export */   "resultEditSetData": function() { return /* binding */ resultEditSetData; },
/* harmony export */   "resultEditFailData": function() { return /* binding */ resultEditFailData; },
/* harmony export */   "resultEditGetData": function() { return /* binding */ resultEditGetData; },
/* harmony export */   "deleteResultFail": function() { return /* binding */ deleteResultFail; },
/* harmony export */   "deleteResult": function() { return /* binding */ deleteResult; },
/* harmony export */   "postResultDataStart": function() { return /* binding */ postResultDataStart; },
/* harmony export */   "postResultDataFail": function() { return /* binding */ postResultDataFail; },
/* harmony export */   "postResultData": function() { return /* binding */ postResultData; },
/* harmony export */   "updateResultDataStart": function() { return /* binding */ updateResultDataStart; },
/* harmony export */   "updateResultData": function() { return /* binding */ updateResultData; }
/* harmony export */ });
/* harmony import */ var _ActionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ActionTypes */ "./redux/actions/ActionTypes.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var sweetalert__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! sweetalert */ "./node_modules/sweetalert/dist/sweetalert.min.js");
/* harmony import */ var sweetalert__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(sweetalert__WEBPACK_IMPORTED_MODULE_2__);
/* module decorator */ module = __webpack_require__.hmd(module);


 // import { baseUrl } from "../../shared/baseUrl";

var resultSetData = function resultSetData(result) {
  return {
    type: _ActionTypes__WEBPACK_IMPORTED_MODULE_0__.RESULT_SET_DATA,
    result: result
  };
};
var resultFailData = function resultFailData(error) {
  return {
    type: _ActionTypes__WEBPACK_IMPORTED_MODULE_0__.RESULT_FAIL_DATA,
    error: error
  };
};
var resultLoading = function resultLoading() {
  return {
    type: _ActionTypes__WEBPACK_IMPORTED_MODULE_0__.RESULT_LOADING
  };
};
var resultGetData = function resultGetData(data) {// return (dispatch) => {
  //   dispatch(resultLoading());
  //   axios
  //     .get(baseUrl + `result/${data?.id}`, {
  //       headers: {
  //         Accept: "application/json",
  //         "Content-Type": "application/json",
  //         Authorization: "Bearer " + data.token,
  //       },
  //     })
  //     .then((res) => {
  //       dispatch(resultSetData(res.data));
  //       console.log("graph data", res.data);
  //     })
  //     .catch((error) => dispatch(resultFailData(error)));
  // };
}; // export const testReportData = (data) => {
//   return (dispatch) => {
//     dispatch(resultLoading());
//     axios
//       .get(baseUrl + "getTemp", {
//         headers: {
//           Accept: "application/json",
//           "Content-Type": "application/json",
//           Authorization: "Bearer " + data.token,
//         },
//       })
//       .then((res) => {
//         dispatch(resultEditSetData(res.data));
//         console.log("response data", res.data);
//       })
//       .catch((error) => dispatch(resultEditFailData(error)));
//   };
// };

var resultEditSetData = function resultEditSetData(mainResult) {
  return {
    type: _ActionTypes__WEBPACK_IMPORTED_MODULE_0__.RESULT_EDIT_SET_DATA,
    mainResult: mainResult
  };
};
var resultEditFailData = function resultEditFailData(error) {
  return {
    type: _ActionTypes__WEBPACK_IMPORTED_MODULE_0__.RESULT_EDIT_FAIL_DATA,
    error: error
  };
};
var resultEditGetData = function resultEditGetData(data) {// return (dispatch) => {
  //   dispatch(resultLoading());
  //   axios
  //     .get(baseUrl + `getTemp/${data?.id}`, {
  //       headers: {
  //         Accept: "application/json",
  //         "Content-Type": "application/json",
  //         Authorization: "Bearer " + data.token,
  //       },
  //     })
  //     .then((res) => {
  //       dispatch(resultEditSetData(res.data));
  //       console.log("response data", res.data);
  //     })
  //     .catch((error) => dispatch(resultEditFailData(error)));
  // };
};
var deleteResultFail = function deleteResultFail(error) {
  return {
    type: _ActionTypes__WEBPACK_IMPORTED_MODULE_0__.DELETE_RESULT_FAIL,
    error: error
  };
};
var deleteResult = function deleteResult(data, id) {// return (dispatch) => {
  //   if (id) {
  //     axios
  //       .delete(baseUrl + `result/${id}`, {
  //         headers: {
  //           Accept: "application/json",
  //           "Content-Type": "application/json",
  //           Authorization: "Bearer " + data?.token,
  //         },
  //       })
  //       .then(() => {
  //         console.log("swal");
  //         swal("Successfully Deleted  Result!").then(() => {
  //           dispatch(resultGetData(data));
  //         });
  //       })
  //       .catch((error) => dispatch(deleteResultFail(error)));
  //   }
  // };
};
var postResultDataStart = function postResultDataStart() {
  return {
    type: _ActionTypes__WEBPACK_IMPORTED_MODULE_0__.POST_RESULT_DATA_START
  };
};
var postResultDataFail = function postResultDataFail(error) {
  return {
    type: _ActionTypes__WEBPACK_IMPORTED_MODULE_0__.POST_RESULT_DATA_FAIL,
    error: error
  };
};
var postResultData = function postResultData(data, user, toggle) {// return (dispatch) => {
  //   dispatch(postResultDataStart());
  //   axios
  //     .post(baseUrl + "result", user, {
  //       headers: {
  //         Accept: "application/json",
  //         "Content-Type": "application/json",
  //         Authorization: "Bearer " + data?.token,
  //       },
  //     })
  //     .then(() => {
  //       console.log("swal");
  //       swal("Successfully Created  Result!").then(() => {
  //         dispatch(resultGetData(data));
  //         toggle();
  //       });
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //       dispatch(postResultDataFail(error));
  //     });
  // };
};
var updateResultDataStart = function updateResultDataStart() {
  return {
    type: _ActionTypes__WEBPACK_IMPORTED_MODULE_0__.UPDATE_RESULT_DATA_START
  };
};
var updateResultData = function updateResultData(data, user, toggle) {// return (dispatch) => {
  //   dispatch(updateResultDataStart());
  //   axios
  //     .post(baseUrl + `result/${data.id}?_method=PUT`, user, {
  //       headers: {
  //         Accept: "application/json",
  //         "Content-Type": "application/json",
  //         Authorization: "Bearer " + data.token,
  //       },
  //     })
  //     .then(() => {
  //       console.log("swal");
  //       swal("Successfully Updated  Result!").then(() => {
  //         toggle();
  //         dispatch(resultGetData(data));
  //       });
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  // };
};

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguMzRhZjYwODk0YTA5NzQ5YWVlYTguaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLElBQUl1QixNQUFNLEdBQUcsSUFBSUMsS0FBSixFQUFiOztBQUNBLFNBQVNDLElBQVQsQ0FBY0MsS0FBZCxFQUFxQjtBQUFBOztBQUFBOztBQUNuQixrQkFBMEJwQiwrQ0FBUSxDQUFDLEVBQUQsQ0FBbEM7QUFBQSxNQUFPcUIsS0FBUDtBQUFBLE1BQWNDLFFBQWQ7O0FBRUEsbUJBQThCdEIsK0NBQVEsQ0FBQyxFQUFELENBQXRDO0FBQUEsTUFBT3VCLE9BQVA7QUFBQSxNQUFnQkMsVUFBaEI7O0FBRUFDLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGNBQVosRUFBNEJOLEtBQUssQ0FBQ0gsTUFBbEM7QUFFQVEsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFxQkwsS0FBckI7O0FBQ0EsTUFBTU0sWUFBWSxHQUFHLFNBQWZBLFlBQWUsQ0FBQ0MsTUFBRCxFQUFTQyxhQUFULEVBQTJCO0FBQzlDO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBLFFBQUloQixJQUFJLEdBQUc7QUFDVEksTUFBQUEsTUFBTSxFQUFFQTtBQURDLEtBQVg7QUFHQVEsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVliLElBQVo7QUFFQW5CLElBQUFBLGlEQUFBLENBQ1EsT0FEUixFQUNpQm1CLElBRGpCLEVBRUdrQixJQUZILENBRVEsVUFBQ0MsR0FBRCxFQUFTO0FBQ2JQLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZTSxHQUFaO0FBQ0FQLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLHFDQUFaO0FBQ0FULE1BQUFBLE1BQU0sR0FBRyxFQUFUO0FBQ0FnQixNQUFBQSxPQUFPLENBQUNDLElBQVIsQ0FBYSxXQUFiO0FBQ0QsS0FQSCxXQVFTLFVBQUNDLEdBQUQsRUFBUztBQUNkVixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWVMsR0FBRyxDQUFDQyxRQUFKLENBQWF2QixJQUF6QixFQURjLENBRWQ7QUFDQTtBQUNELEtBWkg7QUFhRCxHQTlCRDs7QUErQkFZLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVosRUFBcUJULE1BQXJCO0FBQ0EsTUFBTW9CLFVBQVUsR0FBR3hCLDhEQUFuQjtBQUVBLHNCQUNFO0FBQUssYUFBUyxFQUFDLEVBQWY7QUFBQSw0QkFDRSw4REFBQyxrREFBRDtBQUFBLDhCQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFRTtBQUFNLFdBQUcsRUFBQyxNQUFWO0FBQWlCLFlBQUksRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFLRSw4REFBQyw0Q0FBRDtBQUFNLGVBQVMsRUFBQyxtQ0FBaEI7QUFBQSw2QkFDRSw4REFBQyxnREFBRDtBQUFBLCtCQUNFLDhEQUFDLDBDQUFEO0FBQ0UsdUJBQWEsRUFBRTtBQUNiSSxZQUFBQSxNQUFNLEVBQUUsRUFESztBQUVic0IsWUFBQUEsTUFBTSxFQUFFO0FBRkssV0FEakI7QUFLRSxrQkFBUSxFQUFFWixZQUxaO0FBQUEsb0JBT0csa0JBQUNhLFNBQUQsRUFBZTtBQUNkLGdDQUNFLDhEQUFDLDRDQUFEO0FBQUEseUJBQ0czQix1REFESCxhQUNHQSx1REFESCx1QkFDR0EsMkRBQUEsQ0FBVSxVQUFDNkIsQ0FBRCxFQUFJQyxFQUFKLEVBQVc7QUFDcEIsb0NBQ0U7QUFBZ0IsMkJBQVMsRUFBQyxNQUExQjtBQUFBLDBDQUNFLDhEQUFDLGlEQUFEO0FBQUEsK0JBQ0csR0FESCxFQUVHRCxDQUFDLENBQUNDLEVBRkwsT0FFVU4sVUFGVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREYsZUFLRSw4REFBQyxvREFBRDtBQUFBLDhCQUFlSyxDQUFDLENBQUNFO0FBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTEYsZUFNRSw4REFBQyxnREFBRDtBQUFBLDhCQUFXRixDQUFDLENBQUNHO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFORixlQU9FLDhEQUFDLDhDQUFEO0FBQ0Usd0JBQUksRUFBQyxRQURQO0FBRUUsMEJBQU0sRUFBRSxnQkFBQ0MsWUFBRCxFQUFrQjtBQUN4QiwwQ0FDRTtBQUFBLCtDQUNFLDhEQUFDLDJDQUFEO0FBQUEsaURBQ0UsOERBQUMsMkNBQUQ7QUFBQSxtREFDRSw4REFBQyxpREFBRDtBQUFBLHFEQUNFLDhEQUFDLGtEQUFEO0FBQVkseUNBQVMsRUFBQyxvQkFBdEI7QUFBQSwwQ0FDR2hDLDBEQURILGFBQ0dBLDBEQURILHVCQUNHQSw4REFBQSxDQUFhLFVBQUNpQyxHQUFELEVBQVM7QUFDckIsc0RBQ0U7QUFFRSw2Q0FBUyxFQUFDLDZGQUZaO0FBQUEsNERBSUUsOERBQUMseUNBQUQ7QUFDRSwwQ0FBSSxFQUFDLE9BRFAsQ0FFRTtBQUZGO0FBR0UsMkNBQUssRUFBRUEsR0FBRyxDQUFDQyxZQUhiO0FBSUUsK0NBQVMsRUFBQyxRQUpaO0FBS0UsOENBQVEsRUFBRSxvQkFBTTtBQUNkMUIsd0NBQUFBLFFBQVEsQ0FBQztBQUNQMkIsMENBQUFBLFdBQVcsRUFBRVAsQ0FBQyxDQUFDQyxFQURSO0FBRVBKLDBDQUFBQSxNQUFNLEVBQUVRLEdBQUcsQ0FBQ0M7QUFGTCx5Q0FBRCxDQUFSOztBQUtBLDRDQUFJL0IsTUFBTSxDQUFDcUIsTUFBUCxHQUFnQixDQUFwQixFQUF1QjtBQUNyQiwrQ0FDRSxJQUFJWSxDQUFDLEdBQUcsQ0FEVixFQUVFQSxDQUFDLEdBQUdqQyxNQUFNLENBQUNxQixNQUZiLEVBR0VZLENBQUMsRUFISCxFQUlFO0FBQ0EsZ0RBQ0VqQyxNQUFNLENBQUNpQyxDQUFELENBQU4sQ0FBVUQsV0FBVixJQUNBUCxDQUFDLENBQUNDLEVBRkosRUFHRTtBQUNBbEIsOENBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVo7QUFDQVQsOENBQUFBLE1BQU0sQ0FBQ2tDLE1BQVAsQ0FBY0QsQ0FBZCxFQUFpQixDQUFqQixFQUFvQjtBQUNsQkQsZ0RBQUFBLFdBQVcsRUFBRVAsQ0FBQyxDQUFDQyxFQURHO0FBRWxCSixnREFBQUEsTUFBTSxFQUNKUSxHQUFHLENBQUNDO0FBSFksK0NBQXBCO0FBTUE1Qiw4Q0FBQUEsS0FBSyxDQUFDZ0MsYUFBTixDQUNFbkMsTUFERjtBQUdBO0FBQ0QsNkNBZkQsTUFlTyxJQUNMQSxNQUFNLENBQUNpQyxDQUFELENBQU4sQ0FDR0QsV0FESCxLQUNtQlAsQ0FBQyxDQUFDQyxFQUZoQixFQUdMO0FBQ0FsQiw4Q0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWjtBQUVBVCw4Q0FBQUEsTUFBTSxDQUFDaUIsSUFBUCxDQUFZO0FBQ1ZlLGdEQUFBQSxXQUFXLEVBQUVQLENBQUMsQ0FBQ0MsRUFETDtBQUVWSixnREFBQUEsTUFBTSxFQUNKUSxHQUFHLENBQUNDLFlBSEksQ0FJVjs7QUFKVSwrQ0FBWjtBQU1BNUIsOENBQUFBLEtBQUssQ0FBQ2dDLGFBQU4sQ0FDRW5DLE1BREY7QUFHQTtBQUNEO0FBQ0Y7QUFDRix5Q0F2Q0QsTUF1Q087QUFDTFEsMENBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVo7QUFDQVQsMENBQUFBLE1BQU0sQ0FBQ2lCLElBQVAsQ0FBWTtBQUNWZSw0Q0FBQUEsV0FBVyxFQUFFUCxDQUFDLENBQUNDLEVBREw7QUFFVkosNENBQUFBLE1BQU0sRUFBRVEsR0FBRyxDQUFDQztBQUZGLDJDQUFaO0FBSUE1QiwwQ0FBQUEsS0FBSyxDQUFDZ0MsYUFBTixDQUFvQm5DLE1BQXBCO0FBQ0Q7QUFDRjtBQTFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZDQUpGLEVBZ0VHOEIsR0FBRyxDQUFDTSxXQWhFUDtBQUFBLHFDQUNPTixHQUFHLENBQUNKLEVBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQ0FERjtBQW9FRCxpQ0FyRUE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFERjtBQXNGRDtBQXpGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVBGO0FBQUEsbUJBQVVELENBQUMsQ0FBQ0MsRUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGO0FBcUdELGVBdEdBLENBREgsZUF3R0U7QUFBSyx5QkFBUyxFQUFDLHFCQUFmO0FBQUEsdUNBQ0UsOERBQUMsOENBQUQ7QUFDRSx1QkFBSyxNQURQO0FBRUUsMkJBQVMsRUFBQyxnQ0FGWjtBQUdFLHNCQUFJLEVBQUMsUUFIUCxDQUlFO0FBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXhHRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREY7QUFxSEQ7QUE3SEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUEySUQ7O0dBckxReEI7O0tBQUFBOztBQXVMVCxJQUFNbUMsZUFBZSxHQUFHLFNBQWxCQSxlQUFrQixDQUFDQyxLQUFELEVBQVc7QUFDakMsU0FBTztBQUNMdEMsSUFBQUEsTUFBTSxFQUFFc0MsS0FBSyxDQUFDdEMsTUFBTixDQUFhQTtBQURoQixHQUFQO0FBR0QsQ0FKRDs7QUFNQSxJQUFNdUMsa0JBQWtCLEdBQUcsU0FBckJBLGtCQUFxQixDQUFDQyxRQUFELEVBQWM7QUFDdkMsU0FBTztBQUNMTCxJQUFBQSxhQUFhLEVBQUUsdUJBQUN2QyxJQUFEO0FBQUEsYUFBVTRDLFFBQVEsQ0FBQ3pDLHlEQUFBLENBQXNCSCxJQUF0QixDQUFELENBQWxCO0FBQUEsS0FEVjtBQUVMNkMsSUFBQUEsY0FBYyxFQUFFLHdCQUFDN0MsSUFBRCxFQUFPOEIsRUFBUDtBQUFBLGFBQWNjLFFBQVEsQ0FBQ3pDLHdEQUFBLENBQXFCSCxJQUFyQixFQUEyQjhCLEVBQTNCLENBQUQsQ0FBdEI7QUFBQSxLQUZYO0FBR0xpQixJQUFBQSxnQkFBZ0IsRUFBRSwwQkFBQy9DLElBQUQsRUFBT2dELElBQVAsRUFBYUMsTUFBYjtBQUFBLGFBQ2hCTCxRQUFRLENBQUN6QywwREFBQSxDQUF1QkgsSUFBdkIsRUFBNkJnRCxJQUE3QixFQUFtQ0MsTUFBbkMsQ0FBRCxDQURRO0FBQUEsS0FIYjtBQUtMRSxJQUFBQSxrQkFBa0IsRUFBRSw0QkFBQ25ELElBQUQsRUFBT2dELElBQVAsRUFBYUMsTUFBYjtBQUFBLGFBQ2xCTCxRQUFRLENBQUN6Qyw0REFBQSxDQUF5QkgsSUFBekIsRUFBK0JnRCxJQUEvQixFQUFxQ0MsTUFBckMsQ0FBRCxDQURVO0FBQUEsS0FMZjtBQU9MSSxJQUFBQSxpQkFBaUIsRUFBRSwyQkFBQ3JELElBQUQ7QUFBQSxhQUFVNEMsUUFBUSxDQUFDekMsNkRBQUEsQ0FBMEJILElBQTFCLENBQUQsQ0FBbEI7QUFBQTtBQVBkLEdBQVA7QUFTRCxDQVZEOztBQVdBLCtEQUFlRSxvREFBTyxDQUFDdUMsZUFBRCxFQUFrQkUsa0JBQWxCLENBQVAsQ0FBNkNyQyxJQUE3QyxDQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoT0E7QUFDQTtDQUVBOztBQUVPLElBQU1pQyxhQUFhLEdBQUcsU0FBaEJBLGFBQWdCLENBQUNuQyxNQUFELEVBQVk7QUFDdkMsU0FBTztBQUNMb0QsSUFBQUEsSUFBSSxFQUFFRix5REFERDtBQUVMbEQsSUFBQUEsTUFBTSxFQUFFQTtBQUZILEdBQVA7QUFJRCxDQUxNO0FBT0EsSUFBTXNELGNBQWMsR0FBRyxTQUFqQkEsY0FBaUIsQ0FBQ0MsS0FBRCxFQUFXO0FBQ3ZDLFNBQU87QUFDTEgsSUFBQUEsSUFBSSxFQUFFRiwwREFERDtBQUVMSyxJQUFBQSxLQUFLLEVBQUVBO0FBRkYsR0FBUDtBQUlELENBTE07QUFNQSxJQUFNRSxhQUFhLEdBQUcsU0FBaEJBLGFBQWdCLEdBQU07QUFDakMsU0FBTztBQUNMTCxJQUFBQSxJQUFJLEVBQUVGLHdEQUF5QlE7QUFEMUIsR0FBUDtBQUdELENBSk07QUFLQSxJQUFNQyxhQUFhLEdBQUcsU0FBaEJBLGFBQWdCLENBQUMvRCxJQUFELEVBQVUsQ0FDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDRCxDQWpCTSxFQW1CUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBRU8sSUFBTWdFLGlCQUFpQixHQUFHLFNBQXBCQSxpQkFBb0IsQ0FBQ0MsVUFBRCxFQUFnQjtBQUMvQyxTQUFPO0FBQ0xULElBQUFBLElBQUksRUFBRUYsOERBREQ7QUFFTFcsSUFBQUEsVUFBVSxFQUFFQTtBQUZQLEdBQVA7QUFJRCxDQUxNO0FBT0EsSUFBTUUsa0JBQWtCLEdBQUcsU0FBckJBLGtCQUFxQixDQUFDUixLQUFELEVBQVc7QUFDM0MsU0FBTztBQUNMSCxJQUFBQSxJQUFJLEVBQUVGLCtEQUREO0FBRUxLLElBQUFBLEtBQUssRUFBRUE7QUFGRixHQUFQO0FBSUQsQ0FMTTtBQU9BLElBQU1OLGlCQUFpQixHQUFHLFNBQXBCQSxpQkFBb0IsQ0FBQ3JELElBQUQsRUFBVSxDQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNELENBakJNO0FBbUJBLElBQU1xRSxnQkFBZ0IsR0FBRyxTQUFuQkEsZ0JBQW1CLENBQUNWLEtBQUQsRUFBVztBQUN6QyxTQUFPO0FBQ0xILElBQUFBLElBQUksRUFBRUYsNERBREQ7QUFFTEssSUFBQUEsS0FBSyxFQUFFQTtBQUZGLEdBQVA7QUFJRCxDQUxNO0FBT0EsSUFBTWIsWUFBWSxHQUFHLFNBQWZBLFlBQWUsQ0FBQzlDLElBQUQsRUFBTzhCLEVBQVAsRUFBYyxDQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNELENBcEJNO0FBc0JBLElBQU15QyxtQkFBbUIsR0FBRyxTQUF0QkEsbUJBQXNCLEdBQU07QUFDdkMsU0FBTztBQUNMZixJQUFBQSxJQUFJLEVBQUVGLGdFQUFpQ2tCO0FBRGxDLEdBQVA7QUFHRCxDQUpNO0FBTUEsSUFBTUMsa0JBQWtCLEdBQUcsU0FBckJBLGtCQUFxQixDQUFDZCxLQUFELEVBQVc7QUFDM0MsU0FBTztBQUNMSCxJQUFBQSxJQUFJLEVBQUVGLCtEQUREO0FBRUxLLElBQUFBLEtBQUssRUFBRUE7QUFGRixHQUFQO0FBSUQsQ0FMTTtBQU9BLElBQU1ULGNBQWMsR0FBRyxTQUFqQkEsY0FBaUIsQ0FBQ2xELElBQUQsRUFBT2dELElBQVAsRUFBYUMsTUFBYixFQUF3QixDQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNELENBdkJNO0FBeUJBLElBQU0wQixxQkFBcUIsR0FBRyxTQUF4QkEscUJBQXdCLEdBQU07QUFDekMsU0FBTztBQUNMbkIsSUFBQUEsSUFBSSxFQUFFRixrRUFBbUNzQjtBQURwQyxHQUFQO0FBR0QsQ0FKTTtBQU1BLElBQU14QixnQkFBZ0IsR0FBRyxTQUFuQkEsZ0JBQW1CLENBQUNwRCxJQUFELEVBQU9nRCxJQUFQLEVBQWFDLE1BQWIsRUFBd0IsQ0FDdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0QsQ0F0Qk0iLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vX05fRS8uL3JlZHV4L2FjdGlvbnMvUmVzdWx0Q3JlYXRvcnMuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xuaW1wb3J0IHsgRmllbGQsIEZpZWxkQXJyYXksIEZvcm1payB9IGZyb20gXCJmb3JtaWtcIjtcbmltcG9ydCBIZWFkIGZyb20gXCJuZXh0L2hlYWRcIjtcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7XG4gIEJ1dHRvbixcbiAgQ2FyZCxcbiAgQ2FyZEJvZHksXG4gIENhcmRIZWFkZXIsXG4gIENhcmRTdWJ0aXRsZSxcbiAgQ2FyZFRleHQsXG4gIENhcmRUaXRsZSxcbiAgQ29sLFxuICBGb3JtLFxuICBGb3JtR3JvdXAsXG4gIElucHV0R3JvdXAsXG4gIFJvdyxcbn0gZnJvbSBcInJlYWN0c3RyYXBcIjtcbmltcG9ydCBkYXRhIGZyb20gXCIuLi9jb21wb25lbnRzL0RhdGEvRGF0YS5qc29uXCI7XG5pbXBvcnQgb3B0aW9ucyBmcm9tIFwiLi4vY29tcG9uZW50cy9EYXRhL29wdGlvbnMuanNvblwiO1xuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xuaW1wb3J0ICogYXMgYWN0aW9ucyBmcm9tIFwiLi4vcmVkdXgvYWN0aW9uc1wiO1xuXG52YXIgcmVzdWx0ID0gbmV3IEFycmF5KCk7XG5mdW5jdGlvbiBIb21lKHByb3BzKSB7XG4gIGNvbnN0IFt2YWx1ZSwgc2V0VmFsdWVdID0gdXNlU3RhdGUoe30pO1xuXG4gIGNvbnN0IFtjb21wYW55LCBzZXRDb21wYW55XSA9IHVzZVN0YXRlKHt9KTtcblxuICBjb25zb2xlLmxvZyhcInByb3BzLnJlc3VsdFwiLCBwcm9wcy5yZXN1bHQpO1xuXG4gIGNvbnNvbGUubG9nKFwidmFsdWVcIiwgdmFsdWUpO1xuICBjb25zdCBoYW5kbGVTdWJtaXQgPSAodmFsdWVzLCBzZXRTdWJtaXR0aW5nKSA9PiB7XG4gICAgLy8gaWYocHJvcHMucmVzdWx0KSB7XG5cbiAgICAvLyAgICAgcHJvcHMucmVzdWx0Py5tYXAoKHIpID0+IHtcbiAgICAvLyAgICAgICBkYXRhPy5tYXAoKGQpID0+IHtcbiAgICAvLyAgICAgICAgIGlmKHIucXVlc3Rpb25faWQgPT0gZC5xdWVzdGlvbl9pZCkge1xuICAgIC8vICAgICAgICAgICBpZihkLkNEVS9DU1UgPT0gKVxuICAgIC8vICAgICAgICAgfVxuICAgIC8vICAgICAgIH0pXG4gICAgLy8gICAgIH0pXG5cbiAgICAvLyB9XG4gICAgbGV0IGRhdGEgPSB7XG4gICAgICByZXN1bHQ6IHJlc3VsdCxcbiAgICB9O1xuICAgIGNvbnNvbGUubG9nKGRhdGEpO1xuXG4gICAgYXhpb3NcbiAgICAgIC5wb3N0KFwiL3Rlc3RcIiwgZGF0YSlcbiAgICAgIC50aGVuKChyZXMpID0+IHtcbiAgICAgICAgY29uc29sZS5sb2cocmVzKTtcbiAgICAgICAgY29uc29sZS5sb2coXCJpbnRpYWwgdmFsdWUgaXMgc3VibWl0ZWQgdG8gcmVzdWx0c1wiKTtcbiAgICAgICAgcmVzdWx0ID0gW107XG4gICAgICAgIGhpc3RvcnkucHVzaChcIi90aGFua3lvdVwiKTtcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyhlcnIucmVzcG9uc2UuZGF0YSk7XG4gICAgICAgIC8vIGhpc3RvcnkucHVzaChcIi9leGFtLWFwcGVhcmVkXCIpO1xuICAgICAgICAvLyByZXN1bHQgPSBbXTtcbiAgICAgIH0pO1xuICB9O1xuICBjb25zb2xlLmxvZyhcImFycmF5XCIsIHJlc3VsdCk7XG4gIGNvbnN0IGRhdGFMZW5ndGggPSBkYXRhLmxlbmd0aDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiXCI+XG4gICAgICA8SGVhZD5cbiAgICAgICAgPHRpdGxlPkNyZWF0ZSBOZXh0IEFwcDwvdGl0bGU+XG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cbiAgICAgIDwvSGVhZD5cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNSBib3JkZXItMiBzaGFkb3ctbWQgcm91bmRlZC1tZFwiPlxuICAgICAgICA8Q2FyZEJvZHk+XG4gICAgICAgICAgPEZvcm1pa1xuICAgICAgICAgICAgaW5pdGlhbFZhbHVlcz17e1xuICAgICAgICAgICAgICByZXN1bHQ6IFtdLFxuICAgICAgICAgICAgICBhbnN3ZXI6IFwiXCIsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7KGZvcm1Qcm9wcykgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxGb3JtPlxuICAgICAgICAgICAgICAgICAge2RhdGE/Lm1hcCgoZCwgaWQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17ZC5pZH0gY2xhc3NOYW1lPVwibXQtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcmRUaXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge1wiIFwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZC5pZH0ve2RhdGFMZW5ndGh9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NhcmRUaXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkU3VidGl0bGU+e2QuU2NobGFnd29ydH08L0NhcmRTdWJ0aXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkVGV4dD57ZC5xdWVzdGlvbl90ZXh0fTwvQ2FyZFRleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRBcnJheVxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVzdWx0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVuZGVyPXsoYXJyYXlIZWxwZXJzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSb3c+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dEdyb3VwIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcHRpb25zPy5tYXAoKG9wdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtvcHQuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGJnLWdyYXktNjAwIHRleHQtd2hpdGUgcm91bmRlZC1tZCB0ZXh0LWNlbnRlciBob3ZlcjpiZy15ZWxsb3ctMzAwIGhvdmVyOnRleHQtYmxhY2sgbWItMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBuYW1lPVwiYW5zd2VyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtvcHQub3B0aW9uX1ZhbHVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFZhbHVlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6IG9wdC5vcHRpb25fVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgaSA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpIDwgcmVzdWx0Lmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGkrK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV0ucXVlc3Rpb25faWQgPT1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZC5pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic3BsaWNlXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQuc3BsaWNlKGksIDEsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHQub3B0aW9uX1ZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wcy5yZXN1bHRTZXREYXRhKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucXVlc3Rpb25faWQgIT09IGQuaWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImVsc2VfaWZcIik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uX2lkOiBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdC5vcHRpb25fVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wcy5yZXN1bHRTZXREYXRhKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZWxzZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjogb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wcy5yZXN1bHRTZXREYXRhKHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3B0Lm9wdGlvbl90ZXh0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjoge2Zvcm1Qcm9wcy52YWx1ZXMuYW5zd2VyfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvSW5wdXRHcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIGJsb2NrXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLTIgcC0yIGJvcmRlci1ibGFjayBtdC03XCJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAvLyBkaXNhYmxlZD17Zm9ybVByb3BzLmlzU3VibWl0dGluZ31cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIEVlZ2VibmlzIHplaWdlblxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvRm9ybT5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPC9Gb3JtaWs+XG4gICAgICAgIDwvQ2FyZEJvZHk+XG4gICAgICA8L0NhcmQ+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IChzdGF0ZSkgPT4ge1xuICByZXR1cm4ge1xuICAgIHJlc3VsdDogc3RhdGUucmVzdWx0LnJlc3VsdCxcbiAgfTtcbn07XG5cbmNvbnN0IG1hcERpc3BhdGNoVG9Qcm9wcyA9IChkaXNwYXRjaCkgPT4ge1xuICByZXR1cm4ge1xuICAgIHJlc3VsdFNldERhdGE6IChkYXRhKSA9PiBkaXNwYXRjaChhY3Rpb25zLnJlc3VsdFNldERhdGEoZGF0YSkpLFxuICAgIG9uRGVsZXRlUmVzdWx0OiAoZGF0YSwgaWQpID0+IGRpc3BhdGNoKGFjdGlvbnMuZGVsZXRlUmVzdWx0KGRhdGEsIGlkKSksXG4gICAgb25Qb3N0UmVzdWx0RGF0YTogKGRhdGEsIHVzZXIsIHRvZ2dsZSkgPT5cbiAgICAgIGRpc3BhdGNoKGFjdGlvbnMucG9zdFJlc3VsdERhdGEoZGF0YSwgdXNlciwgdG9nZ2xlKSksXG4gICAgb25VcGRhdGVSZXN1bHREYXRhOiAoZGF0YSwgdXNlciwgdG9nZ2xlKSA9PlxuICAgICAgZGlzcGF0Y2goYWN0aW9ucy51cGRhdGVSZXN1bHREYXRhKGRhdGEsIHVzZXIsIHRvZ2dsZSkpLFxuICAgIHJlc3VsdEVkaXRHZXREYXRhOiAoZGF0YSkgPT4gZGlzcGF0Y2goYWN0aW9ucy5yZXN1bHRFZGl0R2V0RGF0YShkYXRhKSksXG4gIH07XG59O1xuZXhwb3J0IGRlZmF1bHQgY29ubmVjdChtYXBTdGF0ZVRvUHJvcHMsIG1hcERpc3BhdGNoVG9Qcm9wcykoSG9tZSk7XG4iLCJpbXBvcnQgKiBhcyBhY3Rpb25UeXBlIGZyb20gXCIuL0FjdGlvblR5cGVzXCI7XHJcbmltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IHN3YWwgZnJvbSBcInN3ZWV0YWxlcnRcIjtcclxuLy8gaW1wb3J0IHsgYmFzZVVybCB9IGZyb20gXCIuLi8uLi9zaGFyZWQvYmFzZVVybFwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IHJlc3VsdFNldERhdGEgPSAocmVzdWx0KSA9PiB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IGFjdGlvblR5cGUuUkVTVUxUX1NFVF9EQVRBLFxyXG4gICAgcmVzdWx0OiByZXN1bHQsXHJcbiAgfTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCByZXN1bHRGYWlsRGF0YSA9IChlcnJvcikgPT4ge1xyXG4gIHJldHVybiB7XHJcbiAgICB0eXBlOiBhY3Rpb25UeXBlLlJFU1VMVF9GQUlMX0RBVEEsXHJcbiAgICBlcnJvcjogZXJyb3IsXHJcbiAgfTtcclxufTtcclxuZXhwb3J0IGNvbnN0IHJlc3VsdExvYWRpbmcgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IGFjdGlvblR5cGUuUkVTVUxUX0xPQURJTkcsXHJcbiAgfTtcclxufTtcclxuZXhwb3J0IGNvbnN0IHJlc3VsdEdldERhdGEgPSAoZGF0YSkgPT4ge1xyXG4gIC8vIHJldHVybiAoZGlzcGF0Y2gpID0+IHtcclxuICAvLyAgIGRpc3BhdGNoKHJlc3VsdExvYWRpbmcoKSk7XHJcbiAgLy8gICBheGlvc1xyXG4gIC8vICAgICAuZ2V0KGJhc2VVcmwgKyBgcmVzdWx0LyR7ZGF0YT8uaWR9YCwge1xyXG4gIC8vICAgICAgIGhlYWRlcnM6IHtcclxuICAvLyAgICAgICAgIEFjY2VwdDogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgLy8gICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAvLyAgICAgICAgIEF1dGhvcml6YXRpb246IFwiQmVhcmVyIFwiICsgZGF0YS50b2tlbixcclxuICAvLyAgICAgICB9LFxyXG4gIC8vICAgICB9KVxyXG4gIC8vICAgICAudGhlbigocmVzKSA9PiB7XHJcbiAgLy8gICAgICAgZGlzcGF0Y2gocmVzdWx0U2V0RGF0YShyZXMuZGF0YSkpO1xyXG4gIC8vICAgICAgIGNvbnNvbGUubG9nKFwiZ3JhcGggZGF0YVwiLCByZXMuZGF0YSk7XHJcbiAgLy8gICAgIH0pXHJcbiAgLy8gICAgIC5jYXRjaCgoZXJyb3IpID0+IGRpc3BhdGNoKHJlc3VsdEZhaWxEYXRhKGVycm9yKSkpO1xyXG4gIC8vIH07XHJcbn07XHJcblxyXG4vLyBleHBvcnQgY29uc3QgdGVzdFJlcG9ydERhdGEgPSAoZGF0YSkgPT4ge1xyXG4vLyAgIHJldHVybiAoZGlzcGF0Y2gpID0+IHtcclxuLy8gICAgIGRpc3BhdGNoKHJlc3VsdExvYWRpbmcoKSk7XHJcbi8vICAgICBheGlvc1xyXG4vLyAgICAgICAuZ2V0KGJhc2VVcmwgKyBcImdldFRlbXBcIiwge1xyXG4vLyAgICAgICAgIGhlYWRlcnM6IHtcclxuLy8gICAgICAgICAgIEFjY2VwdDogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbi8vICAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuLy8gICAgICAgICAgIEF1dGhvcml6YXRpb246IFwiQmVhcmVyIFwiICsgZGF0YS50b2tlbixcclxuLy8gICAgICAgICB9LFxyXG4vLyAgICAgICB9KVxyXG4vLyAgICAgICAudGhlbigocmVzKSA9PiB7XHJcbi8vICAgICAgICAgZGlzcGF0Y2gocmVzdWx0RWRpdFNldERhdGEocmVzLmRhdGEpKTtcclxuXHJcbi8vICAgICAgICAgY29uc29sZS5sb2coXCJyZXNwb25zZSBkYXRhXCIsIHJlcy5kYXRhKTtcclxuLy8gICAgICAgfSlcclxuXHJcbi8vICAgICAgIC5jYXRjaCgoZXJyb3IpID0+IGRpc3BhdGNoKHJlc3VsdEVkaXRGYWlsRGF0YShlcnJvcikpKTtcclxuLy8gICB9O1xyXG4vLyB9O1xyXG5cclxuZXhwb3J0IGNvbnN0IHJlc3VsdEVkaXRTZXREYXRhID0gKG1haW5SZXN1bHQpID0+IHtcclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZS5SRVNVTFRfRURJVF9TRVRfREFUQSxcclxuICAgIG1haW5SZXN1bHQ6IG1haW5SZXN1bHQsXHJcbiAgfTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCByZXN1bHRFZGl0RmFpbERhdGEgPSAoZXJyb3IpID0+IHtcclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZS5SRVNVTFRfRURJVF9GQUlMX0RBVEEsXHJcbiAgICBlcnJvcjogZXJyb3IsXHJcbiAgfTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCByZXN1bHRFZGl0R2V0RGF0YSA9IChkYXRhKSA9PiB7XHJcbiAgLy8gcmV0dXJuIChkaXNwYXRjaCkgPT4ge1xyXG4gIC8vICAgZGlzcGF0Y2gocmVzdWx0TG9hZGluZygpKTtcclxuICAvLyAgIGF4aW9zXHJcbiAgLy8gICAgIC5nZXQoYmFzZVVybCArIGBnZXRUZW1wLyR7ZGF0YT8uaWR9YCwge1xyXG4gIC8vICAgICAgIGhlYWRlcnM6IHtcclxuICAvLyAgICAgICAgIEFjY2VwdDogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgLy8gICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAvLyAgICAgICAgIEF1dGhvcml6YXRpb246IFwiQmVhcmVyIFwiICsgZGF0YS50b2tlbixcclxuICAvLyAgICAgICB9LFxyXG4gIC8vICAgICB9KVxyXG4gIC8vICAgICAudGhlbigocmVzKSA9PiB7XHJcbiAgLy8gICAgICAgZGlzcGF0Y2gocmVzdWx0RWRpdFNldERhdGEocmVzLmRhdGEpKTtcclxuICAvLyAgICAgICBjb25zb2xlLmxvZyhcInJlc3BvbnNlIGRhdGFcIiwgcmVzLmRhdGEpO1xyXG4gIC8vICAgICB9KVxyXG4gIC8vICAgICAuY2F0Y2goKGVycm9yKSA9PiBkaXNwYXRjaChyZXN1bHRFZGl0RmFpbERhdGEoZXJyb3IpKSk7XHJcbiAgLy8gfTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBkZWxldGVSZXN1bHRGYWlsID0gKGVycm9yKSA9PiB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IGFjdGlvblR5cGUuREVMRVRFX1JFU1VMVF9GQUlMLFxyXG4gICAgZXJyb3I6IGVycm9yLFxyXG4gIH07XHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgZGVsZXRlUmVzdWx0ID0gKGRhdGEsIGlkKSA9PiB7XHJcbiAgLy8gcmV0dXJuIChkaXNwYXRjaCkgPT4ge1xyXG4gIC8vICAgaWYgKGlkKSB7XHJcbiAgLy8gICAgIGF4aW9zXHJcbiAgLy8gICAgICAgLmRlbGV0ZShiYXNlVXJsICsgYHJlc3VsdC8ke2lkfWAsIHtcclxuICAvLyAgICAgICAgIGhlYWRlcnM6IHtcclxuICAvLyAgICAgICAgICAgQWNjZXB0OiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAvLyAgICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgLy8gICAgICAgICAgIEF1dGhvcml6YXRpb246IFwiQmVhcmVyIFwiICsgZGF0YT8udG9rZW4sXHJcbiAgLy8gICAgICAgICB9LFxyXG4gIC8vICAgICAgIH0pXHJcbiAgLy8gICAgICAgLnRoZW4oKCkgPT4ge1xyXG4gIC8vICAgICAgICAgY29uc29sZS5sb2coXCJzd2FsXCIpO1xyXG4gIC8vICAgICAgICAgc3dhbChcIlN1Y2Nlc3NmdWxseSBEZWxldGVkICBSZXN1bHQhXCIpLnRoZW4oKCkgPT4ge1xyXG4gIC8vICAgICAgICAgICBkaXNwYXRjaChyZXN1bHRHZXREYXRhKGRhdGEpKTtcclxuICAvLyAgICAgICAgIH0pO1xyXG4gIC8vICAgICAgIH0pXHJcbiAgLy8gICAgICAgLmNhdGNoKChlcnJvcikgPT4gZGlzcGF0Y2goZGVsZXRlUmVzdWx0RmFpbChlcnJvcikpKTtcclxuICAvLyAgIH1cclxuICAvLyB9O1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IHBvc3RSZXN1bHREYXRhU3RhcnQgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IGFjdGlvblR5cGUuUE9TVF9SRVNVTFRfREFUQV9TVEFSVCxcclxuICB9O1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IHBvc3RSZXN1bHREYXRhRmFpbCA9IChlcnJvcikgPT4ge1xyXG4gIHJldHVybiB7XHJcbiAgICB0eXBlOiBhY3Rpb25UeXBlLlBPU1RfUkVTVUxUX0RBVEFfRkFJTCxcclxuICAgIGVycm9yOiBlcnJvcixcclxuICB9O1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IHBvc3RSZXN1bHREYXRhID0gKGRhdGEsIHVzZXIsIHRvZ2dsZSkgPT4ge1xyXG4gIC8vIHJldHVybiAoZGlzcGF0Y2gpID0+IHtcclxuICAvLyAgIGRpc3BhdGNoKHBvc3RSZXN1bHREYXRhU3RhcnQoKSk7XHJcbiAgLy8gICBheGlvc1xyXG4gIC8vICAgICAucG9zdChiYXNlVXJsICsgXCJyZXN1bHRcIiwgdXNlciwge1xyXG4gIC8vICAgICAgIGhlYWRlcnM6IHtcclxuICAvLyAgICAgICAgIEFjY2VwdDogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgLy8gICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAvLyAgICAgICAgIEF1dGhvcml6YXRpb246IFwiQmVhcmVyIFwiICsgZGF0YT8udG9rZW4sXHJcbiAgLy8gICAgICAgfSxcclxuICAvLyAgICAgfSlcclxuICAvLyAgICAgLnRoZW4oKCkgPT4ge1xyXG4gIC8vICAgICAgIGNvbnNvbGUubG9nKFwic3dhbFwiKTtcclxuICAvLyAgICAgICBzd2FsKFwiU3VjY2Vzc2Z1bGx5IENyZWF0ZWQgIFJlc3VsdCFcIikudGhlbigoKSA9PiB7XHJcbiAgLy8gICAgICAgICBkaXNwYXRjaChyZXN1bHRHZXREYXRhKGRhdGEpKTtcclxuICAvLyAgICAgICAgIHRvZ2dsZSgpO1xyXG4gIC8vICAgICAgIH0pO1xyXG4gIC8vICAgICB9KVxyXG4gIC8vICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XHJcbiAgLy8gICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gIC8vICAgICAgIGRpc3BhdGNoKHBvc3RSZXN1bHREYXRhRmFpbChlcnJvcikpO1xyXG4gIC8vICAgICB9KTtcclxuICAvLyB9O1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IHVwZGF0ZVJlc3VsdERhdGFTdGFydCA9ICgpID0+IHtcclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZS5VUERBVEVfUkVTVUxUX0RBVEFfU1RBUlQsXHJcbiAgfTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCB1cGRhdGVSZXN1bHREYXRhID0gKGRhdGEsIHVzZXIsIHRvZ2dsZSkgPT4ge1xyXG4gIC8vIHJldHVybiAoZGlzcGF0Y2gpID0+IHtcclxuICAvLyAgIGRpc3BhdGNoKHVwZGF0ZVJlc3VsdERhdGFTdGFydCgpKTtcclxuICAvLyAgIGF4aW9zXHJcbiAgLy8gICAgIC5wb3N0KGJhc2VVcmwgKyBgcmVzdWx0LyR7ZGF0YS5pZH0/X21ldGhvZD1QVVRgLCB1c2VyLCB7XHJcbiAgLy8gICAgICAgaGVhZGVyczoge1xyXG4gIC8vICAgICAgICAgQWNjZXB0OiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAvLyAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxyXG4gIC8vICAgICAgICAgQXV0aG9yaXphdGlvbjogXCJCZWFyZXIgXCIgKyBkYXRhLnRva2VuLFxyXG4gIC8vICAgICAgIH0sXHJcbiAgLy8gICAgIH0pXHJcbiAgLy8gICAgIC50aGVuKCgpID0+IHtcclxuICAvLyAgICAgICBjb25zb2xlLmxvZyhcInN3YWxcIik7XHJcbiAgLy8gICAgICAgc3dhbChcIlN1Y2Nlc3NmdWxseSBVcGRhdGVkICBSZXN1bHQhXCIpLnRoZW4oKCkgPT4ge1xyXG4gIC8vICAgICAgICAgdG9nZ2xlKCk7XHJcbiAgLy8gICAgICAgICBkaXNwYXRjaChyZXN1bHRHZXREYXRhKGRhdGEpKTtcclxuICAvLyAgICAgICB9KTtcclxuICAvLyAgICAgfSlcclxuICAvLyAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xyXG4gIC8vICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAvLyAgICAgfSk7XHJcbiAgLy8gfTtcclxufTtcclxuIl0sIm5hbWVzIjpbImF4aW9zIiwiRmllbGQiLCJGaWVsZEFycmF5IiwiRm9ybWlrIiwiSGVhZCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiQnV0dG9uIiwiQ2FyZCIsIkNhcmRCb2R5IiwiQ2FyZEhlYWRlciIsIkNhcmRTdWJ0aXRsZSIsIkNhcmRUZXh0IiwiQ2FyZFRpdGxlIiwiQ29sIiwiRm9ybSIsIkZvcm1Hcm91cCIsIklucHV0R3JvdXAiLCJSb3ciLCJkYXRhIiwib3B0aW9ucyIsImNvbm5lY3QiLCJhY3Rpb25zIiwicmVzdWx0IiwiQXJyYXkiLCJIb21lIiwicHJvcHMiLCJ2YWx1ZSIsInNldFZhbHVlIiwiY29tcGFueSIsInNldENvbXBhbnkiLCJjb25zb2xlIiwibG9nIiwiaGFuZGxlU3VibWl0IiwidmFsdWVzIiwic2V0U3VibWl0dGluZyIsInBvc3QiLCJ0aGVuIiwicmVzIiwiaGlzdG9yeSIsInB1c2giLCJlcnIiLCJyZXNwb25zZSIsImRhdGFMZW5ndGgiLCJsZW5ndGgiLCJhbnN3ZXIiLCJmb3JtUHJvcHMiLCJtYXAiLCJkIiwiaWQiLCJTY2hsYWd3b3J0IiwicXVlc3Rpb25fdGV4dCIsImFycmF5SGVscGVycyIsIm9wdCIsIm9wdGlvbl9WYWx1ZSIsInF1ZXN0aW9uX2lkIiwiaSIsInNwbGljZSIsInJlc3VsdFNldERhdGEiLCJvcHRpb25fdGV4dCIsIm1hcFN0YXRlVG9Qcm9wcyIsInN0YXRlIiwibWFwRGlzcGF0Y2hUb1Byb3BzIiwiZGlzcGF0Y2giLCJvbkRlbGV0ZVJlc3VsdCIsImRlbGV0ZVJlc3VsdCIsIm9uUG9zdFJlc3VsdERhdGEiLCJ1c2VyIiwidG9nZ2xlIiwicG9zdFJlc3VsdERhdGEiLCJvblVwZGF0ZVJlc3VsdERhdGEiLCJ1cGRhdGVSZXN1bHREYXRhIiwicmVzdWx0RWRpdEdldERhdGEiLCJhY3Rpb25UeXBlIiwic3dhbCIsInR5cGUiLCJSRVNVTFRfU0VUX0RBVEEiLCJyZXN1bHRGYWlsRGF0YSIsImVycm9yIiwiUkVTVUxUX0ZBSUxfREFUQSIsInJlc3VsdExvYWRpbmciLCJSRVNVTFRfTE9BRElORyIsInJlc3VsdEdldERhdGEiLCJyZXN1bHRFZGl0U2V0RGF0YSIsIm1haW5SZXN1bHQiLCJSRVNVTFRfRURJVF9TRVRfREFUQSIsInJlc3VsdEVkaXRGYWlsRGF0YSIsIlJFU1VMVF9FRElUX0ZBSUxfREFUQSIsImRlbGV0ZVJlc3VsdEZhaWwiLCJERUxFVEVfUkVTVUxUX0ZBSUwiLCJwb3N0UmVzdWx0RGF0YVN0YXJ0IiwiUE9TVF9SRVNVTFRfREFUQV9TVEFSVCIsInBvc3RSZXN1bHREYXRhRmFpbCIsIlBPU1RfUkVTVUxUX0RBVEFfRkFJTCIsInVwZGF0ZVJlc3VsdERhdGFTdGFydCIsIlVQREFURV9SRVNVTFRfREFUQV9TVEFSVCJdLCJzb3VyY2VSb290IjoiIn0=