"use strict";
(() => {
var exports = {};
exports.id = "pages/graph";
exports.ids = ["pages/graph"];
exports.modules = {

/***/ "./pages/graph.js":
/*!************************!*\
  !*** ./pages/graph.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! reactstrap */ "reactstrap");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(reactstrap__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-chartjs-2 */ "react-chartjs-2");
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
var _jsxFileName = "E:\\git vinraj\\company-test\\pages\\graph.js";






const BarGraph = props => {
  var _props$login, _props$login$login, _props$result, _props$result2;

  const accessToken = `${(_props$login = props.login) === null || _props$login === void 0 ? void 0 : (_props$login$login = _props$login.login) === null || _props$login$login === void 0 ? void 0 : _props$login$login.token}`;
  let data = {
    token: accessToken,
    id: 1
  };
  const {
    0: showGraph,
    1: setShowGraph
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: chartData,
    1: setChartData
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
  let graph = [];
  let graphdata = [];
  graph = props.result;
  graphdata = (_props$result = props.result) === null || _props$result === void 0 ? void 0 : _props$result.map(gd => {
    return {
      label: "",
      data: gd,
      backgroundColor: ["rgba(255, 99, 132, 0.2)", "rgba(54, 162, 235, 0.2)", "rgba(255, 206, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(255, 159, 64, 0.2)", "rgba(255, 99, 132, 0.2)", "rgba(54, 162, 235, 0.2)", "rgba(255, 206, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(255, 159, 64, 0.2)", "rgba(255, 99, 132, 0.2)", "rgba(54, 162, 235, 0.2)", "rgba(255, 206, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(255, 159, 64, 0.2)", "rgba(255, 99, 132, 0.2)", "rgba(54, 162, 235, 0.2)", "rgba(255, 206, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(255, 159, 64, 0.2)"],
      borderColor: ["rgba(255, 99, 132, 1)", "rgba(54, 162, 235, 1)", "rgba(255, 206, 86, 1)", "rgba(75, 192, 192, 1)", "rgba(153, 102, 255, 1)", "rgba(255, 159, 64, 1)", "rgba(255, 99, 132, 1)", "rgba(54, 162, 235, 1)", "rgba(255, 206, 86, 1)", "rgba(75, 192, 192, 1)", "rgba(153, 102, 255, 1)", "rgba(255, 159, 64, 1)", "rgba(255, 99, 132, 1)", "rgba(54, 162, 235, 1)", "rgba(255, 206, 86, 1)", "rgba(75, 192, 192, 1)", "rgba(153, 102, 255, 1)", "rgba(255, 159, 64, 1)", "rgba(255, 99, 132, 1)", "rgba(54, 162, 235, 1)", "rgba(255, 206, 86, 1)", "rgba(75, 192, 192, 1)", "rgba(153, 102, 255, 1)", "rgba(255, 159, 64, 1)"],
      borderWidth: 1
    };
  });

  const Chart = () => {
    let time = [];
    let temp = [];
    let sensors = [];
    console.log("Chart Function"); // for (const dataObj of graph) {
    //   dataObj?.data.map((t) => {
    //     time.push(t.time);
    //   });
    //   sensors.push(dataObj?.sensor);
    // }

    setChartData({
      labels: ["CDU/MDU", "SPD", "AfD", "FDP", "Grüne", "Linke"],
      datasets: [{
        label: "data",
        data: [10, 20, 40, 50, 90, 10],
        fill: true,
        backgroundColor: "yellow",
        borderColor: "yellow"
      }]
    });
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    Chart();
  }, [graphdata && ((_props$result2 = props.result) === null || _props$result2 === void 0 ? void 0 : _props$result2.length) > 0]);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.Card, {
    className: "h-auto p-3",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_1__.CardBody, {
      className: "p-0",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("h3", {
        className: "text-center pt-4 pr-4 pl-4 pb-1 ",
        children: "Ihr Ergebnis"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 114,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__.Bar, {
        data: chartData,
        className: "h-auto",
        options: {
          responsive: true,
          title: {
            text: "THICCNESS SCALE",
            display: true
          },
          scales: {
            yAxes: {
              ticks: {
                beginAtZero: true
              }
            }
          }
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 116,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 113,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 112,
    columnNumber: 5
  }, undefined);
};

const mapStateToProps = state => {
  return {
    result: state.result.mainResult
  };
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_redux__WEBPACK_IMPORTED_MODULE_2__.connect)(mapStateToProps)(BarGraph));

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react-chartjs-2":
/*!**********************************!*\
  !*** external "react-chartjs-2" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("react-chartjs-2");

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "reactstrap":
/*!*****************************!*\
  !*** external "reactstrap" ***!
  \*****************************/
/***/ ((module) => {

module.exports = require("reactstrap");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/graph.js"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvZ3JhcGguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFFQTtBQUVBOzs7QUFFQSxNQUFNUSxRQUFRLEdBQUlDLEtBQUQsSUFBVztBQUFBOztBQUMxQixRQUFNQyxXQUFXLEdBQUksR0FBRCxnQkFBR0QsS0FBSyxDQUFDRSxLQUFULHVFQUFHLGFBQWFBLEtBQWhCLHVEQUFHLG1CQUFvQkMsS0FBTSxFQUFqRDtBQUVBLE1BQUlDLElBQUksR0FBRztBQUNURCxJQUFBQSxLQUFLLEVBQUVGLFdBREU7QUFFVEksSUFBQUEsRUFBRSxFQUFFO0FBRkssR0FBWDtBQUtBLFFBQU07QUFBQSxPQUFDQyxTQUFEO0FBQUEsT0FBWUM7QUFBWixNQUE0QmQsK0NBQVEsQ0FBQyxLQUFELENBQTFDO0FBQ0EsUUFBTTtBQUFBLE9BQUNlLFNBQUQ7QUFBQSxPQUFZQztBQUFaLE1BQTRCaEIsK0NBQVEsQ0FBQyxFQUFELENBQTFDO0FBQ0EsTUFBSWlCLEtBQUssR0FBRyxFQUFaO0FBQ0EsTUFBSUMsU0FBUyxHQUFHLEVBQWhCO0FBQ0FELEVBQUFBLEtBQUssR0FBR1YsS0FBSyxDQUFDWSxNQUFkO0FBQ0FELEVBQUFBLFNBQVMsb0JBQUdYLEtBQUssQ0FBQ1ksTUFBVCxrREFBRyxjQUFjQyxHQUFkLENBQW1CQyxFQUFELElBQVE7QUFDcEMsV0FBTztBQUNMQyxNQUFBQSxLQUFLLEVBQUUsRUFERjtBQUVMWCxNQUFBQSxJQUFJLEVBQUVVLEVBRkQ7QUFHTEUsTUFBQUEsZUFBZSxFQUFFLENBQ2YseUJBRGUsRUFFZix5QkFGZSxFQUdmLHlCQUhlLEVBSWYseUJBSmUsRUFLZiwwQkFMZSxFQU1mLHlCQU5lLEVBT2YseUJBUGUsRUFRZix5QkFSZSxFQVNmLHlCQVRlLEVBVWYseUJBVmUsRUFXZiwwQkFYZSxFQVlmLHlCQVplLEVBYWYseUJBYmUsRUFjZix5QkFkZSxFQWVmLHlCQWZlLEVBZ0JmLHlCQWhCZSxFQWlCZiwwQkFqQmUsRUFrQmYseUJBbEJlLEVBbUJmLHlCQW5CZSxFQW9CZix5QkFwQmUsRUFxQmYseUJBckJlLEVBc0JmLHlCQXRCZSxFQXVCZiwwQkF2QmUsRUF3QmYseUJBeEJlLENBSFo7QUE2QkxDLE1BQUFBLFdBQVcsRUFBRSxDQUNYLHVCQURXLEVBRVgsdUJBRlcsRUFHWCx1QkFIVyxFQUlYLHVCQUpXLEVBS1gsd0JBTFcsRUFNWCx1QkFOVyxFQU9YLHVCQVBXLEVBUVgsdUJBUlcsRUFTWCx1QkFUVyxFQVVYLHVCQVZXLEVBV1gsd0JBWFcsRUFZWCx1QkFaVyxFQWFYLHVCQWJXLEVBY1gsdUJBZFcsRUFlWCx1QkFmVyxFQWdCWCx1QkFoQlcsRUFpQlgsd0JBakJXLEVBa0JYLHVCQWxCVyxFQW1CWCx1QkFuQlcsRUFvQlgsdUJBcEJXLEVBcUJYLHVCQXJCVyxFQXNCWCx1QkF0QlcsRUF1Qlgsd0JBdkJXLEVBd0JYLHVCQXhCVyxDQTdCUjtBQXdETEMsTUFBQUEsV0FBVyxFQUFFO0FBeERSLEtBQVA7QUEwREQsR0EzRFcsQ0FBWjs7QUE2REEsUUFBTUMsS0FBSyxHQUFHLE1BQU07QUFDbEIsUUFBSUMsSUFBSSxHQUFHLEVBQVg7QUFDQSxRQUFJQyxJQUFJLEdBQUcsRUFBWDtBQUNBLFFBQUlDLE9BQU8sR0FBRyxFQUFkO0FBQ0FDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGdCQUFaLEVBSmtCLENBS2xCO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQWYsSUFBQUEsWUFBWSxDQUFDO0FBQ1hnQixNQUFBQSxNQUFNLEVBQUUsQ0FBQyxTQUFELEVBQVksS0FBWixFQUFtQixLQUFuQixFQUEwQixLQUExQixFQUFpQyxPQUFqQyxFQUEwQyxPQUExQyxDQURHO0FBRVhDLE1BQUFBLFFBQVEsRUFBRSxDQUNSO0FBQ0VYLFFBQUFBLEtBQUssRUFBRSxNQURUO0FBRUVYLFFBQUFBLElBQUksRUFBRSxDQUFDLEVBQUQsRUFBSyxFQUFMLEVBQVMsRUFBVCxFQUFhLEVBQWIsRUFBaUIsRUFBakIsRUFBcUIsRUFBckIsQ0FGUjtBQUdFdUIsUUFBQUEsSUFBSSxFQUFFLElBSFI7QUFJRVgsUUFBQUEsZUFBZSxFQUFFLFFBSm5CO0FBS0VDLFFBQUFBLFdBQVcsRUFBRTtBQUxmLE9BRFE7QUFGQyxLQUFELENBQVo7QUFZRCxHQXpCRDs7QUEwQkF6QixFQUFBQSxnREFBUyxDQUFDLE1BQU07QUFDZDJCLElBQUFBLEtBQUs7QUFDTixHQUZRLEVBRU4sQ0FBQ1IsU0FBUyxJQUFJLG1CQUFBWCxLQUFLLENBQUNZLE1BQU4sa0VBQWNnQixNQUFkLElBQXVCLENBQXJDLENBRk0sQ0FBVDtBQUdBLHNCQUNFLDhEQUFDLDRDQUFEO0FBQU0sYUFBUyxFQUFDLFlBQWhCO0FBQUEsMkJBQ0UsOERBQUMsZ0RBQUQ7QUFBVSxlQUFTLEVBQUMsS0FBcEI7QUFBQSw4QkFDRTtBQUFJLGlCQUFTLEVBQUMsa0NBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFHRSw4REFBQyxnREFBRDtBQUNFLFlBQUksRUFBRXBCLFNBRFI7QUFFRSxpQkFBUyxFQUFDLFFBRlo7QUFHRSxlQUFPLEVBQUU7QUFDUHFCLFVBQUFBLFVBQVUsRUFBRSxJQURMO0FBRVBDLFVBQUFBLEtBQUssRUFBRTtBQUFFQyxZQUFBQSxJQUFJLEVBQUUsaUJBQVI7QUFBMkJDLFlBQUFBLE9BQU8sRUFBRTtBQUFwQyxXQUZBO0FBR1BDLFVBQUFBLE1BQU0sRUFBRTtBQUNOQyxZQUFBQSxLQUFLLEVBQUU7QUFDTEMsY0FBQUEsS0FBSyxFQUFFO0FBQ0xDLGdCQUFBQSxXQUFXLEVBQUU7QUFEUjtBQURGO0FBREQ7QUFIRDtBQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBdUJELENBOUhEOztBQWdJQSxNQUFNQyxlQUFlLEdBQUlDLEtBQUQsSUFBVztBQUNqQyxTQUFPO0FBQ0wxQixJQUFBQSxNQUFNLEVBQUUwQixLQUFLLENBQUMxQixNQUFOLENBQWEyQjtBQURoQixHQUFQO0FBR0QsQ0FKRDs7QUFNQSxpRUFBZTFDLG9EQUFPLENBQUN3QyxlQUFELENBQVAsQ0FBeUJ0QyxRQUF6QixDQUFmOzs7Ozs7Ozs7O0FDN0lBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jb21wYW55LXRlc3QvLi9wYWdlcy9ncmFwaC5qcyIsIndlYnBhY2s6Ly9jb21wYW55LXRlc3QvZXh0ZXJuYWwgXCJyZWFjdFwiIiwid2VicGFjazovL2NvbXBhbnktdGVzdC9leHRlcm5hbCBcInJlYWN0LWNoYXJ0anMtMlwiIiwid2VicGFjazovL2NvbXBhbnktdGVzdC9leHRlcm5hbCBcInJlYWN0LXJlZHV4XCIiLCJ3ZWJwYWNrOi8vY29tcGFueS10ZXN0L2V4dGVybmFsIFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIiLCJ3ZWJwYWNrOi8vY29tcGFueS10ZXN0L2V4dGVybmFsIFwicmVhY3RzdHJhcFwiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IEJ1dHRvbiwgQ2FyZCwgQ2FyZEJvZHkgfSBmcm9tIFwicmVhY3RzdHJhcFwiO1xyXG5cclxuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xyXG5cclxuaW1wb3J0IHsgQmFyIH0gZnJvbSBcInJlYWN0LWNoYXJ0anMtMlwiO1xyXG5cclxuY29uc3QgQmFyR3JhcGggPSAocHJvcHMpID0+IHtcclxuICBjb25zdCBhY2Nlc3NUb2tlbiA9IGAke3Byb3BzLmxvZ2luPy5sb2dpbj8udG9rZW59YDtcclxuXHJcbiAgbGV0IGRhdGEgPSB7XHJcbiAgICB0b2tlbjogYWNjZXNzVG9rZW4sXHJcbiAgICBpZDogMSxcclxuICB9O1xyXG5cclxuICBjb25zdCBbc2hvd0dyYXBoLCBzZXRTaG93R3JhcGhdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjaGFydERhdGEsIHNldENoYXJ0RGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgbGV0IGdyYXBoID0gW107XHJcbiAgbGV0IGdyYXBoZGF0YSA9IFtdO1xyXG4gIGdyYXBoID0gcHJvcHMucmVzdWx0O1xyXG4gIGdyYXBoZGF0YSA9IHByb3BzLnJlc3VsdD8ubWFwKChnZCkgPT4ge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgbGFiZWw6IFwiXCIsXHJcbiAgICAgIGRhdGE6IGdkLFxyXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6IFtcclxuICAgICAgICBcInJnYmEoMjU1LCA5OSwgMTMyLCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDU0LCAxNjIsIDIzNSwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDIwNiwgODYsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoNzUsIDE5MiwgMTkyLCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDE1MywgMTAyLCAyNTUsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoMjU1LCAxNTksIDY0LCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgOTksIDEzMiwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSg1NCwgMTYyLCAyMzUsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoMjU1LCAyMDYsIDg2LCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDc1LCAxOTIsIDE5MiwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSgxNTMsIDEwMiwgMjU1LCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgMTU5LCA2NCwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDk5LCAxMzIsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoNTQsIDE2MiwgMjM1LCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgMjA2LCA4NiwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSg3NSwgMTkyLCAxOTIsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoMTUzLCAxMDIsIDI1NSwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDE1OSwgNjQsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoMjU1LCA5OSwgMTMyLCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDU0LCAxNjIsIDIzNSwgMC4yKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDIwNiwgODYsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoNzUsIDE5MiwgMTkyLCAwLjIpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDE1MywgMTAyLCAyNTUsIDAuMilcIixcclxuICAgICAgICBcInJnYmEoMjU1LCAxNTksIDY0LCAwLjIpXCIsXHJcbiAgICAgIF0sXHJcbiAgICAgIGJvcmRlckNvbG9yOiBbXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgOTksIDEzMiwgMSlcIixcclxuICAgICAgICBcInJnYmEoNTQsIDE2MiwgMjM1LCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDIwNiwgODYsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDc1LCAxOTIsIDE5MiwgMSlcIixcclxuICAgICAgICBcInJnYmEoMTUzLCAxMDIsIDI1NSwgMSlcIixcclxuICAgICAgICBcInJnYmEoMjU1LCAxNTksIDY0LCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDk5LCAxMzIsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDU0LCAxNjIsIDIzNSwgMSlcIixcclxuICAgICAgICBcInJnYmEoMjU1LCAyMDYsIDg2LCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSg3NSwgMTkyLCAxOTIsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDE1MywgMTAyLCAyNTUsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgMTU5LCA2NCwgMSlcIixcclxuICAgICAgICBcInJnYmEoMjU1LCA5OSwgMTMyLCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSg1NCwgMTYyLCAyMzUsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgMjA2LCA4NiwgMSlcIixcclxuICAgICAgICBcInJnYmEoNzUsIDE5MiwgMTkyLCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSgxNTMsIDEwMiwgMjU1LCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDE1OSwgNjQsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDI1NSwgOTksIDEzMiwgMSlcIixcclxuICAgICAgICBcInJnYmEoNTQsIDE2MiwgMjM1LCAxKVwiLFxyXG4gICAgICAgIFwicmdiYSgyNTUsIDIwNiwgODYsIDEpXCIsXHJcbiAgICAgICAgXCJyZ2JhKDc1LCAxOTIsIDE5MiwgMSlcIixcclxuICAgICAgICBcInJnYmEoMTUzLCAxMDIsIDI1NSwgMSlcIixcclxuICAgICAgICBcInJnYmEoMjU1LCAxNTksIDY0LCAxKVwiLFxyXG4gICAgICBdLFxyXG5cclxuICAgICAgYm9yZGVyV2lkdGg6IDEsXHJcbiAgICB9O1xyXG4gIH0pO1xyXG5cclxuICBjb25zdCBDaGFydCA9ICgpID0+IHtcclxuICAgIGxldCB0aW1lID0gW107XHJcbiAgICBsZXQgdGVtcCA9IFtdO1xyXG4gICAgbGV0IHNlbnNvcnMgPSBbXTtcclxuICAgIGNvbnNvbGUubG9nKFwiQ2hhcnQgRnVuY3Rpb25cIik7XHJcbiAgICAvLyBmb3IgKGNvbnN0IGRhdGFPYmogb2YgZ3JhcGgpIHtcclxuICAgIC8vICAgZGF0YU9iaj8uZGF0YS5tYXAoKHQpID0+IHtcclxuICAgIC8vICAgICB0aW1lLnB1c2godC50aW1lKTtcclxuICAgIC8vICAgfSk7XHJcblxyXG4gICAgLy8gICBzZW5zb3JzLnB1c2goZGF0YU9iaj8uc2Vuc29yKTtcclxuICAgIC8vIH1cclxuXHJcbiAgICBzZXRDaGFydERhdGEoe1xyXG4gICAgICBsYWJlbHM6IFtcIkNEVS9NRFVcIiwgXCJTUERcIiwgXCJBZkRcIiwgXCJGRFBcIiwgXCJHcsO8bmVcIiwgXCJMaW5rZVwiXSxcclxuICAgICAgZGF0YXNldHM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBsYWJlbDogXCJkYXRhXCIsXHJcbiAgICAgICAgICBkYXRhOiBbMTAsIDIwLCA0MCwgNTAsIDkwLCAxMF0sXHJcbiAgICAgICAgICBmaWxsOiB0cnVlLFxyXG4gICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBcInllbGxvd1wiLFxyXG4gICAgICAgICAgYm9yZGVyQ29sb3I6IFwieWVsbG93XCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgIH0pO1xyXG4gIH07XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIENoYXJ0KCk7XHJcbiAgfSwgW2dyYXBoZGF0YSAmJiBwcm9wcy5yZXN1bHQ/Lmxlbmd0aCA+IDBdKTtcclxuICByZXR1cm4gKFxyXG4gICAgPENhcmQgY2xhc3NOYW1lPVwiaC1hdXRvIHAtM1wiPlxyXG4gICAgICA8Q2FyZEJvZHkgY2xhc3NOYW1lPVwicC0wXCI+XHJcbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB0LTQgcHItNCBwbC00IHBiLTEgXCI+SWhyIEVyZ2VibmlzPC9oMz5cclxuXHJcbiAgICAgICAgPEJhclxyXG4gICAgICAgICAgZGF0YT17Y2hhcnREYXRhfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiaC1hdXRvXCJcclxuICAgICAgICAgIG9wdGlvbnM9e3tcclxuICAgICAgICAgICAgcmVzcG9uc2l2ZTogdHJ1ZSxcclxuICAgICAgICAgICAgdGl0bGU6IHsgdGV4dDogXCJUSElDQ05FU1MgU0NBTEVcIiwgZGlzcGxheTogdHJ1ZSB9LFxyXG4gICAgICAgICAgICBzY2FsZXM6IHtcclxuICAgICAgICAgICAgICB5QXhlczoge1xyXG4gICAgICAgICAgICAgICAgdGlja3M6IHtcclxuICAgICAgICAgICAgICAgICAgYmVnaW5BdFplcm86IHRydWUsXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvQ2FyZEJvZHk+XHJcbiAgICA8L0NhcmQ+XHJcbiAgKTtcclxufTtcclxuXHJcbmNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IChzdGF0ZSkgPT4ge1xyXG4gIHJldHVybiB7XHJcbiAgICByZXN1bHQ6IHN0YXRlLnJlc3VsdC5tYWluUmVzdWx0LFxyXG4gIH07XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjb25uZWN0KG1hcFN0YXRlVG9Qcm9wcykoQmFyR3JhcGgpO1xyXG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC1jaGFydGpzLTJcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QtcmVkdXhcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0c3RyYXBcIik7Il0sIm5hbWVzIjpbIlJlYWN0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJCdXR0b24iLCJDYXJkIiwiQ2FyZEJvZHkiLCJjb25uZWN0IiwiQmFyIiwiQmFyR3JhcGgiLCJwcm9wcyIsImFjY2Vzc1Rva2VuIiwibG9naW4iLCJ0b2tlbiIsImRhdGEiLCJpZCIsInNob3dHcmFwaCIsInNldFNob3dHcmFwaCIsImNoYXJ0RGF0YSIsInNldENoYXJ0RGF0YSIsImdyYXBoIiwiZ3JhcGhkYXRhIiwicmVzdWx0IiwibWFwIiwiZ2QiLCJsYWJlbCIsImJhY2tncm91bmRDb2xvciIsImJvcmRlckNvbG9yIiwiYm9yZGVyV2lkdGgiLCJDaGFydCIsInRpbWUiLCJ0ZW1wIiwic2Vuc29ycyIsImNvbnNvbGUiLCJsb2ciLCJsYWJlbHMiLCJkYXRhc2V0cyIsImZpbGwiLCJsZW5ndGgiLCJyZXNwb25zaXZlIiwidGl0bGUiLCJ0ZXh0IiwiZGlzcGxheSIsInNjYWxlcyIsInlBeGVzIiwidGlja3MiLCJiZWdpbkF0WmVybyIsIm1hcFN0YXRlVG9Qcm9wcyIsInN0YXRlIiwibWFpblJlc3VsdCJdLCJzb3VyY2VSb290IjoiIn0=