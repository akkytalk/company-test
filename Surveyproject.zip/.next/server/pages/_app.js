(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./components/Header/Meta.js":
/*!***********************************!*\
  !*** ./components/Header/Meta.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "E:\\git vinraj\\company-test\\components\\Header\\Meta.js";



const Meta = ({
  title,
  keywords,
  description
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_0___default()), {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("meta", {
      name: "viewport",
      content: "width=device-width, initial-scale=1"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("meta", {
      name: "keywords",
      content: keywords
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("meta", {
      name: "description",
      content: description
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("meta", {
      charSet: "utf-8"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("link", {
      rel: "icon",
      href: "/favicon.ico"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("title", {
      children: title
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 5,
    columnNumber: 5
  }, undefined);
};

Meta.defaultProps = {// title: "Pasterock.io",
  // keywords: "paste, programming",
  // description: "create paste",
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Meta);

/***/ }),

/***/ "./components/Layout.js":
/*!******************************!*\
  !*** ./components/Layout.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Header_Meta__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Header/Meta */ "./components/Header/Meta.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "E:\\git vinraj\\company-test\\components\\Layout.js";



function Layout({
  children
}) {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
    className: "",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_Header_Meta__WEBPACK_IMPORTED_MODULE_0__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 7
    }, this), children]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 5,
    columnNumber: 5
  }, this);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

/***/ }),

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tailwindcss_tailwind_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tailwindcss/tailwind.css */ "./node_modules/tailwindcss/tailwind.css");
/* harmony import */ var tailwindcss_tailwind_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tailwindcss_tailwind_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/Layout */ "./components/Layout.js");
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../styles/globals.css */ "./styles/globals.css");
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _redux_ConfigureStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../redux/ConfigureStore */ "./redux/ConfigureStore.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! redux-persist/integration/react */ "redux-persist/integration/react");
/* harmony import */ var redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);
var _jsxFileName = "E:\\git vinraj\\company-test\\pages\\_app.js";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








const {
  persistor,
  store
} = (0,_redux_ConfigureStore__WEBPACK_IMPORTED_MODULE_3__.configureStore)();

function MyApp({
  Component,
  pageProps
}) {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(react_redux__WEBPACK_IMPORTED_MODULE_4__.Provider, {
    store: store,
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_5__.PersistGate, {
      persistor: persistor,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_1__.default, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(Component, _objectSpread({}, pageProps), void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 15,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 14,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 12,
    columnNumber: 5
  }, this);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

/***/ }),

/***/ "./redux/ConfigureStore.js":
/*!*********************************!*\
  !*** ./redux/ConfigureStore.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "configureStore": () => (/* binding */ configureStore)
/* harmony export */ });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux-persist */ "redux-persist");
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux_persist__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var redux_thunk__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! redux-thunk */ "redux-thunk");
/* harmony import */ var redux_thunk__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(redux_thunk__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var redux_logger__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! redux-logger */ "redux-logger");
/* harmony import */ var redux_logger__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(redux_logger__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! redux-persist/lib/storage */ "redux-persist/lib/storage");
/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _reducers_RResult__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./reducers/RResult */ "./redux/reducers/RResult.js");






const config = {
  key: "company-test",
  storage: (redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_4___default()),
  debug: true
};
const configureStore = () => {
  const store = (0,redux__WEBPACK_IMPORTED_MODULE_0__.createStore)((0,redux_persist__WEBPACK_IMPORTED_MODULE_1__.persistCombineReducers)(config, {
    result: _reducers_RResult__WEBPACK_IMPORTED_MODULE_5__.default
  }), (0,redux__WEBPACK_IMPORTED_MODULE_0__.applyMiddleware)((redux_thunk__WEBPACK_IMPORTED_MODULE_2___default()), (redux_logger__WEBPACK_IMPORTED_MODULE_3___default())));
  const persistor = (0,redux_persist__WEBPACK_IMPORTED_MODULE_1__.persistStore)(store);
  return {
    persistor,
    store
  };
}; // import { createStore, applyMiddleware, compose } from "redux";
// import { persistStore, persistCombineReducers } from "redux-persist";
// import thunk from "redux-thunk";
// import storage from "redux-persist/lib/storage";
// // import storage from "../storage";
// import Result from "./reducers/RResult";
// import logger from "redux-logger";
// const config = {
//   key: "company",
//   storage,
//   debug: true,
// };
// const composeEnhancer = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
// export const configureStore = () => {
//   const store = createStore(
//     persistCombineReducers(config, {
//       result: Result,
//     }),
//     composeEnhancer(applyMiddleware(thunk, logger))
//   );
//   const persistor = persistStore(store);
//   return { persistor, store };
// };

/***/ }),

/***/ "./redux/actions/ActionTypes.js":
/*!**************************************!*\
  !*** ./redux/actions/ActionTypes.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RESULT_GET_DATA": () => (/* binding */ RESULT_GET_DATA),
/* harmony export */   "RESULT_SET_DATA": () => (/* binding */ RESULT_SET_DATA),
/* harmony export */   "RESULT_FAIL_DATA": () => (/* binding */ RESULT_FAIL_DATA),
/* harmony export */   "DELETE_RESULT_FAIL": () => (/* binding */ DELETE_RESULT_FAIL),
/* harmony export */   "POST_RESULT_DATA": () => (/* binding */ POST_RESULT_DATA),
/* harmony export */   "POST_RESULT_DATA_START": () => (/* binding */ POST_RESULT_DATA_START),
/* harmony export */   "POST_RESULT_DATA_FAIL": () => (/* binding */ POST_RESULT_DATA_FAIL),
/* harmony export */   "POST_RESULT_DATA_SUCCESS": () => (/* binding */ POST_RESULT_DATA_SUCCESS),
/* harmony export */   "UPDATE_RESULT_DATA_START": () => (/* binding */ UPDATE_RESULT_DATA_START),
/* harmony export */   "RESULT_LOADING": () => (/* binding */ RESULT_LOADING),
/* harmony export */   "RESULT_EDIT_SET_DATA": () => (/* binding */ RESULT_EDIT_SET_DATA),
/* harmony export */   "RESULT_EDIT_FAIL_DATA": () => (/* binding */ RESULT_EDIT_FAIL_DATA)
/* harmony export */ });
// Result actionTypes
const RESULT_GET_DATA = "RESULT_GET_DATA";
const RESULT_SET_DATA = "RESULT_SET_DATA";
const RESULT_FAIL_DATA = "RESULT_FAIL_DATA";
const DELETE_RESULT_FAIL = "DELETE_RESULT_FAIL";
const POST_RESULT_DATA = "POST_RESULT_DATA";
const POST_RESULT_DATA_START = "POST_RESULT_DATA_START";
const POST_RESULT_DATA_FAIL = "POST_RESULT_DATA_FAIL";
const POST_RESULT_DATA_SUCCESS = "POST_RESULT_DATA_SUCCESS";
const UPDATE_RESULT_DATA_START = "UPDATE_RESULT_DATA_START";
const RESULT_LOADING = "RESULT_LOADING";
const RESULT_EDIT_SET_DATA = "RESULT_EDIT_SET_DATA";
const RESULT_EDIT_FAIL_DATA = "RESULT_EDIT_FAIL_DATA";

/***/ }),

/***/ "./redux/reducers/RResult.js":
/*!***********************************!*\
  !*** ./redux/reducers/RResult.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _actions_ActionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../actions/ActionTypes */ "./redux/actions/ActionTypes.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const initialState = {
  result: [],
  error: false,
  mainResult: [],
  isLoading: false
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case _actions_ActionTypes__WEBPACK_IMPORTED_MODULE_0__.RESULT_SET_DATA:
      return _objectSpread(_objectSpread({}, state), {}, {
        result: action.result,
        isLoading: false,
        error: false
      });

    case _actions_ActionTypes__WEBPACK_IMPORTED_MODULE_0__.RESULT_FAIL_DATA:
      return _objectSpread(_objectSpread({}, state), {}, {
        isLoading: false,
        error: action.error // result: [],

      });

    case _actions_ActionTypes__WEBPACK_IMPORTED_MODULE_0__.RESULT_LOADING:
      return _objectSpread(_objectSpread({}, state), {}, {
        isLoading: true,
        error: false // result: [],
        // mainResult: [],

      });

    case _actions_ActionTypes__WEBPACK_IMPORTED_MODULE_0__.POST_RESULT_DATA_FAIL:
      return _objectSpread(_objectSpread({}, state), {}, {
        isLoading: false,
        error: action.error
      });

    case _actions_ActionTypes__WEBPACK_IMPORTED_MODULE_0__.RESULT_EDIT_SET_DATA:
      return _objectSpread(_objectSpread({}, state), {}, {
        isLoading: false,
        error: false,
        mainResult: action.mainResult
      });

    case _actions_ActionTypes__WEBPACK_IMPORTED_MODULE_0__.RESULT_EDIT_FAIL_DATA:
      return _objectSpread(_objectSpread({}, state), {}, {
        isLoading: false,
        error: action.error // mainResult: [],

      });

    case _actions_ActionTypes__WEBPACK_IMPORTED_MODULE_0__.UPDATE_RESULT_DATA_START:
      return _objectSpread(_objectSpread({}, state), {}, {
        isLoading: false
      });

    default:
      return state;
  }
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (reducer);

/***/ }),

/***/ "./node_modules/tailwindcss/tailwind.css":
/*!***********************************************!*\
  !*** ./node_modules/tailwindcss/tailwind.css ***!
  \***********************************************/
/***/ (() => {



/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "redux":
/*!************************!*\
  !*** external "redux" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("redux");

/***/ }),

/***/ "redux-logger":
/*!*******************************!*\
  !*** external "redux-logger" ***!
  \*******************************/
/***/ ((module) => {

"use strict";
module.exports = require("redux-logger");

/***/ }),

/***/ "redux-persist":
/*!********************************!*\
  !*** external "redux-persist" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = require("redux-persist");

/***/ }),

/***/ "redux-persist/integration/react":
/*!**************************************************!*\
  !*** external "redux-persist/integration/react" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("redux-persist/integration/react");

/***/ }),

/***/ "redux-persist/lib/storage":
/*!********************************************!*\
  !*** external "redux-persist/lib/storage" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("redux-persist/lib/storage");

/***/ }),

/***/ "redux-thunk":
/*!******************************!*\
  !*** external "redux-thunk" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("redux-thunk");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.js"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvX2FwcC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7OztBQUVBLE1BQU1DLElBQUksR0FBRyxDQUFDO0FBQUVDLEVBQUFBLEtBQUY7QUFBU0MsRUFBQUEsUUFBVDtBQUFtQkMsRUFBQUE7QUFBbkIsQ0FBRCxLQUFzQztBQUNqRCxzQkFDRSw4REFBQyxrREFBRDtBQUFBLDRCQUNFO0FBQU0sVUFBSSxFQUFDLFVBQVg7QUFBc0IsYUFBTyxFQUFDO0FBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFFRTtBQUFNLFVBQUksRUFBQyxVQUFYO0FBQXNCLGFBQU8sRUFBRUQ7QUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGRixlQUdFO0FBQU0sVUFBSSxFQUFDLGFBQVg7QUFBeUIsYUFBTyxFQUFFQztBQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUhGLGVBSUU7QUFBTSxhQUFPLEVBQUM7QUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUpGLGVBS0U7QUFBTSxTQUFHLEVBQUMsTUFBVjtBQUFpQixVQUFJLEVBQUM7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFMRixlQU1FO0FBQUEsZ0JBQVFGO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQVVELENBWEQ7O0FBYUFELElBQUksQ0FBQ0ksWUFBTCxHQUFvQixDQUNsQjtBQUNBO0FBQ0E7QUFIa0IsQ0FBcEI7QUFNQSxpRUFBZUosSUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3JCQTs7O0FBRUEsU0FBU0ssTUFBVCxDQUFnQjtBQUFFQyxFQUFBQTtBQUFGLENBQWhCLEVBQThCO0FBQzVCLHNCQUNFO0FBQUssYUFBUyxFQUFDLEVBQWY7QUFBQSw0QkFDRSw4REFBQyxpREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsRUFFR0EsUUFGSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQU1EOztBQUVELGlFQUFlRCxNQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1hBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNO0FBQUVLLEVBQUFBLFNBQUY7QUFBYUMsRUFBQUE7QUFBYixJQUF1QkoscUVBQWMsRUFBM0M7O0FBQ0EsU0FBU0ssS0FBVCxDQUFlO0FBQUVDLEVBQUFBLFNBQUY7QUFBYUMsRUFBQUE7QUFBYixDQUFmLEVBQXlDO0FBQ3ZDLHNCQUNFLDhEQUFDLGlEQUFEO0FBQVUsU0FBSyxFQUFFSCxLQUFqQjtBQUFBLDJCQUNFLDhEQUFDLHdFQUFEO0FBQWEsZUFBUyxFQUFFRCxTQUF4QjtBQUFBLDZCQUNFLDhEQUFDLHVEQUFEO0FBQUEsK0JBQ0UsOERBQUMsU0FBRCxvQkFBZUksU0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFTRDs7QUFFRCxpRUFBZUYsS0FBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTVcsTUFBTSxHQUFHO0FBQ2JDLEVBQUFBLEdBQUcsRUFBRSxjQURRO0FBRWJILEVBQUFBLE9BRmE7QUFHYkksRUFBQUEsS0FBSyxFQUFFO0FBSE0sQ0FBZjtBQU1PLE1BQU1sQixjQUFjLEdBQUcsTUFBTTtBQUNsQyxRQUFNSSxLQUFLLEdBQUdJLGtEQUFXLENBQ3ZCRyxxRUFBc0IsQ0FBQ0ssTUFBRCxFQUFTO0FBQzdCRyxJQUFBQSxNQUFNLEVBQUVKLHNEQUFPQTtBQURjLEdBQVQsQ0FEQyxFQUl2Qk4sc0RBQWUsQ0FBQ0csb0RBQUQsRUFBUUMscURBQVIsQ0FKUSxDQUF6QjtBQU9BLFFBQU1WLFNBQVMsR0FBR08sMkRBQVksQ0FBQ04sS0FBRCxDQUE5QjtBQUVBLFNBQU87QUFBRUQsSUFBQUEsU0FBRjtBQUFhQyxJQUFBQTtBQUFiLEdBQVA7QUFDRCxDQVhNLEVBWVA7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvQ0E7QUFFTyxNQUFNZ0IsZUFBZSxHQUFHLGlCQUF4QjtBQUNBLE1BQU1DLGVBQWUsR0FBRyxpQkFBeEI7QUFDQSxNQUFNQyxnQkFBZ0IsR0FBRyxrQkFBekI7QUFDQSxNQUFNQyxrQkFBa0IsR0FBRyxvQkFBM0I7QUFDQSxNQUFNQyxnQkFBZ0IsR0FBRyxrQkFBekI7QUFDQSxNQUFNQyxzQkFBc0IsR0FBRyx3QkFBL0I7QUFDQSxNQUFNQyxxQkFBcUIsR0FBRyx1QkFBOUI7QUFDQSxNQUFNQyx3QkFBd0IsR0FBRywwQkFBakM7QUFFQSxNQUFNQyx3QkFBd0IsR0FBRywwQkFBakM7QUFDQSxNQUFNQyxjQUFjLEdBQUcsZ0JBQXZCO0FBQ0EsTUFBTUMsb0JBQW9CLEdBQUcsc0JBQTdCO0FBQ0EsTUFBTUMscUJBQXFCLEdBQUcsdUJBQTlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZFA7QUFFQSxNQUFNRSxZQUFZLEdBQUc7QUFDbkJkLEVBQUFBLE1BQU0sRUFBRSxFQURXO0FBRW5CZSxFQUFBQSxLQUFLLEVBQUUsS0FGWTtBQUduQkMsRUFBQUEsVUFBVSxFQUFFLEVBSE87QUFJbkJDLEVBQUFBLFNBQVMsRUFBRTtBQUpRLENBQXJCOztBQU9BLE1BQU1DLE9BQU8sR0FBRyxDQUFDQyxLQUFLLEdBQUdMLFlBQVQsRUFBdUJNLE1BQXZCLEtBQWtDO0FBQ2hELFVBQVFBLE1BQU0sQ0FBQ0MsSUFBZjtBQUNFLFNBQUtSLGlFQUFMO0FBQ0UsNkNBQ0tNLEtBREw7QUFFRW5CLFFBQUFBLE1BQU0sRUFBRW9CLE1BQU0sQ0FBQ3BCLE1BRmpCO0FBR0VpQixRQUFBQSxTQUFTLEVBQUUsS0FIYjtBQUlFRixRQUFBQSxLQUFLLEVBQUU7QUFKVDs7QUFPRixTQUFLRixrRUFBTDtBQUNFLDZDQUNLTSxLQURMO0FBRUVGLFFBQUFBLFNBQVMsRUFBRSxLQUZiO0FBR0VGLFFBQUFBLEtBQUssRUFBRUssTUFBTSxDQUFDTCxLQUhoQixDQUlFOztBQUpGOztBQU1GLFNBQUtGLGdFQUFMO0FBQ0UsNkNBQ0tNLEtBREw7QUFFRUYsUUFBQUEsU0FBUyxFQUFFLElBRmI7QUFHRUYsUUFBQUEsS0FBSyxFQUFFLEtBSFQsQ0FJRTtBQUNBOztBQUxGOztBQVFGLFNBQUtGLHVFQUFMO0FBQ0UsNkNBQ0tNLEtBREw7QUFFRUYsUUFBQUEsU0FBUyxFQUFFLEtBRmI7QUFHRUYsUUFBQUEsS0FBSyxFQUFFSyxNQUFNLENBQUNMO0FBSGhCOztBQUtGLFNBQUtGLHNFQUFMO0FBQ0UsNkNBQ0tNLEtBREw7QUFFRUYsUUFBQUEsU0FBUyxFQUFFLEtBRmI7QUFHRUYsUUFBQUEsS0FBSyxFQUFFLEtBSFQ7QUFJRUMsUUFBQUEsVUFBVSxFQUFFSSxNQUFNLENBQUNKO0FBSnJCOztBQU1GLFNBQUtILHVFQUFMO0FBQ0UsNkNBQ0tNLEtBREw7QUFFRUYsUUFBQUEsU0FBUyxFQUFFLEtBRmI7QUFHRUYsUUFBQUEsS0FBSyxFQUFFSyxNQUFNLENBQUNMLEtBSGhCLENBSUU7O0FBSkY7O0FBTUYsU0FBS0YsMEVBQUw7QUFDRSw2Q0FDS00sS0FETDtBQUVFRixRQUFBQSxTQUFTLEVBQUU7QUFGYjs7QUFLRjtBQUNFLGFBQU9FLEtBQVA7QUFwREo7QUFzREQsQ0F2REQ7O0FBeURBLGlFQUFlRCxPQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEVBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY29tcGFueS10ZXN0Ly4vY29tcG9uZW50cy9IZWFkZXIvTWV0YS5qcyIsIndlYnBhY2s6Ly9jb21wYW55LXRlc3QvLi9jb21wb25lbnRzL0xheW91dC5qcyIsIndlYnBhY2s6Ly9jb21wYW55LXRlc3QvLi9wYWdlcy9fYXBwLmpzIiwid2VicGFjazovL2NvbXBhbnktdGVzdC8uL3JlZHV4L0NvbmZpZ3VyZVN0b3JlLmpzIiwid2VicGFjazovL2NvbXBhbnktdGVzdC8uL3JlZHV4L2FjdGlvbnMvQWN0aW9uVHlwZXMuanMiLCJ3ZWJwYWNrOi8vY29tcGFueS10ZXN0Ly4vcmVkdXgvcmVkdWNlcnMvUlJlc3VsdC5qcyIsIndlYnBhY2s6Ly9jb21wYW55LXRlc3QvZXh0ZXJuYWwgXCJuZXh0L2hlYWRcIiIsIndlYnBhY2s6Ly9jb21wYW55LXRlc3QvZXh0ZXJuYWwgXCJyZWFjdC1yZWR1eFwiIiwid2VicGFjazovL2NvbXBhbnktdGVzdC9leHRlcm5hbCBcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiIiwid2VicGFjazovL2NvbXBhbnktdGVzdC9leHRlcm5hbCBcInJlZHV4XCIiLCJ3ZWJwYWNrOi8vY29tcGFueS10ZXN0L2V4dGVybmFsIFwicmVkdXgtbG9nZ2VyXCIiLCJ3ZWJwYWNrOi8vY29tcGFueS10ZXN0L2V4dGVybmFsIFwicmVkdXgtcGVyc2lzdFwiIiwid2VicGFjazovL2NvbXBhbnktdGVzdC9leHRlcm5hbCBcInJlZHV4LXBlcnNpc3QvaW50ZWdyYXRpb24vcmVhY3RcIiIsIndlYnBhY2s6Ly9jb21wYW55LXRlc3QvZXh0ZXJuYWwgXCJyZWR1eC1wZXJzaXN0L2xpYi9zdG9yYWdlXCIiLCJ3ZWJwYWNrOi8vY29tcGFueS10ZXN0L2V4dGVybmFsIFwicmVkdXgtdGh1bmtcIiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSGVhZCBmcm9tIFwibmV4dC9oZWFkXCI7XHJcblxyXG5jb25zdCBNZXRhID0gKHsgdGl0bGUsIGtleXdvcmRzLCBkZXNjcmlwdGlvbiB9KSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxIZWFkPlxyXG4gICAgICA8bWV0YSBuYW1lPVwidmlld3BvcnRcIiBjb250ZW50PVwid2lkdGg9ZGV2aWNlLXdpZHRoLCBpbml0aWFsLXNjYWxlPTFcIiAvPlxyXG4gICAgICA8bWV0YSBuYW1lPVwia2V5d29yZHNcIiBjb250ZW50PXtrZXl3b3Jkc30gLz5cclxuICAgICAgPG1ldGEgbmFtZT1cImRlc2NyaXB0aW9uXCIgY29udGVudD17ZGVzY3JpcHRpb259IC8+XHJcbiAgICAgIDxtZXRhIGNoYXJTZXQ9XCJ1dGYtOFwiIC8+XHJcbiAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cclxuICAgICAgPHRpdGxlPnt0aXRsZX08L3RpdGxlPlxyXG4gICAgPC9IZWFkPlxyXG4gICk7XHJcbn07XHJcblxyXG5NZXRhLmRlZmF1bHRQcm9wcyA9IHtcclxuICAvLyB0aXRsZTogXCJQYXN0ZXJvY2suaW9cIixcclxuICAvLyBrZXl3b3JkczogXCJwYXN0ZSwgcHJvZ3JhbW1pbmdcIixcclxuICAvLyBkZXNjcmlwdGlvbjogXCJjcmVhdGUgcGFzdGVcIixcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IE1ldGE7XHJcbiIsImltcG9ydCBNZXRhIGZyb20gXCIuL0hlYWRlci9NZXRhXCI7XHJcblxyXG5mdW5jdGlvbiBMYXlvdXQoeyBjaGlsZHJlbiB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiXCI+XHJcbiAgICAgIDxNZXRhIC8+XHJcbiAgICAgIHtjaGlsZHJlbn1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IExheW91dDtcclxuIiwiaW1wb3J0IFwidGFpbHdpbmRjc3MvdGFpbHdpbmQuY3NzXCI7XG5pbXBvcnQgTGF5b3V0IGZyb20gXCIuLi9jb21wb25lbnRzL0xheW91dFwiO1xuaW1wb3J0IFwiLi4vc3R5bGVzL2dsb2JhbHMuY3NzXCI7XG5cbmltcG9ydCB7IGNvbmZpZ3VyZVN0b3JlIH0gZnJvbSBcIi4uL3JlZHV4L0NvbmZpZ3VyZVN0b3JlXCI7XG5pbXBvcnQgeyBQcm92aWRlciB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xuaW1wb3J0IHsgUGVyc2lzdEdhdGUgfSBmcm9tIFwicmVkdXgtcGVyc2lzdC9pbnRlZ3JhdGlvbi9yZWFjdFwiO1xuXG5jb25zdCB7IHBlcnNpc3Rvciwgc3RvcmUgfSA9IGNvbmZpZ3VyZVN0b3JlKCk7XG5mdW5jdGlvbiBNeUFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8UHJvdmlkZXIgc3RvcmU9e3N0b3JlfT5cbiAgICAgIDxQZXJzaXN0R2F0ZSBwZXJzaXN0b3I9e3BlcnNpc3Rvcn0+XG4gICAgICAgIDxMYXlvdXQ+XG4gICAgICAgICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPlxuICAgICAgICA8L0xheW91dD5cbiAgICAgIDwvUGVyc2lzdEdhdGU+XG4gICAgPC9Qcm92aWRlcj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgTXlBcHA7XG4iLCJpbXBvcnQgeyBjcmVhdGVTdG9yZSwgYXBwbHlNaWRkbGV3YXJlIH0gZnJvbSBcInJlZHV4XCI7XHJcbmltcG9ydCB7IHBlcnNpc3RTdG9yZSwgcGVyc2lzdENvbWJpbmVSZWR1Y2VycyB9IGZyb20gXCJyZWR1eC1wZXJzaXN0XCI7XHJcbmltcG9ydCB0aHVuayBmcm9tIFwicmVkdXgtdGh1bmtcIjtcclxuaW1wb3J0IGxvZ2dlciBmcm9tIFwicmVkdXgtbG9nZ2VyXCI7XHJcbmltcG9ydCBzdG9yYWdlIGZyb20gXCJyZWR1eC1wZXJzaXN0L2xpYi9zdG9yYWdlXCI7XHJcbmltcG9ydCBSUmVzdWx0IGZyb20gXCIuL3JlZHVjZXJzL1JSZXN1bHRcIjtcclxuY29uc3QgY29uZmlnID0ge1xyXG4gIGtleTogXCJjb21wYW55LXRlc3RcIixcclxuICBzdG9yYWdlLFxyXG4gIGRlYnVnOiB0cnVlLFxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IGNvbmZpZ3VyZVN0b3JlID0gKCkgPT4ge1xyXG4gIGNvbnN0IHN0b3JlID0gY3JlYXRlU3RvcmUoXHJcbiAgICBwZXJzaXN0Q29tYmluZVJlZHVjZXJzKGNvbmZpZywge1xyXG4gICAgICByZXN1bHQ6IFJSZXN1bHQsXHJcbiAgICB9KSxcclxuICAgIGFwcGx5TWlkZGxld2FyZSh0aHVuaywgbG9nZ2VyKVxyXG4gICk7XHJcblxyXG4gIGNvbnN0IHBlcnNpc3RvciA9IHBlcnNpc3RTdG9yZShzdG9yZSk7XHJcblxyXG4gIHJldHVybiB7IHBlcnNpc3Rvciwgc3RvcmUgfTtcclxufTtcclxuLy8gaW1wb3J0IHsgY3JlYXRlU3RvcmUsIGFwcGx5TWlkZGxld2FyZSwgY29tcG9zZSB9IGZyb20gXCJyZWR1eFwiO1xyXG4vLyBpbXBvcnQgeyBwZXJzaXN0U3RvcmUsIHBlcnNpc3RDb21iaW5lUmVkdWNlcnMgfSBmcm9tIFwicmVkdXgtcGVyc2lzdFwiO1xyXG4vLyBpbXBvcnQgdGh1bmsgZnJvbSBcInJlZHV4LXRodW5rXCI7XHJcbi8vIGltcG9ydCBzdG9yYWdlIGZyb20gXCJyZWR1eC1wZXJzaXN0L2xpYi9zdG9yYWdlXCI7XHJcbi8vIC8vIGltcG9ydCBzdG9yYWdlIGZyb20gXCIuLi9zdG9yYWdlXCI7XHJcbi8vIGltcG9ydCBSZXN1bHQgZnJvbSBcIi4vcmVkdWNlcnMvUlJlc3VsdFwiO1xyXG4vLyBpbXBvcnQgbG9nZ2VyIGZyb20gXCJyZWR1eC1sb2dnZXJcIjtcclxuXHJcbi8vIGNvbnN0IGNvbmZpZyA9IHtcclxuLy8gICBrZXk6IFwiY29tcGFueVwiLFxyXG4vLyAgIHN0b3JhZ2UsXHJcbi8vICAgZGVidWc6IHRydWUsXHJcbi8vIH07XHJcbi8vIGNvbnN0IGNvbXBvc2VFbmhhbmNlciA9IHdpbmRvdy5fX1JFRFVYX0RFVlRPT0xTX0VYVEVOU0lPTl9DT01QT1NFX18gfHwgY29tcG9zZTtcclxuLy8gZXhwb3J0IGNvbnN0IGNvbmZpZ3VyZVN0b3JlID0gKCkgPT4ge1xyXG4vLyAgIGNvbnN0IHN0b3JlID0gY3JlYXRlU3RvcmUoXHJcbi8vICAgICBwZXJzaXN0Q29tYmluZVJlZHVjZXJzKGNvbmZpZywge1xyXG4vLyAgICAgICByZXN1bHQ6IFJlc3VsdCxcclxuLy8gICAgIH0pLFxyXG4vLyAgICAgY29tcG9zZUVuaGFuY2VyKGFwcGx5TWlkZGxld2FyZSh0aHVuaywgbG9nZ2VyKSlcclxuLy8gICApO1xyXG4vLyAgIGNvbnN0IHBlcnNpc3RvciA9IHBlcnNpc3RTdG9yZShzdG9yZSk7XHJcbi8vICAgcmV0dXJuIHsgcGVyc2lzdG9yLCBzdG9yZSB9O1xyXG4vLyB9O1xyXG4iLCIvLyBSZXN1bHQgYWN0aW9uVHlwZXNcclxuXHJcbmV4cG9ydCBjb25zdCBSRVNVTFRfR0VUX0RBVEEgPSBcIlJFU1VMVF9HRVRfREFUQVwiO1xyXG5leHBvcnQgY29uc3QgUkVTVUxUX1NFVF9EQVRBID0gXCJSRVNVTFRfU0VUX0RBVEFcIjtcclxuZXhwb3J0IGNvbnN0IFJFU1VMVF9GQUlMX0RBVEEgPSBcIlJFU1VMVF9GQUlMX0RBVEFcIjtcclxuZXhwb3J0IGNvbnN0IERFTEVURV9SRVNVTFRfRkFJTCA9IFwiREVMRVRFX1JFU1VMVF9GQUlMXCI7XHJcbmV4cG9ydCBjb25zdCBQT1NUX1JFU1VMVF9EQVRBID0gXCJQT1NUX1JFU1VMVF9EQVRBXCI7XHJcbmV4cG9ydCBjb25zdCBQT1NUX1JFU1VMVF9EQVRBX1NUQVJUID0gXCJQT1NUX1JFU1VMVF9EQVRBX1NUQVJUXCI7XHJcbmV4cG9ydCBjb25zdCBQT1NUX1JFU1VMVF9EQVRBX0ZBSUwgPSBcIlBPU1RfUkVTVUxUX0RBVEFfRkFJTFwiO1xyXG5leHBvcnQgY29uc3QgUE9TVF9SRVNVTFRfREFUQV9TVUNDRVNTID0gXCJQT1NUX1JFU1VMVF9EQVRBX1NVQ0NFU1NcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBVUERBVEVfUkVTVUxUX0RBVEFfU1RBUlQgPSBcIlVQREFURV9SRVNVTFRfREFUQV9TVEFSVFwiO1xyXG5leHBvcnQgY29uc3QgUkVTVUxUX0xPQURJTkcgPSBcIlJFU1VMVF9MT0FESU5HXCI7XHJcbmV4cG9ydCBjb25zdCBSRVNVTFRfRURJVF9TRVRfREFUQSA9IFwiUkVTVUxUX0VESVRfU0VUX0RBVEFcIjtcclxuZXhwb3J0IGNvbnN0IFJFU1VMVF9FRElUX0ZBSUxfREFUQSA9IFwiUkVTVUxUX0VESVRfRkFJTF9EQVRBXCI7XHJcbiIsImltcG9ydCAqIGFzIGFjdGlvblR5cGUgZnJvbSBcIi4uL2FjdGlvbnMvQWN0aW9uVHlwZXNcIjtcclxuXHJcbmNvbnN0IGluaXRpYWxTdGF0ZSA9IHtcclxuICByZXN1bHQ6IFtdLFxyXG4gIGVycm9yOiBmYWxzZSxcclxuICBtYWluUmVzdWx0OiBbXSxcclxuICBpc0xvYWRpbmc6IGZhbHNlLFxyXG59O1xyXG5cclxuY29uc3QgcmVkdWNlciA9IChzdGF0ZSA9IGluaXRpYWxTdGF0ZSwgYWN0aW9uKSA9PiB7XHJcbiAgc3dpdGNoIChhY3Rpb24udHlwZSkge1xyXG4gICAgY2FzZSBhY3Rpb25UeXBlLlJFU1VMVF9TRVRfREFUQTpcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICByZXN1bHQ6IGFjdGlvbi5yZXN1bHQsXHJcbiAgICAgICAgaXNMb2FkaW5nOiBmYWxzZSxcclxuICAgICAgICBlcnJvcjogZmFsc2UsXHJcbiAgICAgIH07XHJcblxyXG4gICAgY2FzZSBhY3Rpb25UeXBlLlJFU1VMVF9GQUlMX0RBVEE6XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgaXNMb2FkaW5nOiBmYWxzZSxcclxuICAgICAgICBlcnJvcjogYWN0aW9uLmVycm9yLFxyXG4gICAgICAgIC8vIHJlc3VsdDogW10sXHJcbiAgICAgIH07XHJcbiAgICBjYXNlIGFjdGlvblR5cGUuUkVTVUxUX0xPQURJTkc6XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgaXNMb2FkaW5nOiB0cnVlLFxyXG4gICAgICAgIGVycm9yOiBmYWxzZSxcclxuICAgICAgICAvLyByZXN1bHQ6IFtdLFxyXG4gICAgICAgIC8vIG1haW5SZXN1bHQ6IFtdLFxyXG4gICAgICB9O1xyXG5cclxuICAgIGNhc2UgYWN0aW9uVHlwZS5QT1NUX1JFU1VMVF9EQVRBX0ZBSUw6XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgaXNMb2FkaW5nOiBmYWxzZSxcclxuICAgICAgICBlcnJvcjogYWN0aW9uLmVycm9yLFxyXG4gICAgICB9O1xyXG4gICAgY2FzZSBhY3Rpb25UeXBlLlJFU1VMVF9FRElUX1NFVF9EQVRBOlxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgIGlzTG9hZGluZzogZmFsc2UsXHJcbiAgICAgICAgZXJyb3I6IGZhbHNlLFxyXG4gICAgICAgIG1haW5SZXN1bHQ6IGFjdGlvbi5tYWluUmVzdWx0LFxyXG4gICAgICB9O1xyXG4gICAgY2FzZSBhY3Rpb25UeXBlLlJFU1VMVF9FRElUX0ZBSUxfREFUQTpcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICBpc0xvYWRpbmc6IGZhbHNlLFxyXG4gICAgICAgIGVycm9yOiBhY3Rpb24uZXJyb3IsXHJcbiAgICAgICAgLy8gbWFpblJlc3VsdDogW10sXHJcbiAgICAgIH07XHJcbiAgICBjYXNlIGFjdGlvblR5cGUuVVBEQVRFX1JFU1VMVF9EQVRBX1NUQVJUOlxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgIGlzTG9hZGluZzogZmFsc2UsXHJcbiAgICAgIH07XHJcblxyXG4gICAgZGVmYXVsdDpcclxuICAgICAgcmV0dXJuIHN0YXRlO1xyXG4gIH1cclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHJlZHVjZXI7XHJcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvaGVhZFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC1yZWR1eFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVkdXhcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVkdXgtbG9nZ2VyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlZHV4LXBlcnNpc3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVkdXgtcGVyc2lzdC9pbnRlZ3JhdGlvbi9yZWFjdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWR1eC1wZXJzaXN0L2xpYi9zdG9yYWdlXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlZHV4LXRodW5rXCIpOyJdLCJuYW1lcyI6WyJIZWFkIiwiTWV0YSIsInRpdGxlIiwia2V5d29yZHMiLCJkZXNjcmlwdGlvbiIsImRlZmF1bHRQcm9wcyIsIkxheW91dCIsImNoaWxkcmVuIiwiY29uZmlndXJlU3RvcmUiLCJQcm92aWRlciIsIlBlcnNpc3RHYXRlIiwicGVyc2lzdG9yIiwic3RvcmUiLCJNeUFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyIsImNyZWF0ZVN0b3JlIiwiYXBwbHlNaWRkbGV3YXJlIiwicGVyc2lzdFN0b3JlIiwicGVyc2lzdENvbWJpbmVSZWR1Y2VycyIsInRodW5rIiwibG9nZ2VyIiwic3RvcmFnZSIsIlJSZXN1bHQiLCJjb25maWciLCJrZXkiLCJkZWJ1ZyIsInJlc3VsdCIsIlJFU1VMVF9HRVRfREFUQSIsIlJFU1VMVF9TRVRfREFUQSIsIlJFU1VMVF9GQUlMX0RBVEEiLCJERUxFVEVfUkVTVUxUX0ZBSUwiLCJQT1NUX1JFU1VMVF9EQVRBIiwiUE9TVF9SRVNVTFRfREFUQV9TVEFSVCIsIlBPU1RfUkVTVUxUX0RBVEFfRkFJTCIsIlBPU1RfUkVTVUxUX0RBVEFfU1VDQ0VTUyIsIlVQREFURV9SRVNVTFRfREFUQV9TVEFSVCIsIlJFU1VMVF9MT0FESU5HIiwiUkVTVUxUX0VESVRfU0VUX0RBVEEiLCJSRVNVTFRfRURJVF9GQUlMX0RBVEEiLCJhY3Rpb25UeXBlIiwiaW5pdGlhbFN0YXRlIiwiZXJyb3IiLCJtYWluUmVzdWx0IiwiaXNMb2FkaW5nIiwicmVkdWNlciIsInN0YXRlIiwiYWN0aW9uIiwidHlwZSJdLCJzb3VyY2VSb290IjoiIn0=