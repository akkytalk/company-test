"use strict";
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "axios");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! formik */ "formik");
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! reactstrap */ "reactstrap");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(reactstrap__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Data/Data.json */ "./components/Data/Data.json");
/* harmony import */ var _components_Data_options_json__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../components/Data/options.json */ "./components/Data/options.json");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _redux_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../redux/actions */ "./redux/actions/index.js");
/* harmony import */ var react_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-router */ "react-router");
/* harmony import */ var react_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__);
var _jsxFileName = "E:\\git vinraj\\company-test\\pages\\index.js";











var result = new Array();
var MainResult = new Array();

function Home(props) {
  const {
    0: value,
    1: setValue
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({});
  const history = (0,react_router__WEBPACK_IMPORTED_MODULE_9__.useHistory)();
  const {
    0: company,
    1: setCompany
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
    CDU: 0,
    SPD: 0,
    AfD: 0,
    FDP: 0,
    Grüne: 0,
    Linke: 0
  });
  const {
    0: CDU,
    1: setCDU
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
  const {
    0: SPD,
    1: setSPD
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
  const {
    0: AfD,
    1: setAfD
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
  const {
    0: FDP,
    1: setFDP
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
  const {
    0: Grüne,
    1: setGrüne
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
  const {
    0: Linke,
    1: setLinke
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
  console.log("props.result", props.result);
  console.log("value", value);
  let graphData = [CDU, SPD, AfD, FDP, Grüne, Linke];
  props.resultEditSetData(graphData);
  console.log("array", result);
  console.log("CDU", CDU);
  console.log("SPD", SPD);
  console.log("AfD", AfD);
  console.log("FDP", FDP);
  console.log("Grüne", Grüne);
  console.log("Linke", Linke);
  const dataLength = _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_5__ === null || _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_5__ === void 0 ? void 0 : _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_5__.length;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)("div", {
    className: "",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)("title", {
        children: "Create Next App"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 64,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_4__.Card, {
      className: "p-5 border-2 shadow-md rounded-md",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_4__.CardBody, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
          initialValues: {
            result: [],
            answer: ""
          },
          onSubmit: (values, setSubmitting) => {
            var _props$result;

            // setSPD(SPD + 1);
            if (((_props$result = props.result) === null || _props$result === void 0 ? void 0 : _props$result.length) > 0) {
              var _props$result2, _props$result3;

              console.log("result length", (_props$result2 = props.result) === null || _props$result2 === void 0 ? void 0 : _props$result2.length);
              const resultLength = (_props$result3 = props.result) === null || _props$result3 === void 0 ? void 0 : _props$result3.length;

              for (const r of props.result) {
                console.log("result map");

                for (const d of _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_5__) {
                  console.log("data map");

                  if (r.question_id == d.id) {
                    console.log("r.question_id", r.question_id, "d.id", d.id);

                    if (d.SPD == r.answer) {
                      console.log("SPD before", d.SPD);
                      setSPD(SPD = SPD + 1);
                      console.log("SPD", SPD);
                    }

                    if (d.CDU == r.answer) {
                      console.log("CDU", CDU);
                      setCDU(CDU = CDU + 1);
                    }

                    if (d.AfD == r.answer) {
                      console.log("AfD", AFD);
                      setAfD(AFD = AfD + 1);
                      console.log("AfD after", AFD);
                    }

                    if (d.FDP == r.answer) {
                      console.log("FDP");
                      setFDP(FDP = FDP + 1);
                    }

                    if (d.Grüne == r.answer) {
                      console.log("Grüne");
                      setGrüne(Grüne = Grüne + 1);
                    }

                    if (d.Linke == r.answer) {
                      console.log("Linke");
                      setLinke(Linke = Linke + 1);
                    } else {
                      console.log("else from last if");
                    }
                  }
                }
              } // props.result?.map((r) => {
              //   console.log("result map");
              //   data?.map((d) => {
              //     console.log("data map");
              //     if (r.question_id == d.id) {
              //       console.log("r.question_id", r.question_id, "d.id", d.id);
              //       if (d.SPD == r.answer) {
              //         console.log("SPD");
              //         setSPD(...SPD, SPD + 1);
              //       }
              //       if (d.CDU == r.answer) {
              //         console.log("CDU");
              //         setCDU(...CDU, CDU + 1);
              //       }
              //       if (d.AfD == r.answer) {
              //         console.log("AfD");
              //         setAfD(...AfD, AfD + 1);
              //       }
              //       if (d.FDP == r.answer) {
              //         console.log("FDP");
              //         setFDP(...FDP, FDP + 1);
              //       }
              //       if (d.Grüne == r.answer) {
              //         console.log("Grüne");
              //         setGrüne(...Grüne, Grüne + 1);
              //       }
              //       if (d.Linke == r.answer) {
              //         console.log("Linke");
              //         setLinke(...Linke, Linke + 1);
              //       } else {
              //         console.log("else from last if");
              //       }
              //     }
              //   });
              // });

            } // let graphData = {
            //   CDU: CDU,
            //   SPD: SPD,
            //   AfD: AfD,
            //   FDP: FDP,
            //   Grüne: Grüne,
            //   Linke: Linke,
            // };


            console.log("submit click"); // axios
            //   .post("https://uditsolutions.in/yarn/public/api/scores", data)
            //   .then((res) => {
            //     console.log(res);
            //     console.log("intial value is submited to results");
            //     result = [];
            //     history.push("/thankyou");
            //   })
            //   .catch((err) => {
            //     console.log(err.response.data);
            //     // history.push("/exam-appeared");
            //   });
          },
          children: ({
            handleSubmit
          }) => {
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_4__.Form, {
              onSubmit: handleSubmit,
              children: [_components_Data_Data_json__WEBPACK_IMPORTED_MODULE_5__ === null || _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_5__ === void 0 ? void 0 : _components_Data_Data_json__WEBPACK_IMPORTED_MODULE_5__.map((d, id) => {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)("div", {
                  className: "mt-3",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_4__.CardTitle, {
                    children: [" ", d.id, "/", dataLength]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 187,
                    columnNumber: 25
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_4__.CardSubtitle, {
                    children: d.Schlagwort
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 191,
                    columnNumber: 25
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_4__.CardText, {
                    children: d.question_text
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 192,
                    columnNumber: 25
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.FieldArray, {
                    name: "result",
                    render: arrayHelpers => {
                      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)("div", {
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_4__.Row, {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_4__.Col, {
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_4__.FormGroup, {
                              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_4__.InputGroup, {
                                className: "flex flex-col mt-2",
                                children: _components_Data_options_json__WEBPACK_IMPORTED_MODULE_6__ === null || _components_Data_options_json__WEBPACK_IMPORTED_MODULE_6__ === void 0 ? void 0 : _components_Data_options_json__WEBPACK_IMPORTED_MODULE_6__.map(opt => {
                                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)("label", {
                                    className: "p-2 bg-gray-600 text-white rounded-md text-center hover:bg-yellow-300 hover:text-black mb-1",
                                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                                      type: "radio" // name="answer"
                                      ,
                                      value: opt.option_Value,
                                      className: "hidden",
                                      onChange: () => {
                                        setValue({
                                          question_id: d.id,
                                          answer: opt.option_Value
                                        });

                                        if (result.length > 0) {
                                          for (let i = 0; i < result.length; i++) {
                                            var _result$i;

                                            if (((_result$i = result[i]) === null || _result$i === void 0 ? void 0 : _result$i.question_id) == d.id) {
                                              console.log("splice");
                                              result.splice(i, 1, {
                                                question_id: d.id,
                                                answer: opt.option_Value
                                              });
                                              props.resultSetData(result);
                                              return;
                                            } else if (result[i].question_id !== d.id) {
                                              console.log("else_if question of data", d.id, "result q-id", result[i].question_id);
                                              result.push({
                                                question_id: d.id,
                                                answer: opt.option_Value
                                              });
                                              props.resultSetData(result);
                                              return;
                                            }
                                          }

                                          props.resultSetData(result);
                                        } else {
                                          console.log("else");
                                          result.push({
                                            question_id: d.id,
                                            answer: opt.option_Value
                                          });
                                          props.resultSetData(result);
                                        }
                                      }
                                    }, void 0, false, {
                                      fileName: _jsxFileName,
                                      lineNumber: 208,
                                      columnNumber: 47
                                    }, this), opt.option_text]
                                  }, opt.id, true, {
                                    fileName: _jsxFileName,
                                    lineNumber: 204,
                                    columnNumber: 45
                                  }, this);
                                })
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 201,
                                columnNumber: 39
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 200,
                              columnNumber: 37
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 199,
                            columnNumber: 35
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 198,
                          columnNumber: 33
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 197,
                        columnNumber: 31
                      }, this);
                    }
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 193,
                    columnNumber: 25
                  }, this)]
                }, d.id, true, {
                  fileName: _jsxFileName,
                  lineNumber: 186,
                  columnNumber: 23
                }, this);
              }), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(reactstrap__WEBPACK_IMPORTED_MODULE_4__.Button, {
                  block: true,
                  className: "border-2 p-2 border-black mt-7",
                  type: "submit" // onClick={handleSubmit}
                  // disabled={formProps.isSubmitting}
                  ,
                  children: "Eegebnis zeigen"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 298,
                  columnNumber: 21
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 297,
                columnNumber: 19
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 183,
              columnNumber: 17
            }, this);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 70,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 69,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 68,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 63,
    columnNumber: 5
  }, this);
}

const mapStateToProps = state => {
  return {
    result: state.result.result
  };
};

const mapDispatchToProps = dispatch => {
  return {
    resultSetData: data => dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_8__.resultSetData(data)),
    onDeleteResult: (data, id) => dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_8__.deleteResult(data, id)),
    onPostResultData: (data, user, toggle) => dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_8__.postResultData(data, user, toggle)),
    onUpdateResultData: (data, user, toggle) => dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_8__.updateResultData(data, user, toggle)),
    resultEditSetData: data => dispatch(_redux_actions__WEBPACK_IMPORTED_MODULE_8__.resultEditSetData(data))
  };
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_redux__WEBPACK_IMPORTED_MODULE_7__.connect)(mapStateToProps, mapDispatchToProps)(Home));

/***/ }),

/***/ "./redux/actions/ActionTypes.js":
/*!**************************************!*\
  !*** ./redux/actions/ActionTypes.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RESULT_GET_DATA": () => (/* binding */ RESULT_GET_DATA),
/* harmony export */   "RESULT_SET_DATA": () => (/* binding */ RESULT_SET_DATA),
/* harmony export */   "RESULT_FAIL_DATA": () => (/* binding */ RESULT_FAIL_DATA),
/* harmony export */   "DELETE_RESULT_FAIL": () => (/* binding */ DELETE_RESULT_FAIL),
/* harmony export */   "POST_RESULT_DATA": () => (/* binding */ POST_RESULT_DATA),
/* harmony export */   "POST_RESULT_DATA_START": () => (/* binding */ POST_RESULT_DATA_START),
/* harmony export */   "POST_RESULT_DATA_FAIL": () => (/* binding */ POST_RESULT_DATA_FAIL),
/* harmony export */   "POST_RESULT_DATA_SUCCESS": () => (/* binding */ POST_RESULT_DATA_SUCCESS),
/* harmony export */   "UPDATE_RESULT_DATA_START": () => (/* binding */ UPDATE_RESULT_DATA_START),
/* harmony export */   "RESULT_LOADING": () => (/* binding */ RESULT_LOADING),
/* harmony export */   "RESULT_EDIT_SET_DATA": () => (/* binding */ RESULT_EDIT_SET_DATA),
/* harmony export */   "RESULT_EDIT_FAIL_DATA": () => (/* binding */ RESULT_EDIT_FAIL_DATA)
/* harmony export */ });
// Result actionTypes
const RESULT_GET_DATA = "RESULT_GET_DATA";
const RESULT_SET_DATA = "RESULT_SET_DATA";
const RESULT_FAIL_DATA = "RESULT_FAIL_DATA";
const DELETE_RESULT_FAIL = "DELETE_RESULT_FAIL";
const POST_RESULT_DATA = "POST_RESULT_DATA";
const POST_RESULT_DATA_START = "POST_RESULT_DATA_START";
const POST_RESULT_DATA_FAIL = "POST_RESULT_DATA_FAIL";
const POST_RESULT_DATA_SUCCESS = "POST_RESULT_DATA_SUCCESS";
const UPDATE_RESULT_DATA_START = "UPDATE_RESULT_DATA_START";
const RESULT_LOADING = "RESULT_LOADING";
const RESULT_EDIT_SET_DATA = "RESULT_EDIT_SET_DATA";
const RESULT_EDIT_FAIL_DATA = "RESULT_EDIT_FAIL_DATA";

/***/ }),

/***/ "./redux/actions/ResultCreators.js":
/*!*****************************************!*\
  !*** ./redux/actions/ResultCreators.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "resultSetData": () => (/* binding */ resultSetData),
/* harmony export */   "resultFailData": () => (/* binding */ resultFailData),
/* harmony export */   "resultLoading": () => (/* binding */ resultLoading),
/* harmony export */   "resultGetData": () => (/* binding */ resultGetData),
/* harmony export */   "resultEditSetData": () => (/* binding */ resultEditSetData),
/* harmony export */   "resultEditFailData": () => (/* binding */ resultEditFailData),
/* harmony export */   "resultEditGetData": () => (/* binding */ resultEditGetData),
/* harmony export */   "deleteResultFail": () => (/* binding */ deleteResultFail),
/* harmony export */   "deleteResult": () => (/* binding */ deleteResult),
/* harmony export */   "postResultDataStart": () => (/* binding */ postResultDataStart),
/* harmony export */   "postResultDataFail": () => (/* binding */ postResultDataFail),
/* harmony export */   "postResultData": () => (/* binding */ postResultData),
/* harmony export */   "updateResultDataStart": () => (/* binding */ updateResultDataStart),
/* harmony export */   "updateResultData": () => (/* binding */ updateResultData)
/* harmony export */ });
/* harmony import */ var _ActionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ActionTypes */ "./redux/actions/ActionTypes.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "axios");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var sweetalert__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! sweetalert */ "sweetalert");
/* harmony import */ var sweetalert__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(sweetalert__WEBPACK_IMPORTED_MODULE_2__);


 // import { baseUrl } from "../../shared/baseUrl";

const resultSetData = result => {
  return {
    type: _ActionTypes__WEBPACK_IMPORTED_MODULE_0__.RESULT_SET_DATA,
    result: result
  };
};
const resultFailData = error => {
  return {
    type: _ActionTypes__WEBPACK_IMPORTED_MODULE_0__.RESULT_FAIL_DATA,
    error: error
  };
};
const resultLoading = () => {
  return {
    type: _ActionTypes__WEBPACK_IMPORTED_MODULE_0__.RESULT_LOADING
  };
};
const resultGetData = data => {// return (dispatch) => {
  //   dispatch(resultLoading());
  //   axios
  //     .get(baseUrl + `result/${data?.id}`, {
  //       headers: {
  //         Accept: "application/json",
  //         "Content-Type": "application/json",
  //         Authorization: "Bearer " + data.token,
  //       },
  //     })
  //     .then((res) => {
  //       dispatch(resultSetData(res.data));
  //       console.log("graph data", res.data);
  //     })
  //     .catch((error) => dispatch(resultFailData(error)));
  // };
}; // export const testReportData = (data) => {
//   return (dispatch) => {
//     dispatch(resultLoading());
//     axios
//       .get(baseUrl + "getTemp", {
//         headers: {
//           Accept: "application/json",
//           "Content-Type": "application/json",
//           Authorization: "Bearer " + data.token,
//         },
//       })
//       .then((res) => {
//         dispatch(resultEditSetData(res.data));
//         console.log("response data", res.data);
//       })
//       .catch((error) => dispatch(resultEditFailData(error)));
//   };
// };

const resultEditSetData = mainResult => {
  return {
    type: _ActionTypes__WEBPACK_IMPORTED_MODULE_0__.RESULT_EDIT_SET_DATA,
    mainResult: mainResult
  };
};
const resultEditFailData = error => {
  return {
    type: _ActionTypes__WEBPACK_IMPORTED_MODULE_0__.RESULT_EDIT_FAIL_DATA,
    error: error
  };
};
const resultEditGetData = data => {// return (dispatch) => {
  //   dispatch(resultLoading());
  //   axios
  //     .get(baseUrl + `getTemp/${data?.id}`, {
  //       headers: {
  //         Accept: "application/json",
  //         "Content-Type": "application/json",
  //         Authorization: "Bearer " + data.token,
  //       },
  //     })
  //     .then((res) => {
  //       dispatch(resultEditSetData(res.data));
  //       console.log("response data", res.data);
  //     })
  //     .catch((error) => dispatch(resultEditFailData(error)));
  // };
};
const deleteResultFail = error => {
  return {
    type: _ActionTypes__WEBPACK_IMPORTED_MODULE_0__.DELETE_RESULT_FAIL,
    error: error
  };
};
const deleteResult = (data, id) => {// return (dispatch) => {
  //   if (id) {
  //     axios
  //       .delete(baseUrl + `result/${id}`, {
  //         headers: {
  //           Accept: "application/json",
  //           "Content-Type": "application/json",
  //           Authorization: "Bearer " + data?.token,
  //         },
  //       })
  //       .then(() => {
  //         console.log("swal");
  //         swal("Successfully Deleted  Result!").then(() => {
  //           dispatch(resultGetData(data));
  //         });
  //       })
  //       .catch((error) => dispatch(deleteResultFail(error)));
  //   }
  // };
};
const postResultDataStart = () => {
  return {
    type: _ActionTypes__WEBPACK_IMPORTED_MODULE_0__.POST_RESULT_DATA_START
  };
};
const postResultDataFail = error => {
  return {
    type: _ActionTypes__WEBPACK_IMPORTED_MODULE_0__.POST_RESULT_DATA_FAIL,
    error: error
  };
};
const postResultData = (data, user, toggle) => {// return (dispatch) => {
  //   dispatch(postResultDataStart());
  //   axios
  //     .post(baseUrl + "result", user, {
  //       headers: {
  //         Accept: "application/json",
  //         "Content-Type": "application/json",
  //         Authorization: "Bearer " + data?.token,
  //       },
  //     })
  //     .then(() => {
  //       console.log("swal");
  //       swal("Successfully Created  Result!").then(() => {
  //         dispatch(resultGetData(data));
  //         toggle();
  //       });
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //       dispatch(postResultDataFail(error));
  //     });
  // };
};
const updateResultDataStart = () => {
  return {
    type: _ActionTypes__WEBPACK_IMPORTED_MODULE_0__.UPDATE_RESULT_DATA_START
  };
};
const updateResultData = (data, user, toggle) => {// return (dispatch) => {
  //   dispatch(updateResultDataStart());
  //   axios
  //     .post(baseUrl + `result/${data.id}?_method=PUT`, user, {
  //       headers: {
  //         Accept: "application/json",
  //         "Content-Type": "application/json",
  //         Authorization: "Bearer " + data.token,
  //       },
  //     })
  //     .then(() => {
  //       console.log("swal");
  //       swal("Successfully Updated  Result!").then(() => {
  //         toggle();
  //         dispatch(resultGetData(data));
  //       });
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  // };
};

/***/ }),

/***/ "./redux/actions/index.js":
/*!********************************!*\
  !*** ./redux/actions/index.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "resultGetData": () => (/* reexport safe */ _ResultCreators__WEBPACK_IMPORTED_MODULE_0__.resultGetData),
/* harmony export */   "deleteResult": () => (/* reexport safe */ _ResultCreators__WEBPACK_IMPORTED_MODULE_0__.deleteResult),
/* harmony export */   "postResultData": () => (/* reexport safe */ _ResultCreators__WEBPACK_IMPORTED_MODULE_0__.postResultData),
/* harmony export */   "updateResultData": () => (/* reexport safe */ _ResultCreators__WEBPACK_IMPORTED_MODULE_0__.updateResultData),
/* harmony export */   "resultEditGetData": () => (/* reexport safe */ _ResultCreators__WEBPACK_IMPORTED_MODULE_0__.resultEditGetData),
/* harmony export */   "resultSetData": () => (/* reexport safe */ _ResultCreators__WEBPACK_IMPORTED_MODULE_0__.resultSetData),
/* harmony export */   "resultEditSetData": () => (/* reexport safe */ _ResultCreators__WEBPACK_IMPORTED_MODULE_0__.resultEditSetData)
/* harmony export */ });
/* harmony import */ var _ResultCreators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ResultCreators */ "./redux/actions/ResultCreators.js");


/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ "formik":
/*!*************************!*\
  !*** external "formik" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ "react-router":
/*!*******************************!*\
  !*** external "react-router" ***!
  \*******************************/
/***/ ((module) => {

module.exports = require("react-router");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "reactstrap":
/*!*****************************!*\
  !*** external "reactstrap" ***!
  \*****************************/
/***/ ((module) => {

module.exports = require("reactstrap");

/***/ }),

/***/ "sweetalert":
/*!*****************************!*\
  !*** external "sweetalert" ***!
  \*****************************/
/***/ ((module) => {

module.exports = require("sweetalert");

/***/ }),

/***/ "./components/Data/Data.json":
/*!***********************************!*\
  !*** ./components/Data/Data.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('[{"id":1,"question_text":"Die Debatte um eine Umverteilung durch die Steuerpolitik gibt es bereits seit Jahrzehnten. Befürworten Sie eine stärkere Steuerlast für hohe Einkommen?","Politikfeld":"Einkommen und Vermögen","Schlagwort":"Umverteilung","CDU":"Nein","SPD":"Ja","AfD":"Nein","FDP":"Nein","Grüne":"Ja","Linke":"Ja"},{"id":2,"question_text":"Der Solidaritätszuschlag wurde ursprünglich zur Finanzierung der Kosten der deutschen Einheit sowie des Golfkriegs erhoben und war anfangs auf ein Jahr befristet. Zum 01.01.2021 wurden 90% der Soli-Zahler entlastet, die restlichen Steuerzahler schultern aber immer noch knapp 10 Mrd. Euro pro Jahr. Sind Sie für eine endgültige Abschaffung des Solidaritätszuschlags?","Politikfeld":"Einkommen und Vermögen","Schlagwort":"Solidaritätszuschlag","CDU":"Ja","SPD":"Nein","AfD":"Ja","FDP":"Ja","Grüne":"kA","Linke":"Ja"},{"id":3,"question_text":"Seit mehreren Jahren diskutieren Politikerinnen u.a. über den sog. Mittelstandsbauch im Einkommensteuertarif. Würden Sie eine deutliche Tarifsenkung in der Einkommensteuer über alle Einkommensklassen unterstützen?","Politikfeld":"Einkommen und Vermögen","Schlagwort":"Einkommenssteuer","CDU":"kA","SPD":"Nein","AfD":"kA","FDP":"Ja","Grüne":"Nein","Linke":"Nein"},{"id":4,"question_text":"Politische Akteure aus unterschiedlichen Lagern fordern, die Lücken im Haushalt aus der Pandemie durch eine stärkere Besteuerung von Erbschaften auszugleichen. Stimmen Sie dieser Forderung zu?","Politikfeld":"Einkommen und Vermögen","Schlagwort":"Haushalt","CDU":"Nein","SPD":"Ja","AfD":"Nein","FDP":"Nein","Grüne":"Ja","Linke":"Ja"},{"id":5,"question_text":"Sollte die Spekulationsfrist für Verkäufe von selbstgenutzten Wohnimmobilien dahingehend abgeschafft werden, dass auch nach langfristigem Besitz kein steuerfreier Verkauf mehr möglich ist?","Politikfeld":"Einkommen und Vermögen","Schlagwort":"Spekulationsfrist","CDU":"kA","SPD":"Ja","AfD":"kA","FDP":"kA","Grüne":"kA","Linke":"Ja"},{"id":6,"question_text":"Wer einen Dienstwagen privat nutzt, fällt unter ein besonderes Regime der Besteuerung des geldwerten Vorteils, das klimafreundliche Dienstwagen bevorzugt besteuert. Vielfach wird dies als Dienstwagenprivileg kritisiert. Sind sie für eine höhere Besteuerung privat genutzter Dienstwagen oder zumindest einen sozial-ökologischen Umbau?","Politikfeld":"Einkommen und Vermögen","Schlagwort":"Dienstwagen","CDU":"kA","SPD":"kA","AfD":"kA","FDP":"kA","Grüne":"Ja","Linke":"Ja"},{"id":7,"question_text":"Seit Jahren ist das Ehegattensplitting in der Diskussion, z.B. wird immer wieder gefordert, stattdessene eine Individualbesteuerung einzugführen, bei der ggf. nur ein nicht genutzter Grundfreibetrag übertragen werden kann. Soll das Ehegattensplitting für neu geschlossene Ehen beibehalten werden ?","Politikfeld":"Einkommen und Vermögen","Schlagwort":"Ehegattensplitting","CDU":"Ja","SPD":"Nein","AfD":"kA","FDP":"Ja","Grüne":"Nein","Linke":"Nein"},{"id":8,"question_text":"Sollen kinderreiche Familien steuerlich gefördert werden, in dem das Ehegattensplitting zu einem Familiensplitting erweitert wird?","Politikfeld":"Einkommen und Vermögen","Schlagwort":"Familiensplitting","CDU":"Ja","SPD":"kA","AfD":"Ja","FDP":"kA","Grüne":"kA","Linke":"kA"},{"id":9,"question_text":"Seit der Corona-Krise erlebt das Home Office einen Boom und wird für die Jahre 2020 und 2021 steuerlich auch pauschal anerkannt, während das Finanzamt ein privates Arbeitszimmer nur unter hohen Bedingungen akzeptiert. Sollte der Gesetzgeber dauerhaft die Aufwendungen für ein Home Office erleichtert anerkennen?","Politikfeld":"Einkommen und Vermögen","Schlagwort":"Home Office","CDU":"Ja","SPD":"kA","AfD":"kA","FDP":"Ja","Grüne":"kA","Linke":"kA"},{"id":10,"question_text":"In Österrreich wurde bereits 2014 eine Deckelung beschlossen, wodurch Lohn- und Gehaltszahlungen ab 500 000 Euro beim Arbeitgeber vom Betriebsausgabenabzug ausgeschlossen sind. Wäre eine ähnliche, womöglich weiterreichendere Regelung für Deutschland sinnvoll?","Politikfeld":"Unternehmen","Schlagwort":"Körperschaftsteuer","CDU":"kA","SPD":"Ja","AfD":"kA","FDP":"kA","Grüne":"Ja","Linke":"Ja"},{"id":11,"question_text":"Bei den Fragen nach der Wettbewerbsfähigkeit des Wirtschaftsstandorts Deutschland wie nach einem gerechten Beitrag der Unternehmen zum Gemeinwesen ist die Steuerlast von Unternehmen ein entscheidender Faktor. Unterstützen Sie eine allgemeine Reduzierung der Unternehmensteuern, insbesondere durch eine Senkung des Körperschaftsteuersatzes oder das allgemeine Ziel der Senkung der Steuer- und Abgabenlast?","Politikfeld":"Unternehmen","Schlagwort":"Körperschaftsteuer","CDU":"Ja","SPD":"kA","AfD":"Ja","FDP":"Ja","Grüne":"kA","Linke":"Nein"},{"id":12,"question_text":"Im April dieses Jahres beschloss die große Koalition einen Maßnahmenpaket zur Entlastung von Unternehmen in der Corona-Krise, unter Anderem wurden Erleichterungen bei der Verlustrechnung beschlossen. Manche Parteien wollen die Verlustnutzung für Unternehmen dauerhaft verbessern. Würden Sie eine solche Maßnahme unterstützen?","Politikfeld":"Unternehmen","Schlagwort":"Verlustrechnung","CDU":"Ja","SPD":"kA","AfD":"kA","FDP":"Ja","Grüne":"Ja","Linke":"kA"},{"id":13,"question_text":"Sollten Investitionen von Unternehmen durch bessere Abschreibungsmöglichkeiten gefördert werden, z.B. bei Investitionen in Bildung, den Klimaschutz oder die Digitalisierung?","Politikfeld":"Unternehmen","Schlagwort":"Abschreibung","CDU":"Ja","SPD":"kA","AfD":"kA","FDP":"Ja","Grüne":"Ja","Linke":"kA"},{"id":14,"question_text":"Sollten Investitionen von Unternehmen durch bessere Abschreibungsmöglichkeiten gefördert werden, z.B. bei Investitionen in Bildung, den Klimaschutz oder die Digitalisierung?","Politikfeld":"Unternehmen","Schlagwort":"Finanztransaktionsteuer","CDU":"Ja","SPD":"Ja","AfD":"kA","FDP":"kA","Grüne":"Ja","Linke":"Ja"},{"id":15,"question_text":"Seit 2020 ist eine jährliche steuerliche Förderung von Forschungs-und Entwicklungsaktivitäten mit einer Forschungszulage von bis zu 500.000 € möglich. Sollte diese Summe erhöht werden?","Politikfeld":"Unternehmen","Schlagwort":"Forschungszulage","CDU":"Ja","SPD":"kA","AfD":"kA","FDP":"Ja","Grüne":"Ja","Linke":"kA"},{"id":16,"question_text":"Erst vor wenigen Monaten hat die Große Koalition die Besteuerung von sog. Share Deals in der Grunderwebsteuer ausgeweitet. Unterstützen Sie Forderungen nach einer erneuten Verschärfung, z.B. in Form einer anteiligen Besteuerung bei Unternehmensverkäufen?","Politikfeld":"Unternehmen","Schlagwort":"Grunderwerbsteuer","CDU":"kA","SPD":"Ja","AfD":"kA","FDP":"Ja","Grüne":"Ja","Linke":"Ja"},{"id":17,"question_text":"Soll die Anzeigepflicht für bestimmte grenzüberschreitende Steuergestaltungen auf rein nationale Steuergestaltungen ausgedehnt werden?","Politikfeld":"Unternehmen","Schlagwort":"Steuergestaltungen","CDU":"kA","SPD":"Ja","AfD":"kA","FDP":"kA","Grüne":"Ja","Linke":"kA"},{"id":18,"question_text":"Friedrich Merz wird bis heute mit der Idee einer Steuererklärung assoziiert, die auf einen Bierdeckel passt. Sollte das Ausfüllen der Steuererklärung durch digitale Hilfsmittel erleichtert werden?","Politikfeld":"Sonstiges","Schlagwort":"Steuererklärung","CDU":"Ja","SPD":"kA","AfD":"kA","FDP":"Ja","Grüne":"kA","Linke":"kA"},{"id":19,"question_text":"EU-Steuerrichtlinien brauchen bis heute eine Zustimmung durch ein Einstimmigkeitsverfahren im Rat der EU (ECOFIN), um in Kraft zu treten. Wäre eine Aufweichung dieser Regel in Form einer Mehrheitsentscheidung sinnvoll?","Politikfeld":"Sonstiges","Schlagwort":"International","CDU":"kA","SPD":"Ja","AfD":"kA","FDP":"kA","Grüne":"Ja","Linke":"kA"},{"id":20,"question_text":"Zivilgesellschaftliche Vereinigungen wie Sportvereine profitieren steuerlich von der Kategorisierung als gemeinnütziger Zweck allerdings dürfen diese nicht politisch tätig sein. Ist es sinnvoll, Vereinen ihre steuerlichen Privilegien zu lassen und ihnen ein Recht auf politische Tätgikeit zu gewähren?","Politikfeld":"Sonstiges","Schlagwort":"Körperschaften","CDU":"kA","SPD":"Ja","AfD":"kA","FDP":"kA","Grüne":"Ja","Linke":"Ja"},{"id":21,"question_text":"Digitialisierung, E-Mobilität, Wärmepumpen: Strom wird als Energielieferant immer wichtiger. Einige Parteien wollen die Stromsteuer senken, um klimapolitische Belastungen auszugleichen. Sind sie dafür?","Politikfeld":"Klima und Umwelt","Schlagwort":"Stromsteuer","CDU":"kA","SPD":"kA","AfD":"kA","FDP":"Ja","Grüne":"kA","Linke":"Ja"},{"id":22,"question_text":"Derzeit gelten in Deutschland im Rahmen der Hinzrechnungsbesteuerung viele Länder als Niedrigsteuerländer. Sollte die sog. Niedrigsteuergrenze von derzeit 25% abgesenkt werden?","Politikfeld":"Unternehmen","Schlagwort":"AStG-Niedrigsteuergrenze","CDU":"Ja","SPD":"kA","AfD":"kA","FDP":"Ja","Grüne":"kA","Linke":"kA"},{"id":23,"question_text":"Der ermäßigte Umsatzsteuersatz wird immer wieder kritisiert, von der Politik aber auch gerne als Förderinstrument verwendet. Wären Sie dafür, mehr Produkte ermäßigt zu besteuern, z.B. Medikamente, pflanzliche Milchalternativen, arbeitsintensives Handwerk oder Produkte für Kinder? ","Politikfeld":"Sonstiges","Schlagwort":"Umsatzsteuer","CDU":"kA","SPD":"kA","AfD":"Ja","FDP":"kA","Grüne":"Ja","Linke":"Ja"},{"id":24,"question_text":"Einige Parteien kritisieren Bagatell- und Lenkungssteuern, da sie zu viel Bürokratie verursachen würden und zu wenige Einnahmen generieren. Würden Sie einer Abschaffung von solchen Steuern wie bspw. der Schaumwein- und Zwischenerzeugnissteuer oder der Kaffeesteuer zustimmen?","Politikfeld":"Sonstiges","Schlagwort":"Bagatellsteuern","CDU":"kA","SPD":"kA","AfD":"Ja","FDP":"Ja","Grüne":"kA","Linke":"kA"},{"id":25,"question_text":"1995 wurde die Vermögensteuer vom Bundesverfassungsgericht als verfassungswidrig eingestuft, da sie zu einer ungerechten Besteuerung von Immobilienvermögen im Vergleich zu Kapitalvermögen führte. Seitdem wird eine Wiedereinführung immer wieder diskutiert. Würden Sie eine Wiedereinführung der VSt befürworten?","Politikfeld":"Einkommen und Vermögen","Schlagwort":"Vermögensteuer","CDU":"Nein","SPD":"Ja","AfD":"Nein","FDP":"Nein","Grüne":"Ja","Linke":"Ja"},{"id":26,"question_text":"Wäre es aus Ihrer Sicht eine gute Idee, gezielt die private Vermögensbildung steuerlich zu fördern, z.B. über höhere Freibeträge für Sparer, Mitarbeiterkapitalbeteiligung, private Wertpapiergeschäfte oder höhere vermögenswirksame Leistungen?","Politikfeld":"Einkommen und Vermögen","Schlagwort":"Vermögensbildung","CDU":"Ja","SPD":"kA","AfD":"kA","FDP":"Ja","Grüne":"kA","Linke":"kA"},{"id":27,"question_text":"Sollte der CO2-Emissionshandel auf europäischer Ebene oder sogar global ausgeweitet werden, um die CO2-Minderungsziele besser zu erreichen?","Politikfeld":"Klima und Umwelt","Schlagwort":"Emissionshandel","CDU":"Ja","SPD":"Ja","AfD":"Nein","FDP":"Ja","Grüne":"Ja","Linke":"Ja"},{"id":28,"question_text":"Bis heute finanziert sich die Europäische Union aus Einnahmen aus dem gemeinsamen Außenzoll, Mitgliedsbeiträgen und einer Beteiligung an der Umsatzsteuer der Mitgliedländer in Form einer Umlage. Sollte der EU die Möglichkeit einer unabhängigen Steuererhebung gegeben werden?","Politikfeld":"Sonstiges","Schlagwort":"International","CDU":"kA","SPD":"Ja","AfD":"Nein","FDP":"Nein","Grüne":"Ja","Linke":"Ja"}]');

/***/ }),

/***/ "./components/Data/options.json":
/*!**************************************!*\
  !*** ./components/Data/options.json ***!
  \**************************************/
/***/ ((module) => {

module.exports = JSON.parse('[{"id":1,"option_text":"Ja","option_Value":"Ja"},{"id":1,"option_text":"Nein","option_Value":"Nein"},{"id":1,"option_text":"Nicht wesentlich","option_Value":"kA"}]');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.js"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvaW5kZXguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFjQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLElBQUl3QixNQUFNLEdBQUcsSUFBSUMsS0FBSixFQUFiO0FBQ0EsSUFBSUMsVUFBVSxHQUFHLElBQUlELEtBQUosRUFBakI7O0FBQ0EsU0FBU0UsSUFBVCxDQUFjQyxLQUFkLEVBQXFCO0FBQ25CLFFBQU07QUFBQSxPQUFDQyxLQUFEO0FBQUEsT0FBUUM7QUFBUixNQUFvQnhCLCtDQUFRLENBQUMsRUFBRCxDQUFsQztBQUNBLFFBQU15QixPQUFPLEdBQUdSLHdEQUFVLEVBQTFCO0FBRUEsUUFBTTtBQUFBLE9BQUNTLE9BQUQ7QUFBQSxPQUFVQztBQUFWLE1BQXdCM0IsK0NBQVEsQ0FBQztBQUNyQzRCLElBQUFBLEdBQUcsRUFBRSxDQURnQztBQUVyQ0MsSUFBQUEsR0FBRyxFQUFFLENBRmdDO0FBR3JDQyxJQUFBQSxHQUFHLEVBQUUsQ0FIZ0M7QUFJckNDLElBQUFBLEdBQUcsRUFBRSxDQUpnQztBQUtyQ0MsSUFBQUEsS0FBSyxFQUFFLENBTDhCO0FBTXJDQyxJQUFBQSxLQUFLLEVBQUU7QUFOOEIsR0FBRCxDQUF0QztBQVNBLFFBQU07QUFBQSxPQUFDTCxHQUFEO0FBQUEsT0FBTU07QUFBTixNQUFnQmxDLCtDQUFRLENBQUMsQ0FBRCxDQUE5QjtBQUNBLFFBQU07QUFBQSxPQUFDNkIsR0FBRDtBQUFBLE9BQU1NO0FBQU4sTUFBZ0JuQywrQ0FBUSxDQUFDLENBQUQsQ0FBOUI7QUFDQSxRQUFNO0FBQUEsT0FBQzhCLEdBQUQ7QUFBQSxPQUFNTTtBQUFOLE1BQWdCcEMsK0NBQVEsQ0FBQyxDQUFELENBQTlCO0FBQ0EsUUFBTTtBQUFBLE9BQUMrQixHQUFEO0FBQUEsT0FBTU07QUFBTixNQUFnQnJDLCtDQUFRLENBQUMsQ0FBRCxDQUE5QjtBQUNBLFFBQU07QUFBQSxPQUFDZ0MsS0FBRDtBQUFBLE9BQVFNO0FBQVIsTUFBb0J0QywrQ0FBUSxDQUFDLENBQUQsQ0FBbEM7QUFDQSxRQUFNO0FBQUEsT0FBQ2lDLEtBQUQ7QUFBQSxPQUFRTTtBQUFSLE1BQW9CdkMsK0NBQVEsQ0FBQyxDQUFELENBQWxDO0FBRUF3QyxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBQTRCbkIsS0FBSyxDQUFDSixNQUFsQztBQUVBc0IsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFxQmxCLEtBQXJCO0FBQ0EsTUFBSW1CLFNBQVMsR0FBRyxDQUFDZCxHQUFELEVBQU1DLEdBQU4sRUFBV0MsR0FBWCxFQUFnQkMsR0FBaEIsRUFBcUJDLEtBQXJCLEVBQTRCQyxLQUE1QixDQUFoQjtBQUVBWCxFQUFBQSxLQUFLLENBQUNxQixpQkFBTixDQUF3QkQsU0FBeEI7QUFDQUYsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFxQnZCLE1BQXJCO0FBQ0FzQixFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaLEVBQW1CYixHQUFuQjtBQUNBWSxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaLEVBQW1CWixHQUFuQjtBQUNBVyxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaLEVBQW1CWCxHQUFuQjtBQUNBVSxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaLEVBQW1CVixHQUFuQjtBQUNBUyxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQXFCVCxLQUFyQjtBQUNBUSxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQXFCUixLQUFyQjtBQUVBLFFBQU1XLFVBQVUsR0FBRy9CLHVEQUFILGFBQUdBLHVEQUFILHVCQUFHQSw4REFBbkI7QUFDQSxzQkFDRTtBQUFLLGFBQVMsRUFBQyxFQUFmO0FBQUEsNEJBQ0UsK0RBQUMsa0RBQUQ7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBRUU7QUFBTSxXQUFHLEVBQUMsTUFBVjtBQUFpQixZQUFJLEVBQUM7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBS0UsK0RBQUMsNENBQUQ7QUFBTSxlQUFTLEVBQUMsbUNBQWhCO0FBQUEsNkJBQ0UsK0RBQUMsZ0RBQUQ7QUFBQSwrQkFDRSwrREFBQywwQ0FBRDtBQUNFLHVCQUFhLEVBQUU7QUFDYkssWUFBQUEsTUFBTSxFQUFFLEVBREs7QUFFYjRCLFlBQUFBLE1BQU0sRUFBRTtBQUZLLFdBRGpCO0FBS0Usa0JBQVEsRUFBRSxDQUFDQyxNQUFELEVBQVNDLGFBQVQsS0FBMkI7QUFBQTs7QUFDbkM7QUFDQSxnQkFBSSxrQkFBQTFCLEtBQUssQ0FBQ0osTUFBTixnRUFBYzJCLE1BQWQsSUFBdUIsQ0FBM0IsRUFBOEI7QUFBQTs7QUFDNUJMLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGVBQVosb0JBQTZCbkIsS0FBSyxDQUFDSixNQUFuQyxtREFBNkIsZUFBYzJCLE1BQTNDO0FBQ0Esb0JBQU1JLFlBQVkscUJBQUczQixLQUFLLENBQUNKLE1BQVQsbURBQUcsZUFBYzJCLE1BQW5DOztBQUVBLG1CQUFLLE1BQU1LLENBQVgsSUFBZ0I1QixLQUFLLENBQUNKLE1BQXRCLEVBQThCO0FBQzVCc0IsZ0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFlBQVo7O0FBQ0EscUJBQUssTUFBTVUsQ0FBWCxJQUFnQnRDLHVEQUFoQixFQUFzQjtBQUNwQjJCLGtCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaOztBQUNBLHNCQUFJUyxDQUFDLENBQUNFLFdBQUYsSUFBaUJELENBQUMsQ0FBQ0UsRUFBdkIsRUFBMkI7QUFDekJiLG9CQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxlQUFaLEVBQTZCUyxDQUFDLENBQUNFLFdBQS9CLEVBQTRDLE1BQTVDLEVBQW9ERCxDQUFDLENBQUNFLEVBQXREOztBQUNBLHdCQUFJRixDQUFDLENBQUN0QixHQUFGLElBQVNxQixDQUFDLENBQUNKLE1BQWYsRUFBdUI7QUFDckJOLHNCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxZQUFaLEVBQTBCVSxDQUFDLENBQUN0QixHQUE1QjtBQUNBTSxzQkFBQUEsTUFBTSxDQUFFTixHQUFHLEdBQUdBLEdBQUcsR0FBRyxDQUFkLENBQU47QUFDQVcsc0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVosRUFBbUJaLEdBQW5CO0FBQ0Q7O0FBQ0Qsd0JBQUlzQixDQUFDLENBQUN2QixHQUFGLElBQVNzQixDQUFDLENBQUNKLE1BQWYsRUFBdUI7QUFDckJOLHNCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaLEVBQW1CYixHQUFuQjtBQUNBTSxzQkFBQUEsTUFBTSxDQUFFTixHQUFHLEdBQUdBLEdBQUcsR0FBRyxDQUFkLENBQU47QUFDRDs7QUFDRCx3QkFBSXVCLENBQUMsQ0FBQ3JCLEdBQUYsSUFBU29CLENBQUMsQ0FBQ0osTUFBZixFQUF1QjtBQUNyQk4sc0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVosRUFBbUJhLEdBQW5CO0FBQ0FsQixzQkFBQUEsTUFBTSxDQUFFa0IsR0FBRyxHQUFHeEIsR0FBRyxHQUFHLENBQWQsQ0FBTjtBQUNBVSxzQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksV0FBWixFQUF5QmEsR0FBekI7QUFDRDs7QUFDRCx3QkFBSUgsQ0FBQyxDQUFDcEIsR0FBRixJQUFTbUIsQ0FBQyxDQUFDSixNQUFmLEVBQXVCO0FBQ3JCTixzQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksS0FBWjtBQUNBSixzQkFBQUEsTUFBTSxDQUFFTixHQUFHLEdBQUdBLEdBQUcsR0FBRyxDQUFkLENBQU47QUFDRDs7QUFDRCx3QkFBSW9CLENBQUMsQ0FBQ25CLEtBQUYsSUFBV2tCLENBQUMsQ0FBQ0osTUFBakIsRUFBeUI7QUFDdkJOLHNCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0FILHNCQUFBQSxRQUFRLENBQUVOLEtBQUssR0FBR0EsS0FBSyxHQUFHLENBQWxCLENBQVI7QUFDRDs7QUFDRCx3QkFBSW1CLENBQUMsQ0FBQ2xCLEtBQUYsSUFBV2lCLENBQUMsQ0FBQ0osTUFBakIsRUFBeUI7QUFDdkJOLHNCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0FGLHNCQUFBQSxRQUFRLENBQUVOLEtBQUssR0FBR0EsS0FBSyxHQUFHLENBQWxCLENBQVI7QUFDRCxxQkFIRCxNQUdPO0FBQ0xPLHNCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxtQkFBWjtBQUNEO0FBQ0Y7QUFDRjtBQUNGLGVBeEMyQixDQTBDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDRCxhQS9Fa0MsQ0FpRm5DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUVBRCxZQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBMUZtQyxDQTJGbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0QsV0E3R0g7QUFBQSxvQkErR0csQ0FBQztBQUFFYyxZQUFBQTtBQUFGLFdBQUQsS0FBc0I7QUFDckIsZ0NBQ0UsK0RBQUMsNENBQUQ7QUFBTSxzQkFBUSxFQUFFQSxZQUFoQjtBQUFBLHlCQUNHMUMsdURBREgsYUFDR0EsdURBREgsdUJBQ0dBLDJEQUFBLENBQVUsQ0FBQ3NDLENBQUQsRUFBSUUsRUFBSixLQUFXO0FBQ3BCLG9DQUNFO0FBQWdCLDJCQUFTLEVBQUMsTUFBMUI7QUFBQSwwQ0FDRSwrREFBQyxpREFBRDtBQUFBLCtCQUNHLEdBREgsRUFFR0YsQ0FBQyxDQUFDRSxFQUZMLE9BRVVULFVBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURGLGVBS0UsK0RBQUMsb0RBQUQ7QUFBQSw4QkFBZU8sQ0FBQyxDQUFDTTtBQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUxGLGVBTUUsK0RBQUMsZ0RBQUQ7QUFBQSw4QkFBV04sQ0FBQyxDQUFDTztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBTkYsZUFPRSwrREFBQyw4Q0FBRDtBQUNFLHdCQUFJLEVBQUMsUUFEUDtBQUVFLDBCQUFNLEVBQUdDLFlBQUQsSUFBa0I7QUFDeEIsMENBQ0U7QUFBQSwrQ0FDRSwrREFBQywyQ0FBRDtBQUFBLGlEQUNFLCtEQUFDLDJDQUFEO0FBQUEsbURBQ0UsK0RBQUMsaURBQUQ7QUFBQSxxREFDRSwrREFBQyxrREFBRDtBQUFZLHlDQUFTLEVBQUMsb0JBQXRCO0FBQUEsMENBQ0c3QywwREFESCxhQUNHQSwwREFESCx1QkFDR0EsOERBQUEsQ0FBYzhDLEdBQUQsSUFBUztBQUNyQixzREFDRTtBQUVFLDZDQUFTLEVBQUMsNkZBRlo7QUFBQSw0REFJRSwrREFBQyx5Q0FBRDtBQUNFLDBDQUFJLEVBQUMsT0FEUCxDQUVFO0FBRkY7QUFHRSwyQ0FBSyxFQUFFQSxHQUFHLENBQUNDLFlBSGI7QUFJRSwrQ0FBUyxFQUFDLFFBSlo7QUFLRSw4Q0FBUSxFQUFFLE1BQU07QUFDZHJDLHdDQUFBQSxRQUFRLENBQUM7QUFDUDRCLDBDQUFBQSxXQUFXLEVBQUVELENBQUMsQ0FBQ0UsRUFEUjtBQUVQUCwwQ0FBQUEsTUFBTSxFQUFFYyxHQUFHLENBQUNDO0FBRkwseUNBQUQsQ0FBUjs7QUFLQSw0Q0FBSTNDLE1BQU0sQ0FBQzJCLE1BQVAsR0FBZ0IsQ0FBcEIsRUFBdUI7QUFDckIsK0NBQ0UsSUFBSWlCLENBQUMsR0FBRyxDQURWLEVBRUVBLENBQUMsR0FBRzVDLE1BQU0sQ0FBQzJCLE1BRmIsRUFHRWlCLENBQUMsRUFISCxFQUlFO0FBQUE7O0FBQ0EsZ0RBQ0UsY0FBQTVDLE1BQU0sQ0FBQzRDLENBQUQsQ0FBTix3REFDSVYsV0FESixLQUNtQkQsQ0FBQyxDQUFDRSxFQUZ2QixFQUdFO0FBQ0FiLDhDQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0FBQ0F2Qiw4Q0FBQUEsTUFBTSxDQUFDNkMsTUFBUCxDQUFjRCxDQUFkLEVBQWlCLENBQWpCLEVBQW9CO0FBQ2xCVixnREFBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNFLEVBREc7QUFFbEJQLGdEQUFBQSxNQUFNLEVBQ0pjLEdBQUcsQ0FBQ0M7QUFIWSwrQ0FBcEI7QUFNQXZDLDhDQUFBQSxLQUFLLENBQUMwQyxhQUFOLENBQ0U5QyxNQURGO0FBR0E7QUFDRCw2Q0FmRCxNQWVPLElBQ0xBLE1BQU0sQ0FBQzRDLENBQUQsQ0FBTixDQUNHVixXQURILEtBQ21CRCxDQUFDLENBQUNFLEVBRmhCLEVBR0w7QUFDQWIsOENBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUNFLDBCQURGLEVBRUVVLENBQUMsQ0FBQ0UsRUFGSixFQUdFLGFBSEYsRUFJRW5DLE1BQU0sQ0FBQzRDLENBQUQsQ0FBTixDQUFVVixXQUpaO0FBT0FsQyw4Q0FBQUEsTUFBTSxDQUFDK0MsSUFBUCxDQUFZO0FBQ1ZiLGdEQUFBQSxXQUFXLEVBQUVELENBQUMsQ0FBQ0UsRUFETDtBQUVWUCxnREFBQUEsTUFBTSxFQUNKYyxHQUFHLENBQUNDO0FBSEksK0NBQVo7QUFLQXZDLDhDQUFBQSxLQUFLLENBQUMwQyxhQUFOLENBQ0U5QyxNQURGO0FBR0E7QUFDRDtBQUNGOztBQUNESSwwQ0FBQUEsS0FBSyxDQUFDMEMsYUFBTixDQUFvQjlDLE1BQXBCO0FBQ0QseUNBNUNELE1BNENPO0FBQ0xzQiwwQ0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWjtBQUNBdkIsMENBQUFBLE1BQU0sQ0FBQytDLElBQVAsQ0FBWTtBQUNWYiw0Q0FBQUEsV0FBVyxFQUFFRCxDQUFDLENBQUNFLEVBREw7QUFFVlAsNENBQUFBLE1BQU0sRUFBRWMsR0FBRyxDQUFDQztBQUZGLDJDQUFaO0FBSUF2QywwQ0FBQUEsS0FBSyxDQUFDMEMsYUFBTixDQUFvQjlDLE1BQXBCO0FBQ0Q7QUFDRjtBQS9ESDtBQUFBO0FBQUE7QUFBQTtBQUFBLDRDQUpGLEVBcUVHMEMsR0FBRyxDQUFDTSxXQXJFUDtBQUFBLHFDQUNPTixHQUFHLENBQUNQLEVBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQ0FERjtBQXlFRCxpQ0ExRUE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFERjtBQWdHRDtBQW5HSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQVBGO0FBQUEsbUJBQVVGLENBQUMsQ0FBQ0UsRUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURGO0FBK0dELGVBaEhBLENBREgsZUFrSEU7QUFBSyx5QkFBUyxFQUFDLHFCQUFmO0FBQUEsdUNBQ0UsK0RBQUMsOENBQUQ7QUFDRSx1QkFBSyxNQURQO0FBRUUsMkJBQVMsRUFBQyxnQ0FGWjtBQUdFLHNCQUFJLEVBQUMsUUFIUCxDQUlFO0FBQ0E7QUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBbEhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERjtBQWdJRDtBQWhQSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQThQRDs7QUFFRCxNQUFNYyxlQUFlLEdBQUlDLEtBQUQsSUFBVztBQUNqQyxTQUFPO0FBQ0xsRCxJQUFBQSxNQUFNLEVBQUVrRCxLQUFLLENBQUNsRCxNQUFOLENBQWFBO0FBRGhCLEdBQVA7QUFHRCxDQUpEOztBQU1BLE1BQU1tRCxrQkFBa0IsR0FBSUMsUUFBRCxJQUFjO0FBQ3ZDLFNBQU87QUFDTE4sSUFBQUEsYUFBYSxFQUFHbkQsSUFBRCxJQUFVeUQsUUFBUSxDQUFDdEQseURBQUEsQ0FBc0JILElBQXRCLENBQUQsQ0FENUI7QUFFTDBELElBQUFBLGNBQWMsRUFBRSxDQUFDMUQsSUFBRCxFQUFPd0MsRUFBUCxLQUFjaUIsUUFBUSxDQUFDdEQsd0RBQUEsQ0FBcUJILElBQXJCLEVBQTJCd0MsRUFBM0IsQ0FBRCxDQUZqQztBQUdMb0IsSUFBQUEsZ0JBQWdCLEVBQUUsQ0FBQzVELElBQUQsRUFBTzZELElBQVAsRUFBYUMsTUFBYixLQUNoQkwsUUFBUSxDQUFDdEQsMERBQUEsQ0FBdUJILElBQXZCLEVBQTZCNkQsSUFBN0IsRUFBbUNDLE1BQW5DLENBQUQsQ0FKTDtBQUtMRSxJQUFBQSxrQkFBa0IsRUFBRSxDQUFDaEUsSUFBRCxFQUFPNkQsSUFBUCxFQUFhQyxNQUFiLEtBQ2xCTCxRQUFRLENBQUN0RCw0REFBQSxDQUF5QkgsSUFBekIsRUFBK0I2RCxJQUEvQixFQUFxQ0MsTUFBckMsQ0FBRCxDQU5MO0FBT0xoQyxJQUFBQSxpQkFBaUIsRUFBRzlCLElBQUQsSUFBVXlELFFBQVEsQ0FBQ3RELDZEQUFBLENBQTBCSCxJQUExQixDQUFEO0FBUGhDLEdBQVA7QUFTRCxDQVZEOztBQVdBLGlFQUFlRSxvREFBTyxDQUFDb0QsZUFBRCxFQUFrQkUsa0JBQWxCLENBQVAsQ0FBNkNoRCxJQUE3QyxDQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDOVVBO0FBRU8sTUFBTTBELGVBQWUsR0FBRyxpQkFBeEI7QUFDQSxNQUFNQyxlQUFlLEdBQUcsaUJBQXhCO0FBQ0EsTUFBTUMsZ0JBQWdCLEdBQUcsa0JBQXpCO0FBQ0EsTUFBTUMsa0JBQWtCLEdBQUcsb0JBQTNCO0FBQ0EsTUFBTUMsZ0JBQWdCLEdBQUcsa0JBQXpCO0FBQ0EsTUFBTUMsc0JBQXNCLEdBQUcsd0JBQS9CO0FBQ0EsTUFBTUMscUJBQXFCLEdBQUcsdUJBQTlCO0FBQ0EsTUFBTUMsd0JBQXdCLEdBQUcsMEJBQWpDO0FBRUEsTUFBTUMsd0JBQXdCLEdBQUcsMEJBQWpDO0FBQ0EsTUFBTUMsY0FBYyxHQUFHLGdCQUF2QjtBQUNBLE1BQU1DLG9CQUFvQixHQUFHLHNCQUE3QjtBQUNBLE1BQU1DLHFCQUFxQixHQUFHLHVCQUE5Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNkUDtBQUNBO0NBRUE7O0FBRU8sTUFBTTFCLGFBQWEsR0FBSTlDLE1BQUQsSUFBWTtBQUN2QyxTQUFPO0FBQ0wyRSxJQUFBQSxJQUFJLEVBQUVGLHlEQUREO0FBRUx6RSxJQUFBQSxNQUFNLEVBQUVBO0FBRkgsR0FBUDtBQUlELENBTE07QUFPQSxNQUFNNEUsY0FBYyxHQUFJQyxLQUFELElBQVc7QUFDdkMsU0FBTztBQUNMRixJQUFBQSxJQUFJLEVBQUVGLDBEQUREO0FBRUxJLElBQUFBLEtBQUssRUFBRUE7QUFGRixHQUFQO0FBSUQsQ0FMTTtBQU1BLE1BQU1DLGFBQWEsR0FBRyxNQUFNO0FBQ2pDLFNBQU87QUFDTEgsSUFBQUEsSUFBSSxFQUFFRix3REFBeUJIO0FBRDFCLEdBQVA7QUFHRCxDQUpNO0FBS0EsTUFBTVMsYUFBYSxHQUFJcEYsSUFBRCxJQUFVLENBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0QsQ0FqQk0sRUFtQlA7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUVPLE1BQU04QixpQkFBaUIsR0FBSXVELFVBQUQsSUFBZ0I7QUFDL0MsU0FBTztBQUNMTCxJQUFBQSxJQUFJLEVBQUVGLDhEQUREO0FBRUxPLElBQUFBLFVBQVUsRUFBRUE7QUFGUCxHQUFQO0FBSUQsQ0FMTTtBQU9BLE1BQU1DLGtCQUFrQixHQUFJSixLQUFELElBQVc7QUFDM0MsU0FBTztBQUNMRixJQUFBQSxJQUFJLEVBQUVGLCtEQUREO0FBRUxJLElBQUFBLEtBQUssRUFBRUE7QUFGRixHQUFQO0FBSUQsQ0FMTTtBQU9BLE1BQU1LLGlCQUFpQixHQUFJdkYsSUFBRCxJQUFVLENBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0QsQ0FqQk07QUFtQkEsTUFBTXdGLGdCQUFnQixHQUFJTixLQUFELElBQVc7QUFDekMsU0FBTztBQUNMRixJQUFBQSxJQUFJLEVBQUVGLDREQUREO0FBRUxJLElBQUFBLEtBQUssRUFBRUE7QUFGRixHQUFQO0FBSUQsQ0FMTTtBQU9BLE1BQU12QixZQUFZLEdBQUcsQ0FBQzNELElBQUQsRUFBT3dDLEVBQVAsS0FBYyxDQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNELENBcEJNO0FBc0JBLE1BQU1pRCxtQkFBbUIsR0FBRyxNQUFNO0FBQ3ZDLFNBQU87QUFDTFQsSUFBQUEsSUFBSSxFQUFFRixnRUFBaUNQO0FBRGxDLEdBQVA7QUFHRCxDQUpNO0FBTUEsTUFBTW1CLGtCQUFrQixHQUFJUixLQUFELElBQVc7QUFDM0MsU0FBTztBQUNMRixJQUFBQSxJQUFJLEVBQUVGLCtEQUREO0FBRUxJLElBQUFBLEtBQUssRUFBRUE7QUFGRixHQUFQO0FBSUQsQ0FMTTtBQU9BLE1BQU1uQixjQUFjLEdBQUcsQ0FBQy9ELElBQUQsRUFBTzZELElBQVAsRUFBYUMsTUFBYixLQUF3QixDQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNELENBdkJNO0FBeUJBLE1BQU02QixxQkFBcUIsR0FBRyxNQUFNO0FBQ3pDLFNBQU87QUFDTFgsSUFBQUEsSUFBSSxFQUFFRixrRUFBbUNKO0FBRHBDLEdBQVA7QUFHRCxDQUpNO0FBTUEsTUFBTVQsZ0JBQWdCLEdBQUcsQ0FBQ2pFLElBQUQsRUFBTzZELElBQVAsRUFBYUMsTUFBYixLQUF3QixDQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDRCxDQXRCTTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pLUDs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jb21wYW55LXRlc3QvLi9wYWdlcy9pbmRleC5qcyIsIndlYnBhY2s6Ly9jb21wYW55LXRlc3QvLi9yZWR1eC9hY3Rpb25zL0FjdGlvblR5cGVzLmpzIiwid2VicGFjazovL2NvbXBhbnktdGVzdC8uL3JlZHV4L2FjdGlvbnMvUmVzdWx0Q3JlYXRvcnMuanMiLCJ3ZWJwYWNrOi8vY29tcGFueS10ZXN0L2V4dGVybmFsIFwiYXhpb3NcIiIsIndlYnBhY2s6Ly9jb21wYW55LXRlc3QvZXh0ZXJuYWwgXCJmb3JtaWtcIiIsIndlYnBhY2s6Ly9jb21wYW55LXRlc3QvZXh0ZXJuYWwgXCJuZXh0L2hlYWRcIiIsIndlYnBhY2s6Ly9jb21wYW55LXRlc3QvZXh0ZXJuYWwgXCJyZWFjdFwiIiwid2VicGFjazovL2NvbXBhbnktdGVzdC9leHRlcm5hbCBcInJlYWN0LXJlZHV4XCIiLCJ3ZWJwYWNrOi8vY29tcGFueS10ZXN0L2V4dGVybmFsIFwicmVhY3Qtcm91dGVyXCIiLCJ3ZWJwYWNrOi8vY29tcGFueS10ZXN0L2V4dGVybmFsIFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIiLCJ3ZWJwYWNrOi8vY29tcGFueS10ZXN0L2V4dGVybmFsIFwicmVhY3RzdHJhcFwiIiwid2VicGFjazovL2NvbXBhbnktdGVzdC9leHRlcm5hbCBcInN3ZWV0YWxlcnRcIiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XG5pbXBvcnQgeyBGaWVsZCwgRmllbGRBcnJheSwgRm9ybWlrIH0gZnJvbSBcImZvcm1pa1wiO1xuaW1wb3J0IEhlYWQgZnJvbSBcIm5leHQvaGVhZFwiO1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHtcbiAgQnV0dG9uLFxuICBDYXJkLFxuICBDYXJkQm9keSxcbiAgQ2FyZEhlYWRlcixcbiAgQ2FyZFN1YnRpdGxlLFxuICBDYXJkVGV4dCxcbiAgQ2FyZFRpdGxlLFxuICBDb2wsXG4gIEZvcm0sXG4gIEZvcm1Hcm91cCxcbiAgSW5wdXRHcm91cCxcbiAgUm93LFxufSBmcm9tIFwicmVhY3RzdHJhcFwiO1xuaW1wb3J0IGRhdGEgZnJvbSBcIi4uL2NvbXBvbmVudHMvRGF0YS9EYXRhLmpzb25cIjtcbmltcG9ydCBvcHRpb25zIGZyb20gXCIuLi9jb21wb25lbnRzL0RhdGEvb3B0aW9ucy5qc29uXCI7XG5pbXBvcnQgeyBjb25uZWN0IH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XG5pbXBvcnQgKiBhcyBhY3Rpb25zIGZyb20gXCIuLi9yZWR1eC9hY3Rpb25zXCI7XG5pbXBvcnQgeyB1c2VIaXN0b3J5IH0gZnJvbSBcInJlYWN0LXJvdXRlclwiO1xuXG52YXIgcmVzdWx0ID0gbmV3IEFycmF5KCk7XG52YXIgTWFpblJlc3VsdCA9IG5ldyBBcnJheSgpO1xuZnVuY3Rpb24gSG9tZShwcm9wcykge1xuICBjb25zdCBbdmFsdWUsIHNldFZhbHVlXSA9IHVzZVN0YXRlKHt9KTtcbiAgY29uc3QgaGlzdG9yeSA9IHVzZUhpc3RvcnkoKTtcblxuICBjb25zdCBbY29tcGFueSwgc2V0Q29tcGFueV0gPSB1c2VTdGF0ZSh7XG4gICAgQ0RVOiAwLFxuICAgIFNQRDogMCxcbiAgICBBZkQ6IDAsXG4gICAgRkRQOiAwLFxuICAgIEdyw7xuZTogMCxcbiAgICBMaW5rZTogMCxcbiAgfSk7XG5cbiAgY29uc3QgW0NEVSwgc2V0Q0RVXSA9IHVzZVN0YXRlKDApO1xuICBjb25zdCBbU1BELCBzZXRTUERdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtBZkQsIHNldEFmRF0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW0ZEUCwgc2V0RkRQXSA9IHVzZVN0YXRlKDApO1xuICBjb25zdCBbR3LDvG5lLCBzZXRHcsO8bmVdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtMaW5rZSwgc2V0TGlua2VdID0gdXNlU3RhdGUoMCk7XG5cbiAgY29uc29sZS5sb2coXCJwcm9wcy5yZXN1bHRcIiwgcHJvcHMucmVzdWx0KTtcblxuICBjb25zb2xlLmxvZyhcInZhbHVlXCIsIHZhbHVlKTtcbiAgbGV0IGdyYXBoRGF0YSA9IFtDRFUsIFNQRCwgQWZELCBGRFAsIEdyw7xuZSwgTGlua2VdO1xuXG4gIHByb3BzLnJlc3VsdEVkaXRTZXREYXRhKGdyYXBoRGF0YSk7XG4gIGNvbnNvbGUubG9nKFwiYXJyYXlcIiwgcmVzdWx0KTtcbiAgY29uc29sZS5sb2coXCJDRFVcIiwgQ0RVKTtcbiAgY29uc29sZS5sb2coXCJTUERcIiwgU1BEKTtcbiAgY29uc29sZS5sb2coXCJBZkRcIiwgQWZEKTtcbiAgY29uc29sZS5sb2coXCJGRFBcIiwgRkRQKTtcbiAgY29uc29sZS5sb2coXCJHcsO8bmVcIiwgR3LDvG5lKTtcbiAgY29uc29sZS5sb2coXCJMaW5rZVwiLCBMaW5rZSk7XG5cbiAgY29uc3QgZGF0YUxlbmd0aCA9IGRhdGE/Lmxlbmd0aDtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiPlxuICAgICAgPEhlYWQ+XG4gICAgICAgIDx0aXRsZT5DcmVhdGUgTmV4dCBBcHA8L3RpdGxlPlxuICAgICAgICA8bGluayByZWw9XCJpY29uXCIgaHJlZj1cIi9mYXZpY29uLmljb1wiIC8+XG4gICAgICA8L0hlYWQ+XG4gICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTUgYm9yZGVyLTIgc2hhZG93LW1kIHJvdW5kZWQtbWRcIj5cbiAgICAgICAgPENhcmRCb2R5PlxuICAgICAgICAgIDxGb3JtaWtcbiAgICAgICAgICAgIGluaXRpYWxWYWx1ZXM9e3tcbiAgICAgICAgICAgICAgcmVzdWx0OiBbXSxcbiAgICAgICAgICAgICAgYW5zd2VyOiBcIlwiLFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIG9uU3VibWl0PXsodmFsdWVzLCBzZXRTdWJtaXR0aW5nKSA9PiB7XG4gICAgICAgICAgICAgIC8vIHNldFNQRChTUEQgKyAxKTtcbiAgICAgICAgICAgICAgaWYgKHByb3BzLnJlc3VsdD8ubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwicmVzdWx0IGxlbmd0aFwiLCBwcm9wcy5yZXN1bHQ/Lmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0TGVuZ3RoID0gcHJvcHMucmVzdWx0Py5sZW5ndGg7XG5cbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IHIgb2YgcHJvcHMucmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInJlc3VsdCBtYXBcIik7XG4gICAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGQgb2YgZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImRhdGEgbWFwXCIpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoci5xdWVzdGlvbl9pZCA9PSBkLmlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJyLnF1ZXN0aW9uX2lkXCIsIHIucXVlc3Rpb25faWQsIFwiZC5pZFwiLCBkLmlkKTtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoZC5TUEQgPT0gci5hbnN3ZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiU1BEIGJlZm9yZVwiLCBkLlNQRCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTUEQoKFNQRCA9IFNQRCArIDEpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiU1BEXCIsIFNQRCk7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIGlmIChkLkNEVSA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDRFVcIiwgQ0RVKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldENEVSgoQ0RVID0gQ0RVICsgMSkpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICBpZiAoZC5BZkQgPT0gci5hbnN3ZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQWZEXCIsIEFGRCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRBZkQoKEFGRCA9IEFmRCArIDEpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQWZEIGFmdGVyXCIsIEFGRCk7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIGlmIChkLkZEUCA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJGRFBcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRGRFAoKEZEUCA9IEZEUCArIDEpKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGQuR3LDvG5lID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkdyw7xuZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEdyw7xuZSgoR3LDvG5lID0gR3LDvG5lICsgMSkpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICBpZiAoZC5MaW5rZSA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJMaW5rZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldExpbmtlKChMaW5rZSA9IExpbmtlICsgMSkpO1xuICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImVsc2UgZnJvbSBsYXN0IGlmXCIpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIHByb3BzLnJlc3VsdD8ubWFwKChyKSA9PiB7XG4gICAgICAgICAgICAgICAgLy8gICBjb25zb2xlLmxvZyhcInJlc3VsdCBtYXBcIik7XG4gICAgICAgICAgICAgICAgLy8gICBkYXRhPy5tYXAoKGQpID0+IHtcbiAgICAgICAgICAgICAgICAvLyAgICAgY29uc29sZS5sb2coXCJkYXRhIG1hcFwiKTtcbiAgICAgICAgICAgICAgICAvLyAgICAgaWYgKHIucXVlc3Rpb25faWQgPT0gZC5pZCkge1xuICAgICAgICAgICAgICAgIC8vICAgICAgIGNvbnNvbGUubG9nKFwici5xdWVzdGlvbl9pZFwiLCByLnF1ZXN0aW9uX2lkLCBcImQuaWRcIiwgZC5pZCk7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgaWYgKGQuU1BEID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgICBjb25zb2xlLmxvZyhcIlNQRFwiKTtcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIHNldFNQRCguLi5TUEQsIFNQRCArIDEpO1xuICAgICAgICAgICAgICAgIC8vICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyAgICAgICBpZiAoZC5DRFUgPT0gci5hbnN3ZXIpIHtcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIGNvbnNvbGUubG9nKFwiQ0RVXCIpO1xuICAgICAgICAgICAgICAgIC8vICAgICAgICAgc2V0Q0RVKC4uLkNEVSwgQ0RVICsgMSk7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgfVxuICAgICAgICAgICAgICAgIC8vICAgICAgIGlmIChkLkFmRCA9PSByLmFuc3dlcikge1xuICAgICAgICAgICAgICAgIC8vICAgICAgICAgY29uc29sZS5sb2coXCJBZkRcIik7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgICBzZXRBZkQoLi4uQWZELCBBZkQgKyAxKTtcbiAgICAgICAgICAgICAgICAvLyAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gICAgICAgaWYgKGQuRkRQID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgICBjb25zb2xlLmxvZyhcIkZEUFwiKTtcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIHNldEZEUCguLi5GRFAsIEZEUCArIDEpO1xuICAgICAgICAgICAgICAgIC8vICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyAgICAgICBpZiAoZC5HcsO8bmUgPT0gci5hbnN3ZXIpIHtcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIGNvbnNvbGUubG9nKFwiR3LDvG5lXCIpO1xuICAgICAgICAgICAgICAgIC8vICAgICAgICAgc2V0R3LDvG5lKC4uLkdyw7xuZSwgR3LDvG5lICsgMSk7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgfVxuICAgICAgICAgICAgICAgIC8vICAgICAgIGlmIChkLkxpbmtlID09IHIuYW5zd2VyKSB7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgICBjb25zb2xlLmxvZyhcIkxpbmtlXCIpO1xuICAgICAgICAgICAgICAgIC8vICAgICAgICAgc2V0TGlua2UoLi4uTGlua2UsIExpbmtlICsgMSk7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIGNvbnNvbGUubG9nKFwiZWxzZSBmcm9tIGxhc3QgaWZcIik7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgfVxuICAgICAgICAgICAgICAgIC8vICAgICB9XG4gICAgICAgICAgICAgICAgLy8gICB9KTtcbiAgICAgICAgICAgICAgICAvLyB9KTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIC8vIGxldCBncmFwaERhdGEgPSB7XG4gICAgICAgICAgICAgIC8vICAgQ0RVOiBDRFUsXG4gICAgICAgICAgICAgIC8vICAgU1BEOiBTUEQsXG4gICAgICAgICAgICAgIC8vICAgQWZEOiBBZkQsXG4gICAgICAgICAgICAgIC8vICAgRkRQOiBGRFAsXG4gICAgICAgICAgICAgIC8vICAgR3LDvG5lOiBHcsO8bmUsXG4gICAgICAgICAgICAgIC8vICAgTGlua2U6IExpbmtlLFxuICAgICAgICAgICAgICAvLyB9O1xuXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic3VibWl0IGNsaWNrXCIpO1xuICAgICAgICAgICAgICAvLyBheGlvc1xuICAgICAgICAgICAgICAvLyAgIC5wb3N0KFwiaHR0cHM6Ly91ZGl0c29sdXRpb25zLmluL3lhcm4vcHVibGljL2FwaS9zY29yZXNcIiwgZGF0YSlcbiAgICAgICAgICAgICAgLy8gICAudGhlbigocmVzKSA9PiB7XG4gICAgICAgICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhyZXMpO1xuICAgICAgICAgICAgICAvLyAgICAgY29uc29sZS5sb2coXCJpbnRpYWwgdmFsdWUgaXMgc3VibWl0ZWQgdG8gcmVzdWx0c1wiKTtcbiAgICAgICAgICAgICAgLy8gICAgIHJlc3VsdCA9IFtdO1xuICAgICAgICAgICAgICAvLyAgICAgaGlzdG9yeS5wdXNoKFwiL3RoYW5reW91XCIpO1xuICAgICAgICAgICAgICAvLyAgIH0pXG4gICAgICAgICAgICAgIC8vICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKGVyci5yZXNwb25zZS5kYXRhKTtcbiAgICAgICAgICAgICAgLy8gICAgIC8vIGhpc3RvcnkucHVzaChcIi9leGFtLWFwcGVhcmVkXCIpO1xuXG4gICAgICAgICAgICAgIC8vICAgfSk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHsoeyBoYW5kbGVTdWJtaXQgfSkgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxGb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxuICAgICAgICAgICAgICAgICAge2RhdGE/Lm1hcCgoZCwgaWQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17ZC5pZH0gY2xhc3NOYW1lPVwibXQtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcmRUaXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge1wiIFwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZC5pZH0ve2RhdGFMZW5ndGh9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NhcmRUaXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkU3VidGl0bGU+e2QuU2NobGFnd29ydH08L0NhcmRTdWJ0aXRsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkVGV4dD57ZC5xdWVzdGlvbl90ZXh0fTwvQ2FyZFRleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRBcnJheVxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVzdWx0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVuZGVyPXsoYXJyYXlIZWxwZXJzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSb3c+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dEdyb3VwIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcHRpb25zPy5tYXAoKG9wdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtvcHQuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGJnLWdyYXktNjAwIHRleHQtd2hpdGUgcm91bmRlZC1tZCB0ZXh0LWNlbnRlciBob3ZlcjpiZy15ZWxsb3ctMzAwIGhvdmVyOnRleHQtYmxhY2sgbWItMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBuYW1lPVwiYW5zd2VyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtvcHQub3B0aW9uX1ZhbHVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFZhbHVlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnN3ZXI6IG9wdC5vcHRpb25fVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgaSA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpIDwgcmVzdWx0Lmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGkrK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/LnF1ZXN0aW9uX2lkID09IGQuaWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInNwbGljZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnNwbGljZShpLCAxLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25faWQ6IGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcHMucmVzdWx0U2V0RGF0YShcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0W2ldXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnF1ZXN0aW9uX2lkICE9PSBkLmlkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbHNlX2lmIHF1ZXN0aW9uIG9mIGRhdGFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwicmVzdWx0IHEtaWRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV0ucXVlc3Rpb25faWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25faWQ6IGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3BzLnJlc3VsdFNldERhdGEoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcHMucmVzdWx0U2V0RGF0YShyZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZWxzZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbl9pZDogZC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcjogb3B0Lm9wdGlvbl9WYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wcy5yZXN1bHRTZXREYXRhKHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3B0Lm9wdGlvbl90ZXh0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2VyOntcIiBcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZXN1bHQ/Lm1hcCgocikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoci5xdWVzdGlvbl9pZCA9PSBkLmlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHIuYW5zd2VyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvSW5wdXRHcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIGJsb2NrXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLTIgcC0yIGJvcmRlci1ibGFjayBtdC03XCJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAvLyBvbkNsaWNrPXtoYW5kbGVTdWJtaXR9XG4gICAgICAgICAgICAgICAgICAgICAgLy8gZGlzYWJsZWQ9e2Zvcm1Qcm9wcy5pc1N1Ym1pdHRpbmd9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICBFZWdlYm5pcyB6ZWlnZW5cbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L0Zvcm0+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgIDwvRm9ybWlrPlxuICAgICAgICA8L0NhcmRCb2R5PlxuICAgICAgPC9DYXJkPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5jb25zdCBtYXBTdGF0ZVRvUHJvcHMgPSAoc3RhdGUpID0+IHtcbiAgcmV0dXJuIHtcbiAgICByZXN1bHQ6IHN0YXRlLnJlc3VsdC5yZXN1bHQsXG4gIH07XG59O1xuXG5jb25zdCBtYXBEaXNwYXRjaFRvUHJvcHMgPSAoZGlzcGF0Y2gpID0+IHtcbiAgcmV0dXJuIHtcbiAgICByZXN1bHRTZXREYXRhOiAoZGF0YSkgPT4gZGlzcGF0Y2goYWN0aW9ucy5yZXN1bHRTZXREYXRhKGRhdGEpKSxcbiAgICBvbkRlbGV0ZVJlc3VsdDogKGRhdGEsIGlkKSA9PiBkaXNwYXRjaChhY3Rpb25zLmRlbGV0ZVJlc3VsdChkYXRhLCBpZCkpLFxuICAgIG9uUG9zdFJlc3VsdERhdGE6IChkYXRhLCB1c2VyLCB0b2dnbGUpID0+XG4gICAgICBkaXNwYXRjaChhY3Rpb25zLnBvc3RSZXN1bHREYXRhKGRhdGEsIHVzZXIsIHRvZ2dsZSkpLFxuICAgIG9uVXBkYXRlUmVzdWx0RGF0YTogKGRhdGEsIHVzZXIsIHRvZ2dsZSkgPT5cbiAgICAgIGRpc3BhdGNoKGFjdGlvbnMudXBkYXRlUmVzdWx0RGF0YShkYXRhLCB1c2VyLCB0b2dnbGUpKSxcbiAgICByZXN1bHRFZGl0U2V0RGF0YTogKGRhdGEpID0+IGRpc3BhdGNoKGFjdGlvbnMucmVzdWx0RWRpdFNldERhdGEoZGF0YSkpLFxuICB9O1xufTtcbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QobWFwU3RhdGVUb1Byb3BzLCBtYXBEaXNwYXRjaFRvUHJvcHMpKEhvbWUpO1xuIiwiLy8gUmVzdWx0IGFjdGlvblR5cGVzXHJcblxyXG5leHBvcnQgY29uc3QgUkVTVUxUX0dFVF9EQVRBID0gXCJSRVNVTFRfR0VUX0RBVEFcIjtcclxuZXhwb3J0IGNvbnN0IFJFU1VMVF9TRVRfREFUQSA9IFwiUkVTVUxUX1NFVF9EQVRBXCI7XHJcbmV4cG9ydCBjb25zdCBSRVNVTFRfRkFJTF9EQVRBID0gXCJSRVNVTFRfRkFJTF9EQVRBXCI7XHJcbmV4cG9ydCBjb25zdCBERUxFVEVfUkVTVUxUX0ZBSUwgPSBcIkRFTEVURV9SRVNVTFRfRkFJTFwiO1xyXG5leHBvcnQgY29uc3QgUE9TVF9SRVNVTFRfREFUQSA9IFwiUE9TVF9SRVNVTFRfREFUQVwiO1xyXG5leHBvcnQgY29uc3QgUE9TVF9SRVNVTFRfREFUQV9TVEFSVCA9IFwiUE9TVF9SRVNVTFRfREFUQV9TVEFSVFwiO1xyXG5leHBvcnQgY29uc3QgUE9TVF9SRVNVTFRfREFUQV9GQUlMID0gXCJQT1NUX1JFU1VMVF9EQVRBX0ZBSUxcIjtcclxuZXhwb3J0IGNvbnN0IFBPU1RfUkVTVUxUX0RBVEFfU1VDQ0VTUyA9IFwiUE9TVF9SRVNVTFRfREFUQV9TVUNDRVNTXCI7XHJcblxyXG5leHBvcnQgY29uc3QgVVBEQVRFX1JFU1VMVF9EQVRBX1NUQVJUID0gXCJVUERBVEVfUkVTVUxUX0RBVEFfU1RBUlRcIjtcclxuZXhwb3J0IGNvbnN0IFJFU1VMVF9MT0FESU5HID0gXCJSRVNVTFRfTE9BRElOR1wiO1xyXG5leHBvcnQgY29uc3QgUkVTVUxUX0VESVRfU0VUX0RBVEEgPSBcIlJFU1VMVF9FRElUX1NFVF9EQVRBXCI7XHJcbmV4cG9ydCBjb25zdCBSRVNVTFRfRURJVF9GQUlMX0RBVEEgPSBcIlJFU1VMVF9FRElUX0ZBSUxfREFUQVwiO1xyXG4iLCJpbXBvcnQgKiBhcyBhY3Rpb25UeXBlIGZyb20gXCIuL0FjdGlvblR5cGVzXCI7XHJcbmltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IHN3YWwgZnJvbSBcInN3ZWV0YWxlcnRcIjtcclxuLy8gaW1wb3J0IHsgYmFzZVVybCB9IGZyb20gXCIuLi8uLi9zaGFyZWQvYmFzZVVybFwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IHJlc3VsdFNldERhdGEgPSAocmVzdWx0KSA9PiB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IGFjdGlvblR5cGUuUkVTVUxUX1NFVF9EQVRBLFxyXG4gICAgcmVzdWx0OiByZXN1bHQsXHJcbiAgfTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCByZXN1bHRGYWlsRGF0YSA9IChlcnJvcikgPT4ge1xyXG4gIHJldHVybiB7XHJcbiAgICB0eXBlOiBhY3Rpb25UeXBlLlJFU1VMVF9GQUlMX0RBVEEsXHJcbiAgICBlcnJvcjogZXJyb3IsXHJcbiAgfTtcclxufTtcclxuZXhwb3J0IGNvbnN0IHJlc3VsdExvYWRpbmcgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IGFjdGlvblR5cGUuUkVTVUxUX0xPQURJTkcsXHJcbiAgfTtcclxufTtcclxuZXhwb3J0IGNvbnN0IHJlc3VsdEdldERhdGEgPSAoZGF0YSkgPT4ge1xyXG4gIC8vIHJldHVybiAoZGlzcGF0Y2gpID0+IHtcclxuICAvLyAgIGRpc3BhdGNoKHJlc3VsdExvYWRpbmcoKSk7XHJcbiAgLy8gICBheGlvc1xyXG4gIC8vICAgICAuZ2V0KGJhc2VVcmwgKyBgcmVzdWx0LyR7ZGF0YT8uaWR9YCwge1xyXG4gIC8vICAgICAgIGhlYWRlcnM6IHtcclxuICAvLyAgICAgICAgIEFjY2VwdDogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgLy8gICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAvLyAgICAgICAgIEF1dGhvcml6YXRpb246IFwiQmVhcmVyIFwiICsgZGF0YS50b2tlbixcclxuICAvLyAgICAgICB9LFxyXG4gIC8vICAgICB9KVxyXG4gIC8vICAgICAudGhlbigocmVzKSA9PiB7XHJcbiAgLy8gICAgICAgZGlzcGF0Y2gocmVzdWx0U2V0RGF0YShyZXMuZGF0YSkpO1xyXG4gIC8vICAgICAgIGNvbnNvbGUubG9nKFwiZ3JhcGggZGF0YVwiLCByZXMuZGF0YSk7XHJcbiAgLy8gICAgIH0pXHJcbiAgLy8gICAgIC5jYXRjaCgoZXJyb3IpID0+IGRpc3BhdGNoKHJlc3VsdEZhaWxEYXRhKGVycm9yKSkpO1xyXG4gIC8vIH07XHJcbn07XHJcblxyXG4vLyBleHBvcnQgY29uc3QgdGVzdFJlcG9ydERhdGEgPSAoZGF0YSkgPT4ge1xyXG4vLyAgIHJldHVybiAoZGlzcGF0Y2gpID0+IHtcclxuLy8gICAgIGRpc3BhdGNoKHJlc3VsdExvYWRpbmcoKSk7XHJcbi8vICAgICBheGlvc1xyXG4vLyAgICAgICAuZ2V0KGJhc2VVcmwgKyBcImdldFRlbXBcIiwge1xyXG4vLyAgICAgICAgIGhlYWRlcnM6IHtcclxuLy8gICAgICAgICAgIEFjY2VwdDogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbi8vICAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuLy8gICAgICAgICAgIEF1dGhvcml6YXRpb246IFwiQmVhcmVyIFwiICsgZGF0YS50b2tlbixcclxuLy8gICAgICAgICB9LFxyXG4vLyAgICAgICB9KVxyXG4vLyAgICAgICAudGhlbigocmVzKSA9PiB7XHJcbi8vICAgICAgICAgZGlzcGF0Y2gocmVzdWx0RWRpdFNldERhdGEocmVzLmRhdGEpKTtcclxuXHJcbi8vICAgICAgICAgY29uc29sZS5sb2coXCJyZXNwb25zZSBkYXRhXCIsIHJlcy5kYXRhKTtcclxuLy8gICAgICAgfSlcclxuXHJcbi8vICAgICAgIC5jYXRjaCgoZXJyb3IpID0+IGRpc3BhdGNoKHJlc3VsdEVkaXRGYWlsRGF0YShlcnJvcikpKTtcclxuLy8gICB9O1xyXG4vLyB9O1xyXG5cclxuZXhwb3J0IGNvbnN0IHJlc3VsdEVkaXRTZXREYXRhID0gKG1haW5SZXN1bHQpID0+IHtcclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZS5SRVNVTFRfRURJVF9TRVRfREFUQSxcclxuICAgIG1haW5SZXN1bHQ6IG1haW5SZXN1bHQsXHJcbiAgfTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCByZXN1bHRFZGl0RmFpbERhdGEgPSAoZXJyb3IpID0+IHtcclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZS5SRVNVTFRfRURJVF9GQUlMX0RBVEEsXHJcbiAgICBlcnJvcjogZXJyb3IsXHJcbiAgfTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCByZXN1bHRFZGl0R2V0RGF0YSA9IChkYXRhKSA9PiB7XHJcbiAgLy8gcmV0dXJuIChkaXNwYXRjaCkgPT4ge1xyXG4gIC8vICAgZGlzcGF0Y2gocmVzdWx0TG9hZGluZygpKTtcclxuICAvLyAgIGF4aW9zXHJcbiAgLy8gICAgIC5nZXQoYmFzZVVybCArIGBnZXRUZW1wLyR7ZGF0YT8uaWR9YCwge1xyXG4gIC8vICAgICAgIGhlYWRlcnM6IHtcclxuICAvLyAgICAgICAgIEFjY2VwdDogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgLy8gICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAvLyAgICAgICAgIEF1dGhvcml6YXRpb246IFwiQmVhcmVyIFwiICsgZGF0YS50b2tlbixcclxuICAvLyAgICAgICB9LFxyXG4gIC8vICAgICB9KVxyXG4gIC8vICAgICAudGhlbigocmVzKSA9PiB7XHJcbiAgLy8gICAgICAgZGlzcGF0Y2gocmVzdWx0RWRpdFNldERhdGEocmVzLmRhdGEpKTtcclxuICAvLyAgICAgICBjb25zb2xlLmxvZyhcInJlc3BvbnNlIGRhdGFcIiwgcmVzLmRhdGEpO1xyXG4gIC8vICAgICB9KVxyXG4gIC8vICAgICAuY2F0Y2goKGVycm9yKSA9PiBkaXNwYXRjaChyZXN1bHRFZGl0RmFpbERhdGEoZXJyb3IpKSk7XHJcbiAgLy8gfTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBkZWxldGVSZXN1bHRGYWlsID0gKGVycm9yKSA9PiB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IGFjdGlvblR5cGUuREVMRVRFX1JFU1VMVF9GQUlMLFxyXG4gICAgZXJyb3I6IGVycm9yLFxyXG4gIH07XHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgZGVsZXRlUmVzdWx0ID0gKGRhdGEsIGlkKSA9PiB7XHJcbiAgLy8gcmV0dXJuIChkaXNwYXRjaCkgPT4ge1xyXG4gIC8vICAgaWYgKGlkKSB7XHJcbiAgLy8gICAgIGF4aW9zXHJcbiAgLy8gICAgICAgLmRlbGV0ZShiYXNlVXJsICsgYHJlc3VsdC8ke2lkfWAsIHtcclxuICAvLyAgICAgICAgIGhlYWRlcnM6IHtcclxuICAvLyAgICAgICAgICAgQWNjZXB0OiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAvLyAgICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgLy8gICAgICAgICAgIEF1dGhvcml6YXRpb246IFwiQmVhcmVyIFwiICsgZGF0YT8udG9rZW4sXHJcbiAgLy8gICAgICAgICB9LFxyXG4gIC8vICAgICAgIH0pXHJcbiAgLy8gICAgICAgLnRoZW4oKCkgPT4ge1xyXG4gIC8vICAgICAgICAgY29uc29sZS5sb2coXCJzd2FsXCIpO1xyXG4gIC8vICAgICAgICAgc3dhbChcIlN1Y2Nlc3NmdWxseSBEZWxldGVkICBSZXN1bHQhXCIpLnRoZW4oKCkgPT4ge1xyXG4gIC8vICAgICAgICAgICBkaXNwYXRjaChyZXN1bHRHZXREYXRhKGRhdGEpKTtcclxuICAvLyAgICAgICAgIH0pO1xyXG4gIC8vICAgICAgIH0pXHJcbiAgLy8gICAgICAgLmNhdGNoKChlcnJvcikgPT4gZGlzcGF0Y2goZGVsZXRlUmVzdWx0RmFpbChlcnJvcikpKTtcclxuICAvLyAgIH1cclxuICAvLyB9O1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IHBvc3RSZXN1bHREYXRhU3RhcnQgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IGFjdGlvblR5cGUuUE9TVF9SRVNVTFRfREFUQV9TVEFSVCxcclxuICB9O1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IHBvc3RSZXN1bHREYXRhRmFpbCA9IChlcnJvcikgPT4ge1xyXG4gIHJldHVybiB7XHJcbiAgICB0eXBlOiBhY3Rpb25UeXBlLlBPU1RfUkVTVUxUX0RBVEFfRkFJTCxcclxuICAgIGVycm9yOiBlcnJvcixcclxuICB9O1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IHBvc3RSZXN1bHREYXRhID0gKGRhdGEsIHVzZXIsIHRvZ2dsZSkgPT4ge1xyXG4gIC8vIHJldHVybiAoZGlzcGF0Y2gpID0+IHtcclxuICAvLyAgIGRpc3BhdGNoKHBvc3RSZXN1bHREYXRhU3RhcnQoKSk7XHJcbiAgLy8gICBheGlvc1xyXG4gIC8vICAgICAucG9zdChiYXNlVXJsICsgXCJyZXN1bHRcIiwgdXNlciwge1xyXG4gIC8vICAgICAgIGhlYWRlcnM6IHtcclxuICAvLyAgICAgICAgIEFjY2VwdDogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgLy8gICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAvLyAgICAgICAgIEF1dGhvcml6YXRpb246IFwiQmVhcmVyIFwiICsgZGF0YT8udG9rZW4sXHJcbiAgLy8gICAgICAgfSxcclxuICAvLyAgICAgfSlcclxuICAvLyAgICAgLnRoZW4oKCkgPT4ge1xyXG4gIC8vICAgICAgIGNvbnNvbGUubG9nKFwic3dhbFwiKTtcclxuICAvLyAgICAgICBzd2FsKFwiU3VjY2Vzc2Z1bGx5IENyZWF0ZWQgIFJlc3VsdCFcIikudGhlbigoKSA9PiB7XHJcbiAgLy8gICAgICAgICBkaXNwYXRjaChyZXN1bHRHZXREYXRhKGRhdGEpKTtcclxuICAvLyAgICAgICAgIHRvZ2dsZSgpO1xyXG4gIC8vICAgICAgIH0pO1xyXG4gIC8vICAgICB9KVxyXG4gIC8vICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XHJcbiAgLy8gICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gIC8vICAgICAgIGRpc3BhdGNoKHBvc3RSZXN1bHREYXRhRmFpbChlcnJvcikpO1xyXG4gIC8vICAgICB9KTtcclxuICAvLyB9O1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IHVwZGF0ZVJlc3VsdERhdGFTdGFydCA9ICgpID0+IHtcclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZS5VUERBVEVfUkVTVUxUX0RBVEFfU1RBUlQsXHJcbiAgfTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCB1cGRhdGVSZXN1bHREYXRhID0gKGRhdGEsIHVzZXIsIHRvZ2dsZSkgPT4ge1xyXG4gIC8vIHJldHVybiAoZGlzcGF0Y2gpID0+IHtcclxuICAvLyAgIGRpc3BhdGNoKHVwZGF0ZVJlc3VsdERhdGFTdGFydCgpKTtcclxuICAvLyAgIGF4aW9zXHJcbiAgLy8gICAgIC5wb3N0KGJhc2VVcmwgKyBgcmVzdWx0LyR7ZGF0YS5pZH0/X21ldGhvZD1QVVRgLCB1c2VyLCB7XHJcbiAgLy8gICAgICAgaGVhZGVyczoge1xyXG4gIC8vICAgICAgICAgQWNjZXB0OiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAvLyAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxyXG4gIC8vICAgICAgICAgQXV0aG9yaXphdGlvbjogXCJCZWFyZXIgXCIgKyBkYXRhLnRva2VuLFxyXG4gIC8vICAgICAgIH0sXHJcbiAgLy8gICAgIH0pXHJcbiAgLy8gICAgIC50aGVuKCgpID0+IHtcclxuICAvLyAgICAgICBjb25zb2xlLmxvZyhcInN3YWxcIik7XHJcbiAgLy8gICAgICAgc3dhbChcIlN1Y2Nlc3NmdWxseSBVcGRhdGVkICBSZXN1bHQhXCIpLnRoZW4oKCkgPT4ge1xyXG4gIC8vICAgICAgICAgdG9nZ2xlKCk7XHJcbiAgLy8gICAgICAgICBkaXNwYXRjaChyZXN1bHRHZXREYXRhKGRhdGEpKTtcclxuICAvLyAgICAgICB9KTtcclxuICAvLyAgICAgfSlcclxuICAvLyAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xyXG4gIC8vICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAvLyAgICAgfSk7XHJcbiAgLy8gfTtcclxufTtcclxuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiYXhpb3NcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiZm9ybWlrXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvaGVhZFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC1yZWR1eFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC1yb3V0ZXJcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0c3RyYXBcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic3dlZXRhbGVydFwiKTsiXSwibmFtZXMiOlsiYXhpb3MiLCJGaWVsZCIsIkZpZWxkQXJyYXkiLCJGb3JtaWsiLCJIZWFkIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJCdXR0b24iLCJDYXJkIiwiQ2FyZEJvZHkiLCJDYXJkSGVhZGVyIiwiQ2FyZFN1YnRpdGxlIiwiQ2FyZFRleHQiLCJDYXJkVGl0bGUiLCJDb2wiLCJGb3JtIiwiRm9ybUdyb3VwIiwiSW5wdXRHcm91cCIsIlJvdyIsImRhdGEiLCJvcHRpb25zIiwiY29ubmVjdCIsImFjdGlvbnMiLCJ1c2VIaXN0b3J5IiwicmVzdWx0IiwiQXJyYXkiLCJNYWluUmVzdWx0IiwiSG9tZSIsInByb3BzIiwidmFsdWUiLCJzZXRWYWx1ZSIsImhpc3RvcnkiLCJjb21wYW55Iiwic2V0Q29tcGFueSIsIkNEVSIsIlNQRCIsIkFmRCIsIkZEUCIsIkdyw7xuZSIsIkxpbmtlIiwic2V0Q0RVIiwic2V0U1BEIiwic2V0QWZEIiwic2V0RkRQIiwic2V0R3LDvG5lIiwic2V0TGlua2UiLCJjb25zb2xlIiwibG9nIiwiZ3JhcGhEYXRhIiwicmVzdWx0RWRpdFNldERhdGEiLCJkYXRhTGVuZ3RoIiwibGVuZ3RoIiwiYW5zd2VyIiwidmFsdWVzIiwic2V0U3VibWl0dGluZyIsInJlc3VsdExlbmd0aCIsInIiLCJkIiwicXVlc3Rpb25faWQiLCJpZCIsIkFGRCIsImhhbmRsZVN1Ym1pdCIsIm1hcCIsIlNjaGxhZ3dvcnQiLCJxdWVzdGlvbl90ZXh0IiwiYXJyYXlIZWxwZXJzIiwib3B0Iiwib3B0aW9uX1ZhbHVlIiwiaSIsInNwbGljZSIsInJlc3VsdFNldERhdGEiLCJwdXNoIiwib3B0aW9uX3RleHQiLCJtYXBTdGF0ZVRvUHJvcHMiLCJzdGF0ZSIsIm1hcERpc3BhdGNoVG9Qcm9wcyIsImRpc3BhdGNoIiwib25EZWxldGVSZXN1bHQiLCJkZWxldGVSZXN1bHQiLCJvblBvc3RSZXN1bHREYXRhIiwidXNlciIsInRvZ2dsZSIsInBvc3RSZXN1bHREYXRhIiwib25VcGRhdGVSZXN1bHREYXRhIiwidXBkYXRlUmVzdWx0RGF0YSIsIlJFU1VMVF9HRVRfREFUQSIsIlJFU1VMVF9TRVRfREFUQSIsIlJFU1VMVF9GQUlMX0RBVEEiLCJERUxFVEVfUkVTVUxUX0ZBSUwiLCJQT1NUX1JFU1VMVF9EQVRBIiwiUE9TVF9SRVNVTFRfREFUQV9TVEFSVCIsIlBPU1RfUkVTVUxUX0RBVEFfRkFJTCIsIlBPU1RfUkVTVUxUX0RBVEFfU1VDQ0VTUyIsIlVQREFURV9SRVNVTFRfREFUQV9TVEFSVCIsIlJFU1VMVF9MT0FESU5HIiwiUkVTVUxUX0VESVRfU0VUX0RBVEEiLCJSRVNVTFRfRURJVF9GQUlMX0RBVEEiLCJhY3Rpb25UeXBlIiwic3dhbCIsInR5cGUiLCJyZXN1bHRGYWlsRGF0YSIsImVycm9yIiwicmVzdWx0TG9hZGluZyIsInJlc3VsdEdldERhdGEiLCJtYWluUmVzdWx0IiwicmVzdWx0RWRpdEZhaWxEYXRhIiwicmVzdWx0RWRpdEdldERhdGEiLCJkZWxldGVSZXN1bHRGYWlsIiwicG9zdFJlc3VsdERhdGFTdGFydCIsInBvc3RSZXN1bHREYXRhRmFpbCIsInVwZGF0ZVJlc3VsdERhdGFTdGFydCJdLCJzb3VyY2VSb290IjoiIn0=